"""Data model for extracted tables. Raw text is never altered; interpretation lives elsewhere."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional

ENGINE_VERSION = "tables-1.0"


@dataclass
class Header:
    name: str                      # final column name (parent / child joined)
    parent: str = ""               # upper header level text, if any
    leaf: str = ""                 # lowest header level text
    original: list = field(default_factory=list)   # raw header pieces as found in the PDF
    flags: list = field(default_factory=list)      # e.g. "ambiguous header"
    renamed_from: str = ""         # set when the user renames (original wording kept)


@dataclass
class Row:
    page: int
    orig: list                     # original layout (blank where the PDF merges cells)
    norm: list                     # normalized (merged values repeated)
    flags: list = field(default_factory=list)          # row-level review flags
    cell_flags: dict = field(default_factory=dict)     # col index -> [flag,...]
    bbox: Optional[tuple] = None   # (x0, top, x1, bottom) on `page`
    pages: list = field(default_factory=list)          # all pages the row touches
    group: str = ""                # group-label band the row sits under (e.g. SUBSTATION)
    anchor: str = ""               # value of the row-number column (e.g. Sr.)


@dataclass
class Table:
    title: str = ""
    section: str = ""              # heading the table sits under
    section_level: int = 0
    page_from: int = 0
    page_to: int = 0
    headers: list = field(default_factory=list)        # list[Header]
    rows: list = field(default_factory=list)           # list[Row]
    method: str = ""
    quality: float = 0.0
    quality_notes: list = field(default_factory=list)
    col_edges: list = field(default_factory=list)
    page_bboxes: dict = field(default_factory=dict)    # page -> bbox
    has_groups: bool = False
    anchor_col: Optional[int] = None
    stats: dict = field(default_factory=dict)
    source: str = ""               # file path
    engine_version: str = ENGINE_VERSION

    @property
    def column_names(self):
        return [h.name for h in self.headers]

    def flagged_rows(self):
        return [r for r in self.rows if r.flags or r.cell_flags]

    def to_dict(self):
        d = asdict(self)
        return d

    def summary(self):
        return {"title": self.title, "section": self.section, "pages": f"{self.page_from}-{self.page_to}",
                "columns": len(self.headers), "rows": len(self.rows), "method": self.method,
                "quality": round(self.quality, 2), "review_rows": len(self.flagged_rows())}
