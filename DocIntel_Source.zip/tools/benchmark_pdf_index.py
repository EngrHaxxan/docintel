"""Reproducible PDF indexing benchmark (python tools/benchmark_pdf_index.py [daily_copies] [invoice_pdfs]) -> JSON.
Corpus: copies of the real daily report, the SCAL and RACI PDFs (from tests/real_pdfs) + one-page generated invoices."""
import json, os, shutil, sys, tempfile, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from docintel.library import Library
from docintel import search as S


def main(n_daily=60, n_inv=100):
    tmp = tempfile.mkdtemp(); root = os.path.join(tmp, "src"); os.makedirs(root)
    rp = os.path.join(os.path.dirname(__file__), "..", "tests", "real_pdfs")
    for i in range(n_daily):
        shutil.copy(os.path.join(rp, "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf"), os.path.join(root, f"daily_{i:03d}.pdf"))
    shutil.copy(os.path.join(rp, "WI-NG-6460-001-001_SCAL_Rev03.pdf"), root); shutil.copy(os.path.join(rp, "RACI_Matrix_UGC_Submittals.pdf"), root)
    from reportlab.pdfgen import canvas
    for i in range(n_inv):
        c = canvas.Canvas(os.path.join(root, f"inv_{i:04d}.pdf")); c.drawString(72, 700, f"Invoice No: INV-{i:05d}"); c.drawString(72, 680, "Total: 1,000.00 " + "word " * 120); c.save()
    lib = Library(os.path.join(tmp, "home")); lib.add_root(root)
    rep = {"files": n_daily + n_inv + 2, "workers": lib.cfg["workers"]}
    t = time.time(); lib.scan(); rep["scan_s"] = round(time.time() - t, 2)
    t = time.time(); st = lib.index(); rep["index_s"] = round(time.time() - t, 2); rep["indexed"], rep["errors"] = st["indexed"], st["errors"]
    t = time.time(); h = S.search(lib.db, "INV-00042", "text", limit=50); rep["search_ms"] = round((time.time() - t) * 1000); rep["search_hits"] = len(h)
    t = time.time(); lib.scan(); rep["rescan_unchanged_s"] = round(time.time() - t, 2)
    t = time.time(); lib.index(); rep["reindex_unchanged_s"] = round(time.time() - t, 2)
    rep["ocr_pages"] = lib.db.one("SELECT COUNT(*) n FROM segments WHERE kind='ocr'")["n"]
    rep["pages_indexed"] = lib.db.one("SELECT COUNT(*) n FROM segments")["n"]
    rep["tables_legacy"] = lib.db.one("SELECT COUNT(*) n FROM tables_")["n"]
    shutil.rmtree(tmp, ignore_errors=True)
    print(json.dumps(rep))


if __name__ == "__main__":
    main(*[int(a) for a in sys.argv[1:3]])
