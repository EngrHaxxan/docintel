"""AI-assisted extraction in bulk (Milestone 9). A local model reads the TEXT of each document (native text or OCR text) and returns the values
of the fields you named (one record per document) or the rows of a table you described (many rows per document).
Nothing the model says is trusted blindly: every value must be found in the text of the document, otherwise the cell is flagged for review.
Results are stored as ordinary tables (method ai-fields / ai-rows), so search, review, corrections and Excel export work like for any table."""
from __future__ import annotations
import json, re, time, unicodedata
from ..tables.office import table_from_rows
from ..tables import store
from .provider import ProviderError

SYS_FIELDS = ("EXTRACT FIELDS. You extract values from document text. Reply with ONLY one JSON object, no other text: "
              '{"<field name>": {"value": "<text copied exactly from the document>", "page": <page number>}} or null for a field the document does not contain. '
              "Copy values exactly as written (keep %, units, codes, punctuation, Arabic text). Never guess, calculate, translate or reformat.")
SYS_ROWS = ("EXTRACT ROWS. You extract the rows of a table from document text. Reply with ONLY one JSON object, no other text: "
            '{"rows": [{"page": <page number>, "values": {"<column name>": "<text copied exactly from the document>"}}]}. '
            "One entry per table row, in reading order. Use an empty string for an empty cell. Copy values exactly as written. Never guess, calculate, translate or reformat.")


# ---------------------------------------------------------------- helpers
def norm(s):
    s = unicodedata.normalize("NFKC", str(s))
    s = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]", "", s)
    return re.sub(r"\s+", " ", s).strip().casefold()


def squeeze(s):
    return re.sub(r"\s+", "", norm(s))


def parse_json(text):
    """The first JSON object in a model answer (models like to add words or code fences around it)."""
    t = re.sub(r"```(?:json)?", "", text or "")
    a = t.find("{")
    while a != -1:
        depth = 0
        for i in range(a, len(t)):
            depth += (t[i] == "{") - (t[i] == "}")
            if depth == 0:
                try:
                    return json.loads(t[a:i + 1])
                except ValueError:
                    break
        a = t.find("{", a + 1)
    raise ProviderError("The model did not return a usable answer (no JSON). Try again, or choose a stronger model.")


def document_pages(db, file_id):
    """[(page number, text)] from the index (native text or OCR text)."""
    out = []
    for i, r in enumerate(db.q("SELECT loc, text FROM segments WHERE file_id=? ORDER BY id", (file_id,)), 1):
        m = re.match(r"p(\d+)$", r["loc"] or "")
        out.append((int(m.group(1)) if m else i, r["text"] or ""))
    return out


def choose_pages(pages, labels, budget, whole=False):
    """Fields: only the pages that mention the field names (+ the first page) so a 40-page report fits the model; rows: all pages in order."""
    if whole:
        return pages
    words = {w for l in labels for w in re.findall(r"\w{3,}", norm(l))}
    scored = sorted(pages, key=lambda p: (-sum(1 for w in words if w in norm(p[1])), p[0]))
    chosen, used = {}, 0
    for n, t in ([pages[0]] if pages else []) + scored:
        if n in chosen:
            continue
        if used + len(t) > budget and chosen:
            continue
        chosen[n] = t; used += len(t)
    return [(n, chosen[n]) for n in sorted(chosen)]


def windows(pages, budget):
    cur, size = [], 0
    for n, t in pages:
        if cur and size + len(t) > budget:
            yield cur; cur, size = [], 0
        cur.append((n, t[:budget])); size += min(len(t), budget)
    if cur:
        yield cur


def doc_text(pages):
    return "\n".join(f"[PAGE {n}]\n{t}" for n, t in pages)


def ask_json(provider, system, user, max_tokens=1800):
    try:
        return parse_json(provider.complete(system, user, max_tokens=max_tokens))
    except ProviderError as e:
        if "usable answer" not in str(e):
            raise
        return parse_json(provider.complete(system, user + "\n\nReturn ONLY valid JSON.", max_tokens=max_tokens))


def find_page(value, texts, claimed=None):
    """Page where the value really occurs (the claimed page first), else None."""
    v, vs = norm(value), squeeze(value)
    if not v:
        return None
    order = ([claimed] if claimed in texts else []) + [n for n in texts if n != claimed]
    for n in order:
        if v in norm(texts[n]) or (len(vs) >= 3 and vs in squeeze(texts[n])):
            return n
    return None


# ---------------------------------------------------------------- one document
def extract_fields(provider, pages, fields, instructions="", budget=12000):
    """-> {field: (value, page or None, verified)}"""
    use = choose_pages(pages, fields, budget)
    user = f"FIELDS: {', '.join(fields)}\nINSTRUCTIONS: {instructions or 'none'}\n\nDOCUMENT TEXT:\n{doc_text(use)}"
    ans = ask_json(provider, SYS_FIELDS, user)
    texts = dict(pages)
    out = {}
    for f in fields:
        a = ans.get(f)
        if isinstance(a, dict):
            v, pg = str(a.get("value", "") if a.get("value") is not None else "").strip(), a.get("page")
        elif a is None or a == "":
            v, pg = "", None
        else:
            v, pg = str(a).strip(), None
        if not v:
            out[f] = ("", None, True)                       # "not present" is a legitimate answer: nothing to verify
            continue
        pg_ok = find_page(v, texts, pg if isinstance(pg, int) else None)
        out[f] = (v, pg_ok, pg_ok is not None)
    return out


def extract_rows(provider, pages, columns, instructions="", budget=12000):
    """-> [(values dict, page, {col: verified})]"""
    texts, out = dict(pages), []
    for win in windows(pages, budget):
        user = f"COLUMNS: {', '.join(columns)}\nINSTRUCTIONS: {instructions or 'none'}\n\nDOCUMENT TEXT:\n{doc_text(win)}"
        ans = ask_json(provider, SYS_ROWS, user, max_tokens=3000)
        for r in ans.get("rows", []) if isinstance(ans.get("rows"), list) else []:
            vals = r.get("values", {}) if isinstance(r, dict) else {}
            ver, row = {}, {}
            page = r.get("page") if isinstance(r.get("page"), int) else None
            for c in columns:
                v = str(vals.get(c, "") if vals.get(c) is not None else "").strip()
                row[c] = v
                ver[c] = (not v) or find_page(v, texts, page) is not None
            if any(row.values()):
                out.append((row, page, ver))
    return out


def build_table(model_name, mode, columns, items, file_path, title):
    """items: fields -> [(row dict, page, verified map)] ; returns a Table (cells that were not found in the text are flagged for review)."""
    hdr = list(columns) + ["Source page"]
    rows, flags = [hdr], []
    for row, page, ver in items:
        rows.append([row[c] for c in columns] + [str(page) if page else ""]); flags.append([c for c in columns if not ver[c] and row[c]])
    t = table_from_rows(rows, title=title, section="AI extraction", page=1, method="ai-" + mode, source=file_path, header=True)
    if t is None:                                          # fewer than two columns/rows: build the one-row table by hand
        from ..tables.model import Table, Header, Row
        t = Table(title=title, section="AI extraction", page_from=1, page_to=1, headers=[Header(name=h, leaf=h, original=[h]) for h in hdr],
                  rows=[Row(page=1, orig=list(r), norm=list(r)) for r in rows[1:]], method="ai-" + mode, quality=0.5, source=file_path)
    total = sum(1 for row, _, _ in items for c in columns if row[c])
    bad = sum(len(f) for f in flags)
    for r, bad_cols in zip(t.rows, flags):
        for c in bad_cols:
            r.cell_flags[list(columns).index(c)] = ["review: AI value not found in the document text"]
        pg = next((int(x) for x in [r.orig[-1]] if str(x).isdigit()), None)
        if pg:
            r.page = pg
    t.quality = round(0.5 + 0.4 * ((total - bad) / total if total else 1.0), 2)
    t.quality_notes = [f"extracted by the AI model '{model_name}'; every value was checked against the document text" + (f" - {bad} of {total} value(s) NOT found: please review" if bad else " - all values found")]
    t.stats = {"ai_model": model_name, "values": total, "unverified": bad}
    t.engine_version = "ai"
    return t, total, bad


def save_ai_table(db, file_id, table):
    from ..tables.store import save_analysis
    from ..tables.engine import Analysis
    db.x("DELETE FROM doc_tables WHERE file_id=? AND method LIKE 'ai-%' AND title=?", (file_id, table.title))
    return save_analysis(db, file_id, Analysis(table.source, 1, [], [table], [], [], 0.0), replace=False)[0]


# ---------------------------------------------------------------- bulk
class AIExtractor:
    """Runs the extraction on many documents as a job (listed with the other jobs: summary, report, export, retry)."""
    def __init__(self, lib, provider=None):
        from ..batch import BatchRunner
        self.lib, self.db = lib, lib.db
        self.provider = provider or lib.ai_models().provider()
        self.br = BatchRunner(lib)

    @staticmethod
    def title(mode, columns):
        return ("AI fields: " if mode == "fields" else "AI table: ") + ", ".join(columns)

    def create_job(self, columns, instructions="", mode="fields", root_ids=None, file_ids=None):
        prof = {"name": self.title(mode, columns), "description": "AI-assisted extraction", "ai": {"mode": mode, "columns": list(columns), "instructions": instructions,
                                                                                            "title": self.title(mode, columns), "model": self.provider.name}}
        return self.br.create_job(prof, root_ids=root_ids, file_ids=file_ids, title=prof["name"])

    def run(self, columns, instructions="", mode="fields", root_ids=None, file_ids=None, control=None, progress=None):
        jid = self.create_job(columns, instructions, mode, root_ids, file_ids)
        self.run_job(jid, control, progress)
        return jid

    def run_job(self, job_id, control=None, progress=None):
        if not self.provider.available():
            raise ProviderError("No AI model is connected. Connect one under AI tools > Connect or switch AI model.")
        prof = self.br.job_profile(job_id); ai = prof["ai"]
        reg = self.lib.ai_models(); m = reg.get(reg.active_name()) or {}
        budget = int(m.get("context_chars") or 12000)
        items = self.db.q("SELECT * FROM job_items WHERE job_id=? AND status='pending' ORDER BY id", (job_id,))
        for i, it in enumerate(items):
            if control is not None:
                control.wait_if_paused()
                if control.cancelled:
                    break
            try:
                self._one(it, ai, budget)
            except Exception as e:
                import logging
                logging.getLogger("docintel").exception("ai extraction failed: %s", it["path"])
                msg = str(e) if isinstance(e, ProviderError) else "This document could not be processed. You can retry it later."
                self.br._set(it["id"], status="failed", message=msg, detail=f"{type(e).__name__}: {e}")
            if progress:
                progress(i + 1, len(items), it["name"])
        left = self.db.one("SELECT COUNT(*) n FROM job_items WHERE job_id=? AND status='pending'", (job_id,))["n"]
        self.db.x("UPDATE extraction_jobs SET status=?, finished=?, stats_json=? WHERE id=?", ("cancelled" if left else "done", time.time(), json.dumps(self.br.summary(job_id)), job_id))
        return self.br.summary(job_id)

    def _one(self, it, ai, budget):
        pages = document_pages(self.db, it["file_id"])
        if not any(t.strip() for _, t in pages):
            return self.br._set(it["id"], status="no_tables", message="The document has no readable text (not indexed yet, or a scan without OCR text).")
        cols = ai["columns"]
        if ai["mode"] == "fields":
            res = extract_fields(self.provider, pages, cols, ai["instructions"], budget)
            row = {c: res[c][0] for c in cols}
            ver = {c: res[c][2] for c in cols}
            pgs = sorted({p for _, p, _ in res.values() if p})
            items = [(row, pgs[0] if pgs else None, ver)] if any(v.strip() for v in row.values()) else []
        else:
            items = extract_rows(self.provider, pages, cols, ai["instructions"], budget)
        if not items:
            return self.br._set(it["id"], status="section_not_found", message="The model found nothing matching your description in this document.")
        t, total, bad = build_table(self.provider.name, ai["mode"], cols, items, it["path"], ai["title"])
        tid = save_ai_table(self.db, it["file_id"], t)
        self.br._set(it["id"], status="partial" if bad else "processed", message=(f"{bad} of {total} value(s) not found in the document text: review them" if bad else ""),
                     tables=1, records=len(t.rows), review_rows=sum(1 for r in t.rows if r.cell_flags), table_ids_json=json.dumps([tid]))

    def retry(self, job_id, control=None, progress=None):
        self.db.x("UPDATE job_items SET status='pending', message=NULL, detail=NULL WHERE job_id=? AND status IN ('failed','partial','no_tables','section_not_found')", (job_id,))
        return self.run_job(job_id, control, progress)

    def add_new_documents(self, job_id, control=None, progress=None):
        scope = json.loads(self.db.one("SELECT scope_json FROM extraction_jobs WHERE id=?", (job_id,))["scope_json"])
        known = {r["file_id"] for r in self.db.q("SELECT file_id FROM job_items WHERE job_id=?", (job_id,))}
        new = [r for r in self.br.scope_files(scope) if r["id"] not in known]
        self.br._add_items(job_id, new)
        s = self.run_job(job_id, control, progress); s["new_documents"] = len(new)
        return s

    def entries(self, job_id):
        from ..wizard import Entry
        ai = self.br.job_profile(job_id)["ai"]; out = []
        for it in self.br.items(job_id, ("processed", "partial")):
            for t in store.list_tables(self.db, it["file_id"]):
                if str(t["method"]).startswith("ai-"):
                    tb = store.load_table(self.db, t["id"])
                    if tb.title == ai["title"]:
                        out.append(Entry(it["name"], it["path"], tb, t["id"], it["file_id"]))
        return out
