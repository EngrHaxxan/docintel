# Test report - DocIntel 1.0.0 (Windows release candidate)

**Read this first: nothing in this report was run on Windows.** The Windows installer and portable package do not exist yet. Everything below ran on a Linux sandbox
(Python 3.12, 1 CPU, 4 GB RAM). Linux results show the *program logic and packaging approach* work; they do **not** prove Windows compatibility. The Windows pipeline
(`WINDOWS_BUILD_GUIDE.md`) is written to produce that proof automatically; its verdict will appear in `BUILD_RESULT.txt`.

## 1. Required scenarios (A-F): status
| Scenario | Windows status | Linux evidence this round |
|---|---|---|
| A Fresh install, no Python needed, OCR found, launch | **PENDING (CI step "Install / run / uninstall check")** | frozen app (PyInstaller, no Python on PATH needed) ran self-check and GUI start: 16/16 |
| B Multi-folder index, search identifier, restart persistence | PENDING (CI smoke) | 3 roots, nested folders, OCR identifier found with path, Arabic search, index persisted: pass |
| C Extract, review, export new + template, formulas/formatting/provenance | PENDING (CI smoke) | pass (formulas kept and extended, formats kept, Provenance sheet) |
| D Offline | PENDING (CI step with Windows Firewall rules) | whole smoke run inside an empty network namespace: 17/17 |
| E Portable in another folder, data stays beside app | PENDING (CI portable step) | unzipped into `/tmp/Portable Test Dir/DocIntel` (spaces): 17/17, data in `DocIntel_Data` |
| F Interrupt/resume, inaccessible dir, disconnected drive | PENDING (CI; ACL test is Windows-only) | killed mid-batch then resumed (1,500 files all indexed); unplugged-drive: flagged, data stays searchable |

## 2. What was actually run (Linux)
* **Automated suite: 43 passed, 4 skipped, 0 failed** (`pytest tests`). Skipped: unreadable-directory test (needs non-root) and 3 Windows-only tests
  (long paths, case-insensitive roots, locked files) - these run on the Windows build server. New this round: spaces/Unicode in folder, file, data and OCR-data paths;
  portable data-folder rules; Excel template safety (charts block the write, original untouched); plain-English errors; field-name helper; GUI first-run/smoke.
* **Packaged-app smoke harness** (`tools/smoke_packaged.py`) against the PyInstaller build: installed-style 16/16, portable 17/17, portable + no network 17/17.
* **Release script** (`tools/make_release.py`) executed on Linux with the real Windows Tesseract layout (unpacked from the pinned official installer): app, portable zip,
  offline-resources zip and checksums produced; the Windows-only steps (running `tesseract.exe`, Inno Setup) were skipped.
* GUI driven headlessly (Xvfb): start page, first-run welcome, drag-and-drop library loads (an actual drop was not exercised).

## 3. Arabic / English OCR (corrected result)
My first report said Arabic OCR was poor. That was caused by a wrongly generated test image. Re-tested with correctly shaped Arabic + English text through the application's own OCR
pipeline (5 lines, mean similarity to the known text):
| Condition | clean | 3-degree skew | 0.4x resolution | blur | heavy speckle noise | JPEG quality 18 | combined (skew+downscale+blur+JPEG) |
|---|---|---|---|---|---|---|---|
| Score | 1.00 | 1.00 | 1.00 | 1.00 | 0.29 -> **0.9+ after the new denoise retry** (one word wrong) | 1.00 | 1.00 |
Caveats: synthetic text in one font; real scans, stamps, handwriting and other Arabic fonts are untested. Numbers inside Arabic lines can come out in reversed digit-group order (e.g. 2026-03-14 read as 14-03-2026); the review queue flags ambiguous dates.
`tessdata_best` was no better than `tessdata_fast` on this test, so the smaller fast files are shipped.

## 4. Other measurements carried forward (Linux, earlier build; not repeated on Windows)
40-row page-spanning invoice table 200/200 cells exact; OCR identifier 4/4; 5,540 files indexed in 31 s on 1 CPU, peak 338 MB; exact search 17 ms.

## 5. Status of the limitations you listed
| Item | Status |
|---|---|
| Windows exe/installer built and verified | **Not yet.** Pipeline ready; awaits the first Windows run. |
| Arabic OCR weak | Corrected (see 3); real-world scans still untested. Denoise retry + deskew added. |
| Semantic search | **Not implemented** (needs an embedding model; would add ~100 MB+ and risk; left out rather than faked). |
| Natural-language extraction | **Not implemented.** A deterministic helper turns typed field names into fields ("Describe fields I want"); it does not understand sentences. |
| Native DWG | **Not implemented** (proprietary format; export to DXF/PDF). DXF and PDF drawings work. |
| Drag-and-drop folders | Implemented (tkinterdnd2); loads under test; a real drop is untested; falls back to the Add button. |
| Real engineering drawings | **Not tested** (only synthetic DXF/PDF title blocks). |
| Scale beyond 5,540 files | **Not tested.** |
| Filesystem monitoring | Implemented, **still no automated test**. |
| Legacy/OpenDocument formats | ODT/ODS checked by hand once (worked; ODS adds one empty column); ODP, RTF, legacy DOC/PPT/XLS untested. |
| Excel writer loses charts/images/pivots | **Mitigated**: such templates are now refused unless the user picks a results-only workbook or explicitly accepts the loss; original is never changed. Macros (.xlsm) are kept but never executed; not tested with real macro workbooks. |

## 6. Remaining verification steps (cannot be done by me)
1. Run the Windows build (click steps in the guide) and read `BUILD_RESULT.txt`.
2. On a *different, clean* Windows 11 PC (not the build server): install, run the guide's first-run steps, and try a few of your real documents (especially Arabic scans and your Excel templates).
3. Report anything odd with a screenshot; the log is at Settings & Diagnostics > Show log.


---
# Milestone 1 addendum - table & section engine (v1.1.0-m1)
**Run on Linux only (Python 3.12/3.x, 1 CPU). Not run on Windows yet - pending GitHub Actions.**
- `python -m unittest tests.test_tables_engine`: 19 tests, all pass (real daily report: Construction 4 rows / Issues 3 rows exact; real SCAL: 1,000/1,000 sequential rows over pages 5-40, headers, reference rows 1/15/202/999, rows split by page breaks (11, 179), merged-cell original vs normalized, row 1000 horizontal merge, source quirks incl. invisible Arabic mark, running header excluded; synthetic: special values/percent/codes/Unicode+Arabic text, multi-page repeated header, merged cells, two tables on a page, borderless; Excel export text-exact).
- `python tools/table_accuracy.py`: 102 hand-verified cells correct, 0 wrong, 0 missing, 0 extra rows.
- Existing suite (`tests/test_docintel.py`, `tests/test_release_readiness.py`) was NOT run in this sandbox (pytest could not be installed offline). The old modules were not modified except `cli.py` (new `tables` command) and `__init__.py` (version), so CI must confirm.
- Measured time (Linux, 1 CPU): SCAL 41 pages = ~16 s total analysis (all tables); daily report 2 pages = 0.3 s.


---
# Milestone 2 addendum - stored tables, value model, Excel options (v1.2.0-m2)
**Run on Linux only; Windows pending.**
- `python -m unittest tests.test_tables_store` = 17 tests pass (values, database round-trip equals engine output, reuse of unchanged files / forced re-extraction, unsupported + missing file messages, corrections keep the original, header rename + hidden columns, cascade delete, schema upgrade v1->v2, typed/raw Excel, combined sheets, row-limit rollover, leaf headers, old normaliser `percentage`/`auto`).
- `tests.test_tables_engine` (Milestone 1) still 19/19 pass.
- Measured (SCAL table 1,000 rows x 13 cols, Linux 1 CPU): save to database 0.10 s, load 0.06 s, Excel export (Original+Normalized sheets) 0.39 s raw / 0.96 s typed, peak process memory ~102 MB. Output opens in LibreOffice (Excel itself not available here).
- Smoke test: scan + index + `extract_tables` on a library folder works with the old indexing code.


---
# Milestone 3 addendum - guided interface (v1.3.0-m3)
**Linux only. Tkinter is NOT installed in the Linux sandbox, so the real window has not been drawn or clicked by me. The Windows run is the first real GUI test.**
- `tests.test_wizard` 15 pass (selection/exclusion, headings and similar-heading candidates, section across documents with missing-section notes, selected fields incl. not-found column left blank and flagged, free-text request, honest "nothing matched", matching records, corrections persisted with original kept, uncertain marks, rename/hide, export arrangements xlsx/per-document/CSV/history record, stacking by default for same columns, individual file outside library, text mode, unreadable file message).
- `tools/gui_stub_check.py` passes: every Home action and all five wizard steps for all seven modes, preview edit/mark/rename/hide, export, review and history windows, run against a stand-in for Tkinter. This catches Python-level mistakes only - not layout, fonts, sizes or real widget behaviour.
- `tests.test_tables_engine` 19 + `tests.test_tables_store` 17 still pass. Existing pytest suite still unrun here (no pytest) - CI runs it, including the updated tab count (11) and the new `home_ok` / `wizard_ok` smoke fields.


---
# Update 1.3.1-m3 (after Windows build 9)
Linux only. 57 tests pass (`tests.test_tables_engine` 19, `tests.test_tables_store` 23, `tests.test_wizard` 15) + `tools/gui_stub_check.py`. `tools/table_accuracy.py`: 102/102 cells correct, SCAL 1,000 rows. New real-PDF check: RACI matrix 134/134 rows sequential over pages 2-6, R/A in exactly one department column per row, remarks and group headings present. Not yet run on Windows.


# Update 1.4.0-m4 (tested on Linux only; Windows build pending)
- tests/test_batch.py: 10 tests pass (profiles round trip, continue after a broken PDF and an unsupported file, similar heading needs confirmation, confirm + export with Job report sheet, stacked single sheet, retry + add-new-only, cancel/resume, fields/header-name/request profiles, profile from wizard has no page numbers, real SCAL (1000 rows) / RACI (134 rows) found by column names only).
- Full set run here with unittest: 66 tests OK (test_docintel.py and test_release_readiness.py need pytest: run by the Windows workflow). tools/gui_stub_check.py OK (fake Tkinter, not a real window).
- Measured (Linux, 1 CPU): 100 daily reports, first batch 35.6 s (~0.36 s per report); a second saved extraction on the same reports 0.3 s (tables already stored); add-new with nothing new 0.00 s; export of 400 rows 0.4 s.


# Update 1.5.0-m5 (tested on Linux only; Windows build pending)
- tests/test_performance.py: 6 tests pass (fast index searchable, words on demand + cached, process pool result identical to threads, broken PDF reported not crashing the pool, incremental = only new files, speed presets, engine table cells searchable). Full unittest set here: 74 pass; the 2 pytest-only files run on Windows. test_docintel.py::test_native_pdf_text_and_positions was adapted (word boxes are now on demand).
- Measured (Linux, 1 CPU, 2 workers): 32 files / 87 pages: 82 s with the old reader, 0.81 s now. 162 files / 267 pages: 1.74 s (old reader did not finish in 300 s). Re-index of unchanged files 0.0 s. Search 1 ms.
- Not measured: Windows, multi-core speed-up of the process pool (sandbox has 1 CPU), scanned/OCR folders, Arabic PDFs on the fast path, 1,500-document libraries.


# Update 1.6.0-m6 (tested on Linux only; Windows build pending)
- tests/test_office_tables.py (5 tests, pass): docx/xlsx/csv/html/pptx tables, merged cells original vs normalized, percent and leading zeros kept, batch by Word section, search, job report.
- tests/test_scanned_tables.py: English scanned table (image-only PDF) read with OCR: 20 of 20 cells exact at 200 dpi and at 150 dpi (clean synthetic scans only). Arabic scanned-table test is SYNTHETIC and skipped here (no Arabic OCR data / reshaping libraries in the sandbox); it runs on Windows only if those libraries are installed. NO real Arabic or real scan has been tested.
- Full set here: 82 pass (pytest-only files not run). tools/gui_stub_check.py OK.


# Update 1.6.1-m6 (real scanned PDFs; tested on Linux only, Windows build pending)
- English BoQ scan (Annexure_4_NIT_BOQ, 2 pages, 154 dpi source): one table across both pages, header `Sr No | Service Code | Description | UOM | Qty | Rate | Amount` found, items 1-10 as separate rows with description joined to its item; item 11 read as `li` (OCR), sub-total lines kept. 32/32 spot words exact (after line erasing; 12/32 before). 12-13 s for 2 pages.
- Pricing schedule scan (C_PA_4400023707, first 3 of 27 pages, ~6.5 s/page): values read correctly (e.g. A.SS.2.1.1 | Breakdown | Main Substation | PHASE I | 1 | LT | 2,000,000.00). KNOWN LIMIT: the table is split in two at the first bold group row and the first table's header row is read as a data row (OCR cannot see bold/grey group bands). Not fixed yet.
- Medical form scan: runs, no failures (not a grid table, nothing useful expected). Arabic BoQ scan: NOT tested here (no Arabic OCR data in the sandbox); a test that only checks "runs and finds a table" runs on Windows.
- Suite here: 80 + scanned tests pass; pytest-only files not run.


# Update 1.6.2-m6 (tested on Linux only, English OCR; Windows build pending)
- Real English scans, after the fixes: BoQ (2 p): header found, items 1-10 as one record each with description joined (11 read as 'li'), 3 summary rows. Pricing schedule (first 3 p): ONE table p1-3, 131 rows (120 unique item numbers), 3 sub-total rows kept separate, no title/header rows leaked. Tests assert these (tolerant).
- Arabic BoQ scan: structure only checked with English OCR (no Arabic data here): pages 1-2 gave no table, pages 3-4 fragments. NOT FIXED. Suspected causes (unverified): dotted separator lines are not detected as ruling lines, mirrored (right-to-left) column order, Tesseract on stretched italic Arabic.
- Medical form (1 p): one 16x6 table with 'Column N' headers (the yes/no grid), not useful yet.
- Known leftovers: OCR header typo 'TOM' for 'UOM', '11' read as 'li'; no section headings from scans (selection by column names works).
- Suite: 80 + scanned tests pass here.
