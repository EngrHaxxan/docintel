"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.5.0-m5"
