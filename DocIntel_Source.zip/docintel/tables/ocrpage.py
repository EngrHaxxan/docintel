"""Scanned pages: OCR word boxes become a PageData, so the same table logic (alignment based) can read tables from scans."""
from __future__ import annotations
import collections
from .geometry import PageData


def _line_runs(dark, minlen, gap=2):
    """Horizontal runs of dark pixels (gaps up to `gap` pixels are bridged) that are at least `minlen` long: (row, start, end)."""
    import numpy as np
    out = []
    for r in range(dark.shape[0]):
        row = dark[r]
        if row.sum() < minlen:
            continue
        idx = np.flatnonzero(row)
        br = np.flatnonzero(np.diff(idx) > gap + 1)
        st, en = idx[np.r_[0, br + 1]], idx[np.r_[br, len(idx) - 1]]
        for a, b in zip(st, en):
            if b - a + 1 >= minlen:
                out.append((r, int(a), int(b)))
    return out


def _group(runs, tol=2):
    """Thick lines span several pixel rows: merge neighbouring runs that overlap into one stroke (centre, start, end)."""
    done, open_ = [], []
    for pos, a, b in runs:
        hit = None
        for o in open_:
            if pos - o["last"] <= tol and min(b, o["e"]) - max(a, o["s"]) >= 0.5 * min(b - a, o["e"] - o["s"]):
                hit = o; break
        if hit:
            hit["sum"] += pos; hit["n"] += 1; hit["last"] = pos; hit["s"] = min(hit["s"], a); hit["e"] = max(hit["e"], b)
        else:
            open_.append({"sum": pos, "n": 1, "last": pos, "s": a, "e": b})
        still = []
        for o in open_:
            (still if pos - o["last"] <= tol else done).append(o)
        open_ = still
    done += open_
    return [(o["sum"] / o["n"], o["s"], o["e"]) for o in done]


def erase_lines(g, hs, vs):
    """White-out the ruling lines (pixel coordinates) so that they do not touch the letters during OCR."""
    from PIL import ImageDraw
    g = g.convert("L").copy()
    d = ImageDraw.Draw(g)
    t = max(2, round(g.width / 600))
    for y, x0, x1 in hs:
        d.rectangle([x0, y - t, x1, y + t], fill=255)
    for x, y0, y1 in vs:
        d.rectangle([x - t, y0, x + t, y1], fill=255)
    return g


def detect_lines(g, sx=1.0, sy=1.0, work=1600):
    """Ruling lines of a scanned page (numpy + Pillow only): -> (hs, vs) in PDF points (pixels when sx = sy = 1), same format as vector strokes."""
    import numpy as np
    from PIL import Image
    w0, h0 = g.size
    f = max(1, round(max(w0, h0) / work))
    a = np.asarray(g.convert("L").resize((max(1, w0 // f), max(1, h0 // f)), Image.BOX))
    dark = a < 150
    hr = _group(_line_runs(dark, max(60, int(0.10 * dark.shape[1])), gap=1))
    vr = _group(_line_runs(np.ascontiguousarray(dark.T), max(30, int(0.025 * dark.shape[0])), gap=2))
    hs = [(y * f * sy, x0 * f * sx, x1 * f * sx) for y, x0, x1 in hr]
    vs = [(x * f * sx, y0 * f * sy, y1 * f * sy) for x, y0, y1 in vr]
    return hs, vs


_NOISE = set("|_[]\\/")


def ocr_pagedata(path, page_no, width, height, engine, dpi=300):
    """-> (PageData or None, note). Renders the page, runs OCR, maps word boxes back to PDF points."""
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(path)
    try:
        img = doc[page_no - 1].render(scale=dpi / 72.0).to_pil()
    finally:
        doc.close()
    store = {}

    def pre(g):
        try:
            hs_px, vs_px = detect_lines(g)
            store["px"] = (hs_px, vs_px)
            return erase_lines(g, hs_px, vs_px)
        except Exception:
            return g
    text, conf, words, (iw, ih) = engine.run(img, pre=pre)
    if not words:
        return None, "no text was recognised on this scanned page"
    if abs(iw / ih - width / height) > 0.08 * (width / height):
        return None, "the scanned page is rotated in a way that could not be matched to the page; try another scan"
    sx, sy = width / iw, height / ih
    ws = []
    for t, x0, y0, x1, y1, c in words:
        tt = str(t).strip()
        if tt and not (set(tt) <= _NOISE) and not (len(tt) > 2 and set(tt) <= set("-_=~.\u2014")):          # ruling lines read as characters
            
            ws.append({"text": t, "x0": x0 * sx, "x1": x1 * sx, "top": y0 * sy, "bottom": y1 * sy, "size": max(4.0, (y1 - y0) * sy),
                       "bold": False, "fontname": "ocr", "ocr_conf": c})
    # OCR box heights are noisy (a tall letter or a descender changes them): a word only counts as "bigger text" (heading candidate)
    # when it is much bigger (1.8x) than the typical word; everything else gets the typical size. OCR cannot tell bold from normal text.
    hts = sorted(w["size"] for w in ws)
    body = round(hts[len(hts) // 2], 1) if hts else 0.0
    for w in ws:
        if w["size"] <= 1.8 * body:
            w["size"] = body
    hs_px, vs_px = store.get("px", ([], []))
    hs = [(y * sy, a * sx, b * sx) for y, a, b in hs_px]
    vs = [(x * sx, a * sy, b * sy) for x, a, b in vs_px]
    pd = PageData(page_no, float(width), float(height), ws, [], hs, vs, [], body)
    pd.ocr, pd.ocr_conf = True, float(conf)
    return pd, ""
