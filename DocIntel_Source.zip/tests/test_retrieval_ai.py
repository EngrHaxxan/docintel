"""Milestone 7: structured retrieval with citations + the (disabled by default) AI layer with consent gate."""
import json, os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from docintel.library import Library
from docintel.retrieval import Retriever, parse_filter, build_pack
from docintel.llm.provider import NoProvider, CallableProvider, ProviderUnavailable, provider_from_config
from docintel.llm.assistant import Assistant, ConsentRequired, ProviderBlocked
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_office_tables as OT
DAILY = os.path.join(HERE, "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "s"); os.makedirs(self.src)
        shutil.copy(DAILY, os.path.join(self.src, "daily_01.pdf")); shutil.copy(DAILY, os.path.join(self.src, "daily_02.pdf")); OT.build(self.src)
        self.lib = Library(os.path.join(self.tmp, "h")); self.lib.cfg.set("workers", 1)
        self.lib.add_root(self.src); self.lib.scan(); self.lib.index(); self.lib.extract_tables()
        self.R = Retriever(self.lib)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


class Retrieval(Base):
    def test_filters_parse(self):
        self.assertEqual(parse_filter("Urgency=High"), ("Urgency", "=", "High"))
        self.assertEqual(parse_filter("Qty>=10"), ("Qty", ">=", "10"))
        with self.assertRaises(ValueError):
            parse_filter("nonsense")

    def test_records_have_citations(self):
        recs = self.R.find_records(filters=["Urgency=High"], section="Issues", ext="pdf")
        self.assertEqual(len(recs), 6)                                              # 3 issues in each of 2 reports (the Word file has one more)
        r = recs[0]; c = r.citation()
        self.assertTrue(c["file"].startswith("daily_") and c["page"] == 2 and c["row"] >= 1 and c["table"])
        self.assertIn("page 2", r.cite_text()); self.assertEqual(r.cells["Urgency"], "High")

    def test_query_scope_and_numeric_filter(self):
        self.assertEqual(len(self.R.find_records("Backfilling", ext="pdf")), 2)       # one construction row in each of the 2 reports
        self.assertEqual({r.file for r in self.R.find_records("Backfilling", ext="docx")}, {"report.docx"})
        hi = self.R.find_records(filters=["Done>70"], ext="xlsx")                     # 65% / 90% in the workbook
        self.assertEqual([r.cells["Task"] for r in hi], ["Fencing"])
        self.assertEqual(self.R.find_records("zzzz-not-there"), [])

    def test_corrections_are_used(self):
        r = self.R.find_records("Compaction", ext="docx")[0]
        self.lib.db.x("UPDATE table_cells SET corrected_orig='Compaction (checked)', corrected_norm='Compaction (checked)' WHERE raw_orig='Compaction'")
        self.assertIn("checked", self.R.find_records("checked", ext="docx")[0].text())

    def test_catalog_and_text_search(self):
        self.assertTrue(any("Issue" in c["headers"] or "Issue Type" in c["headers"] for c in self.R.catalog(section="Issues")))
        self.assertTrue(self.R.search_text("Construction"))

    def test_cli_records(self):
        from docintel import cli
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cli.main(["--home", os.path.join(self.tmp, "h"), "records", "--filter", "Urgency=High", "--section", "Issues", "--ext", "pdf", "--json"])
        data = json.loads(buf.getvalue())
        self.assertEqual(len(data), 6); self.assertEqual(data[0]["source"]["page"], 2); self.assertEqual(data[0]["cells"]["Urgency"], "High")


class Assistance(Base):
    def test_default_is_off(self):
        self.assertFalse(self.lib.ai_available()); self.assertIsInstance(provider_from_config(self.lib.cfg), NoProvider)
        a = self.lib.assistant(); pack, prev = a.prepare("Which issues are open?", section="Issues")
        with self.assertRaises(ProviderUnavailable):
            a.ask("Which issues are open?", pack, prev)
        self.assertEqual(self.lib.db.one("SELECT COUNT(*) n FROM llm_audit")["n"], 0)            # nothing sent

    def test_pack_is_only_selected_records_numbered(self):
        recs = self.R.find_records(filters=["Urgency=High"], section="Issues", ext="pdf")
        pack = build_pack("q", recs, max_records=4)
        self.assertEqual([i.id for i in pack.items], ["E1", "E2", "E3", "E4"]); self.assertTrue(pack.truncated)
        self.assertIn("[E1] (daily_01.pdf", pack.prompt()); self.assertNotIn("Impact", json.dumps(pack.manifest()))   # manifest has no cell text

    def test_local_provider_answer_with_citations_and_checks(self):
        seen = {}
        def fn(system, user):
            seen["user"] = user; return "Three issues are open [E1] [E2] [E3] and one more [E99]."
        a = Assistant(self.lib, CallableProvider(fn, "test-local", "local"))
        pack, prev = a.prepare("Which issues are open?", filters=["Status=Open"], section="Issues")
        self.assertFalse(prev["leaves_computer"])
        ans = a.ask("Which issues are open?", pack, prev)
        self.assertEqual([e.id for e in ans.cited], ["E1", "E2", "E3"]); self.assertTrue(any("E99" in w for w in ans.warnings))
        self.assertIn("UGC", seen["user"]); self.assertEqual(self.lib.db.one("SELECT kind FROM llm_audit")["kind"], "local")
        a2 = Assistant(self.lib, CallableProvider(lambda s, u: "They are all fine.", "t", "local"))
        self.assertTrue(any("does not refer" in w for w in a2.ask("q", pack, prev).warnings))

    def test_remote_needs_switch_and_confirmation_of_this_content(self):
        calls = []
        a = Assistant(self.lib, CallableProvider(lambda s, u: calls.append(u) or "Open: UGC [E1]", "remote-x", "remote"))
        pack, prev = a.prepare("open issues?", filters=["Status=Open"], section="Issues")
        self.assertTrue(prev["leaves_computer"]); self.assertGreater(prev["records"], 0)
        with self.assertRaises(ProviderBlocked):                                        # offline mode is the default
            a.ask("open issues?", pack, prev, consent=prev["token"])
        self.lib.cfg.set("offline_mode", False); self.lib.cfg.set("allow_network", True)
        with self.assertRaises(ConsentRequired) as cm:
            a.ask("open issues?", pack, prev)                                           # no confirmation
        self.assertEqual(cm.exception.preview["records"], prev["records"])
        with self.assertRaises(ConsentRequired):
            a.ask("open issues?", pack, prev, consent="wrong")
        self.assertEqual(calls, [])                                                     # nothing was sent before the user confirmed
        ans = a.ask("open issues?", pack, prev, consent=prev["token"])
        self.assertEqual(len(calls), 1); self.assertEqual(ans.cited[0].id, "E1")
        self.assertEqual(self.lib.db.one("SELECT consent FROM llm_audit")["consent"], prev["token"])

    def test_no_matching_records_sends_nothing(self):
        calls = []
        a = Assistant(self.lib, CallableProvider(lambda s, u: calls.append(u) or "x", "t", "local"))
        pack, prev = a.prepare("zzzz-nothing-here")
        ans = a.ask("zzzz-nothing-here", pack, prev)
        self.assertEqual(calls, []); self.assertIn("Not found", ans.text)


if __name__ == "__main__":
    unittest.main()
