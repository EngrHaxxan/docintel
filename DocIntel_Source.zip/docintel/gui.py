"""DocIntel desktop GUI (Tkinter/ttk - ships with Python, so PyInstaller builds need no extra GUI runtime).
All heavy work runs on background threads; the UI polls a queue, so it stays responsive during large jobs."""
import json, os, queue, subprocess, sys, threading, time, traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, scrolledtext

from . import __version__
from .library import Library, JobControl
from . import search as S, extraction as E, excel_export as XL, compare as C, diagnostics as D, drawings, preview as P
from . import paths, friendly
from . import extractors as XT

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    _Base = TkinterDnD.Tk
except Exception:          # drag-and-drop is optional; the Add folder button always works
    TkinterDnD = DND_FILES = None
    _Base = tk.Tk


def open_path(p):
    if os.name == "nt": os.startfile(p)
    elif sys.platform == "darwin": subprocess.Popen(["open", p])
    else: subprocess.Popen(["xdg-open", p])


class Tree(ttk.Frame):
    """Treeview with scrollbars and simple sortable columns."""
    def __init__(self, master, columns, widths=None, height=12, **kw):
        super().__init__(master)
        self.tv = ttk.Treeview(self, columns=columns, show="headings", height=height, **kw)
        for i, c in enumerate(columns):
            self.tv.heading(c, text=c, command=lambda c=c: self.sort(c))
            self.tv.column(c, width=(widths or {}).get(c, 120), anchor="w")
        sy = ttk.Scrollbar(self, orient="vertical", command=self.tv.yview); sx = ttk.Scrollbar(self, orient="horizontal", command=self.tv.xview)
        self.tv.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.tv.grid(row=0, column=0, sticky="nsew"); sy.grid(row=0, column=1, sticky="ns"); sx.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1); self.columnconfigure(0, weight=1)
    def clear(self): self.tv.delete(*self.tv.get_children())
    def add(self, values, iid=None, tags=()): return self.tv.insert("", "end", iid=iid, values=values, tags=tags)
    def selected(self): return self.tv.selection()
    def sort(self, col):
        items = [(self.tv.set(k, col), k) for k in self.tv.get_children("")]
        try: items.sort(key=lambda t: float(t[0]))
        except ValueError: items.sort(key=lambda t: t[0].lower())
        for i, (_, k) in enumerate(items): self.tv.move(k, "", i)


class App(_Base):
    def __init__(self, home=None, smoke=None):
        super().__init__()
        self.dnd_ok = False
        try:
            self.iconbitmap(os.path.join(paths.resource_dir(), "assets", "icon.ico")) if os.name == "nt" else None
        except Exception:
            pass
        self.title(f"DocIntel {__version__} - offline document intelligence")
        self.geometry("1280x820"); self.minsize(1000, 650)
        self.lib = Library(home)
        if self.lib.cfg["offline_mode"]: D.enforce_offline()
        self.q = queue.Queue(); self.control = JobControl(); self.job_thread = None; self.monitor = None
        self.run_id = None; self.preview_img = None
        style = ttk.Style(self)
        try: style.theme_use("vista" if os.name == "nt" else "clam")
        except tk.TclError: pass
        style.configure("Treeview", rowheight=24); style.configure("TButton", padding=4)
        self._build_status()
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True, padx=6, pady=(6, 0))
        self.tabs = {}
        for name, fn in [("Start here", self.tab_start), ("Dashboard", self.tab_dashboard), ("Sources", self.tab_sources), ("Search", self.tab_search),
                         ("Extract", self.tab_extract), ("Review", self.tab_review), ("Tables", self.tab_tables),
                         ("Compare", self.tab_compare), ("Export", self.tab_export), ("Settings & Diagnostics", self.tab_settings)]:
            f = ttk.Frame(self.nb, padding=8); self.nb.add(f, text=name); self.tabs[name] = f; fn(f)
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.refresh_all())
        self._build_menu(); self._enable_dnd()
        self.after(150, self.poll); self.refresh_all()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if smoke:
            self.after(300, lambda: self._smoke(smoke))
        elif not self.lib.cfg.get("first_run_done"):
            self.after(400, self.first_run)

    # ---------------------------------------------------------------- infrastructure
    def _build_status(self):
        bar = ttk.Frame(self); bar.pack(side="bottom", fill="x", padx=6, pady=4)
        self.status = tk.StringVar(value="Ready"); ttk.Label(bar, textvariable=self.status).pack(side="left")
        self.prog = ttk.Progressbar(bar, length=220, mode="determinate"); self.prog.pack(side="right")
        self.btn_cancel = ttk.Button(bar, text="Cancel", command=self.control.cancel, state="disabled"); self.btn_cancel.pack(side="right", padx=3)
        self.btn_pause = ttk.Button(bar, text="Pause", command=self.toggle_pause, state="disabled"); self.btn_pause.pack(side="right", padx=3)

    def toggle_pause(self):
        if self.control.paused: self.control.resume(); self.btn_pause.config(text="Pause"); self.status.set("Resumed")
        else: self.control.pause(); self.btn_pause.config(text="Resume"); self.status.set("Paused (current files finish first)")

    def run_bg(self, label, fn, done=None):
        if self.job_thread and self.job_thread.is_alive():
            messagebox.showinfo("Busy", "Another job is running. Wait, pause, or cancel it first."); return
        self.control = JobControl(); self.btn_cancel.config(command=self.control.cancel, state="normal"); self.btn_pause.config(state="normal", text="Pause")
        self.status.set(label + " ..."); self.prog.config(mode="indeterminate"); self.prog.start(12)
        def work():
            try: res = fn(self.control)
            except Exception as e:
                self.q.put(("error", friendly.explain(e, label), traceback.format_exc())); return
            self.q.put(("done", label, res, done))
        self.job_thread = threading.Thread(target=work, daemon=True); self.job_thread.start()

    def progress_cb(self, kind, *rest):
        self.q.put(("progress", kind, rest))

    def poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "progress":
                    kind, rest = m[1], m[2]
                    if kind == "index":
                        st = rest[1]
                        self.prog.stop(); self.prog.config(mode="determinate", maximum=max(1, st["total"]), value=st["done"])
                        self.status.set(f"Indexing {st['done']}/{st['total']}  (errors {st['errors']}, unsupported {st['unsupported']})")
                    elif kind == "scan": self.status.set(f"Scanning {rest[0]}: {rest[1]['new']} new, {rest[1]['changed']} changed ...")
                elif m[0] == "done":
                    self.prog.stop(); self.prog.config(mode="determinate", value=0); self.btn_cancel.config(state="disabled"); self.btn_pause.config(state="disabled")
                    self.status.set(f"{m[1]}: finished" + (" (cancelled)" if self.control.cancelled else ""))
                    if m[3]: m[3](m[2])
                    self.refresh_all()
                elif m[0] == "error":
                    self.prog.stop(); self.btn_cancel.config(state="disabled"); self.btn_pause.config(state="disabled")
                    self.status.set(m[1][0]); messagebox.showerror(m[1][0], m[1][1])
        except queue.Empty: pass
        self.after(150, self.poll)

    def refresh_all(self):
        for fn in (self.refresh_dashboard, self.refresh_sources, self.refresh_runs, self.refresh_start):
            try: fn()
            except Exception: pass

    def on_close(self):
        if self.monitor: self.monitor.stop()
        self.control.cancel(); self.destroy()

    # ---------------------------------------------------------------- start page, menu, first run, drag-and-drop
    def _build_menu(self):
        m = tk.Menu(self); h = tk.Menu(m, tearoff=0)
        h.add_command(label="Getting started...", command=self.first_run)
        h.add_command(label="Run self-check", command=self.show_selfcheck)
        h.add_command(label="Open data folder", command=lambda: open_path(self.lib.cfg.home))
        h.add_separator(); h.add_command(label="About DocIntel", command=lambda: messagebox.showinfo("About", f"DocIntel {__version__}\nOffline document search and Excel extraction.\nData folder: {self.lib.cfg.home}"))
        m.add_cascade(label="Help", menu=h); self.config(menu=m)

    def _enable_dnd(self):
        if not DND_FILES: return
        try:
            for w in (self.src_tree.tv, self.start_drop):
                w.drop_target_register(DND_FILES); w.dnd_bind("<<Drop>>", self.on_drop)
            self.dnd_ok = True
        except Exception:
            self.dnd_ok = False

    def on_drop(self, ev):
        items = [p for p in self.tk.splitlist(ev.data)]
        self.add_paths([p if os.path.isdir(p) else os.path.dirname(p) for p in items])

    def add_paths(self, plist):
        added, problems = 0, []
        for p in plist:
            try: self.lib.add_root(p); added += 1
            except ValueError as e:
                msg = str(e)
                problems.append(("That folder is already in DocIntel: " if "already" in msg else "Could not add: ") + p)
        self.refresh_all()
        if problems: messagebox.showinfo("Folders", "\n".join(problems))
        if added and messagebox.askyesno("Index now?", f"{added} folder(s) added. Read and index the documents now?\n(You can keep using DocIntel while it works.)"):
            self.update_all()

    def tab_start(self, f):
        ttk.Label(f, text="Welcome to DocIntel", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(f, text="Find information in your documents and send it to Excel - everything stays on this computer.", font=("Segoe UI", 11)).pack(anchor="w", pady=(0, 10))
        self.health = tk.StringVar(); self.health_lbl = ttk.Label(f, textvariable=self.health, font=("Segoe UI", 10)); self.health_lbl.pack(anchor="w", pady=4)
        steps = [("1.  Add your folders", "Choose the folders (or drives) that hold your documents. You can add as many as you like.", self.add_folder),
                 ("2.  Read my documents", "DocIntel reads every file once so searching is instant. Scanned pages are read with OCR. This can take a while the first time.", self.update_all),
                 ("3.  Search", "Look for a name, number or phrase across all folders at once.", lambda: self.nb.select(self.tabs["Search"])),
                 ("4.  Pull data into Excel", "Pick what you want (dates, amounts, tables...), check anything uncertain, then export.", lambda: self.nb.select(self.tabs["Extract"]))]
        for t, d, c in steps:
            row = ttk.Frame(f); row.pack(fill="x", pady=5)
            ttk.Button(row, text=t, command=c, width=28).pack(side="left", padx=(0, 12))
            ttk.Label(row, text=d, wraplength=800, justify="left").pack(side="left")
        self.start_drop = tk.Label(f, text="Tip: you can also drag folders from Windows Explorer and drop them here." if DND_FILES else "Tip: use the 'Add your folders' button to choose folders.", bg="#eef3f8", relief="groove", height=3)
        self.start_drop.pack(fill="x", pady=14)
        self.start_summary = tk.StringVar(); ttk.Label(f, textvariable=self.start_summary).pack(anchor="w")

    def refresh_start(self):
        probs = self.env_problems()
        if probs:
            self.health.set("Attention: " + " ".join(probs)); self.health_lbl.config(foreground="#b00020")
        else:
            self.health.set("Everything needed is installed and ready (offline reading of PDFs, scans and Office files)."); self.health_lbl.config(foreground="#1b6e2e")
        t = self.lib.dashboard()["totals"]
        self.start_summary.set(f"Documents ready for search: {t.get('indexed', 0)}    waiting: {t.get('pending', 0)}    could not be read: {t.get('error', 0) + t.get('unsupported', 0)}")

    def env_problems(self):
        out = []
        try:
            o = XT.OCR(self.lib.cfg); langs = o.available_langs()
            if not langs: out.append("The OCR component (for scanned pages and images) was not found, so scans cannot be read. Re-install DocIntel or see Help > Run self-check.")
            else:
                if "eng" not in langs: out.append("English OCR data is missing.")
                if "ara" not in langs: out.append("Arabic OCR data is missing (Arabic scans won't be read; digital Arabic text still works).")
        except Exception:
            out.append("The OCR component could not be started, so scans cannot be read.")
        if not paths.writable(self.lib.cfg.home): out.append(f"DocIntel cannot write to its data folder ({self.lib.cfg.home}).")
        return out

    def show_selfcheck(self):
        self.nb.select(self.tabs["Settings & Diagnostics"]); self.run_doctor()

    def first_run(self):
        w = tk.Toplevel(self); w.title("Welcome to DocIntel"); w.transient(self); w.geometry("640x520")
        ttk.Label(w, text="Welcome to DocIntel", font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        probs = self.env_problems()
        chk = ("Checked your computer: everything DocIntel needs is present." if not probs else "Checked your computer - please note:\n- " + "\n- ".join(probs))
        ttk.Label(w, text=chk, wraplength=600, foreground=("#1b6e2e" if not probs else "#b00020")).pack(anchor="w", padx=16, pady=6)
        txt = ("How it works (4 steps):\n\n  1. Add folders - click \"Add folder\" (or drag folders in) for every place your documents are kept.\n"
               "  2. Read my documents - DocIntel reads each file once and remembers it. Nothing is changed or deleted.\n"
               "  3. Search - type a word, a number or a drawing/invoice number; results show the file and the page.\n"
               "  4. Extract to Excel - choose the items you need, check anything marked for review, then export. Your Excel files are never overwritten unless you say so.\n\n"
               "DocIntel works fully offline and never sends your documents anywhere.")
        ttk.Label(w, text=txt, wraplength=600, justify="left").pack(anchor="w", padx=16, pady=8)
        def add_now():
            while True:
                p = filedialog.askdirectory(parent=w, title="Choose a folder with documents")
                if not p: break
                self.add_paths_quiet([p])
                if not messagebox.askyesno("Add another?", "Folder added. Add another folder?", parent=w): break
            self.refresh_all()
        def done():
            self.lib.cfg.set("first_run_done", True); w.destroy()
            if self.lib.roots() and messagebox.askyesno("Start reading", "Read the documents in your folders now?"): self.update_all()
        ttk.Button(w, text="Add my folders now...", command=add_now).pack(pady=6)
        ttk.Button(w, text="Finish", command=done).pack(pady=2)
        w.protocol("WM_DELETE_WINDOW", done)

    def add_paths_quiet(self, plist):
        for p in plist:
            try: self.lib.add_root(p)
            except ValueError: pass

    def _smoke(self, out_json):
        """Used by the automated Windows tests: opens the real GUI, checks it, writes a JSON report, exits."""
        rep = {"tabs": len(self.nb.tabs()), "version": __version__, "data_dir": self.lib.cfg.home, "dnd": self.dnd_ok,
               "problems": self.env_problems(), "doctor_ok": D.doctor(self.lib)["ok"], "portable": paths.is_portable(), "frozen": paths.frozen()}
        json.dump(rep, open(out_json, "w"), indent=1); self.destroy()

    # ---------------------------------------------------------------- dashboard
    def tab_dashboard(self, f):
        self.dash_txt = tk.StringVar(); ttk.Label(f, textvariable=self.dash_txt, font=("Segoe UI", 11), justify="left").pack(anchor="w")
        self.dash_tree = Tree(f, ("Source", "Path", "State", "Indexed", "Pending", "Errors", "Unsupported", "Missing", "Last scan"),
                              {"Path": 330, "Source": 150, "Last scan": 140}, height=10)
        self.dash_tree.pack(fill="both", expand=True, pady=8)
        ttk.Label(f, text="Recent jobs").pack(anchor="w")
        self.job_tree = Tree(f, ("Id", "Kind", "Status", "Started", "Result"), {"Result": 520}, height=6); self.job_tree.pack(fill="both", expand=True)

    def refresh_dashboard(self):
        d = self.lib.dashboard(); t = d["totals"]
        self.dash_txt.set(f"Files indexed: {t.get('indexed', 0)}    pending: {t.get('pending', 0)}    errors: {t.get('error', 0)}    unsupported: {t.get('unsupported', 0)}"
                          f"    missing: {t.get('missing', 0)}\nSearchable segments: {d['segments']}    stored tables: {d['tables']}    index size: {d['db_mb']} MB    "
                          f"mode: {'OFFLINE (network blocked)' if self.lib.cfg['offline_mode'] else 'online allowed'}")
        self.dash_tree.clear()
        for r in d["roots"]:
            s = r["files"]; ls = time.strftime("%Y-%m-%d %H:%M", time.localtime(r["last_scan"])) if r["last_scan"] else "never"
            state = ("enabled" if r["enabled"] else "disabled") + ("" if r["available"] else " - UNAVAILABLE")
            self.dash_tree.add((r["name"], r["path"], state, s.get("indexed", 0), s.get("pending", 0), s.get("error", 0), s.get("unsupported", 0), s.get("missing", 0), ls))
        self.job_tree.clear()
        for j in self.lib.db.q("SELECT * FROM jobs ORDER BY id DESC LIMIT 12"):
            self.job_tree.add((j["id"], j["kind"], j["status"], time.strftime("%m-%d %H:%M", time.localtime(j["started"])), (j["stats"] or "")[:200]))

    # ---------------------------------------------------------------- sources
    def tab_sources(self, f):
        bar = ttk.Frame(f); bar.pack(fill="x")
        for text, cmd in [("Add folder...", self.add_folder), ("Add several (paste paths)...", self.add_many), ("Remove from index", self.remove_root),
                          ("Enable/Disable", self.toggle_root), ("Filters...", self.edit_filters)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=2)
        bar2 = ttk.Frame(f); bar2.pack(fill="x", pady=4)
        for text, cmd in [("Update all (scan + index)", self.update_all), ("Update selected", self.update_selected), ("Full rescan selected", lambda: self.update_selected(True)),
                          ("Index pending", self.index_pending), ("Retry failed", self.retry_failed)]:
            ttk.Button(bar2, text=text, command=cmd).pack(side="left", padx=2)
        self.mon_var = tk.BooleanVar(); ttk.Checkbutton(bar2, text="Watch folders for changes", variable=self.mon_var, command=self.toggle_monitor).pack(side="left", padx=12)
        self.src_tree = Tree(f, ("Id", "Name", "Path", "Enabled", "Available", "Ext filter", "Exclude", "Files"), {"Path": 380, "Id": 40, "Name": 140}, height=14)
        self.src_tree.pack(fill="both", expand=True)
        ttk.Label(f, text="Removing a source only removes it from the index; your files are never touched. Unavailable drives keep their indexed data (not treated as deleted).",
                  foreground="#555").pack(anchor="w", pady=4)

    def refresh_sources(self):
        self.src_tree.clear()
        for r in self.lib.roots():
            n = self.lib.db.one("SELECT COUNT(*) FROM files WHERE root_id=? AND status!='missing'", (r["id"],))[0]
            self.src_tree.add((r["id"], r["name"], r["path"], "yes" if r["enabled"] else "no", "yes" if r["available"] else "NO", r["include_ext"], r["exclude_globs"], n), iid=str(r["id"]))
        self.root_list_refresh()

    def sel_roots(self): return [int(i) for i in self.src_tree.selected()]
    def add_folder(self):
        p = filedialog.askdirectory(title="Choose a folder to add")
        if p:
            self.add_paths([p])
    def add_many(self):
        s = simpledialog.askstring("Add several folders", "One folder path per line:", parent=self) if False else self._multiline("Add several folders", "One folder path per line:")
        if s: self.add_paths([l.strip().strip('"') for l in s.splitlines() if l.strip()])
    def remove_root(self):
        ids = self.sel_roots()
        if ids and messagebox.askyesno("Remove", "Remove the selected sources from the index?\nYour files on disk are NOT deleted."):
            for i in ids: self.lib.remove_root(i)
            self.refresh_all()
    def toggle_root(self):
        for r in self.lib.roots():
            if r["id"] in self.sel_roots(): self.lib.update_root(r["id"], enabled=0 if r["enabled"] else 1)
        self.refresh_all()
    def edit_filters(self):
        for i in self.sel_roots()[:1]:
            r = next(x for x in self.lib.roots() if x["id"] == i)
            ext = simpledialog.askstring("Extensions", "Only these extensions (comma separated, empty = all supported):", initialvalue=r["include_ext"], parent=self)
            if ext is None: return
            ex = simpledialog.askstring("Exclude", "Exclude names/folders (wildcards, comma separated):", initialvalue=r["exclude_globs"], parent=self)
            if ex is None: return
            self.lib.update_root(i, include_ext=ext, exclude_globs=ex); self.refresh_all()
    def update_all(self): self._update(None)
    def update_selected(self, full=False): self._update(self.sel_roots() or None, full)
    def _update(self, ids, full=False):
        def job(ctl):
            s = self.lib.scan(ids, full=full, control=ctl, progress=self.progress_cb)
            return self.lib.index(ids, control=ctl, progress=self.progress_cb)
        self.run_bg("Scan + index", job)
    def index_pending(self): self.run_bg("Index", lambda ctl: self.lib.index(control=ctl, progress=self.progress_cb))
    def retry_failed(self): n = self.lib.retry_failed(); self.status.set(f"{n} failed files re-queued"); self.index_pending()
    def toggle_monitor(self):
        from .monitor import Monitor
        if self.mon_var.get():
            self.monitor = Monitor(self.lib, on_change=lambda rid: self.lib.index([rid])); self.monitor.start(); self.status.set("Watching folders")
        elif self.monitor: self.monitor.stop(); self.monitor = None; self.status.set("Stopped watching")

    def _multiline(self, title, prompt):
        w = tk.Toplevel(self); w.title(title); w.transient(self); out = {"v": None}
        ttk.Label(w, text=prompt).pack(anchor="w", padx=8, pady=4)
        t = scrolledtext.ScrolledText(w, width=80, height=10); t.pack(padx=8, pady=4)
        def ok(): out["v"] = t.get("1.0", "end"); w.destroy()
        ttk.Button(w, text="OK", command=ok).pack(pady=6); w.grab_set(); self.wait_window(w); return out["v"]

    # ---------------------------------------------------------------- search
    def tab_search(self, f):
        top = ttk.Frame(f); top.pack(fill="x")
        self.s_query = tk.StringVar(); e = ttk.Entry(top, textvariable=self.s_query, width=50); e.pack(side="left", padx=2); e.bind("<Return>", lambda ev: self.do_search())
        self.s_mode = ttk.Combobox(top, values=["text", "word", "all", "regex", "fuzzy"], width=8, state="readonly"); self.s_mode.set("text"); self.s_mode.pack(side="left", padx=2)
        ttk.Label(top, text="ext:").pack(side="left"); self.s_ext = tk.StringVar(); ttk.Entry(top, textvariable=self.s_ext, width=12).pack(side="left")
        ttk.Label(top, text="path starts with:").pack(side="left", padx=(8, 0)); self.s_path = tk.StringVar(); ttk.Entry(top, textvariable=self.s_path, width=22).pack(side="left")
        self.s_case = tk.BooleanVar(); ttk.Checkbutton(top, text="match case", variable=self.s_case).pack(side="left", padx=6)
        ttk.Button(top, text="Search", command=self.do_search).pack(side="left")
        ttk.Label(f, text="text = substring/phrase (exact) | word = whole word | all = every term | regex | fuzzy = tolerates OCR errors (approximate!)", foreground="#555").pack(anchor="w")
        mid = ttk.PanedWindow(f, orient="horizontal"); mid.pack(fill="both", expand=True, pady=4)
        left = ttk.Frame(mid); mid.add(left, weight=1)
        ttk.Label(left, text="Search only in (none selected = all enabled):").pack(anchor="w")
        self.root_list = tk.Listbox(left, selectmode="extended", height=8, exportselection=False, width=28); self.root_list.pack(fill="y")
        right = ttk.Frame(mid); mid.add(right, weight=5)
        self.res_tree = Tree(right, ("File", "Location", "Method", "Conf", "Match", "Excerpt", "Path"), {"File": 160, "Excerpt": 420, "Path": 300, "Conf": 50, "Location": 90, "Match": 110, "Method": 60}, height=12)
        self.res_tree.pack(fill="both", expand=True); self.res_tree.tv.bind("<<TreeviewSelect>>", self.on_hit); self.res_tree.tv.bind("<Double-1>", lambda e: self.open_hit())
        self.hits = {}
        bot = ttk.Frame(f); bot.pack(fill="both", expand=True)
        self.s_info = tk.StringVar(); ttk.Label(bot, textvariable=self.s_info).pack(anchor="w")
        pv = ttk.Frame(bot); pv.pack(fill="both", expand=True)
        self.s_text = scrolledtext.ScrolledText(pv, height=8, width=46, wrap="word"); self.s_text.pack(side="left", fill="y")
        self.s_img = tk.Label(pv, text="(source preview)", bg="#eee"); self.s_img.pack(side="left", fill="both", expand=True, padx=4)
        b = ttk.Frame(f); b.pack(fill="x"); ttk.Button(b, text="Open file", command=self.open_hit).pack(side="left"); ttk.Button(b, text="Open folder", command=lambda: self.open_hit(True)).pack(side="left", padx=4)

    def root_list_refresh(self):
        if hasattr(self, "root_list"):
            sel = self.root_list.curselection(); self.root_list.delete(0, "end"); self._rl_ids = []
            for r in self.lib.roots(): self.root_list.insert("end", r["name"]); self._rl_ids.append(r["id"])
            for i in sel:
                if i < self.root_list.size(): self.root_list.selection_set(i)

    def do_search(self):
        ids = [self._rl_ids[i] for i in self.root_list.curselection()] or None
        ext = [x.strip() for x in self.s_ext.get().replace(";", ",").split(",") if x.strip()] or None
        try:
            hits = S.search(self.lib.db, self.s_query.get(), self.s_mode.get(), ids, ext, self.s_path.get() or None, case_sensitive=self.s_case.get(), limit=1000)
        except Exception as e:
            t, m = friendly.explain(e, "search"); messagebox.showerror("Search: " + t, m); return
        self.res_tree.clear(); self.hits = {}
        for i, h in enumerate(hits):
            self.hits[str(i)] = h
            self.res_tree.add((h.name, h.loc, h.method, f"{h.confidence:.2f}", h.match[:60], h.excerpt, h.path), iid=str(i))
        self.status.set(f"{len(hits)} result(s)")

    def on_hit(self, _=None):
        sel = self.res_tree.selected()
        if not sel: return
        h = self.hits[sel[0]]
        self.s_info.set(f"{h.path}  -  {h.loc}  -  extraction: {h.method}, quality indicator {h.confidence:.2f}")
        self.s_text.delete("1.0", "end")
        if h.seg_id > 0:
            row = self.lib.db.one("SELECT text,words_json,page_w,page_h FROM segments WHERE id=?", (h.seg_id,))
            self.s_text.insert("end", row["text"])
            idx = self.s_text.search(h.match.split(", ")[0], "1.0", nocase=True)
            if idx:
                self.s_text.tag_add("hl", idx, f"{idx}+{len(h.match.split(', ')[0])}c"); self.s_text.tag_config("hl", background="yellow"); self.s_text.see(idx)
            bbox = E.locate_bbox(json.loads(row["words_json"]) if row["words_json"] else None, h.match)
            self.show_preview(h.path, h.loc, bbox, row["page_w"], row["page_h"])
        else:
            self.s_text.insert("end", h.excerpt); self.show_preview(h.path, h.loc.split(" table")[0], None, 0, 0)

    def show_preview(self, path, loc, bbox, pw, ph):
        try:
            from PIL import ImageTk
            img = P.render_preview(path, loc, bbox, pw, ph)
            if img is None: self.s_img.config(image="", text="(no visual preview for this file type)"); return
            img.thumbnail((760, 300)); self.preview_img = ImageTk.PhotoImage(img); self.s_img.config(image=self.preview_img, text="")
        except Exception as e:
            self.s_img.config(image="", text=f"(preview unavailable: {e})"[:80])

    def open_hit(self, folder=False):
        sel = self.res_tree.selected()
        if sel:
            p = self.hits[sel[0]].path; open_path(os.path.dirname(p) if folder else p)

    # ---------------------------------------------------------------- extract
    def tab_extract(self, f):
        top = ttk.Frame(f); top.pack(fill="x")
        ttk.Label(top, text="Profile:").pack(side="left"); self.prof_cb = ttk.Combobox(top, width=30, values=E.list_profiles(self.lib.db)); self.prof_cb.pack(side="left", padx=4)
        for t, c in [("Load", self.prof_load), ("Save", self.prof_save), ("Import JSON...", self.prof_import), ("Export JSON...", self.prof_export), ("New: drawing title block", self.prof_drawing)]:
            ttk.Button(top, text=t, command=c).pack(side="left", padx=2)
        row = ttk.Frame(f); row.pack(fill="x", pady=4)
        self.p_name = tk.StringVar(); self.p_mode = tk.StringVar(value="document"); self.p_glob = tk.StringVar(); self.p_keys = tk.StringVar(); self.p_min = tk.StringVar(value="1"); self.p_ext = tk.StringVar()
        for lab, var, w in [("Name", self.p_name, 22), ("File name pattern", self.p_glob, 16), ("Extensions", self.p_ext, 12), ("Duplicate-key fields", self.p_keys, 22), ("Min fields found", self.p_min, 4)]:
            ttk.Label(row, text=lab).pack(side="left"); ttk.Entry(row, textvariable=var, width=w).pack(side="left", padx=(2, 8))
        ttk.Label(row, text="Mode").pack(side="left"); ttk.Combobox(row, textvariable=self.p_mode, values=["document", "table"], width=9, state="readonly").pack(side="left")
        self.fld_tree = Tree(f, ("Field", "Type", "Labels (comma separated)", "Regex", "Required", "Min", "Max", "Always review"), {"Labels (comma separated)": 260, "Regex": 220, "Type": 70, "Required": 60, "Min": 50, "Max": 50, "Always review": 90}, height=8)
        self.fld_tree.pack(fill="both", expand=True)
        b = ttk.Frame(f); b.pack(fill="x", pady=3)
        for t, c in [("Describe fields I want...", self.fld_quick), ("Add field", self.fld_add), ("Edit field", self.fld_edit), ("Remove field", self.fld_del)]: ttk.Button(b, text=t, command=c).pack(side="left", padx=2)
        ttk.Button(b, text="RUN EXTRACTION on indexed files", command=self.run_extraction).pack(side="right")
        ttk.Label(f, text="Document mode: finds 'Label: value' lines/regex matches. Table mode: one record per table row, columns matched by header text (handles repeated headers and tables continued on the next page).", foreground="#555").pack(anchor="w")
        self.ext_tree = Tree(f, ("Record",), height=8); self.ext_tree.pack(fill="both", expand=True)

    def profile_from_form(self):
        fields = []
        for iid in self.fld_tree.tv.get_children():
            v = self.fld_tree.tv.item(iid, "values")
            num = lambda s: float(s) if str(s).strip() not in ("", "None") else None
            fields.append({"name": v[0], "type": v[1], "labels": [x.strip() for x in str(v[2]).split(",") if x.strip()], "regex": v[3] or None,
                           "required": v[4] == "yes", "min": num(v[5]), "max": num(v[6]), "always_review": v[7] == "yes"})
        return {"name": self.p_name.get().strip(), "mode": self.p_mode.get(), "name_glob": self.p_glob.get().strip(), "exts": [x.strip() for x in self.p_ext.get().split(",") if x.strip()],
                "key_fields": [x.strip() for x in self.p_keys.get().split(",") if x.strip()], "min_fields_matched": int(self.p_min.get() or 1), "fields": fields,
                "root_ids": [self._rl_ids[i] for i in self.root_list.curselection()]}

    def profile_to_form(self, p):
        self.p_name.set(p.get("name", "")); self.p_mode.set(p.get("mode", "document")); self.p_glob.set(p.get("name_glob", "")); self.p_ext.set(",".join(p.get("exts", [])))
        self.p_keys.set(",".join(p.get("key_fields", []))); self.p_min.set(str(p.get("min_fields_matched", 1))); self.fld_tree.clear()
        for f in p.get("fields", []):
            self.fld_tree.add((f["name"], f.get("type", "text"), ", ".join(f.get("labels", [])), f.get("regex") or "", "yes" if f.get("required") else "", f.get("min") if f.get("min") is not None else "", f.get("max") if f.get("max") is not None else "", "yes" if f.get("always_review") else ""))

    def prof_load(self):
        try: self.profile_to_form(E.load_profile(self.lib.db, self.prof_cb.get()))
        except KeyError as e: messagebox.showwarning("Profile", str(e))
    def prof_save(self):
        try: p = E.save_profile(self.lib.db, self.profile_from_form())
        except Exception as e: messagebox.showerror("Profile", str(e)); return
        self.prof_cb.config(values=E.list_profiles(self.lib.db)); self.prof_cb.set(p["name"]); self.status.set("Profile saved")
    def prof_import(self):
        p = filedialog.askopenfilename(filetypes=[("Profile JSON", "*.json")])
        if p: self.profile_to_form(json.load(open(p, encoding="utf-8")))
    def prof_export(self):
        p = filedialog.asksaveasfilename(defaultextension=".json", initialfile=self.p_name.get() + ".json")
        if p: json.dump(self.profile_from_form(), open(p, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    def prof_drawing(self): self.profile_to_form(drawings.title_block_profile())
    def _field_dialog(self, vals=("", "text", "", "", "", "", "", "")):
        w = tk.Toplevel(self); w.title("Field"); w.transient(self); out = {}
        vars_ = [tk.StringVar(value=str(x)) for x in vals]
        labs = ["Field name", "Type", "Labels in documents (comma separated)", "Regex (optional; group 1 = value)", "Required (yes/blank)", "Min", "Max", "Always review (yes/blank)"]
        for i, (l, v) in enumerate(zip(labs, vars_)):
            ttk.Label(w, text=l).grid(row=i, column=0, sticky="w", padx=6, pady=2)
            (ttk.Combobox(w, textvariable=v, values=["text", "date", "number", "integer", "currency", "id"], width=40, state="readonly") if i == 1 else ttk.Entry(w, textvariable=v, width=60)).grid(row=i, column=1, padx=6)
        def ok(): out["v"] = tuple(v.get() for v in vars_); w.destroy()
        ttk.Button(w, text="OK", command=ok).grid(row=len(labs), column=1, pady=6, sticky="e"); w.grab_set(); self.wait_window(w); return out.get("v")
    def fld_quick(self):
        s = self._multiline("Describe the fields", "Type the items you want to extract, separated by commas or one per line.\nExample:  Date, Project, Manpower, Invoice number, Total amount\n(DocIntel looks for these words followed by a colon, and guesses the data type; you can fine-tune each field afterwards.)")
        if s:
            for n in [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]:
                g = friendly.guess_field(n)
                self.fld_tree.add((g["name"], g["type"], ", ".join(g["labels"]), "", "", "", "", "yes" if g["always_review"] else ""))
            if not self.p_name.get(): self.p_name.set("My extraction")
            self.status.set("Fields added - check the types, then click RUN EXTRACTION")

    def fld_add(self):
        v = self._field_dialog()
        if v and v[0]: self.fld_tree.add(v)
    def fld_edit(self):
        s = self.fld_tree.selected()
        if s:
            v = self._field_dialog(self.fld_tree.tv.item(s[0], "values"))
            if v: self.fld_tree.tv.item(s[0], values=v)
    def fld_del(self):
        for s in self.fld_tree.selected(): self.fld_tree.tv.delete(s)

    def run_extraction(self):
        try: p = E.save_profile(self.lib.db, self.profile_from_form())
        except Exception as e: messagebox.showerror("Profile", str(e)); return
        self.prof_cb.config(values=E.list_profiles(self.lib.db))
        def job(ctl): return E.run_profile(self.lib, p)
        def done(rid):
            self.run_id = rid; self.show_run(rid); self.run_cb.set(str(rid)) if hasattr(self, "run_cb") else None
            n = len(E.review_queue(self.lib.db, rid)); self.status.set(f"Run {rid} complete: {n} value(s) need review (see Review tab)")
        self.run_bg("Extraction", job, done)

    def show_run(self, rid):
        fields = [x["name"] for x in json.loads(self.lib.db.one("SELECT params FROM runs WHERE id=?", (rid,))[0])["fields"]]
        t = self.ext_tree; t.tv.config(columns=["Record"] + fields)
        for c in ["Record"] + fields: t.tv.heading(c, text=c); t.tv.column(c, width=120)
        t.clear(); recs, held = E.records_for_export(self.lib.db, rid, True)
        for r in recs: t.add([os.path.basename(next(iter(r["src"].values()))["path"]) if r["src"] else ""] + [r["values"].get(f) for f in fields])

    # ---------------------------------------------------------------- review
    def tab_review(self, f):
        top = ttk.Frame(f); top.pack(fill="x")
        ttk.Label(top, text="Run:").pack(side="left"); self.run_cb = ttk.Combobox(top, width=8); self.run_cb.pack(side="left", padx=4)
        ttk.Button(top, text="Load review queue", command=self.load_review).pack(side="left")
        self.rv_all = tk.BooleanVar(); ttk.Checkbutton(top, text="show all values", variable=self.rv_all).pack(side="left", padx=6)
        self.rv_tree = Tree(f, ("Id", "Status", "Field", "Raw text", "Normalised", "Corrected", "Conf", "Issues", "File", "Location"), {"Issues": 330, "File": 200, "Id": 50, "Status": 70, "Conf": 50}, height=14)
        self.rv_tree.pack(fill="both", expand=True, pady=4); self.rv_tree.tv.bind("<<TreeviewSelect>>", self.rv_select)
        b = ttk.Frame(f); b.pack(fill="x")
        for t, c in [("Approve as is", lambda: self.rv_act("approved")), ("Correct...", self.rv_correct), ("Reject record", lambda: self.rv_act("rejected")), ("Mark unresolved", lambda: self.rv_act("unresolved")), ("Approve ALL 'ok' values", self.rv_all_ok)]:
            ttk.Button(b, text=t, command=c).pack(side="left", padx=2)
        pv = ttk.Frame(f); pv.pack(fill="both", expand=True)
        self.rv_img = tk.Label(pv, text="(select a value to see the source region)", bg="#eee"); self.rv_img.pack(fill="both", expand=True, pady=4)

    def refresh_runs(self):
        if hasattr(self, "run_cb"):
            runs = [str(r["id"]) for r in self.lib.db.q("SELECT id FROM runs ORDER BY id DESC LIMIT 50")]
            self.run_cb.config(values=runs); self.exp_run.config(values=runs) if hasattr(self, "exp_run") else None
            if not self.run_cb.get() and runs: self.run_cb.set(runs[0])
            if hasattr(self, "exp_run") and not self.exp_run.get() and runs: self.exp_run.set(runs[0])

    def load_review(self):
        if not self.run_cb.get(): return
        rid = int(self.run_cb.get()); self.run_id = rid; self.rv_tree.clear()
        rows = self.lib.db.q("SELECT * FROM vals WHERE run_id=? ORDER BY record_key,id", (rid,)) if self.rv_all.get() else E.review_queue(self.lib.db, rid)
        for v in rows:
            iss = "; ".join(json.loads(v["issues"])) if v["issues"] else ""
            self.rv_tree.add((v["id"], v["status"], v["field"], v["raw"], v["normalized"], v["correction"] or "", f"{v['confidence']:.2f}", iss, os.path.basename(v["abspath"] or ""), v["loc"]), iid=str(v["id"]))

    def rv_select(self, _=None):
        s = self.rv_tree.selected()
        if not s: return
        v = self.lib.db.one("SELECT * FROM vals WHERE id=?", (int(s[0]),))
        seg = self.lib.db.one("SELECT page_w,page_h FROM segments WHERE file_id=? AND loc=? LIMIT 1", (v["file_id"], v["loc"])) if v["loc"] else None
        try:
            from PIL import ImageTk
            img = P.render_preview(v["abspath"], v["loc"] or "p1", json.loads(v["bbox"]) if v["bbox"] else None, seg["page_w"] if seg else 0, seg["page_h"] if seg else 0)
            if img is None: self.rv_img.config(image="", text=f"No visual preview for this file type.  Raw text: {v['raw']}"); return
            img.thumbnail((1000, 280)); self.rv_pv = ImageTk.PhotoImage(img); self.rv_img.config(image=self.rv_pv, text="")
        except Exception as e: self.rv_img.config(image="", text=f"preview unavailable: {e}")

    def rv_ids(self): return [int(i) for i in self.rv_tree.selected()]
    def rv_act(self, status):
        for i in self.rv_ids(): E.set_value(self.lib.db, i, status=status)
        self.load_review()
    def rv_correct(self):
        for i in self.rv_ids()[:1]:
            v = self.lib.db.one("SELECT * FROM vals WHERE id=?", (i,))
            n = simpledialog.askstring("Correct value", f"{v['field']}  (raw text: {v['raw']!r})\nCorrected value:", initialvalue=v["correction"] or v["normalized"] or "", parent=self)
            if n is not None: E.set_value(self.lib.db, i, correction=n)
        self.load_review()
    def rv_all_ok(self):
        if self.run_id and messagebox.askyesno("Approve", "Approve every value not flagged for review?"): E.approve_all_ok(self.lib.db, self.run_id); self.load_review()

    # ---------------------------------------------------------------- tables
    def tab_tables(self, f):
        top = ttk.Frame(f); top.pack(fill="x")
        self.t_q = tk.StringVar(); ttk.Label(top, text="File name contains:").pack(side="left"); ttk.Entry(top, textvariable=self.t_q, width=30).pack(side="left", padx=4)
        ttk.Button(top, text="Find tables", command=self.find_tables).pack(side="left")
        self.tb_list = Tree(f, ("Id", "File", "Location", "Method", "Rows", "Confidence", "Corrected", "Note"), {"File": 240, "Note": 260, "Id": 50, "Rows": 50}, height=6); self.tb_list.pack(fill="x", pady=4)
        self.tb_list.tv.bind("<<TreeviewSelect>>", self.tb_open)
        self.tb_grid = Tree(f, ("c",), height=14); self.tb_grid.pack(fill="both", expand=True); self.tb_grid.tv.bind("<Double-1>", self.tb_edit_cell)
        b = ttk.Frame(f); b.pack(fill="x", pady=3)
        for t, c in [("Save corrections", self.tb_save), ("Restore original", self.tb_reset), ("Insert column", lambda: self.tb_col(1)), ("Delete column", lambda: self.tb_col(-1)), ("Delete row", self.tb_delrow), ("Export table to Excel...", self.tb_export)]:
            ttk.Button(b, text=t, command=c).pack(side="left", padx=2)
        ttk.Label(f, text="Double-click a cell to correct it. The original extraction is always kept; corrections are stored separately.", foreground="#555").pack(anchor="w")
        self.tb_rows = None; self.tb_id = None

    def find_tables(self):
        self.tb_list.clear()
        for t in self.lib.db.q("SELECT t.*, f.name fname FROM tables_ t JOIN files f ON f.id=t.file_id WHERE f.name LIKE ? ORDER BY f.name, t.id LIMIT 500", (f"%{self.t_q.get()}%",)):
            self.tb_list.add((t["id"], t["fname"], t["loc"], t["method"], len(json.loads(t["rows_json"])), f"{t['confidence']:.2f}", "yes" if t["corrected_json"] else "", t["note"] or ""), iid=str(t["id"]))

    def tb_open(self, _=None):
        s = self.tb_list.selected()
        if not s: return
        t = self.lib.db.one("SELECT * FROM tables_ WHERE id=?", (int(s[0]),)); self.tb_id = t["id"]
        self.tb_rows = json.loads(t["corrected_json"] or t["rows_json"]); self.tb_draw()

    def tb_draw(self):
        n = max((len(r) for r in self.tb_rows), default=1); cols = [f"c{i + 1}" for i in range(n)]
        g = self.tb_grid; g.tv.config(columns=cols)
        for c in cols: g.tv.heading(c, text=c.upper()); g.tv.column(c, width=110)
        g.clear()
        for i, r in enumerate(self.tb_rows): g.add(list(r) + [""] * (n - len(r)), iid=str(i))

    def tb_edit_cell(self, ev):
        g = self.tb_grid.tv; row = g.identify_row(ev.y); col = g.identify_column(ev.x)
        if not row or not col: return
        ci = int(col[1:]) - 1; ri = int(row)
        new = simpledialog.askstring("Edit cell", f"Row {ri + 1}, column {ci + 1}", initialvalue=(self.tb_rows[ri][ci] if ci < len(self.tb_rows[ri]) else ""), parent=self)
        if new is not None:
            self.tb_rows[ri] += [""] * (ci + 1 - len(self.tb_rows[ri])); self.tb_rows[ri][ci] = new; self.tb_draw()
    def tb_col(self, d):
        if not self.tb_rows: return
        if d > 0:
            for r in self.tb_rows: r.append("")
        else:
            for r in self.tb_rows:
                if r: r.pop()
        self.tb_draw()
    def tb_delrow(self):
        for s in sorted((int(i) for i in self.tb_grid.selected()), reverse=True): del self.tb_rows[s]
        self.tb_draw()
    def tb_save(self):
        if self.tb_id: self.lib.db.x("UPDATE tables_ SET corrected_json=? WHERE id=?", (json.dumps(self.tb_rows, ensure_ascii=False), self.tb_id)); self.find_tables(); self.status.set("Correction saved (original kept)")
    def tb_reset(self):
        if self.tb_id: self.lib.db.x("UPDATE tables_ SET corrected_json=NULL WHERE id=?", (self.tb_id,)); self.tb_open(); self.find_tables()
    def tb_export(self):
        if self.tb_id:
            p = filedialog.asksaveasfilename(defaultextension=".xlsx")
            if p: XL.export_table(self.lib.db, self.tb_id, p); self.status.set(f"Exported {p}")

    # ---------------------------------------------------------------- compare
    def tab_compare(self, f):
        b = ttk.Frame(f); b.pack(fill="x")
        ttk.Button(b, text="Exact duplicate files", command=self.cmp_exact).pack(side="left", padx=2)
        ttk.Button(b, text="Near-duplicate documents", command=self.cmp_near).pack(side="left", padx=2)
        ttk.Label(b, text="Run:").pack(side="left", padx=(14, 2)); self.cmp_run = ttk.Combobox(b, width=6); self.cmp_run.pack(side="left")
        ttk.Label(b, text="key fields:").pack(side="left", padx=2); self.cmp_keys = tk.StringVar(); ttk.Entry(b, textvariable=self.cmp_keys, width=26).pack(side="left")
        ttk.Button(b, text="Conflicting / duplicate records", command=self.cmp_conf).pack(side="left", padx=2)
        self.cmp_out = scrolledtext.ScrolledText(f, wrap="none"); self.cmp_out.pack(fill="both", expand=True, pady=6)
        ttk.Label(f, text="Nothing is merged or resolved automatically: conflicts are shown with their sources so you decide.", foreground="#555").pack(anchor="w")
    def _cmp_show(self, s): self.cmp_out.delete("1.0", "end"); self.cmp_out.insert("end", s)
    def cmp_exact(self):
        g = C.exact_duplicate_files(self.lib.db); self._cmp_show("\n\n".join(f"{x['count']} identical copies ({x['size']} bytes):\n  " + "\n  ".join(x["paths"]) for x in g) or "No exact duplicates.")
    def cmp_near(self):
        self.run_bg("Near-duplicate analysis", lambda ctl: C.near_duplicate_files(self.lib.db), lambda r: self._cmp_show("\n".join(f"{d['similarity']:.0%}  {d['a']}\n      {d['b']}" for d in r) or "No near-duplicates found."))
    def cmp_conf(self):
        if not self.cmp_run.get(): return
        res = C.conflicting_records(self.lib.db, int(self.cmp_run.get()), [k.strip() for k in self.cmp_keys.get().split(",") if k.strip()]); out = []
        for r in res:
            out.append(f"{r['status']}: {r['key']}  records {r['records']}")
            for d in r["differences"]:
                out.append(f"   field {d['field']}:"); out += [f"      {v['value']!r}   <- {v['source']}" for v in d["values"]]
        self._cmp_show("\n".join(out) or "No duplicate keys / conflicts in this run.")

    # ---------------------------------------------------------------- export
    def tab_export(self, f):
        r = ttk.Frame(f); r.pack(fill="x")
        ttk.Label(r, text="Run:").pack(side="left"); self.exp_run = ttk.Combobox(r, width=6); self.exp_run.pack(side="left", padx=4)
        self.exp_unrev = tk.BooleanVar(); ttk.Checkbutton(r, text="include records still needing review", variable=self.exp_unrev).pack(side="left", padx=10)
        r2 = ttk.LabelFrame(f, text="Destination", padding=6); r2.pack(fill="x", pady=6)
        self.exp_tpl = tk.StringVar(); ttk.Label(r2, text="Existing Excel template (leave empty for a new workbook):").grid(row=0, column=0, sticky="w")
        ttk.Entry(r2, textvariable=self.exp_tpl, width=70).grid(row=0, column=1); ttk.Button(r2, text="Browse...", command=self.exp_browse).grid(row=0, column=2, padx=4)
        ttk.Label(r2, text="Worksheet:").grid(row=1, column=0, sticky="w"); self.exp_sheet = ttk.Combobox(r2, width=30, state="readonly"); self.exp_sheet.grid(row=1, column=1, sticky="w")
        self.exp_mode = ttk.Combobox(r2, values=["append", "update"], width=8, state="readonly"); self.exp_mode.set("append"); self.exp_mode.grid(row=1, column=2)
        self.exp_inplace = tk.BooleanVar(); ttk.Checkbutton(r2, text="Write into the template itself (a timestamped backup is made first). Default: new file, original untouched.", variable=self.exp_inplace).grid(row=2, column=0, columnspan=3, sticky="w")
        self.map_tree = Tree(f, ("Extracted field", "Excel column"), {"Extracted field": 220, "Excel column": 260}, height=7); self.map_tree.pack(fill="x")
        b = ttk.Frame(f); b.pack(fill="x", pady=4)
        for t, c in [("Load fields / auto-map", self.exp_automap), ("Change mapping...", self.exp_remap), ("PREVIEW changes", self.exp_preview), ("EXPORT", self.exp_do), ("Export CSV...", self.exp_csv)]:
            ttk.Button(b, text=t, command=c).pack(side="left", padx=3)
        self.exp_out = scrolledtext.ScrolledText(f, height=14); self.exp_out.pack(fill="both", expand=True)
        self.exp_headers = []

    def exp_browse(self):
        p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xlsm")])
        if p:
            self.exp_tpl.set(p); info = XL.read_headers(p); self.exp_sheet.config(values=info["sheets"]); self.exp_sheet.set(info["sheet"]); self.exp_headers = list(info["headers"]); self.exp_automap()

    def _run_fields(self):
        rid = int(self.exp_run.get()); return rid, json.loads(self.lib.db.one("SELECT params FROM runs WHERE id=?", (rid,))[0])

    def exp_automap(self):
        if not self.exp_run.get(): return
        rid, prof = self._run_fields(); fields = [f["name"] for f in prof["fields"]]
        if self.exp_tpl.get():
            info = XL.read_headers(self.exp_tpl.get(), self.exp_sheet.get() or None); self.exp_headers = list(info["headers"]); m = XL.auto_mapping(fields, self.exp_headers)
        else: m = {f: f for f in fields}
        self.map_tree.clear()
        for f in fields: self.map_tree.add((f, m.get(f, "")), iid=f)
    def exp_remap(self):
        for s in self.map_tree.selected():
            v = simpledialog.askstring("Mapping", f"Excel column header for '{s}'\n(available: {', '.join(self.exp_headers) or 'new workbook uses field names'}; empty = do not export):", initialvalue=self.map_tree.tv.set(s, "Excel column"), parent=self)
            if v is not None: self.map_tree.tv.set(s, "Excel column", v)
    def mapping(self): return {k: self.map_tree.tv.set(k, "Excel column") for k in self.map_tree.tv.get_children() if self.map_tree.tv.set(k, "Excel column")}
    def _say(self, s): self.exp_out.delete("1.0", "end"); self.exp_out.insert("end", s)

    def exp_preview(self):
        if not self.exp_run.get(): return
        rid, prof = self._run_fields(); recs, held = E.records_for_export(self.lib.db, rid, self.exp_unrev.get())
        out = [f"{len(recs)} record(s) ready, {len(held)} held back (values still need review)."]
        if not self.exp_tpl.get():
            out.append("Destination: NEW workbook (sheet 'Extracted' + 'Provenance'). Columns: " + ", ".join(self.mapping()))
            for r in recs[:50]: out.append("  " + " | ".join(str(r["values"].get(k)) for k in self.mapping()))
        else:
            try: plan = XL.preview(self.exp_tpl.get(), recs, self.mapping(), self.exp_sheet.get() or None, mode=self.exp_mode.get(), key_columns=prof.get("key_fields"))
            except Exception as e: self._say(str(e)); return
            out.append(f"Target: {plan['target']}  sheet '{plan['sheet']}'  mode {plan['mode']}")
            if plan["risks"]: out.append("WARNING - parts of this workbook that the writer cannot preserve: " + ", ".join(plan["risks"]) + "  -> export to a NEW file (default) and keep the original.")
            for o in plan["ops"][:200]: out.append("  " + json.dumps(o, ensure_ascii=False, default=str))
            for c in plan["conflicts"]: out.append(f"  CONFLICT {c}")
        self._say("\n".join(out))

    def exp_do(self):
        if not self.exp_run.get(): return
        rid, prof = self._run_fields(); fields = [k for k in self.mapping()]; recs, held = E.records_for_export(self.lib.db, rid, self.exp_unrev.get())
        if held and not messagebox.askyesno("Held back", f"{len(held)} record(s) still need review and will NOT be exported. Continue?"): return
        if self.exp_tpl.get():
            if self.exp_inplace.get() and not messagebox.askyesno("Write into template", "The template will be modified (a backup copy is made first). Continue?"): return
            try:
                try: res = XL.apply(self.lib.db, rid, self.exp_tpl.get(), recs, self.mapping(), self.exp_sheet.get() or None, mode=self.exp_mode.get(), key_columns=prof.get("key_fields"), in_place=self.exp_inplace.get())
                except XL.RiskyTemplate as rt:
                    ans = messagebox.askyesnocancel("This Excel file has items DocIntel can't keep",
                        str(rt) + "\n\nYour original file will NOT be changed in any case.\n\nYES  = save the extracted data in a NEW, separate workbook (recommended - nothing is lost)\nNO   = make a copy of your file WITH the new rows, but the items listed above will be missing from the copy\nCANCEL = stop")
                    if ans is None: return
                    if ans:
                        p = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile="extracted.xlsx")
                        if not p: return
                        for r in recs: r["values"] = {k: r["values"].get(k) for k in fields}
                        r2 = XL.export_new(self.lib.db, rid, recs, fields, p); self._say(f"Output: {r2['output']}\nRows: {r2['rows']}\nVerified after re-opening: {r2['verified']}"); return
                    res = XL.apply(self.lib.db, rid, self.exp_tpl.get(), recs, self.mapping(), self.exp_sheet.get() or None, mode=self.exp_mode.get(), key_columns=prof.get("key_fields"), in_place=False, allow_lossy=True)
            except Exception as e:
                t, m = friendly.explain(e, "export"); messagebox.showerror(t, m); return
            a = res["audit"]; self._say(f"Output: {res['output']}\nBackup: {res['backup']}\nInserted {len(a['inserted'])}, updated {len(a['updated'])}, skipped {len(a['skipped'])}, conflicts kept {len(a['rejected_conflicts'])}\nVerified after re-opening: {a['verified']} ({a['verify_message']})")
        else:
            p = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile="extracted.xlsx")
            if p:
                for r in recs: r["values"] = {k: r["values"].get(k) for k in fields}
                res = XL.export_new(self.lib.db, rid, recs, fields, p); self._say(f"Output: {res['output']}\nRows: {res['rows']}\nVerified after re-opening: {res['verified']}")
    def exp_csv(self):
        if not self.exp_run.get(): return
        rid, prof = self._run_fields(); recs, _ = E.records_for_export(self.lib.db, rid, self.exp_unrev.get())
        p = filedialog.asksaveasfilename(defaultextension=".csv")
        if p: self._say("Wrote " + XL.export_csv(recs, list(self.mapping()), p, "\t" if p.endswith(".tsv") else ","))

    # ---------------------------------------------------------------- settings
    def tab_settings(self, f):
        g = ttk.LabelFrame(f, text="Settings", padding=8); g.pack(fill="x")
        self.set_vars = {}
        for i, (k, lab) in enumerate([("workers", "Parallel workers (1-4; each OCR job uses a CPU core)"), ("ocr_langs", "OCR languages (Tesseract codes, e.g. eng+ara)"), ("max_file_mb", "Skip files larger than (MB)"), ("review_confidence_threshold", "Send to review when quality indicator below")]):
            ttk.Label(g, text=lab).grid(row=i, column=0, sticky="w"); v = tk.StringVar(value=str(self.lib.cfg[k])); self.set_vars[k] = v; ttk.Entry(g, textvariable=v, width=14).grid(row=i, column=1, padx=6)
        self.off_var = tk.BooleanVar(value=self.lib.cfg["offline_mode"]); ttk.Checkbutton(g, text="Offline mode (block all network connections from this app; takes effect on restart)", variable=self.off_var).grid(row=4, column=0, columnspan=2, sticky="w")
        self.df_var = tk.BooleanVar(value=self.lib.cfg["day_first"]); ttk.Checkbutton(g, text="Dates are day-first (31/12/2026)", variable=self.df_var).grid(row=5, column=0, columnspan=2, sticky="w")
        ttk.Button(g, text="Save settings", command=self.save_settings).grid(row=6, column=0, pady=4, sticky="w")
        b = ttk.LabelFrame(f, text="Diagnostics and recovery", padding=8); b.pack(fill="x", pady=8)
        for t, c in [("Run self-check (doctor)", self.run_doctor), ("Check index integrity", self.check_integrity), ("Rebuild search index", self.rebuild_fts), ("Re-extract everything from sources", self.reindex_all), ("Backup index + settings...", self.do_backup), ("Open data folder", lambda: open_path(self.lib.cfg.home)), ("Show log", self.show_log)]:
            ttk.Button(b, text=t, command=c).pack(side="left", padx=2)
        self.diag = scrolledtext.ScrolledText(f, height=18); self.diag.pack(fill="both", expand=True)
        ttk.Label(f, text=f"Data folder: {self.lib.cfg.home}", foreground="#555").pack(anchor="w")
    def save_settings(self):
        c = self.lib.cfg
        try:
            c.set("workers", max(1, min(8, int(self.set_vars["workers"].get())))); c.set("ocr_langs", self.set_vars["ocr_langs"].get()); c.set("max_file_mb", int(self.set_vars["max_file_mb"].get()))
            c.set("review_confidence_threshold", float(self.set_vars["review_confidence_threshold"].get())); c.set("offline_mode", self.off_var.get()); c.set("day_first", self.df_var.get())
        except ValueError as e: messagebox.showerror("Settings", str(e)); return
        self.status.set("Settings saved")
    def _diag(self, s): self.diag.delete("1.0", "end"); self.diag.insert("end", s)
    def run_doctor(self):
        rep = D.doctor(self.lib); self._diag("\n".join(("[OK]  " if c["ok"] else "[!!]  ") + c["name"] + (f"  -  {c['detail']}" if c["detail"] else "") for c in rep["checks"]) + ("\n\nALL CHECKS PASSED" if rep["ok"] else "\n\nSOME CHECKS FAILED"))
    def check_integrity(self): self._diag(json.dumps(self.lib.db.integrity_check(), indent=1))
    def rebuild_fts(self): self.lib.db.rebuild_fts(); self._diag("Full-text index rebuilt.")
    def reindex_all(self):
        if messagebox.askyesno("Re-extract", "Discard all extracted text and re-process every file from the original sources?\n(Corrections you made to tables will be lost.)"): self.lib.reindex_all(); self.index_pending()
    def do_backup(self):
        p = filedialog.asksaveasfilename(defaultextension=".zip", initialfile=f"docintel_backup_{time.strftime('%Y%m%d')}.zip")
        if p: D.backup(self.lib, p); self._diag(f"Backup written: {p}")
    def show_log(self):
        try: self._diag(open(self.lib.cfg.log_path, encoding="utf-8").read()[-20000:])
        except OSError: self._diag("(no log yet)")


def run_gui(home=None, smoke=None):
    if os.name == "nt":
        try:
            import ctypes; ctypes.windll.shcore.SetProcessDpiAwareness(1)      # crisp text on high-DPI screens
        except Exception: pass
    try:
        app = App(home, smoke)
    except Exception as e:
        t, m = friendly.explain(e, "startup")
        r = tk.Tk(); r.withdraw(); messagebox.showerror("DocIntel could not start - " + t, m); r.destroy(); return 1
    app.mainloop(); return 0


if __name__ == "__main__":
    run_gui()
