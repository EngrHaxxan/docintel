"""Milestone 7: structured retrieval. One place that returns extracted RECORDS (table rows) with their source (file, page, table, section,
row) for search, for Excel and for a future AI assistant. Offline, deterministic, no AI needed. Every record carries a citation."""
from __future__ import annotations
import json, re
from dataclasses import dataclass, field
from .tables import store

_OPS = ("<=", ">=", "!=", "=", "~", "<", ">")


@dataclass
class Record:
    file_id: int
    file: str
    path: str
    page: int
    table_id: int
    table: str
    section: str
    row_no: int
    cells: dict = field(default_factory=dict)          # header -> value as extracted (corrections applied)
    flags: list = field(default_factory=list)
    quality: float = 0.0

    def citation(self):
        return {"file": self.file, "path": self.path, "page": self.page, "table_id": self.table_id, "table": self.table or self.section,
                "section": self.section, "row": self.row_no, "file_id": self.file_id}

    def cite_text(self):
        t = self.table or self.section
        return f"{self.file}, page {self.page}" + (f", {t}" if t else "") + f", row {self.row_no}"

    def text(self):
        return "; ".join(f"{k}: {v}" for k, v in self.cells.items() if str(v).strip())


def parse_filter(s):
    """'Urgency=High' | 'Status~open' (contains) | 'Qty>10' | 'Total>=1000' | 'Owner!=SE' -> (column, op, value)."""
    for op in _OPS:
        if op in s:
            a, b = s.split(op, 1)
            return a.strip(), op, b.strip()
    raise ValueError(f"Not a filter: {s!r}. Use for example  Urgency=High  or  Qty>10  or  Status~open")


def _num(v):
    try:
        return float(re.sub(r"[,\s%]", "", str(v)))
    except ValueError:
        return None


def _match(cell, op, want):
    c, w = str(cell or "").strip(), want.strip()
    if op == "=":
        return c.lower() == w.lower()
    if op == "!=":
        return c.lower() != w.lower()
    if op == "~":
        return w.lower() in c.lower()
    a, b = _num(c), _num(w)
    if a is None or b is None:
        return False
    return {"<": a < b, ">": a > b, "<=": a <= b, ">=": a >= b}[op]


class Retriever:
    def __init__(self, lib):
        self.lib, self.db = lib, lib.db

    # ------------------------------------------------------------ tables in scope
    def _tables(self, file_ids=None, root_ids=None, ext=None, section="", table_like="", query=""):
        sql = ("SELECT t.id FROM doc_tables t JOIN files f ON f.id=t.file_id WHERE f.missing_since IS NULL")
        args = []
        if file_ids:
            sql += f" AND f.id IN ({','.join('?' * len(file_ids))})"; args += list(file_ids)
        if root_ids:
            sql += f" AND f.root_id IN ({','.join('?' * len(root_ids))})"; args += list(root_ids)
        if ext:
            sql += " AND lower(ltrim(f.ext,'.'))=?"; args.append(ext.lower().lstrip("."))
        if section:
            sql += " AND lower(COALESCE(t.section,'')) LIKE ?"; args.append(f"%{section.lower()}%")
        if table_like:
            sql += " AND lower(COALESCE(t.title,'')||' '||COALESCE(t.section,'')) LIKE ?"; args.append(f"%{table_like.lower()}%")
        for w in query.split():                              # every word must occur in some cell of the table (cheap pre-filter)
            sql += (" AND EXISTS(SELECT 1 FROM table_cells c JOIN table_rows tr ON tr.id=c.row_id WHERE tr.table_id=t.id "
                    "AND instr(lower(COALESCE(c.corrected_orig,c.raw_orig,'')), lower(?))>0)")
            args.append(w)
        return [r["id"] for r in self.db.q(sql + " ORDER BY f.name, t.id", tuple(args))]

    def catalog(self, **scope):
        """Which tables exist (for the user to pick from): id, file, page range, section, rows, headers."""
        out = []
        for tid in self._tables(**scope):
            t = store.load_table(self.db, tid)
            f = self.db.one("SELECT f.name, f.abspath FROM doc_tables d JOIN files f ON f.id=d.file_id WHERE d.id=?", (tid,))
            out.append({"table_id": tid, "file": f["name"], "path": f["abspath"], "pages": f"{t.page_from}-{t.page_to}", "section": t.section,
                        "rows": len(t.rows), "headers": [h.name for h in t.headers]})
        return out

    # ------------------------------------------------------------ records
    def find_records(self, query="", filters=(), limit=200, use="norm", max_tables=2000, **scope):
        """Rows of extracted tables that contain every word of `query` and satisfy every filter ('Column=value', 'Qty>10', 'Status~open').
        scope: file_ids, root_ids, ext, section, table_like."""
        flt = [parse_filter(f) if isinstance(f, str) else tuple(f) for f in filters]
        words = [w.lower() for w in query.split()]
        out = []
        for tid in self._tables(query=query, **scope)[:max_tables]:
            t = store.load_table(self.db, tid)
            row = self.db.one("SELECT f.id, f.name, f.abspath FROM doc_tables d JOIN files f ON f.id=d.file_id WHERE d.id=?", (tid,))
            names, seen = [], {}
            for i, h in enumerate(t.headers):
                n = h.name or f"Column {i + 1}"
                seen[n] = seen.get(n, 0) + 1
                names.append(n if seen[n] == 1 else f"{n} ({seen[n]})")
            for ri, r in enumerate(t.rows, 1):
                vals = r.norm if use == "norm" else r.orig
                cells = {names[i]: (vals[i] if i < len(vals) else "") for i in range(len(names))}
                hay = " ".join(str(v) for v in cells.values()).lower()
                if words and not all(w in hay for w in words):
                    continue
                ok = True
                for col, op, want in flt:
                    key = next((n for n in cells if n.lower() == col.lower()), None) or next((n for n in cells if col.lower() in n.lower()), None)
                    if key is None or not _match(cells[key], op, want):
                        ok = False; break
                if ok:
                    out.append(Record(row["id"], row["name"], row["abspath"], r.page or t.page_from, tid, t.title, t.section, ri, cells,
                                      [f for fl in r.cell_flags.values() for f in fl] + list(r.flags), t.quality))
                    if len(out) >= limit:
                        return out
        return out

    _STOP = set("what which who when where how many much show list give tell about have there their with from that this those these are was were the and for not any all each per between into over under out has had been being does did can could should would will".split())

    def keyword_records(self, question, limit=60, **scope):
        """Free-text question without explicit filters: records ranked by how many of the question's meaningful words they contain
        (no AI involved; only a shortlist of candidates for the user / a future assistant)."""
        words = [w for w in dict.fromkeys(re.findall(r"[\w.\-/&%]{3,}", question.lower())) if w not in self._STOP][:6]
        hits = {}
        for w in words:
            for r in self.find_records(w, limit=400, **scope):
                key = (r.table_id, r.row_no)
                if key in hits:
                    hits[key][0] += 1
                else:
                    hits[key] = [1, r]
        ranked = sorted(hits.values(), key=lambda x: (-x[0], x[1].file, x[1].table_id, x[1].row_no))
        return [r for n, r in ranked[:limit]]

    def search_text(self, query, limit=50, **kw):
        """Page text search with citations (file, page, snippet)."""
        from . import search as S
        return [{"file": h.name, "path": h.path, "page": h.loc, "kind": h.kind, "snippet": h.excerpt, "file_id": h.file_id}
                for h in S.search(self.db, query, "text", limit=limit, **kw)]


# ============================================================================ evidence for an assistant
@dataclass
class Evidence:
    id: str
    record: Record
    text: str


@dataclass
class EvidencePack:
    question: str
    items: list = field(default_factory=list)
    truncated: bool = False

    def chars(self):
        return sum(len(i.text) for i in self.items) + len(self.question)

    def prompt(self):
        lines = [f"[{i.id}] ({i.record.cite_text()}) {i.text}" for i in self.items]
        return "EVIDENCE:\n" + "\n".join(lines) + f"\n\nQUESTION: {self.question}"

    def manifest(self):
        """What would leave the computer: one line per record (no more)."""
        return [{"id": i.id, **i.record.citation(), "chars": len(i.text)} for i in self.items]

    def fingerprint(self):
        import hashlib
        return hashlib.sha256(self.prompt().encode("utf-8")).hexdigest()[:16]


def build_pack(question, records, max_records=40, max_chars=12000):
    """Only the selected records (never whole documents), numbered E1, E2, ... so an answer can cite them."""
    pack, used = EvidencePack(question), 0
    for r in records:
        txt = r.text()
        if len(pack.items) >= max_records or used + len(txt) > max_chars:
            pack.truncated = True
            break
        pack.items.append(Evidence(f"E{len(pack.items) + 1}", r, txt)); used += len(txt)
    return pack
