"""Windows-readiness tests. Cross-platform ones run everywhere (spaces/Unicode paths, portable mode, safety rules);
the ones marked windows_only run on the Windows CI runner."""
import json, os, shutil, subprocess, sys

import openpyxl, pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from docintel.library import Library
from docintel import paths, friendly, excel_export as XL, extractors as X, search as S
from docintel.config import Config

windows_only = pytest.mark.skipif(os.name != "nt", reason="Windows runner only")


def test_spaces_and_unicode_in_paths(tmp_path):
    d = tmp_path / "مجلد التقارير With Spaces" / "سنة 2026"; d.mkdir(parents=True)
    (d / "تقرير يومي.txt").write_text("Project: Muna-1\nالمشروع: منى\n", encoding="utf-8")
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (900, 200), "white"); ImageDraw.Draw(im).text((30, 60), "Invoice No: INV-55555", fill="black")
    im.save(d / "scan with space.png")
    l = Library(str(tmp_path / "data dir ü"))
    l.add_root(str(tmp_path / "مجلد التقارير With Spaces")); l.scan(); st = l.index()
    assert st["errors"] == 0 and st["indexed"] == 2
    assert S.search(l.db, "INV-55555") and S.search(l.db, "منى")
    assert all("\\\\?\\" not in r["abspath"] for r in l.db.q("SELECT abspath FROM files"))


def test_tessdata_folder_with_spaces_and_unicode(tmp_path, monkeypatch):
    monkeypatch.setenv("TESSDATA_PREFIX", os.environ.get("TESSDATA_PREFIX", ""))      # restored after the test (OCR sets it)
    src = "/usr/share/tesseract-ocr/5/tessdata"
    if not os.path.isdir(src): pytest.skip("system tessdata not at the Linux default path")
    td = tmp_path / "Program Files (x86)" / "Tess ö" / "tessdata"; td.mkdir(parents=True)
    for f in ("eng.traineddata", "osd.traineddata"): shutil.copy(os.path.join(src, f), td / f)
    cfg = Config(str(tmp_path / "h")); cfg.set("tessdata_dir", str(td)); cfg.set("ocr_langs", "eng"); X.OCR._langs_cache = None
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (900, 200), "white"); ImageDraw.Draw(im).text((30, 60), "Total: 12345", fill="black")
    t, conf, w, _ = X.OCR(cfg).run(im)
    assert "12345" in t
    X.OCR._langs_cache = None


def test_portable_mode_uses_folder_next_to_app(tmp_path, monkeypatch):
    monkeypatch.delenv("DOCINTEL_HOME", raising=False)
    monkeypatch.setattr(paths, "app_dir", lambda: str(tmp_path / "app"))
    (tmp_path / "app").mkdir(); (tmp_path / "app" / "portable.txt").write_text("portable")
    assert paths.is_portable() and paths.data_dir() == str(tmp_path / "app" / "DocIntel_Data")
    os.remove(tmp_path / "app" / "portable.txt")
    assert not paths.is_portable() and "DocIntel_Data" not in paths.data_dir()


def test_portable_readonly_falls_back(tmp_path, monkeypatch):
    monkeypatch.delenv("DOCINTEL_HOME", raising=False)
    monkeypatch.setattr(paths, "app_dir", lambda: str(tmp_path / "app")); (tmp_path / "app").mkdir(); (tmp_path / "app" / "portable.txt").write_text("x")
    monkeypatch.setattr(paths, "writable", lambda p: False)
    assert "DocIntel_Data" not in paths.data_dir()


def test_risky_template_blocked_then_allowed(tmp_path, tmp_path_factory):
    from openpyxl.chart import BarChart, Reference
    p = str(tmp_path / "t.xlsx"); wb = openpyxl.Workbook(); ws = wb.active; ws.append(["Date", "Qty"]); ws.append(["2026-01-01", 1])
    ch = BarChart(); ch.add_data(Reference(ws, min_col=2, min_row=1, max_row=2)); ws.add_chart(ch, "E2"); wb.save(p)
    l = Library(str(tmp_path / "h")); rec = [{"key": "1:0", "values": {"Date": "2026-02-01", "Qty": "5"}, "src": {}, "types": {}}]
    before = open(p, "rb").read()
    with pytest.raises(XL.RiskyTemplate) as e:
        XL.apply(l.db, 1, p, rec, {"Date": "Date", "Qty": "Qty"})
    assert "charts" in str(e.value) and open(p, "rb").read() == before
    assert not [f for f in os.listdir(tmp_path) if "_export_" in f]               # nothing was written
    res = XL.apply(l.db, 1, p, rec, {"Date": "Date", "Qty": "Qty"}, allow_lossy=True)
    assert os.path.exists(res["output"]) and open(p, "rb").read() == before         # original untouched even then
    out = XL.export_new(l.db, 1, rec, ["Date", "Qty"], str(tmp_path / "results_only.xlsx"))
    assert out["verified"]


def test_friendly_errors_are_plain_english():
    t, m = friendly.explain(PermissionError(13, "denied"))
    assert "open in Excel" in m and "Traceback" not in m
    t, m = friendly.explain(FileNotFoundError("x"))
    assert "unplugged" in m
    import sqlite3
    assert "damaged" in friendly.explain(sqlite3.DatabaseError("malformed"))[0] + friendly.explain(sqlite3.DatabaseError("malformed"))[1]
    assert "Nothing was lost" in friendly.explain(KeyError("zzz"))[1]


def test_quick_field_guessing():
    g = {n: friendly.guess_field(n) for n in ["Date", "Project", "Manpower", "Invoice number", "Total amount", "Revision", "Drawing number"]}
    assert g["Date"]["type"] == "date" and g["Project"]["type"] == "text" and g["Manpower"]["type"] == "integer"
    assert g["Invoice number"]["type"] == "id" and g["Total amount"]["type"] == "number"
    assert g["Revision"]["always_review"] and g["Drawing number"]["type"] == "id"


def test_ocr_strips_bidi_marks_and_handles_noise(tmp_path):
    assert X.BIDI_MARKS.sub("", "\u200eDate: 1\u200f") == "Date: 1"


def test_gui_first_run_and_smoke(tmp_path):
    if not os.environ.get("DISPLAY") and os.name != "nt": pytest.skip("no display")
    out = str(tmp_path / "s.json")
    r = subprocess.run([sys.executable, "-m", "docintel", "--home", str(tmp_path / "h"), "gui", "--smoke-test", out], capture_output=True, text=True, timeout=120,
                       cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    rep = json.load(open(out))
    assert rep["tabs"] == 11 and rep["doctor_ok"] and rep["problems"] == []
    assert rep.get("home_ok") and rep.get("wizard_ok"), rep.get("wizard_error")


@windows_only
def test_windows_long_path_prefix_never_stored(tmp_path):
    d = tmp_path
    for i in range(6): d = d / ("x" * 45)
    os.makedirs(paths.long_path(str(d)), exist_ok=True)
    open(paths.long_path(str(d / "doc.txt")), "w").write("needle-long-path")
    l = Library(str(tmp_path / "h")); l.add_root(str(tmp_path)); l.scan(); l.index()
    assert S.search(l.db, "needle-long-path")
    assert not any(r["abspath"].startswith("\\\\?\\") for r in l.db.q("SELECT abspath FROM files"))


@windows_only
def test_windows_case_insensitive_root_duplicates(tmp_path):
    l = Library(str(tmp_path / "h")); (tmp_path / "Reports").mkdir()
    l.add_root(str(tmp_path / "Reports"))
    with pytest.raises(ValueError): l.add_root(str(tmp_path / "reports"))


@windows_only
def test_windows_locked_file_is_reported_not_fatal(tmp_path):
    d = tmp_path / "r"; d.mkdir(); (d / "a.txt").write_text("fine"); locked = d / "b.txt"; locked.write_text("locked")
    l = Library(str(tmp_path / "h")); l.add_root(str(d)); l.scan()
    with open(locked, "r+"):          # Windows sharing: another handle open for write
        import msvcrt
        st = l.index()
    assert st["indexed"] >= 1
