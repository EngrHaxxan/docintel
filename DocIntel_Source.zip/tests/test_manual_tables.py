"""Milestone 8: manual table selection (rectangle + column lines), saved as template, scanned pages with OCR."""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from docintel.library import Library
from docintel.tables import store
from docintel.tables.manual import manual_extract, apply_template, save_manual_table

COLS = (72, 150, 330, 500)


def make_pdf(path, rows, header=("Ref", "Item", "Description", "Qty"), two_line_header=False, top=700):
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(path); c.setFont("Helvetica", 10)
    c.drawString(72, 800, "Site report - some text above the table that must not be part of it")
    y = top
    if two_line_header:
        for x, t in zip(COLS, ("Item", "Item", "Work", "Quantity")):
            c.drawString(x, y, t)
        y -= 12
        for x, t in zip(COLS, ("Ref", "Name", "Description", "(m3)")):
            c.drawString(x, y, t)
        y -= 16
    else:
        for x, t in zip(COLS, header):
            c.drawString(x, y, t)
        y -= 16
    for r in rows:
        for x, t in zip(COLS, r):
            if t:
                c.drawString(x, y, t)
        y -= 14
    c.drawString(72, y - 30, "Notes: text below the table")
    c.save()
    return (60, 842 - top - 12, 560, 842 - (y + 14) + 4)             # box around the table in PDF points (x0, top, x1, bottom)


ROWS = [("1", "Piling", "Bored piles 600 mm", "12.5"), ("", "", "continued on second line", ""), ("2", "Fencing", "Chain link, 65%", "0.25"),
        ("3", "Cable", "110/13.8 kV  EHV.SWGXX.TEST", "-12.5"), ("4", "Tan ∂", "N/A", "48 V")]


class Manual(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.pdf = os.path.join(self.tmp, "a.pdf")
        self.bbox = make_pdf(self.pdf, [r for r in ROWS if "∂" not in r[1]])

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _box(self, n_rows=None):
        return self.bbox

    def test_auto_columns_header_continuation_values_kept(self):
        t = manual_extract(self.pdf, 1, self._box(5))
        self.assertEqual([h.name for h in t.headers], ["Ref", "Item", "Description", "Qty"])
        self.assertEqual([r.orig[0] for r in t.rows], ["1", "2", "3"])                  # the continuation line joined row 1
        self.assertEqual(t.rows[0].orig[2], "Bored piles 600 mm continued on second line")
        self.assertEqual([r.orig[3] for r in t.rows], ["12.5", "0.25", "-12.5"])
        self.assertEqual(t.rows[1].orig[2], "Chain link, 65%"); self.assertEqual(t.rows[2].orig[2], "110/13.8 kV EHV.SWGXX.TEST".replace("kV ", "kV  ").replace("  ", " "))
        self.assertTrue(t.method.startswith("manual")); self.assertTrue(any("by hand" in n for n in t.quality_notes))

    def test_given_column_lines_and_two_line_header(self):
        p2 = os.path.join(self.tmp, "b.pdf"); box = make_pdf(p2, ROWS[:1] + ROWS[2:3], two_line_header=True)
        t = manual_extract(p2, 1, box, col_edges=[110, 250, 400], header_rows=2)
        self.assertEqual([h.name for h in t.headers], ["Item Ref", "Item Name", "Work Description", "Quantity (m3)"])
        self.assertEqual(len(t.rows), 2)

    def test_errors_are_friendly(self):
        with self.assertRaises(ValueError) as cm:
            manual_extract(self.pdf, 1, (10, 10, 50, 30))
        self.assertIn("No text", str(cm.exception))
        with self.assertRaises(ValueError):
            manual_extract(self.pdf, 1, (60, 842 - 700 - 12, 100, 842 - 700 + 6))        # one narrow column

    def test_saved_with_file_and_kept_when_extracting_again(self):
        src = os.path.join(self.tmp, "s"); os.makedirs(src); shutil.copy(self.pdf, os.path.join(src, "a.pdf"))
        lib = Library(os.path.join(self.tmp, "h")); lib.cfg.set("workers", 1); lib.add_root(src); lib.scan(); lib.index()
        fid = lib.db.one("SELECT id FROM files")["id"]
        t = manual_extract(os.path.join(src, "a.pdf"), 1, self._box(5))
        tid = save_manual_table(lib.db, fid, t)
        self.assertEqual(store.load_table(lib.db, tid).method, "manual")
        self.assertFalse(store.is_current(lib.db, fid))                                  # the file still gets its automatic extraction
        lib.extract_tables(force=True)
        methods = [x["method"] for x in store.list_tables(lib.db, fid)]
        self.assertIn("manual", methods); self.assertGreaterEqual(len(methods), 1)
        lib.extract_tables(force=True)
        self.assertEqual([x["method"] for x in store.list_tables(lib.db, fid)].count("manual"), 1)     # not duplicated, not lost

    def test_template_applies_to_similar_document(self):
        t = manual_extract(self.pdf, 1, self._box(5))
        tpl = t.stats["template"]
        p2 = os.path.join(self.tmp, "other.pdf"); make_pdf(p2, [("7", "Gate", "Steel gate", "2"), ("8", "Wall", "Block wall", "30"), ("9", "Door", "Steel door", "4"), ("10", "Roof", "Roof sheet", "9")])
        t2, warn = apply_template(p2, tpl)
        self.assertEqual([r.orig[0] for r in t2.rows][:2], ["7", "8"]); self.assertEqual([h.name for h in t2.headers], ["Ref", "Item", "Description", "Qty"])
        self.assertTrue(any("check" in w for w in warn)); self.assertFalse(any("differ" in w for w in warn))
        p3 = os.path.join(self.tmp, "diff.pdf"); make_pdf(p3, [("a", "b", "c", "d"), ("e", "f", "g", "h")], header=("Code", "Zone", "Owner", "Status"))
        t3, warn3 = apply_template(p3, tpl)
        self.assertTrue(any("differ" in w for w in warn3))                               # a different layout is announced, not hidden


@unittest.skipUnless(shutil.which("tesseract"), "tesseract not installed")
class ManualScanned(unittest.TestCase):
    def test_scanned_page_selection_uses_ocr(self):
        import test_scanned_tables as TS
        from docintel import extractors as X
        from docintel.config import DEFAULTS
        tmp = tempfile.mkdtemp(); p = os.path.join(tmp, "scan.pdf"); TS.scan_pdf(p, TS.ROWS)
        ocr = X.OCR(dict(DEFAULTS))
        t = manual_extract(p, 1, (40, 130, 560, 300), ocr=lambda: ocr)
        self.assertTrue(t.method.endswith("ocr")); self.assertLessEqual(t.quality, 0.7)
        self.assertEqual(len(t.rows), 5); self.assertEqual([r.orig[0] for r in t.rows], ["1", "2", "3", "4", "5"])
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()


class Discovery(unittest.TestCase):
    """Workflow B: 'I want all activities with progress percentages' - the user does not know where the information is."""
    def test_discover_groups_identical_layouts_and_explains(self):
        from tests.test_wizard import DAILY
        from docintel.wizard import Session
        tmp = tempfile.mkdtemp(); src = os.path.join(tmp, "s"); os.makedirs(src)
        for i in range(3):
            shutil.copy(DAILY, os.path.join(src, f"daily_{i}.pdf"))
        lib = Library(os.path.join(tmp, "h")); lib.cfg.set("workers", 1); lib.add_root(src); lib.scan(); lib.index()
        s = Session(lib); s.select_all(); s.prepare()
        res = s.discover("all activities with progress percentages")
        self.assertTrue(res)
        best = res[0]
        self.assertTrue(any("Progress" in h for h in best["headers"]))                 # the construction table, not the staff / equipment tables
        self.assertEqual(best["documents"], 3); self.assertEqual(best["tables"], 3)    # one layout, found in 3 documents
        self.assertIn("progress", best["matched_columns"])
        iss = s.discover("open issues with urgency and owner")[0]
        self.assertTrue(any("Urgency" in h for h in iss["headers"]))
        self.assertEqual(s.discover("zzzz qqqq"), [])
        shutil.rmtree(tmp, ignore_errors=True)
