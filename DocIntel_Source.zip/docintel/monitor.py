"""Optional folder monitoring (watchdog). Changes trigger a debounced incremental rescan of the affected root.
Reconciliation scans at startup remain the source of truth for anything missed while the app was closed."""
import os, threading, time


class Monitor:
    def __init__(self, lib, debounce=5.0, on_change=None):
        self.lib, self.debounce, self.on_change = lib, debounce, on_change
        self.obs = None
        self._timers = {}
        self._lock = threading.Lock()

    def start(self):
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
        mon = self
        class H(FileSystemEventHandler):
            def __init__(s, rid): s.rid = rid
            def on_any_event(s, ev):
                if not ev.is_directory: mon._poke(s.rid)
        self.obs = Observer()
        for r in self.lib.roots():
            if r["enabled"] and os.path.isdir(r["path"]):
                self.obs.schedule(H(r["id"]), r["path"], recursive=True)
        self.obs.start()

    def _poke(self, rid):
        with self._lock:
            t = self._timers.pop(rid, None)
            if t: t.cancel()
            t = threading.Timer(self.debounce, self._run, args=(rid,))
            t.daemon = True; self._timers[rid] = t; t.start()

    def _run(self, rid):
        try:
            self.lib.scan([rid])
            if self.on_change: self.on_change(rid)
        except Exception:
            pass

    def stop(self):
        with self._lock:
            for t in self._timers.values(): t.cancel()
        if self.obs:
            self.obs.stop(); self.obs.join(5)
