"""Compare saved AI models on YOUR documents (Milestone 9): the same fields are extracted from the same sample documents by each model; the
report shows how many values each model found, how many of them were really in the document text (verified), the time, and where models disagree.
Nothing is saved. This is how you pick the best model for your kind of documents instead of guessing."""
from __future__ import annotations
import time
from .extract import document_pages, extract_fields, extract_rows, norm
from .provider import ProviderError


def compare_models(lib, model_names, file_ids, fields, instructions="", mode="fields", progress=None):
    reg = lib.ai_models(); results = []
    docs = {fid: document_pages(lib.db, fid) for fid in file_ids}
    names = {fid: (lib.db.one("SELECT name FROM files WHERE id=?", (fid,))["name"]) for fid in file_ids}
    for mi, mname in enumerate(model_names):
        m = reg.get(mname); prov = reg.provider(mname); budget = int((m or {}).get("context_chars") or 12000)
        res = {"model": mname, "seconds": 0.0, "found": 0, "verified": 0, "asked": 0, "errors": [], "values": {}}
        t0 = time.time()
        for fid, pages in docs.items():
            if progress:
                progress(mi, len(model_names), f"{mname}: {names[fid]}")
            res["asked"] += len(fields) if mode == "fields" else 0
            try:
                if mode == "fields":
                    out = extract_fields(prov, pages, fields, instructions, budget)
                    for f, (v, pg, ok) in out.items():
                        res["values"][(names[fid], f)] = v
                        if v:
                            res["found"] += 1; res["verified"] += 1 if ok else 0
                else:
                    rows = extract_rows(prov, pages, fields, instructions, budget)
                    for i, (row, pg, ver) in enumerate(rows):
                        for f in fields:
                            res["values"][(names[fid], f"{i + 1}:{f}")] = row[f]
                            if row[f]:
                                res["found"] += 1; res["verified"] += 1 if ver[f] else 0
            except ProviderError as e:
                res["errors"].append(f"{names[fid]}: {e}")
        res["seconds"] = round(time.time() - t0, 1)
        res["verified_pct"] = round(100.0 * res["verified"] / res["found"], 1) if res["found"] else 0.0
        results.append(res)
    for r in results:                                              # agreement with every other model on the values both produced
        for o in results:
            if o is r:
                continue
            both = [k for k in r["values"] if k in o["values"] and (r["values"][k] or o["values"][k])]
            r.setdefault("agree", {})[o["model"]] = round(100.0 * sum(1 for k in both if norm(r["values"][k]) == norm(o["values"][k])) / len(both), 1) if both else None
    return results


def format_report(results):
    lines = ["Model comparison (same documents, same fields)", ""]
    for r in sorted(results, key=lambda r: (-r["verified_pct"], r["seconds"])):
        lines.append(f"{r['model']}: found {r['found']} value(s), {r['verified']} of them confirmed in the document text ({r['verified_pct']}%), {r['seconds']} s" +
                     (f", {len(r['errors'])} error(s)" if r["errors"] else ""))
        for o, a in r.get("agree", {}).items():
            lines.append(f"    agrees with {o} on {a}% of values" if a is not None else f"    nothing to compare with {o}")
    lines += ["", "Higher 'confirmed' is better: a value that is not in the document text is a likely invention. Always look at a sample yourself."]
    return "\n".join(lines)
