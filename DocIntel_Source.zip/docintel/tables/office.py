"""Tables from Word, Excel, PowerPoint, HTML and CSV files, in the same model/store as PDF tables (Milestone 6).
Merged cells are handled like in PDFs: 'orig' keeps blanks where cells are merged, 'norm' repeats the value of vertically merged cells."""
from __future__ import annotations
import os, re
from .model import Table, Header, Row

OFFICE_EXT = {"docx", "xlsx", "xlsm", "pptx", "html", "htm", "csv", "tsv"}


def _numlike(s):
    return bool(re.fullmatch(r"[-+()%$.,\s\d/:]*\d[-+()%$.,\s\d/:]*", s or ""))


def table_from_rows(rows, title="", section="", page=1, method="office", norm_rows=None, source="", notes=None):
    """rows: list of lists of strings (original layout). norm_rows: same shape with merged values repeated (optional)."""
    rows = [[(c if c is not None else "") for c in r] for r in rows]
    norm_rows = norm_rows or rows
    width = max((len(r) for r in rows), default=0)
    pad = lambda r: list(r) + [""] * (width - len(r))
    rows, norm_rows = [pad(r) for r in rows], [pad(r) for r in norm_rows]
    keep = [i for i, r in enumerate(rows) if any(str(c).strip() for c in r)]
    rows, norm_rows = [rows[i] for i in keep], [norm_rows[i] for i in keep]
    usedc = [c for c in range(width) if any(str(r[c]).strip() for r in rows)]
    rows, norm_rows = [[r[c] for c in usedc] for r in rows], [[r[c] for c in usedc] for r in norm_rows]
    if len(rows) < 2 or len(usedc) < 2:
        return None
    first = rows[0]
    has_header = any(str(c).strip() for c in first) and not all(_numlike(str(c)) or not str(c).strip() for c in first)
    hdr_cells = first if has_header else [""] * len(usedc)
    headers = []
    for i, c in enumerate(hdr_cells):
        name = str(c).strip() or f"Column {i + 1}"
        headers.append(Header(name=name, leaf=name, original=[str(c)], flags=[] if str(c).strip() else ["empty header"]))
    body = list(zip(rows, norm_rows))[1:] if has_header else list(zip(rows, norm_rows))
    out = []
    for o, n in body:
        out.append(Row(page=page, orig=[str(x) for x in o], norm=[str(x) for x in n]))
        for i, (a, b) in enumerate(zip(o, n)):
            if str(a) != str(b):
                out[-1].cell_flags[i] = ["merged cell value repeated"]
    t = Table(title=title or section, section=section, page_from=page, page_to=page, headers=headers, rows=out, method=method, quality=0.95 if has_header else 0.7,
              source=source)
    t.quality_notes = list(notes or []) + ([] if has_header else ["no header row found: columns are numbered"])
    return t


# ------------------------------------------------------------------ Word
def docx_tables(path):
    import docx
    from docx.table import Table as DT
    from docx.text.paragraph import Paragraph
    d = docx.Document(path)
    out, heading, n = [], "", 0
    for el in d.element.body.iterchildren():
        tag = el.tag.rsplit("}", 1)[-1]
        if tag == "p":
            p = Paragraph(el, d)
            sn = (p.style.name if p.style is not None else "") or ""
            if (sn.startswith("Heading") or sn == "Title") and p.text.strip():
                heading = p.text.strip()
        elif tag == "tbl":
            n += 1
            tb = DT(el, d)
            cells, nc = tb._cells, len(tb.columns)
            if not nc:
                continue
            rows, norm = [], []
            for r in range(len(cells) // nc):
                o, nm = [], []
                for c in range(nc):
                    cell = cells[r * nc + c]
                    txt = cell.text.strip()
                    if r > 0 and cell._tc is cells[(r - 1) * nc + c]._tc:         # vertical merge: blank in the original layout, repeated when normalized
                        o.append(""); nm.append(norm[-1][c])
                    elif c > 0 and cell._tc is cells[r * nc + c - 1]._tc:         # horizontal merge
                        o.append(""); nm.append("")
                    else:
                        o.append(txt); nm.append(txt)
                rows.append(o); norm.append(nm)
            t = table_from_rows(rows, title=f"Table {n}", section=heading or f"Table {n}", page=1, method="docx-native", norm_rows=norm, source=path)
            if t:
                out.append(t)
    return out


# ------------------------------------------------------------------ Excel
def _xl_text(cell):
    import datetime
    v = cell.value
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, datetime.datetime):
        return v.date().isoformat() if v.time() == datetime.time(0) else v.isoformat(sep=" ")
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, (int, float)):
        f = cell.number_format or "General"
        dec = len(f.split(".")[1].rstrip("%")) if "." in f and re.fullmatch(r"[#,0]*\.0+%?", f.split(";")[0]) else None
        if "%" in f:
            return f"{v * 100:.{dec if dec is not None else 0}f}%" if re.fullmatch(r"[#,0]*(\.0+)?%", f.split(";")[0]) else f"{v * 100:g}%"
        if dec is not None:
            return f"{v:,.{dec}f}" if "," in f else f"{v:.{dec}f}"
        return str(int(v)) if float(v).is_integer() else ("%.15g" % v)
    return str(v).strip()


def xlsx_tables(path, max_cells=3_000_000):
    import openpyxl
    big = os.path.getsize(path) > 30_000_000
    wb = openpyxl.load_workbook(path, read_only=big, data_only=True, keep_vba=False)
    out = []
    for si, ws in enumerate(wb.worksheets, 1):
        if getattr(ws, "sheet_state", "visible") != "visible":
            continue
        grid = [[_xl_text(c) for c in row] for row in ws.iter_rows()]
        norm = [list(r) for r in grid]
        if not big:
            for mr in ws.merged_cells.ranges:
                r0, c0, r1, c1 = mr.min_row - 1, mr.min_col - 1, mr.max_row - 1, mr.max_col - 1
                if r0 >= len(grid):
                    continue
                top = grid[r0][c0] if c0 < len(grid[r0]) else ""
                for r in range(r0, min(r1, len(grid) - 1) + 1):
                    for c in range(c0, c1 + 1):
                        if (r, c) != (r0, c0) and c < len(grid[r]):
                            grid[r][c] = ""
                            norm[r][c] = top if c == c0 else ""        # only vertical merges are repeated
        # blocks separated by blank rows; single-cell rows above a block = its title
        blocks, cur, title, titles = [], [], "", []
        for ri, r in enumerate(grid):
            filled = [c for c in r if str(c).strip()]
            if not filled:
                if cur:
                    blocks.append((cur, title)); cur, title = [], ""
                continue
            if len(filled) == 1 and not cur:
                title = filled[0]; continue
            cur.append(ri)
        if cur:
            blocks.append((cur, title))
        for bi, (idx, ttl) in enumerate(blocks, 1):
            t = table_from_rows([grid[i] for i in idx], title=f"{ws.title}" + (f" - {ttl}" if ttl else ""), section=ttl or ws.title, page=si,
                                method="xlsx-native", norm_rows=[norm[i] for i in idx], source=path,
                                notes=["Excel formulas show the value Excel last saved"])
            if t:
                t.stats = {"sheet": ws.title, "first_row": idx[0] + 1}
                out.append(t)
    return out


# ------------------------------------------------------------------ PowerPoint / HTML / CSV (rows from the existing readers)
def other_tables(path, ext):
    from .. import extractors as X
    from ..config import DEFAULTS
    res = X.extract_file(path, dict(DEFAULTS), lambda: None)
    out = []
    for lt in res.tables:
        m = re.search(r"(\d+)", lt.loc or "")
        page = int(m.group(1)) if (m and ext == "pptx") else 1
        sec = f"Slide {page}" if ext == "pptx" else (lt.loc or "")
        t = table_from_rows(lt.rows, title=lt.loc, section=sec, page=page, method=lt.method, source=path)
        if t:
            out.append(t)
    return out


def office_tables(path, ext):
    ext = ext.lower().lstrip(".")
    if ext == "docx":
        return docx_tables(path)
    if ext in ("xlsx", "xlsm"):
        return xlsx_tables(path)
    return other_tables(path, ext)
