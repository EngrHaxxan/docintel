# Third-party components

DocIntel's own code is MIT-licensed (see LICENSE). It uses the following components. Licences are quoted from each
project's published metadata as understood at build time - **re-check them before commercial redistribution.**

| Component | Purpose | Licence |
|---|---|---|
| Python / Tkinter | runtime and GUI | PSF |
| SQLite (FTS5, trigram tokenizer) | index database | Public domain |
| Tesseract OCR 5 + `eng`, `osd`, `ara` traineddata | OCR | Apache 2.0 |
| pytesseract | Tesseract wrapper | Apache 2.0 |
| pdfplumber / pdfminer.six | PDF text, words, tables | MIT |
| pypdfium2 (PDFium) | PDF page rendering | Apache 2.0 / BSD-3 |
| pypdf | encryption detection | BSD-3 |
| python-docx, python-pptx | Word / PowerPoint reading | MIT |
| openpyxl | Excel reading / writing | MIT |
| Pillow | image handling | HPND (permissive) |
| ezdxf | DXF drawing reading | MIT |
| rapidfuzz | fuzzy search | MIT |
| watchdog | folder monitoring (optional) | Apache 2.0 |
| psutil | benchmark only | BSD-3 |
| PyInstaller | build only | GPL-2.0 with bootloader exception (output may be distributed under any licence) |
| Inno Setup | installer build only (optional) | Inno Setup licence (free) |

**Deliberately NOT used:** PyMuPDF/MuPDF (AGPL/commercial) - excluded from the build. DWG libraries (ODA/Teigha,
LibreDWG-GPL) - native DWG is not read; export DXF/PDF from AutoCAD instead.

**Optional, not bundled:** LibreOffice (MPL 2.0) is used only if installed, to convert legacy .doc/.ppt/.xls.
