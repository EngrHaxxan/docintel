"""Format-specific extractors. Native parsers are preferred over OCR; OCR is a fallback for scans/images.

Every extractor returns an ExtractResult. Nothing here executes macros or scripts from source documents.
"""
import csv, io, json, os, re, zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser

EXTRACTOR_VERSION = 1
MAX_ZIP_UNCOMPRESSED = 1_500_000_000   # zip-bomb guard for OOXML/ODF containers
MAX_ZIP_RATIO = 200


class Unsupported(Exception):
    pass


class Encrypted(Exception):
    pass


class Corrupted(Exception):
    pass


@dataclass
class Segment:
    kind: str            # page | slide | sheet | text | ocr | drawing
    loc: str             # "p3", "slide 2", "Sheet1", "line 1-80", "model"
    text: str
    method: str          # native | ocr | native-vector | ...
    confidence: float = 1.0
    words: list = None   # [[text,x0,y0,x1,y1],...] in page units (for source-region previews)
    page_w: float = 0
    page_h: float = 0


@dataclass
class Table:
    loc: str
    rows: list
    method: str
    confidence: float = 0.9
    idx: int = 0
    note: str = ""


@dataclass
class ExtractResult:
    segments: list = field(default_factory=list)
    tables: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


SUPPORTED = {
    "pdf": "pdf", "png": "image", "jpg": "image", "jpeg": "image", "tif": "image", "tiff": "image",
    "bmp": "image", "gif": "image", "webp": "image",
    "docx": "docx", "pptx": "pptx", "xlsx": "xlsx", "xlsm": "xlsx",
    "csv": "csv", "tsv": "csv", "txt": "text", "log": "text", "md": "text", "rtf": "rtf",
    "odt": "odf", "ods": "odf", "odp": "odf", "html": "html", "htm": "html", "xml": "xml", "json": "json",
    "dxf": "dxf",
    # legacy binary Office formats: need LibreOffice (optional) for conversion
    "doc": "legacy", "ppt": "legacy", "xls": "legacy",
    "dwg": "dwg",
}


# ----------------------------------------------------------------------------- helpers
def decode_bytes(b: bytes) -> str:
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", "replace")
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return b.decode("utf-16", "replace")
    for enc in ("utf-8", "cp1256", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("latin-1", "replace")


def check_zip_safe(path):
    try:
        with zipfile.ZipFile(path) as z:
            total = sum(i.file_size for i in z.infolist())
            comp = sum(i.compress_size for i in z.infolist()) or 1
            if total > MAX_ZIP_UNCOMPRESSED or (total / comp > MAX_ZIP_RATIO and total > 50_000_000):
                raise Unsupported("container rejected: suspicious compression ratio / size (possible zip bomb)")
    except zipfile.BadZipFile:
        raise Corrupted("corrupted or not a valid Office/ODF container")


def clean(s):
    return re.sub(r"[ \t\u00a0]+", " ", (s or "").replace("\x00", "")).strip()


# ----------------------------------------------------------------------------- OCR
BIDI_MARKS = re.compile("[\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def bundled_tesseract():
    """Looks for a Tesseract shipped next to the application (portable/installer layout): <app>/tesseract/tesseract.exe + tessdata/."""
    import sys
    from .paths import app_dir, resource_dir
    bases = [app_dir(), resource_dir(), os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))]
    for b in bases:
        for exe in (("tesseract.exe",) if os.name == "nt" else ("tesseract",)):
            p = os.path.join(b, "tesseract", exe)
            if os.path.exists(p):
                td = os.path.join(b, "tesseract", "tessdata")
                return p, (td if os.path.isdir(td) else None)
    return None, None


class OCR:
    """Tesseract wrapper (local, offline). Languages are limited to those whose traineddata is installed."""
    _langs_cache = None

    def __init__(self, cfg):
        import pytesseract
        self.pt = pytesseract
        cmd, td = cfg.get("tesseract_cmd") or None, cfg.get("tessdata_dir") or None
        if not cmd:
            cmd, td2 = bundled_tesseract()
            td = td or td2
        if cmd:
            pytesseract.pytesseract.tesseract_cmd = cmd
        if td:
            os.environ["TESSDATA_PREFIX"] = td      # env var instead of a quoted CLI option: safe for spaces/Unicode/UNC paths
        self.tessdata = td
        self.cfg = cfg

    def available_langs(self):
        if OCR._langs_cache is None:
            try:
                OCR._langs_cache = set(self.pt.get_languages(config=self._conf()))
            except Exception:
                OCR._langs_cache = set()
        return OCR._langs_cache

    def _conf(self):
        return ""

    def lang(self):
        want = [l for l in self.cfg["ocr_langs"].split("+") if l]
        have = self.available_langs()
        use = [l for l in want if l in have] or (["eng"] if "eng" in have else [])
        return "+".join(use)

    def prep(self, img):
        from PIL import Image, ImageOps
        img = ImageOps.exif_transpose(img)
        if img.mode not in ("L", "RGB"):
            img = img.convert("RGB")
        if img.width * img.height > self.cfg["max_ocr_pixels"]:
            raise Unsupported("image too large for OCR (resource limit)")
        g = ImageOps.grayscale(img)
        if max(g.size) < 1500:    # upscale tiny/low-resolution images
            f = 2 if max(g.size) > 700 else 3
            g = g.resize((g.width * f, g.height * f), Image.LANCZOS)
        g = ImageOps.autocontrast(g)
        return g

    @staticmethod
    def deskew(g, max_angle=6.0, step=0.5):
        """Small-angle skew correction with Pillow only (projection-profile method on a reduced copy)."""
        from PIL import Image
        small = g.copy(); small.thumbnail((700, 700))
        small = small.point(lambda p: 255 if p > 160 else 0)
        best, best_a = -1.0, 0.0
        a = -max_angle
        while a <= max_angle + 1e-6:
            r = small.rotate(a, resample=Image.BILINEAR, fillcolor=255).resize((1, small.height), Image.BOX)
            px = list(r.convert("L").tobytes())
            m = sum(px) / len(px)
            var = sum((v - m) ** 2 for v in px)
            if var > best:
                best, best_a = var, a
            a += step
        if abs(best_a) >= 0.4:
            g = g.rotate(best_a, resample=Image.BICUBIC, expand=True, fillcolor=255)
        return g

    def fix_rotation(self, g):
        try:
            osd = self.pt.image_to_osd(g, config="--psm 0", output_type=self.pt.Output.DICT)
            if osd.get("rotate", 0) and float(osd.get("orientation_conf", 0)) > 2.0:
                g = g.rotate(-osd["rotate"], expand=True, fillcolor=255)
        except Exception:
            pass
        return g

    def run(self, img, fix_rotation=True):
        lang = self.lang()
        if not lang:
            raise Unsupported("no OCR language data installed")
        g = self.prep(img)
        if fix_rotation:
            g = self.fix_rotation(g)
            try:
                g = self.deskew(g)
            except Exception:
                pass
        best = self._ocr(g, lang)
        if best[1] < 0.6:            # poor result: retry once with speckle removal (+ sharpening) and keep the better one
            from PIL import ImageFilter
            alt = self._ocr(g.filter(ImageFilter.MedianFilter(3)).filter(ImageFilter.SHARPEN), lang)
            if alt[1] > best[1]:
                best = alt
        return best

    def _ocr(self, g, lang):
        d = self.pt.image_to_data(g, lang=lang, config="--psm 6 -c preserve_interword_spaces=1",
                                  output_type=self.pt.Output.DICT)
        lines, words, confs = {}, [], []
        for i, t in enumerate(d["text"]):
            t = BIDI_MARKS.sub("", (t or "")).strip()
            if not t:
                continue
            c = float(d["conf"][i])
            if c < 0:
                continue
            key = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
            lines.setdefault(key, []).append(t)
            x, y, w, h = d["left"][i], d["top"][i], d["width"][i], d["height"][i]
            words.append([t, x, y, x + w, y + h, round(c)])
            confs.append(c)
        text = BIDI_MARKS.sub("", "\n".join(" ".join(v) for _, v in sorted(lines.items())))
        conf = (sum(confs) / len(confs) / 100.0) if confs else 0.0
        return text, conf, words, g.size


# ----------------------------------------------------------------------------- PDF
def extract_pdf(path, cfg, ocr_factory):
    import pdfplumber
    res = ExtractResult()
    try:
        pdf = pdfplumber.open(path)
    except Exception as e:
        nm = e.__class__.__name__.lower()
        try:
            from pypdf import PdfReader
            if PdfReader(path).is_encrypted:
                raise Encrypted("PDF is password-protected")
        except Encrypted:
            raise
        except Exception:
            pass
        if "password" in nm or "password" in str(e).lower() or "encrypt" in str(e).lower():
            raise Encrypted("PDF is password-protected")
        raise Corrupted(f"unreadable or corrupted PDF: {e}")
    with pdf:
        n = len(pdf.pages)
        if n > cfg["max_pdf_pages"]:
            res.warnings.append(f"only first {cfg['max_pdf_pages']} of {n} pages processed")
            n = cfg["max_pdf_pages"]
        ocr = None
        for i in range(n):
            page = pdf.pages[i]
            loc = f"p{i + 1}"
            try:
                words = page.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=[])
                text = page.extract_text(layout=False) or ""
            except Exception as e:
                words, text = [], ""
                res.warnings.append(f"{loc}: text extraction failed ({e})")
            native_ok = len(text.strip()) >= 25
            if native_ok:
                w = [[x["text"], round(x["x0"], 1), round(x["top"], 1), round(x["x1"], 1), round(x["bottom"], 1)]
                     for x in words[:8000]]
                res.segments.append(Segment("page", loc, clean_multiline(text), "native", 0.97, w,
                                            float(page.width), float(page.height)))
                try:
                    for ti, t in enumerate(page.find_tables()):
                        rows = [[clean(c) if c else "" for c in r] for r in t.extract()]
                        if len(rows) >= 2 and max(len(r) for r in rows) >= 2:
                            res.tables.append(Table(loc, rows, "pdf-lines", 0.85, ti))
                    if not [t for t in res.tables if t.loc == loc]:   # text-aligned tables (no ruling lines)
                        for ti, t in enumerate(page.find_tables({"vertical_strategy": "text", "horizontal_strategy": "text"})):
                            rows = [[clean(c) if c else "" for c in r] for r in t.extract()]
                            if len(rows) >= 3 and max(len(r) for r in rows) >= 3:
                                res.tables.append(Table(loc, rows, "pdf-text-aligned", 0.6, ti, "no ruling lines: verify"))
                except Exception as e:
                    res.warnings.append(f"{loc}: table detection failed ({e})")
            if (not native_ok) or (page.images and len(text.strip()) < 200):
                # scanned / image-only page: render and OCR
                try:
                    import pypdfium2 as pdfium
                    if ocr is None:
                        ocr = ocr_factory()
                    doc = pdfium.PdfDocument(path)
                    scale = cfg["ocr_dpi"] / 72.0
                    pil = doc[i].render(scale=scale).to_pil()
                    t, conf, w, (iw, ih) = ocr.run(pil)
                    doc.close()
                    if t.strip() and not native_ok:
                        # words are in rendered-pixel space; store page size in pixels for correct preview scaling
                        res.segments.append(Segment("ocr", loc, t, "ocr", conf, w[:8000], iw, ih))
                        res.tables.extend(tables_from_ocr(loc, w, conf))
                        if conf < 0.6:
                            res.warnings.append(f"{loc}: low OCR confidence {conf:.2f}")
                    elif not native_ok:
                        res.warnings.append(f"{loc}: no text found")
                except Unsupported as e:
                    res.warnings.append(f"{loc}: {e}")
                except Exception as e:
                    res.warnings.append(f"{loc}: OCR failed ({e})")
    return res


def clean_multiline(t):
    return "\n".join(clean(l) for l in t.replace("\x00", "").splitlines() if l.strip())


def tables_from_ocr(loc, words, conf):
    """Heuristic table recovery from OCR word boxes: group into rows by y, split into columns on wide gaps.
    Marked low confidence: intended to be verified/corrected in the table viewer."""
    if len(words) < 12:
        return []
    ws = sorted(words, key=lambda w: ((w[2] + w[4]) / 2, w[1]))
    hs = sorted(w[4] - w[2] for w in ws)
    med_h = hs[len(hs) // 2] or 10
    rows, cur, cy = [], [], None
    for w in ws:
        y = (w[2] + w[4]) / 2
        if cy is None or abs(y - cy) <= med_h * 0.6:
            cur.append(w); cy = y if cy is None else (cy + y) / 2
        else:
            rows.append(cur); cur = [w]; cy = y
    if cur:
        rows.append(cur)
    gap = med_h * 2.2
    grid = []
    for r in rows:
        r = sorted(r, key=lambda w: w[1])
        cells, cell = [], [r[0]]
        for w in r[1:]:
            if w[1] - cell[-1][3] > gap:
                cells.append(cell); cell = [w]
            else:
                cell.append(w)
        cells.append(cell)
        grid.append(cells)
    multi = [r for r in grid if len(r) >= 3]
    if len(multi) < 3:
        return []
    # take the longest run of consecutive multi-cell rows with a stable column count
    best, run = [], []
    for r in grid:
        if len(r) >= 3 and (not run or abs(len(r) - len(run[-1])) <= 1):
            run.append(r)
        else:
            if len(run) > len(best): best = run
            run = [r] if len(r) >= 3 else []
    if len(run) > len(best): best = run
    if len(best) < 3:
        return []
    ncol = max(len(r) for r in best)
    out = [[" ".join(w[0] for w in c) for c in r] + [""] * (ncol - len(r)) for r in best]
    return [Table(loc, out, "ocr-geometry", min(0.55, conf), 0, "heuristic from OCR layout: verify before use")]


# ----------------------------------------------------------------------------- images
def extract_image(path, cfg, ocr_factory):
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = cfg["max_ocr_pixels"] * 2
    res = ExtractResult()
    try:
        im = Image.open(path)
        frames = getattr(im, "n_frames", 1)
    except Exception as e:
        raise Corrupted(f"unreadable image: {e}")
    ocr = ocr_factory()
    for fi in range(min(frames, 200)):
        try:
            im.seek(fi)
            t, conf, words, (w, h) = ocr.run(im.copy())
        except Unsupported:
            raise
        except Exception as e:
            res.warnings.append(f"frame {fi + 1}: OCR failed ({e})")
            continue
        loc = "image" if frames == 1 else f"frame{fi + 1}"
        if t.strip():
            res.segments.append(Segment("ocr", loc, t, "ocr", conf, words[:8000], w, h))
            res.tables.extend(tables_from_ocr(loc, words, conf))
            if conf < 0.6:
                res.warnings.append(f"{loc}: low OCR confidence {conf:.2f}")
        else:
            res.warnings.append(f"{loc}: no text found")
    return res


# ----------------------------------------------------------------------------- Office
def extract_docx(path, cfg, _):
    check_zip_safe(path)
    import docx
    res = ExtractResult()
    d = docx.Document(path)
    from docx.table import Table as DT
    from docx.text.paragraph import Paragraph
    body, ti = [], 0
    for el in d.element.body.iterchildren():
        tag = el.tag.rsplit("}", 1)[-1]
        if tag == "p":
            t = clean(Paragraph(el, d).text)
            if t: body.append(t)
        elif tag == "tbl":
            tb = DT(el, d)
            rows = [[clean(c.text) for c in r.cells] for r in tb.rows]
            res.tables.append(Table(f"table {ti + 1}", dedupe_merged(rows), "docx-native", 0.98, ti))
            body.append("\n".join(" | ".join(r) for r in rows))
            ti += 1
    for s in d.sections:
        for p in list(s.header.paragraphs) + list(s.footer.paragraphs):
            if clean(p.text): body.append(clean(p.text))
    chunk = 60
    for i in range(0, len(body), chunk):
        res.segments.append(Segment("text", f"block {i // chunk + 1}", "\n".join(body[i:i + chunk]), "native", 1.0))
    return res


def dedupe_merged(rows):
    # python-docx repeats merged cells in each grid position; collapse consecutive identical cells only when
    # the whole row would otherwise be duplicated (keeps legitimately equal neighbouring values elsewhere)
    return rows


def extract_pptx(path, cfg, _):
    check_zip_safe(path)
    from pptx import Presentation
    res = ExtractResult()
    prs = Presentation(path)
    for si, slide in enumerate(prs.slides, 1):
        texts = []
        def walk(shapes):
            for sh in shapes:
                if sh.shape_type == 6 and hasattr(sh, "shapes"):
                    walk(sh.shapes)
                if getattr(sh, "has_text_frame", False) and sh.has_text_frame:
                    t = clean(sh.text_frame.text)
                    if t: texts.append(t)
                if getattr(sh, "has_table", False) and sh.has_table:
                    rows = [[clean(c.text) for c in r.cells] for r in sh.table.rows]
                    res.tables.append(Table(f"slide {si}", rows, "pptx-native", 0.98, len(res.tables)))
                    texts.append("\n".join(" | ".join(r) for r in rows))
        walk(slide.shapes)
        if slide.has_notes_slide:
            n = clean(slide.notes_slide.notes_text_frame.text)
            if n: texts.append("[notes] " + n)
        if texts:
            res.segments.append(Segment("slide", f"slide {si}", "\n".join(texts), "native", 1.0))
    return res


def extract_xlsx(path, cfg, _):
    check_zip_safe(path)
    import openpyxl
    res = ExtractResult()
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True, keep_vba=False)   # macros never executed
    for ws in wb.worksheets:
        rows, n = [], 0
        for r in ws.iter_rows(values_only=True):
            n += 1
            if n > 200000:
                res.warnings.append(f"{ws.title}: truncated at 200000 rows"); break
            rows.append(["" if v is None else (v.isoformat(sep=" ") if hasattr(v, "isoformat") else str(v)) for v in r])
        while rows and not any(c.strip() for c in rows[-1]): rows.pop()
        if not rows: continue
        text_lines = [" | ".join(c for c in r if c.strip()) for r in rows]
        for i in range(0, len(text_lines), 400):
            res.segments.append(Segment("sheet", f"{ws.title}" + (f" r{i + 1}" if len(text_lines) > 400 else ""),
                                        "\n".join(l for l in text_lines[i:i + 400] if l), "native", 1.0))
        res.tables.append(Table(ws.title, rows[:50000], "xlsx-native", 0.99, len(res.tables)))
    wb.close()
    return res


def extract_csv(path, cfg, _):
    raw = open(path, "rb").read(200_000_000)
    txt = decode_bytes(raw)
    delim = "\t" if path.lower().endswith(".tsv") else None
    if delim is None:
        try: delim = csv.Sniffer().sniff(txt[:20000], delimiters=",;\t|").delimiter
        except Exception: delim = ","
    rows = [[clean(c) for c in r] for r in csv.reader(io.StringIO(txt), delimiter=delim)]
    res = ExtractResult()
    if rows:
        res.tables.append(Table("csv", rows[:100000], "csv-native", 0.99))
        lines = [" | ".join(c for c in r if c) for r in rows]
        for i in range(0, len(lines), 400):
            res.segments.append(Segment("text", f"rows {i + 1}-{min(i + 400, len(lines))}", "\n".join(lines[i:i + 400]), "native"))
    return res


def extract_text(path, cfg, _):
    txt = decode_bytes(open(path, "rb").read(200_000_000))
    return text_result(txt)


def text_result(txt, method="native"):
    res = ExtractResult()
    lines = txt.replace("\x00", "").splitlines()
    for i in range(0, len(lines), 200):
        chunk = "\n".join(lines[i:i + 200])
        if chunk.strip():
            res.segments.append(Segment("text", f"lines {i + 1}-{min(i + 200, len(lines))}", chunk, method))
    return res


def extract_rtf(path, cfg, _):
    s = decode_bytes(open(path, "rb").read(100_000_000))
    s = re.sub(r"\\'([0-9a-f]{2})", lambda m: bytes([int(m.group(1), 16)]).decode("cp1252", "replace"), s)
    s = re.sub(r"\\u(-?\d+)\??", lambda m: chr(int(m.group(1)) % 65536), s)
    s = re.sub(r"\\(par|line)\b", "\n", s)
    s = re.sub(r"\{\\\*[^{}]*\}", "", s)
    s = re.sub(r"\\[a-zA-Z]+-?\d* ?", "", s)
    s = re.sub(r"[{}]", "", s)
    return text_result(s)


class _H(HTMLParser):
    def __init__(self):
        super().__init__(); self.out = []; self.skip = 0; self.rows = []; self.row = None; self.cell = None; self.tables = []
    def handle_starttag(self, t, a):
        if t in ("script", "style"): self.skip += 1
        if t == "table": self.rows = []
        if t == "tr": self.row = []
        if t in ("td", "th"): self.cell = []
        if t in ("br", "p", "div", "li", "tr", "h1", "h2", "h3"): self.out.append("\n")
    def handle_endtag(self, t):
        if t in ("script", "style"): self.skip = max(0, self.skip - 1)
        if t in ("td", "th") and self.row is not None and self.cell is not None:
            self.row.append(clean("".join(self.cell))); self.cell = None
        if t == "tr" and self.row is not None:
            self.rows.append(self.row); self.row = None
        if t == "table" and self.rows:
            self.tables.append(self.rows); self.rows = []
    def handle_data(self, d):
        if self.skip: return
        self.out.append(d)
        if self.cell is not None: self.cell.append(d)


def extract_html(path, cfg, _):
    p = _H(); p.feed(decode_bytes(open(path, "rb").read(100_000_000)))
    res = text_result(clean_multiline("".join(p.out)))
    for i, rows in enumerate(p.tables):
        res.tables.append(Table(f"table {i + 1}", rows, "html-native", 0.95, i))
    return res


def extract_xml(path, cfg, _):
    raw = open(path, "rb").read(100_000_000)
    import xml.etree.ElementTree as ET
    if re.search(rb"<!ENTITY", raw, re.I):
        raise Unsupported("XML with entity declarations rejected (XXE / entity-expansion protection)")
    root = ET.fromstring(raw)
    parts = [" ".join(t for t in e.itertext() if t.strip()) for e in root.iter() if (e.text or "").strip()]
    return text_result("\n".join(f"{e.tag.rsplit('}', 1)[-1]}: {clean(e.text)}" for e in root.iter() if (e.text or '').strip()))


def extract_json(path, cfg, _):
    data = json.loads(decode_bytes(open(path, "rb").read(100_000_000)))
    lines = []
    def walk(o, p=""):
        if isinstance(o, dict):
            for k, v in o.items(): walk(v, f"{p}.{k}" if p else k)
        elif isinstance(o, list):
            for i, v in enumerate(o): walk(v, f"{p}[{i}]")
        else:
            lines.append(f"{p}: {o}")
    walk(data)
    return text_result("\n".join(lines))


def extract_odf(path, cfg, _):
    check_zip_safe(path)
    import xml.etree.ElementTree as ET
    ns = {"t": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
          "tb": "urn:oasis:names:tc:opendocument:xmlns:table:1.0"}
    with zipfile.ZipFile(path) as z:
        raw = z.read("content.xml")
    if b"<!ENTITY" in raw:
        raise Unsupported("ODF content with entity declarations rejected")
    root = ET.fromstring(raw)
    res = ExtractResult()
    paras = ["".join(p.itertext()).strip() for p in root.iter("{%s}p" % ns["t"]) if "".join(p.itertext()).strip()]
    res = text_result("\n".join(paras))
    for i, tb in enumerate(root.iter("{%s}table" % ns["tb"])):
        rows = []
        for tr in tb.iter("{%s}table-row" % ns["tb"]):
            row = []
            for td in tr:
                if td.tag.endswith("table-cell"):
                    row += ["".join(td.itertext()).strip()] * int(td.get("{%s}number-columns-repeated" % ns["tb"], "1") if int(td.get("{%s}number-columns-repeated" % ns["tb"], "1")) < 50 else 1)
            if any(row): rows.append(row)
        if rows:
            res.tables.append(Table(tb.get("{%s}name" % ns["tb"], f"table {i + 1}"), rows, "odf-native", 0.95, i))
    return res


def extract_legacy(path, cfg, _):
    """DOC/PPT/XLS: converted with LibreOffice headless if installed (optional component)."""
    import shutil, subprocess, tempfile
    soffice = shutil.which("soffice") or shutil.which("soffice.exe") or cfg.get("soffice_cmd")
    if not soffice:
        raise Unsupported("legacy binary Office format: install LibreOffice (optional) or re-save as DOCX/PPTX/XLSX")
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    target = {"doc": "docx", "ppt": "pptx", "xls": "xlsx"}[ext]
    with tempfile.TemporaryDirectory() as td:
        from .paths import no_window_flags
        subprocess.run([soffice, "--headless", "--norestore", "--convert-to", target, "--outdir", td, path],
                       check=True, capture_output=True, timeout=180, creationflags=no_window_flags(),
                       env={**os.environ, "HOME": td})
        out = os.path.join(td, os.path.splitext(os.path.basename(path))[0] + "." + target)
        r = {"docx": extract_docx, "pptx": extract_pptx, "xlsx": extract_xlsx}[target](out, cfg, None)
    r.warnings.append("converted from legacy format via LibreOffice")
    return r


# ----------------------------------------------------------------------------- DXF / drawings
TITLE_KEYS = {
    "drawing_no": r"(?:DWG|DRAWING)\.?\s*(?:NO|NUMBER|#)\.?",
    "title": r"TITLE",
    "revision": r"REV(?:ISION)?\.?",
    "scale": r"SCALE",
    "date": r"DATE",
    "drawn": r"DRAWN(?: BY)?",
    "checked": r"CHECKED(?: BY)?",
}


def extract_dxf(path, cfg, _):
    import ezdxf
    res = ExtractResult()
    try:
        doc = ezdxf.readfile(path)
    except Exception as e:
        raise Corrupted(f"unreadable DXF: {e}")
    items = []   # (text, x, y, kind)
    def add(t, x, y, kind):
        t = clean(re.sub(r"\\[A-Za-z][^;]*;|[{}]", "", t or ""))
        if t: items.append((t, round(x, 2), round(y, 2), kind))
    layouts = [doc.modelspace()] + [l for l in doc.layouts if l.name != "Model"]
    for lay in layouts:
        for e in lay.query("TEXT MTEXT"):
            try:
                if e.dxftype() == "TEXT": add(e.dxf.text, e.dxf.insert.x, e.dxf.insert.y, "text")
                else: add(e.text, e.dxf.insert.x, e.dxf.insert.y, "mtext")
            except Exception: pass
        for e in lay.query("INSERT"):
            try:
                for a in e.attribs:
                    add(f"{a.dxf.tag}: {a.dxf.text}", a.dxf.insert.x, a.dxf.insert.y, "attrib")
            except Exception: pass
        for e in lay.query("DIMENSION"):
            try:
                m = e.dxf.get("text", "") or ""
                meas = e.get_measurement() if hasattr(e, "get_measurement") else None
                t = m if m and m != "<>" else (f"{float(meas):.2f}" if isinstance(meas, (int, float)) else "")
                if t: add("DIM " + str(t), e.dxf.defpoint.x, e.dxf.defpoint.y, "dimension")
            except Exception: pass
    if not items:
        res.warnings.append("no text/attribute/dimension entities found")
        return res
    items.sort(key=lambda i: (-i[2], i[1]))
    text = "\n".join(f"{t}" for t, *_ in items)
    words = [[t, x, y, x, y] for t, x, y, _k in items]
    res.segments.append(Segment("drawing", "model", text, "native-vector", 0.97, words))
    # title-block style attribute pairs
    pairs = [("Key", "Value")]
    for t, x, y, k in items:
        if k == "attrib" and ": " in t:
            a, b = t.split(": ", 1); pairs.append((a, b))
    if len(pairs) > 1:
        res.tables.append(Table("title-block attributes", [list(p) for p in pairs], "dxf-attribs", 0.95))
    return res


def extract_dwg(path, cfg, _):
    raise Unsupported("native DWG is not read directly (proprietary format). Export to DXF or PDF from AutoCAD, "
                      "or configure an ODA File Converter path (optional, separately licensed)")


DISPATCH = {
    "pdf": extract_pdf, "image": extract_image, "docx": extract_docx, "pptx": extract_pptx, "xlsx": extract_xlsx,
    "csv": extract_csv, "text": extract_text, "rtf": extract_rtf, "odf": extract_odf, "html": extract_html,
    "xml": extract_xml, "json": extract_json, "dxf": extract_dxf, "legacy": extract_legacy, "dwg": extract_dwg,
}


def extract_file(path, cfg, ocr_factory=None):
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    kind = SUPPORTED.get(ext)
    if not kind:
        raise Unsupported(f"unsupported file type .{ext}")
    if ocr_factory is None:
        ocr_factory = lambda: OCR(cfg)
    return DISPATCH[kind](path, cfg, ocr_factory)
