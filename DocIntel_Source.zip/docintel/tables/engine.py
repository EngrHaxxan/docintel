"""Orchestration: PDF -> headings, strips, grid regions, stitched tables (strategy ladder with quality scores)."""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from .geometry import load_page, find_running_text, visible_words, clip_page, with_fill_edges, drop_ignored_strokes
from .grid import find_regions, build_grid, detect_header, _has_v
from .assemble import assemble, _same_header, make_headers
from .sections import detect_headings, make_strips
from .borderless import find_borderless
from .model import Table


@dataclass
class Cand:
    pd: object
    grid: object
    hdr: tuple
    heading: object
    own_heading: bool
    method: str = "stroke-grid"


@dataclass
class Analysis:
    path: str
    n_pages: int
    headings: list
    tables: list
    failures: list = field(default_factory=list)   # (page, message) plain-English
    discarded: list = field(default_factory=list)  # tiny header-less fragments that look like page furniture
    seconds: float = 0.0


def _jaccard(a, b):
    return len(a & b) / len(a | b) if (a | b) else 1.0


def split_region(pd, g):
    """A region can hold several stacked tables: a new bold header band whose column structure differs starts a new table."""
    nb = g.nb
    sig = []
    for k in range(nb):
        mid = (g.bands[k][0] + g.bands[k][1]) / 2
        sig.append({round(e) for e in g.edges if _has_v(pd.vs, e, mid)})
    def hdr(k): return g.band_bold[k] >= 0.5 and not g.band_label[k] and not g.band_empty[k]
    def prev_nonempty(k):
        j = k - 1
        while j >= 0 and g.band_empty[j]:
            j -= 1
        return j
    cuts = []
    for k in range(1, nb):
        p = prev_nonempty(k)
        if p >= 0 and hdr(k) and not hdr(p) and not g.band_label[p] and _jaccard(sig[k], sig[p]) < 0.9:
            cuts.append(k)
    # empty bands crossed by no inner vertical stroke separate two different tables
    outer = {round(g.edges[0]), round(g.edges[-1])}
    seps = [k for k in range(nb) if g.band_empty[k] and not (sig[k] - outer) and 0 < k < nb - 1]
    if not cuts and not seps:
        return [g.bbox]
    bounds = sorted(set(cuts) | set(seps))
    parts, start = [], 0
    for k in bounds:
        if k in seps:
            if k > start:
                parts.append((start, k - 1))
            start = k + 1
        else:
            if k > start:
                parts.append((start, k - 1))
            start = k
    if start < nb:
        parts.append((start, nb - 1))
    return [(g.bbox[0], g.bands[a][0], g.bbox[2], g.bands[b][1]) for a, b in parts if b >= a]


def _edges_match(a, b, tol=2.5):
    if len(a) != len(b):
        return False
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def _continues(prev: Cand, c: Cand):
    if c.pd.number != prev.pd.number + 1:
        return False
    tol = 7.0 if (prev.method == 'borderless-alignment' and c.method == 'borderless-alignment') else 2.5
    if prev.method != c.method or not _edges_match(prev.grid.edges, c.grid.edges, tol):
        return False
    if prev.grid.bbox[3] < 0.6 * prev.pd.height or c.grid.bbox[1] > 0.4 * c.pd.height:
        return False
    if c.own_heading and (prev.heading is None or c.heading.text != prev.heading.text):
        if c.hdr[1] > 0 or c.heading is None:
            return False                                    # a new section that has its own header = a new table
        c.grid.lead_label = c.heading.text                  # heading band at the top of the page, rows continue: becomes a group label
    h0 = prev.hdr[1]
    k = 0
    while k < c.grid.nb and c.grid.band_empty[k]:
        k += 1
    if c.hdr[1] > 0:                                        # the next page starts with a header-looking row
        hh = make_headers(prev.grid, prev.hdr[2], h0)
        if h0 > 0 and _same_header(c.grid, k, h0, hh):
            return True                                     # repeated header: dropped later
        if c.grid.band_bold[k] >= 0.5:                      # a different bold header = a new table
            return False
        c.hdr = (c.hdr[0], 0, c.hdr[2], "")                 # fill-only "header" was really data
    return True


def _continues_same_page(prev: Cand, c: Cand):
    """A heading band INSIDE a table (e.g. 'CATEGORY-2 ...') must not cut the table in two: same columns, no header of its own,
    directly below -> same table; the heading becomes the group label of the rows below."""
    if c.pd.number != prev.pd.number or c.grid.bbox[1] < prev.grid.bbox[1] or c.method != prev.method:
        return False
    if c.hdr[1] > 0 or c.grid.bbox[1] - prev.grid.bbox[3] > 45 or not (c.heading is not None and c.own_heading):
        return False
    if not _edges_match(prev.grid.edges, c.grid.edges, 2.5):
        # extra column lines (e.g. from a neighbouring box) are tolerated when every column of the table above is present
        pe, ce = prev.grid.edges, c.grid.edges
        hit = sum(1 for a in pe if any(abs(a - b) <= 2.5 for b in ce))
        if hit < 0.8 * len(pe):
            return False
        g2 = build_grid(c.pd, c.grid.bbox, force_edges=pe)
        if g2 is None:
            return False
        c.grid, c.hdr = g2, (c.hdr[0], 0, c.hdr[2], "")
    return True


def _extend_top(c: Cand):
    """Rows of a continued table can start above the first border on the next page (cut by the page break)."""
    pd, g = c.pd, c.grid
    first = g.bands[0][0]
    x0, x1 = g.edges[0], g.edges[-1]
    ws = [w for w in visible_words(pd) if w["bottom"] < first + 0.5 and x0 - 1 <= (w["x0"] + w["x1"]) / 2 <= x1 + 1 and w["top"] > 20]
    if not ws:
        return g
    ext = min(w["top"] for w in ws) - 1.0
    g2 = build_grid(pd, g.bbox, extend_top=ext)
    if g2 is not None:
        g2.notes.append("rows above the first border on this page were included")
        return g2
    return g


def _mark_running_tables(pds):
    """A part of the page whose text repeats at the same place on most pages is a running header/footer box."""
    import re, collections
    if len(pds) < 3:
        return
    seen = collections.defaultdict(set)
    regs = {}
    for pd in pds:
        for r in find_regions(pd, (0, 0, pd.width, pd.height)):
            g = build_grid(pd, r)
            if g is None:
                continue
            for part in split_region(pd, g):
                if not (part[3] < 0.3 * pd.height or part[1] > 0.72 * pd.height):
                    continue
                ws = [w["text"] for w in pd.words if part[0] - 1 <= (w["x0"] + w["x1"]) / 2 <= part[2] + 1 and part[1] - 1 <= (w["top"] + w["bottom"]) / 2 <= part[3] + 1]
                if not ws:
                    continue
                key = (round(part[0] / 6), round(part[1] / 6), re.sub(r"\d+", "#", " ".join(sorted(ws))))
                seen[key].add(pd.number); regs[(pd.number, key)] = part
    need = max(3, int(0.5 * len(pds)))
    byn = {p.number: p for p in pds}
    for (pn, key), r in regs.items():
        if len(seen[key]) >= need:
            byn[pn].ignore.append((r[0] - 1, r[1] - 3, r[2] + 1, r[3] + 3))


def _inside(r, b):
    cx, cy = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
    return b[0] <= cx <= b[2] and b[1] <= cy <= b[3]


def _strip_cands(pdv, bbox, h, own, pd_orig, method="stroke-grid"):
    out, used_boxes = [], []
    for reg in find_regions(pdv, bbox):
        g = build_grid(pdv, reg)
        if g is None:
            continue
        for part in split_region(pdv, g):
            if any(_inside(part, b) for b in pd_orig.ignore):
                continue
            gg = g if part == g.bbox else build_grid(pdv, part)
            if gg is None:
                continue
            out.append(Cand(pdv, gg, detect_header(gg), h, own, method))
            used_boxes.append(gg.bbox)
    if method == "stroke-grid":
        for bg in find_borderless(pdv, bbox, used_boxes):
            out.append(Cand(pdv, bg, detect_header(bg), h, own, "borderless-alignment"))
    return out


def _score(cands):
    """Rows that sit in tables with a real header row (generic 'Column n' headers count for nothing)."""
    s = 0
    for c in cands:
        if c.hdr[1] > 0:
            s += max(0, c.grid.nb - c.hdr[2] - c.hdr[1])
        elif c.grid.nb >= 3:
            s -= 2                                              # fragments with generic 'Column n' headers count against a pass
    return s


def _poor(cands, pd=None):
    """The stroke pass is 'poor' when it explains little of the page text (tables drawn with coloured cells instead of lines)."""
    if not cands:
        return True
    if pd is None:
        return False
    words = visible_words(pd)
    if len(words) < 30:
        return False
    inside = 0
    for w in words:
        cx, cy = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
        if any(c.grid.bbox[0] - 1 <= cx <= c.grid.bbox[2] + 1 and c.grid.bbox[1] <= cy <= c.grid.bbox[3] for c in cands):
            inside += 1
    return inside / len(words) < 0.75 and sum(1 for c in cands if c.hdr[1] == 0 and c.grid.nb >= 3) >= 2


def analyze_pdf(path, pages=None, progress=None, cancel=None) -> Analysis:
    import pdfplumber
    t0 = time.time()
    fails = []
    with pdfplumber.open(path) as pdf:
        n = len(pdf.pages)
        sel = [p for p in (pages or range(1, n + 1)) if 1 <= p <= n]
        pds = []
        for i, p in enumerate(sel):
            if cancel and cancel():
                break
            try:
                pds.append(load_page(pdf.pages[p - 1], p))
            except Exception as e:                                   # keep going; report plainly
                fails.append((p, f"Page {p} could not be read ({type(e).__name__})."))
            finally:
                pdf.pages[p - 1].flush_cache()
            if progress:
                progress(i + 1, len(sel), "reading pages")
    find_running_text(pds)
    _mark_running_tables(pds)
    pds = [drop_ignored_strokes(p) for p in pds]
    headings = detect_headings(pds)
    cands, carry = [], None
    for pd in pds:
        strips = []
        for bbox, h in make_strips(pd, headings, carry):
            own = h is not None and h is not carry
            if h is not None:
                carry = h
            strips.append((bbox, h, own))
        found = [c for bbox, h, own in strips for c in _strip_cands(clip_page(pd, bbox), bbox, h, own, pd)]
        if _poor(found, pd):                                   # tables drawn only with coloured cells: cell edges act as borders
            pdf_ = with_fill_edges(pd)
            alt = [c for bbox, h, own in strips for c in _strip_cands(clip_page(pdf_, bbox), bbox, h, own, pd, "fill-edge-grid")]
            if _score(alt) > _score(found):
                found = alt
        cands.extend(found)
    groups = []
    for c in cands:
        for grp in reversed(groups):
            if grp[-1].pd.number == c.pd.number and _continues_same_page(grp[-1], c):
                c.grid.lead_label = c.heading.text
                grp.append(c); break
            if grp[-1].pd.number == c.pd.number - 1 and _continues(grp[-1], c):
                c.grid = _extend_top(c)
                if getattr(c.grid, "lead_label", None) is None and getattr(c, "_ll", None):
                    pass
                grp.append(c); break
        else:
            groups.append([c])
    tables, discarded = [], []
    for grp in groups:
        try:
            t = assemble([c.grid for c in grp], grp[0].hdr, source=str(path), method=grp[0].method)
        except Exception as e:
            fails.append((grp[0].pd.number, f"A table starting on page {grp[0].pd.number} could not be read ({type(e).__name__}: {e})."))
            continue
        h = grp[0].heading
        t.section = h.text if h else ""
        t.section_level = h.level if h else 0
        if not t.title:
            t.title = t.section
        for c in grp[1:]:
            for note in c.grid.notes:
                t.quality_notes.append(f"page {c.pd.number}: {note}")
        if all(h.name.startswith("Column ") for h in t.headers) and len(t.rows) <= 6:
            discarded.append(t)                                  # page furniture (title blocks, stamps): kept out of the lists
            continue
        tables.append(t)
    return Analysis(str(path), n, headings, tables, fails, discarded, time.time() - t0)
