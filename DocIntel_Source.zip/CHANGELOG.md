# Changelog

## 1.2.0-m2 (Milestone 2: stored tables, value model, Excel options)
- Database schema v2 (additive, old libraries upgrade automatically): `doc_sections`, `doc_tables`, `table_rows`, `table_cells` (raw original-layout and normalized text, suggested kind, flags, user correction stored apart, reviewed mark). Tables are cached per file content + engine version; unchanged files are reused.
- NEW `docintel/tables/store.py` (save/load/list, `set_correction` / `clear_correction` / `mark_reviewed`, `rename_header` keeps the PDF wording, hide columns) and `service.py`; NEW `Library.extract_tables(file_ids, force, control, progress)`. Friendly messages for unsupported / missing / unreadable files (technical detail only in the log).
- NEW `docintel/tables/values.py`: suggests a kind (text, integer, decimal, percentage, date, datetime, currency, duration, boolean, identifier, unit_value, special, empty); never rejects or changes the raw text; ambiguous dates are not converted.
- Old field extraction: new types `percentage` ("65%" -> 0.65, original kept) and `auto` (never rejects).
- Excel export v2: raw-text (default) or typed values (typed adds a raw-text companion sheet), original/normalized layouts, per-table or combined sheets (tables with identical columns stacked, source columns identify them), leaf or joined header names, hidden columns, user corrections included with a "Corrected cells" column, rollover to extra sheets at the Excel row limit, fast write-only writer, valid Excel tables.
- Tests: `tests/test_tables_store.py` (17).

## 1.1.0-m1 (Milestone 1: new table & section engine)
- NEW package `docintel/tables/`: general stroke-grid table reader (row bands from horizontal strokes, columns from vertical strokes, merged cells = missing separator strokes), header detection (bold/fill/row-number evidence, multi-level headers, rotated header text), cross-page stitching with repeated-header removal, rows split by page breaks, horizontal merges, running page-header boxes ignored, borderless tables by text alignment, heading/section detection with side-by-side headings, fuzzy section matching (always shown for confirmation).
- NEW Excel export (`docintel/tables/export.py`): per table an "Original layout" sheet (blanks where the PDF merges cells) and a "Normalized" sheet (merged values repeated), raw text preserved (cells formatted as text), source/page/section/method/review columns, Summary sheet.
- NEW CLI: `python -m docintel tables FILE.pdf [--section "Construction Activities"] [--pages 5-41] [--out result.xlsx]`.
- NEW tests `tests/test_tables_engine.py` (19) and `tools/table_accuracy.py`; real PDFs under `tests/real_pdfs/`.
- Not yet wired into the GUI/library/database (Milestones 2-4). Scanned-page table reconstruction (OCR geometry) is not part of Milestone 1.

## 1.0.1 (fixes after the first real Windows build)
- FIXED self-check reported failure when optional LibreOffice is absent (broke GUI smoke test and "doctor" on Windows).
- FIXED export row order depended on file scan order (records now ordered by source path, then position).
- FIXED packaged app could not read DXF: numpy was excluded from the build but ezdxf requires it (numpy now bundled and pinned).
- ADDED `prototypes/scal_spike2.py`: proof of method for complete extraction of the 41-page SCAL table (1,000/1,000 rows) - not yet part of the app.

## 1.0.0 (Windows release candidate) - changes since the first delivery
**Windows readiness**
- NEW `paths.py`: installed vs portable data folders, resource folders, safe long-path handling. Portable marker file `portable.txt`.
- FIXED scanner would have stored `\\?\`-prefixed paths and failed relative-path calculations on Windows long paths.
- FIXED Tesseract language path now passed via `TESSDATA_PREFIX` (quoted CLI option broke on spaces/backslashes); bundled Tesseract chosen per OS.
- NEW case-insensitive duplicate-root detection on Windows; no console windows for helper processes; DPI awareness; windowed-build stdout handling; UTF-8 CLI output.
- FIXED build spec (`docintel.spec`) had a comment swallowing the closing parenthesis - the earlier delivery's build script could not have worked.
- NEW app icon, GUI+CLI executables, Inno Setup installer (Start Menu, optional desktop icon, uninstall with optional data removal), portable zip.
- NEW GitHub Actions Windows pipeline (tests, build, portable/offline/installer checks, release), pinned Tesseract + language files by SHA-256, `constraints.txt`.
- NEW `tools/smoke_packaged.py` end-to-end test of packaged builds; `DocIntel.exe gui --smoke-test`.

**For non-technical users**
- NEW "Start here" page, first-run welcome and environment check, Help menu, plain-English error messages with next steps (`friendly.py`),
  drag-and-drop folders, "Describe fields I want" helper, indexing-complete prompt, 11-page User Guide PDF, click-by-click build guide.

**OCR**
- CORRECTED earlier finding: Arabic OCR was *not* poor; the earlier test image was generated incorrectly. With correctly shaped text, English+Arabic read at ~100 % on clean, skewed, low-resolution, blurred, JPEG-damaged and speckled images.
- NEW small-angle deskew (Pillow only), automatic denoise retry for low-confidence pages, removal of invisible bidi marks from OCR output.

**Excel**
- NEW templates containing charts, pictures/shapes, pivot tables, slicers or form controls are blocked from being rewritten unless the user chooses a safer results-only workbook or explicitly accepts losing those items (original is never changed).
- FIXED update-by-key matching when the key column holds real dates/numbers.

**Tests**: 43 automated tests (was 34) + 4 platform-specific skips.
