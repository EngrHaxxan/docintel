# Speed (v1.5.0-m5)
- **What was slow:** for every PDF page the index ran three slow pdfplumber passes (word boxes, text, table detection).
- **Now:** the search index reads PDF text with pypdfium2. Word boxes (for highlighting) are computed only when needed and then kept. Tables are detected when you extract them (Extract to Excel / batch jobs), and are then searchable too.
- **OCR** runs only on pages without readable text (before, it also ran, and was thrown away, on pages with a picture and little text).
- **Processing speed** (Settings): Balanced = half the CPU cores, Faster = all but one, Low resource usage = one. With more than one worker, PDFs and images are read in separate processes; if that fails the app silently uses threads.
- Unchanged files are skipped by size + modified time; only new or changed files are read again.
- Measured (Linux, 1 CPU, same 32 files / 87 pages): 82 s before, 0.81 s now. 162 files / 267 pages: 1.74 s. Reproduce: `python tools/benchmark_pdf_index.py 60 100`. Not measured: Windows, many CPU cores, scanned/OCR folders, 1,500-document libraries.
