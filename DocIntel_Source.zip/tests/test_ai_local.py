"""Milestone 9: local model connection layer (tested against a fake local server - NO real language model)."""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fake_llm_server import Fake
from docintel.library import Library
from docintel.llm.provider import OpenAICompatProvider, ProviderError, NoProvider, provider_from_model


class Layer(unittest.TestCase):
    def setUp(self):
        self.srv = Fake(); self.tmp = tempfile.mkdtemp(); self.lib = Library(os.path.join(self.tmp, "h"))

    def tearDown(self):
        self.srv.stop()

    def test_local_detection_and_calls(self):
        p = OpenAICompatProvider(self.srv.url, "fake-chat", embed_model="fake-embed")
        self.assertEqual(p.kind, "local"); self.assertTrue(p.can_embed)
        self.assertEqual(OpenAICompatProvider("https://api.example.com/v1", "m").kind, "remote")
        self.assertEqual(OpenAICompatProvider("http://[::1]:11434/v1", "m").kind, "local")
        self.assertEqual(p.list_models(), ["fake-chat", "fake-embed"])
        ok, msg, secs = p.test(); self.assertTrue(ok, msg); self.assertIn("OK", msg)
        self.assertEqual(len(p.embed(["a b", "c"])), 2)

    def test_friendly_errors(self):
        p = OpenAICompatProvider("http://127.0.0.1:9/v1", "m", timeout=3)
        ok, msg, _ = p.test(); self.assertFalse(ok); self.assertIn("Cannot reach the model server", msg); self.assertIn("running", msg)
        self.srv.mode = "down500"
        ok, msg, _ = OpenAICompatProvider(self.srv.url, "fake-chat").test(); self.assertFalse(ok); self.assertIn("500", msg)

    def test_registry_save_switch_delete(self):
        r = self.lib.ai_models()
        with self.assertRaises(ValueError):
            r.save({"name": "x", "model": ""})
        r.save({"name": "Small", "type": "other", "base_url": self.srv.url, "model": "fake-chat"})
        self.assertEqual(r.active_name(), "Small")                                  # the first saved model becomes active
        r.save({"name": "Big", "type": "ollama", "model": "qwen-big"})
        self.assertEqual(r.get("Big")["base_url"], "http://localhost:11434/v1")      # server type fills the address
        self.assertEqual(r.provider().model, "fake-chat"); r.activate("Big"); self.assertEqual(r.provider().model, "qwen-big")
        self.assertTrue(self.lib.ai_available())                                     # configured = available (not pinged)
        r.delete("Big"); self.assertEqual(r.active_name(), ""); self.assertIsInstance(r.provider(), NoProvider)
        with self.assertRaises(ValueError):
            r.activate("nope")

    def test_offline_guard_allows_this_computer_only(self):
        import socket
        from docintel import diagnostics as D
        D.enforce_offline()
        try:
            self.assertTrue(OpenAICompatProvider(self.srv.url, "fake-chat").test()[0])              # a local model works in offline mode
            s = socket.socket(); s.settimeout(2)
            with self.assertRaises(Exception):
                s.connect(("93.184.216.34", 80))                                                    # the internet does not
        finally:
            socket.socket.connect = D._orig_connect


if __name__ == "__main__":
    unittest.main()
