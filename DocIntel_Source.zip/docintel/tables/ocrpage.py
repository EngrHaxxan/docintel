"""Scanned pages: OCR word boxes become a PageData, so the same table logic (alignment based) can read tables from scans."""
from __future__ import annotations
import collections
from .geometry import PageData


def ocr_pagedata(path, page_no, width, height, engine, dpi=300):
    """-> (PageData or None, note). Renders the page, runs OCR, maps word boxes back to PDF points."""
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(path)
    try:
        img = doc[page_no - 1].render(scale=dpi / 72.0).to_pil()
    finally:
        doc.close()
    text, conf, words, (iw, ih) = engine.run(img)
    if not words:
        return None, "no text was recognised on this scanned page"
    if abs(iw / ih - width / height) > 0.08 * (width / height):
        return None, "the scanned page is rotated in a way that could not be matched to the page; try another scan"
    sx, sy = width / iw, height / ih
    ws = []
    for t, x0, y0, x1, y1, c in words:
        if str(t).strip():
            ws.append({"text": t, "x0": x0 * sx, "x1": x1 * sx, "top": y0 * sy, "bottom": y1 * sy, "size": max(4.0, (y1 - y0) * sy),
                       "bold": False, "fontname": "ocr", "ocr_conf": c})
    sizes = [round(w["size"], 1) for w in ws]
    body = collections.Counter(sizes).most_common(1)[0][0] if sizes else 0.0
    pd = PageData(page_no, float(width), float(height), ws, [], [], [], [], body)
    pd.ocr, pd.ocr_conf = True, float(conf)
    return pd, ""
