"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.6.2-m6"
