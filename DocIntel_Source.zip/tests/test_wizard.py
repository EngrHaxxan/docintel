"""Milestone 3: guided extraction logic (select -> choose -> identify -> preview/correct -> export). Run: python -m unittest tests.test_wizard"""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from openpyxl import load_workbook
from docintel.library import Library
from docintel.wizard import Session, parse_request, match_columns, MODES
from docintel.tables import store

HERE = os.path.dirname(os.path.abspath(__file__))
DAILY = os.path.join(HERE, "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")


class WizardTests(unittest.TestCase):
    def setUp(self):
        from tests.make_table_pdfs import merged_cells
        self.tmp = tempfile.mkdtemp()
        self.d1, self.d2 = os.path.join(self.tmp, "may"), os.path.join(self.tmp, "june")
        os.makedirs(self.d1); os.makedirs(self.d2)
        shutil.copy(DAILY, os.path.join(self.d1, "daily_01.pdf")); shutil.copy(DAILY, os.path.join(self.d2, "daily_02.pdf"))
        merged_cells(os.path.join(self.d2, "other_layout.pdf"))
        self.lib = Library(os.path.join(self.tmp, "home"))
        self.lib.add_root(self.d1); self.lib.add_root(self.d2); self.lib.scan()
        self.s = Session(self.lib)
        self.s.select_all(); self.s.prepare()

    def test_selection_and_counts(self):
        self.assertEqual(self.s.selected_count(), 3)
        fid = self.s.file_ids[0]
        self.s.exclude(fid)
        self.assertEqual(self.s.selected_count(), 2)
        self.s.exclude(fid, False); self.assertEqual(self.s.selected_count(), 3)
        s2 = Session(self.lib); s2.select_roots([r["id"] for r in self.lib.roots() if r["path"].endswith("may")]); self.assertEqual(s2.selected_count(), 1)

    def test_modes_listed(self):
        self.assertEqual([m[0] for m in MODES], ["all_tables", "table", "section", "records", "fields", "text", "custom"])

    def test_headings_and_candidates_need_confirmation(self):
        hs = {h["heading"]: h["documents"] for h in self.s.headings()}
        self.assertEqual(hs["CONSTRUCTION ACTIVITIES"], 2)
        c = self.s.candidates("Construction Work Activities")
        self.assertTrue(c and c[0]["heading"] == "CONSTRUCTION ACTIVITIES")
        self.assertTrue(all("heading" in x and "score" in x for x in c))

    def test_section_extraction_across_documents_and_missing_report(self):
        pv = self.s.build("section", headings=["CONSTRUCTION ACTIVITIES"])
        self.assertEqual([len(e.table.rows) for e in pv], [4, 4])
        self.assertEqual({e.label for e in pv}, {"daily_01.pdf", "daily_02.pdf"})
        self.assertTrue(any("not found in other_layout.pdf" in w for w in self.s.warnings))

    def test_selected_fields_and_not_found_not_invented(self):
        pv = self.s.build("fields", headings=["CONSTRUCTION ACTIVITIES"], fields=["Location", "Activity Description", "Progress", "Estimated Cost"])
        t = pv[0].table
        self.assertEqual([h.name for h in t.headers], ["Location", "Activity Description", "Progress % / 07-Oct-2026", "Progress % / 08-Oct-2026", "Estimated Cost"])
        self.assertEqual(t.rows[0].orig[2:4], ["70%", "100%"])
        self.assertEqual({r.orig[4] for r in t.rows}, {""})
        self.assertTrue(any("Estimated Cost" in w for w in self.s.warnings))
        self.assertTrue(any(f.startswith("review") for f in t.headers[4].flags))

    def test_custom_request(self):
        req = parse_request("Extract every issue from the Issues & Concerns section, including issue description, urgency, owner, status and start date.",
                            [h["heading"] for h in self.s.headings()])
        self.assertEqual(req["section"], "ISSUES & CONCERNS")
        self.assertEqual(req["fields"], ["issue description", "urgency", "owner", "status", "start date"])
        pv = self.s.build("custom", text="Extract every issue from the Issues & Concerns section, including issue description, urgency, owner, status and start date.")
        self.assertEqual(len(pv), 2)
        names = [h.name for h in pv[0].table.headers]
        self.assertEqual(names, ["Description", "Urgency", "Owner", "Status", "Start Date"])
        self.assertEqual(pv[0].table.rows[0].orig, ["Expedite SE response in our request for the handover of as built for existing UGC data", "High", "SE", "Open", "05-May-26"])

    def test_custom_request_nothing_matches_is_honest(self):
        self.s.build("custom", text="show me everything about zebras")
        self.assertTrue(any("matched" in w for w in self.s.warnings))

    def test_matching_records(self):
        pv = self.s.build("records", text="ugc")
        self.assertTrue(pv)
        for e in pv:
            self.assertTrue(all(any("ugc" in v.lower() for v in r.norm + r.orig) for r in e.table.rows))
        self.assertLess(sum(len(e.table.rows) for e in pv), sum(len(e.table.rows) for e in self.s.catalog))

    def test_edit_cell_persists_and_keeps_original(self):
        pv = self.s.build("fields", headings=["CONSTRUCTION ACTIVITIES"], fields=["Progress"])
        e = pv[0]
        self.s.edit_cell(e, 0, 0, "75%")
        self.assertEqual(e.table.rows[0].orig[0], "75%")
        tb = store.load_table(self.lib.db, e.db_id)
        self.assertEqual(tb.rows[0].raw_orig[6], "70%"); self.assertEqual(tb.rows[0].orig[6], "75%")
        with self.assertRaises(ValueError):
            pv2 = self.s.build("fields", headings=["CONSTRUCTION ACTIVITIES"], fields=["Nonexistent thing"])
            self.s.edit_cell(pv2[0], 0, 0, "x")

    def test_mark_uncertain_and_review_count(self):
        pv = self.s.build("section", headings=["ISSUES & CONCERNS"])
        before = self.s.review_count()
        self.s.mark_uncertain(pv[0], 0, 3)
        self.assertEqual(self.s.review_count(), before + 1)
        self.s.mark_uncertain(pv[0], 0, 3, False)
        self.assertEqual(self.s.review_count(), before)

    def test_rename_hide_and_export_arrangements(self):
        pv = self.s.build("section", headings=["CONSTRUCTION ACTIVITIES"])
        self.s.rename_column(pv[0], 5, "Work description")
        self.s.hide_column(pv[0], 9)
        self.assertEqual(pv[0].table.headers[5].renamed_from, "Activity Description")
        self.assertEqual(self.s.suggest_arrangement(), "stacked" if False else self.s.suggest_arrangement())
        p = os.path.join(self.tmp, "out.xlsx")
        self.s.export(p, arrangement="per_table", layouts=("norm",))
        wb = load_workbook(p); self.assertEqual(len(wb.sheetnames), 3)
        files = self.s.export(os.path.join(self.tmp, "per_doc"), arrangement="per_document_files")
        self.assertEqual(sorted(os.path.basename(f) for f in files), ["daily_01.xlsx", "daily_02.xlsx"])
        csvs = self.s.export(os.path.join(self.tmp, "csv"), fmt="csv")
        self.assertEqual(len(csvs), 2)
        head = open(csvs[0], encoding="utf-8-sig").readline()
        self.assertIn("Work description", head); self.assertNotIn("Remarks", head.split("Source file")[0])
        self.assertGreaterEqual(self.lib.db.one("SELECT COUNT(*) FROM exports")[0], 3)

    def test_same_columns_across_documents_stack_by_default(self):
        self.s.build("section", headings=["CONSTRUCTION ACTIVITIES"])
        self.assertEqual(self.s.suggest_arrangement(), "stacked")
        p = os.path.join(self.tmp, "st.xlsx"); self.s.export(p)
        wb = load_workbook(p)
        self.assertEqual(wb[wb.sheetnames[1]].max_row, 9)

    def test_adhoc_file_outside_library(self):
        f = os.path.join(self.tmp, "loose.pdf"); shutil.copy(DAILY, f)
        s = Session(self.lib); s.add_adhoc([f]); s.prepare()
        self.assertEqual(s.selected_count(), 1); self.assertEqual(len(s.catalog), 7)
        pv = s.build("section", headings=["ISSUES & CONCERNS"]); self.assertEqual(len(pv[0].table.rows), 3)
        s.edit_cell(pv[0], 0, 1, "Changed")      # allowed in memory (no database record)
        self.assertEqual(pv[0].table.rows[0].orig[1], "Changed")

    def test_text_mode_uses_indexed_text(self):
        self.lib.index()
        pv = self.s.build("text")
        self.assertTrue(pv and all(len(e.table.rows) > 0 for e in pv))

    def test_unreadable_file_reported_politely(self):
        bad = os.path.join(self.d1, "broken.pdf"); open(bad, "wb").write(b"%PDF-1.4 garbage")
        self.lib.scan(); s = Session(self.lib); s.select_all(); s.prepare()
        st = s.status["broken.pdf"]
        self.assertIn(st[0], ("failed", "no_tables", "partial", "extracted"))
        self.assertNotIn("Traceback", st[1])


if __name__ == "__main__":
    unittest.main()
