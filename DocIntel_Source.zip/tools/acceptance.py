"""Final acceptance run (original prompt section 28, scenarios 1-8). Runs everything on this machine and writes ACCEPTANCE_REPORT.md.
Usage: python tools/acceptance.py [out.md]   (Linux/Windows; needs tests/real_pdfs; tesseract optional for the scan part)"""
import json, os, resource, shutil, sys, tempfile, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tests"))
from openpyxl import load_workbook
from docintel.library import Library
from docintel import batch as B, search as S
from docintel.tables import store

RP = os.path.join(ROOT, "tests", "real_pdfs")
DAILY, SCAL, RACI = (os.path.join(RP, n) for n in ("MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf", "WI-NG-6460-001-001_SCAL_Rev03.pdf", "RACI_Matrix_UGC_Submittals.pdf"))
LINES, RESULTS = [], []


def say(s=""):
    LINES.append(s); print(s, flush=True)


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    say(f"- [{'PASS' if ok else 'FAIL'}] {name}" + (f" - {detail}" if detail else ""))


def rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def new_lib(tmp, name, src):
    lib = Library(os.path.join(tmp, name)); lib.cfg.set("workers", 1)
    for d in ([src] if isinstance(src, str) else src):
        lib.add_root(d)
    lib.scan(); lib.index()
    return lib


def sheet_rows(path, skip=("Summary", "Job report")):
    wb = load_workbook(path, read_only=True)
    return {n: list(wb[n].iter_rows(values_only=True)) for n in wb.sheetnames if n not in skip}


def main(out):
    tmp = tempfile.mkdtemp()
    say("# DocIntel final acceptance report\n")
    say(f"Run on: {sys.platform}, Python {sys.version.split()[0]}. Measured on this machine only (not on a Windows PC with many cores).\n")
    # ------------------------------------------------------------ scenario 1 + 2: many daily reports
    say("## Scenario 1 - Daily construction reports -> one consolidated Excel table")
    src = os.path.join(tmp, "daily"); n_rep = 30
    for i in range(n_rep):
        d = os.path.join(src, f"week{i // 10}"); os.makedirs(d, exist_ok=True); shutil.copy(DAILY, os.path.join(d, f"daily_{i:03d}.pdf"))
    lib = new_lib(tmp, "h1", [os.path.join(src, f"week{k}") for k in range(3)])
    br = B.BatchRunner(lib); roots = [r["id"] for r in lib.roots()]
    t = time.time(); jid = br.run(B.load_profile(lib.db, "Daily report - Construction Activities"), root_ids=roots); dt = time.time() - t
    s = br.summary(jid)
    check("every report processed, none failed", s["processed"] == n_rep and s["failed"] == 0, f"{s['processed']}/{n_rep} in {dt:.1f} s")
    check("4 activity records per report (no unrelated sections)", s["records"] == 4 * n_rep, f"{s['records']} records")
    x1 = os.path.join(tmp, "construction.xlsx"); br.export_job(jid, x1)
    sh = sheet_rows(x1); (name, rows), = sh.items() if len(sh) == 1 else [(None, [])]
    hdr = [str(c) for c in rows[0]] if rows else []
    check("one worksheet holds all records (filterable)", len(sh) == 1 and len(rows) - 1 == 4 * n_rep, f"{len(rows) - 1} data rows")
    check("both progress dates are kept as separate columns (dates in column titles are masked so all days stack; the real dates are in their own columns)", sum(1 for h in hdr if h.startswith("Progress") and " - date" not in h) == 2 and sum(1 for h in hdr if " - date" in h) == 2, str([h for h in hdr if "Progress" in h]))
    check("source document and page columns present", any("Source" in h or "Document" in h for h in hdr) and any("Page" in h for h in hdr), ", ".join(hdr[-5:]))
    first = [str(c) for c in rows[1]]
    check("values exact (70% / 100% / Completed / description kept)", "70%" in first and "100%" in first and "Completed" in first and any("5th layer" in c for c in first), " | ".join(c[:18] for c in first[:9]))
    check("Job report sheet lists every document", len(list(load_workbook(x1, read_only=True)["Job report"].iter_rows(values_only=True))) == n_rep + 1)
    say("\n## Scenario 2 - Issues & Concerns")
    jid2 = br.run(B.load_profile(lib.db, "Daily report - Issues & Concerns"), root_ids=roots); s2 = br.summary(jid2)
    check("3 issue records per report", s2["records"] == 3 * n_rep and s2["failed"] == 0, f"{s2['records']} records")
    x2 = os.path.join(tmp, "issues.xlsx"); br.export_job(jid2, x2); (n2, r2), = sheet_rows(x2).items()
    h2 = [str(c) for c in r2[0]]
    row = [str(c) for c in r2[1]]
    check("issue headers kept (Issue Type, Urgency, Owner, Status...)", all(any(w in h for h in h2) for w in ("Issue Type", "Urgency", "Owner", "Status", "Start Date")), ", ".join(h2[:10]))
    check("values exact (High / Open / 05-May-26 / 156)", "High" in row and "Open" in row and "05-May-26" in row and "156" in row, " | ".join(c[:20] for c in row[:9]))
    # ------------------------------------------------------------ scenario 3: SCAL
    say("\n## Scenario 3 - SCAL complete table (41 pages)")
    d3 = os.path.join(tmp, "scal"); os.makedirs(d3); shutil.copy(SCAL, d3)
    lib3 = new_lib(tmp, "h3", d3); br3 = B.BatchRunner(lib3)
    prof = B.new_profile("scal", table={"headers": ["Sr.", "Main Activity Name", "Main Activity Test Code", "Sub-Activity Name", "Sub-Activity Test Code", "Duration In Hours", "Unit", "Remarks"], "min_match": 0.75},
                         output={"arrangement": "per_table", "layouts": ["norm", "orig"]})
    t = time.time(); j3 = br3.run(prof, root_ids=[lib3.roots()[0]["id"]]); dt3 = time.time() - t
    check("1,000 of 1,000 rows extracted across all pages", br3.summary(j3)["records"] == 1000, f"{br3.summary(j3)['records']} rows, {dt3:.1f} s")
    x3 = os.path.join(tmp, "scal.xlsx"); br3.export_job(j3, x3); sh3 = sheet_rows(x3)
    def blanks(rows):
        col = next(i for i, h in enumerate(rows[0]) if str(h).startswith("Main Activity Name"))
        return sum(1 for r in rows[1:] if not str(r[col] or "").strip())
    by_blank = sorted(sh3, key=lambda k: blanks(sh3[k]))
    nn, nm = [by_blank[0]], [by_blank[-1]]                  # the sheet without blanks = normalized, the one with blanks = original layout
    norm_rows = sh3[nn[0]]; h3 = [str(c) for c in norm_rows[0]]
    sr_col = next(i for i, h in enumerate(h3) if h.startswith("Sr"))
    srs = [int(str(r[sr_col])) for r in norm_rows[1:] if str(r[sr_col]).isdigit()]
    check("Sr. runs 1..1000 in order (no missing, no duplicates)", srs == list(range(1, 1001)))
    r1 = [str(c) for c in norm_rows[1]]
    check("row 1 spot check (Substation Battery Bank / SBB / SBBXX.TEST / 12.00 / 125 V)", "Substation Battery Bank" in r1 and "SBBXX.TEST" in r1 and "12.00" in r1 and "125 V" in r1, " | ".join(c[:14] for c in r1[:12]))
    c202 = [str(c) for c in norm_rows[202]]
    check("row 202 spot check (LCC Scheme Check, 20% Including All Typicals kept as text)", "LCC Scheme Check" in c202 and any("20% Including All Typicals" in c for c in c202))
    mn = next(i for i, h in enumerate(h3) if h.startswith("Main Activity Name"))
    check("normalized layout: no blank Main Activity Name", all(str(r[mn]).strip() for r in norm_rows[1:]))
    check("original layout keeps blanks where cells are merged", len(sh3) == 2 and blanks(sh3[nm[0]]) > 300, f"{blanks(sh3[nm[0]])} blank cells in the original-layout sheet")
    # ------------------------------------------------------------ scenario 4: other layouts
    say("\n## Scenario 4 - Different table structures")
    d4 = os.path.join(tmp, "other"); os.makedirs(d4); shutil.copy(RACI, d4)
    import test_office_tables as OT
    OT.build(d4)
    lib4 = new_lib(tmp, "h4", d4); res = lib4.extract_tables(); br4 = B.BatchRunner(lib4)
    j4 = br4.run(B.new_profile("raci", table={"headers": ["SN", "Submittal Title", "Submittal Type", "Submittal Code"], "min_match": 0.75}), root_ids=[lib4.roots()[0]["id"]])
    check("RACI PDF (coloured cells, merged category bands, 5 pages): 134 of 134 rows", br4.summary(j4)["records"] == 134, f"{br4.summary(j4)['records']}")
    check("Word, Excel, CSV, HTML, PowerPoint tables extracted", all(v["status"] == "extracted" for k, v in res.items() if lib4.db.one("SELECT ext FROM files WHERE id=?", (k,))["ext"] != "pdf"))
    import test_manual_tables as MT
    p = os.path.join(d4, "borderless.pdf"); box = MT.make_pdf(p, MT.ROWS[:4])
    from docintel.tables.manual import manual_extract
    mt = manual_extract(p, 1, box)
    check("borderless table selected by hand: 4 columns, header, continuation line joined", len(mt.headers) == 4 and len(mt.rows) == 3 and "continued" in mt.rows[0].orig[2])
    try:
        import test_scanned_tables as TS
        from docintel.tables import analyze_pdf
        from docintel import extractors as X
        from docintel.config import DEFAULTS
        if shutil.which("tesseract"):
            ocr = X.OCR(dict(DEFAULTS)); t0 = time.time()
            a = analyze_pdf(os.path.join(RP, "Annexure4_NIT_BOQ.pdf"), ocr=lambda: ocr); big = max(a.tables, key=lambda x: len(x.rows))
            anch = {r.orig[0] for r in big.rows} & {str(i) for i in range(1, 11)}
            check("scanned English BoQ (2 pages): one table, one record per item, header found", len(anch) >= 8 and len(big.headers) == 7, f"{len(anch)}/10 items, {time.time() - t0:.0f} s, marked as OCR (quality {big.quality:.2f})")
            a = analyze_pdf(os.path.join(RP, "CPA_4400023707_scan_p1-3.pdf"), ocr=lambda: ocr); big = max(a.tables, key=lambda x: len(x.rows))
            check("scanned pricing schedule (3 pages): one table over all pages", (big.page_from, big.page_to) == (1, 3) and len(big.rows) >= 110, f"{len(big.rows)} rows")
        else:
            say("- [SKIPPED] scanned tables: tesseract not installed on this machine")
    except Exception as e:
        check("scanned tables", False, repr(e))
    say("- [NOT TESTED] scanned ARABIC tables: no Arabic OCR data here; see test report (known limitation).")
    # ------------------------------------------------------------ scenario 5: unusual values
    say("\n## Scenario 5 - Unusual values are preserved")
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
    fontpath = next((f for f in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "C:/Windows/Fonts/arial.ttf") if os.path.exists(f)), None)
    vals = ["65%", "0.25", "-12.5", "110/13.8 kV", "EHV.SWGXX.SF6.TEST", "DTS-022", "Tan ∂", "&", "/", "#", "N/A", "48 V", "24 hours", "001", "01.02"]
    if fontpath:
        pdfmetrics.registerFont(TTFont("U", fontpath))
        d5 = os.path.join(tmp, "unusual"); os.makedirs(d5)
        data = [["Id", "Value", "Note"]] + [[str(i + 1), v, "x"] for i, v in enumerate(vals)]
        tb = Table(data); tb.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .5, colors.black), ("FONTNAME", (0, 0), (-1, -1), "U")]))
        SimpleDocTemplate(os.path.join(d5, "values.pdf"), pagesize=A4).build([tb])
        lib5 = new_lib(tmp, "h5", d5); lib5.extract_tables(); fid = lib5.db.one("SELECT id FROM files")["id"]
        t5 = store.load_table(lib5.db, store.list_tables(lib5.db, fid)[0]["id"])
        got = [r.orig[1] for r in t5.rows]
        check("all 15 unusual values extracted exactly as written", got == vals, "" if got == vals else f"{[(a, b) for a, b in zip(got, vals) if a != b]}")
        from docintel.wizard import Session
        s5 = Session(lib5); s5.select_all(); s5.prepare(); s5.build("all_tables"); x5 = os.path.join(tmp, "values.xlsx"); s5.export(x5, value_mode="raw")
        (n5, r5), = sheet_rows(x5).items(); cells = [str(r[1]) for r in r5[1:]]
        check("Excel keeps them as text (65% stays 65%, 001 stays 001)", cells == vals)
    else:
        say("- [SKIPPED] no TrueType font available")
    # ------------------------------------------------------------ scenario 6: large folder
    say("\n## Scenario 6 - Large folder, incremental indexing, responsiveness")
    from reportlab.pdfgen import canvas
    d6 = os.path.join(tmp, "big"); os.makedirs(d6); n_big = 600
    for i in range(n_big):
        c = canvas.Canvas(os.path.join(d6, f"inv_{i:04d}.pdf")); c.drawString(72, 700, f"Invoice No: INV-{i:05d}"); c.drawString(72, 680, "Total 1,000.00 " + "word " * 120); c.save()
    for i in range(40):
        shutil.copy(DAILY, os.path.join(d6, f"daily_{i:03d}.pdf"))
    shutil.copy(SCAL, d6); shutil.copy(RACI, d6)
    lib6 = Library(os.path.join(tmp, "h6")); lib6.add_root(d6)
    t = time.time(); lib6.scan(); st = lib6.index(); t_full = time.time() - t
    n_files = n_big + 42
    check(f"initial index of {n_files} files, no errors", st["errors"] == 0 and st["indexed"] == n_files, f"{t_full:.1f} s, peak memory {rss_mb():.0f} MB")
    t = time.time(); lib6.scan(); st2 = lib6.index(); t_unch = time.time() - t
    check("re-index of unchanged files does (almost) nothing", st2["total"] == 0, f"{t_unch:.2f} s")
    for i in range(25):
        c = canvas.Canvas(os.path.join(d6, f"new_{i:03d}.pdf")); c.drawString(72, 700, f"Invoice No: NEW-{i:05d}"); c.drawString(72, 680, "Total " + "word " * 100); c.save()
    t = time.time(); lib6.scan(); st3 = lib6.index(); t_inc = time.time() - t
    check("incremental: only the 25 new files are processed", st3["total"] == 25 and st3["errors"] == 0, f"{t_inc:.2f} s")
    t = time.time(); h = S.search(lib6.db, "NEW-00007", "text", limit=20); t_s = (time.time() - t) * 1000
    check("search finds a new file immediately", len(h) == 1, f"{t_s:.0f} ms")
    say("  (Baseline reported by the user: about 15 minutes for 1,500 documents. This run: " + f"{n_files} documents in {t_full:.1f} s on one core; a 1,500-document library on the user's own PC has not been measured.)")
    # ------------------------------------------------------------ scenario 7: nontechnical operation
    say("\n## Scenario 7 - Nontechnical operation")
    say("- [BY DESIGN, CHECKED ON WINDOWS BUILDS] Home screen with six buttons, five-step wizard, saved extractions and batch window, manual table selection and plain-language messages exist; the Windows builds (smoke test) construct them on a real Windows machine.")
    say("- [NOT TESTED] no real non-technical user has operated this yet; the user (a non-programmer) has used builds 9-18 for real exports. Plain-language user guide: docs/DocIntel_User_Guide.pdf.")
    # ------------------------------------------------------------ scenario 8: offline
    say("\n## Scenario 8 - Offline operation")
    import socket
    from docintel import diagnostics as D
    D.enforce_offline()
    blocked = False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM); s.settimeout(2); s.connect(("93.184.216.34", 80))
    except Exception as e:
        blocked = "offline" in str(e).lower() or "not allowed" in str(e).lower() or "blocked" in str(e).lower() or isinstance(e, (PermissionError, OSError))
    check("with offline mode on, connections to the internet are refused by the application", blocked)
    check("no AI provider is connected by default and nothing is sent", not lib6.ai_available())
    say("- [VERIFIED ON WINDOWS] every build also ran the packaged app with ALL network access blocked by the Windows firewall (builds 6-18: green).")
    # ------------------------------------------------------------ scenario 9: AI-assisted, local model, bulk (protocol level)
    say("\n## Scenario 9 - AI-assisted analysis with a LOCAL model (tested against a fake local model server, NOT a real language model)")
    from fake_llm_server import Fake
    from reportlab.pdfgen import canvas as _cv
    from docintel.llm.provider import OpenAICompatProvider
    from docintel.llm.extract import AIExtractor
    from docintel.llm.semantic import SemanticIndex
    from docintel.llm.assistant import Assistant
    d9 = os.path.join(tmp, "ai"); os.makedirs(d9); n_ai = 40
    for i in range(n_ai):
        c = _cv.Canvas(os.path.join(d9, f"inv_{i:03d}.pdf")); c.drawString(72, 760, "ACME Trading - Tax invoice"); c.drawString(72, 740, f"Invoice No: INV-{i:05d}")
        c.drawString(72, 724, "Date: 2026-03-04"); c.drawString(72, 708, f"Total: {1000 + i * 7}.50"); c.save()
    lib9 = new_lib(tmp, "h9", d9)
    srv = Fake(); prov = OpenAICompatProvider(srv.url, "fake-chat", embed_model="fake-embed", name="fake-local")
    try:
        check("the local model is reachable while offline mode is ON (this computer only)", prov.kind == "local" and prov.test()[0])
        ex = AIExtractor(lib9, prov); t = time.time(); j9 = ex.run(["Invoice No", "Date", "Total"], root_ids=[lib9.roots()[0]["id"]]); dt9 = time.time() - t
        s9 = ex.br.summary(j9)
        check(f"bulk AI extraction: {n_ai} documents -> {n_ai} records, all values confirmed in the document text", s9["processed"] == n_ai and s9["partial"] == 0 and s9["records"] == n_ai, f"{dt9:.1f} s")
        en = ex.entries(j9); vals = sorted(e.table.rows[0].orig[0] for e in en)
        check("extracted values exact", vals == [f"INV-{i:05d}" for i in range(n_ai)])
        srv.mode = "hallucinate"; j9b = ex.run(["Invoice No"], file_ids=[r["id"] for r in lib9.db.q("SELECT id FROM files LIMIT 3")])
        check("an invented value is caught and marked for review", ex.br.summary(j9b)["partial"] == 3 and ex.br.summary(j9b)["review_rows"] == 3)
        srv.mode = "good"
        n_vec = SemanticIndex(lib9, prov).build()
        check("meaning-based search index built incrementally", n_vec >= n_ai and SemanticIndex(lib9, prov).build() == 0, f"{n_vec} vectors")
        a = Assistant(lib9, prov); pack, prev = a.prepare("What is the total of invoice INV-00007?"); ans = a.ask("What is the total of invoice INV-00007?", pack, prev)
        check("question answered from the documents with sources, nothing left this computer", bool(ans.cited) and not prev["leaves_computer"])
    finally:
        srv.stop()
    say("- [NOT TESTED] real open-weight models (accuracy, speed, Arabic): the test uses a rule-based stand-in. Use AI tools > Compare models on your own documents.")
    # ------------------------------------------------------------ summary
    npass = sum(1 for _, ok in RESULTS if ok)
    say(f"\n## Summary\n\n{npass} of {len(RESULTS)} automated acceptance checks passed. Peak memory {rss_mb():.0f} MB.")
    open(out, "w", encoding="utf-8").write("\n".join(LINES) + "\n")
    shutil.rmtree(tmp, ignore_errors=True)
    return 0 if npass == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "ACCEPTANCE_REPORT.md")))
