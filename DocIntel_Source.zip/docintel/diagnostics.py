"""Dependency/model verification, offline enforcement, backup/restore, integrity and recovery tools."""
import hashlib, json, os, shutil, socket, sys, time, zipfile


class OfflineViolation(RuntimeError):
    pass


_orig_connect = socket.socket.connect


def enforce_offline():
    """Explicit offline mode: any non-loopback network connection attempted by this process raises."""
    def guarded(self, addr, *a, **k):
        host = addr[0] if isinstance(addr, tuple) else str(addr)
        if self.family in (socket.AF_INET, socket.AF_INET6) and host not in ("127.0.0.1", "::1", "localhost"):
            raise OfflineViolation(f"offline mode: blocked connection to {host}")
        return _orig_connect(self, addr, *a, **k)
    socket.socket.connect = guarded


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def doctor(lib):
    from . import extractors as X
    rep = {"python": sys.version.split()[0], "checks": []}
    def add(name, ok, detail=""):
        rep["checks"].append({"name": name, "ok": bool(ok), "detail": detail})
    for mod, req in [("pdfplumber", True), ("pypdfium2", True), ("docx", True), ("pptx", True), ("openpyxl", True), ("PIL", True),
                     ("pytesseract", True), ("ezdxf", False), ("rapidfuzz", True), ("watchdog", False)]:
        try:
            __import__(mod); add(f"module {mod}", True)
        except Exception as e:
            add(f"module {mod}" + ("" if req else " (optional)"), not req, str(e))
    try:
        o = X.OCR(lib.cfg)
        langs = o.available_langs()
        add("tesseract engine", bool(langs), f"languages: {sorted(langs)}")
        add("OCR language eng", "eng" in langs); add("OCR language ara (Arabic)", "ara" in langs, "optional but recommended")
    except Exception as e:
        add("tesseract engine", False, str(e))
    add("LibreOffice (optional, legacy .doc/.ppt/.xls)", True, "installed" if (shutil.which("soffice") or shutil.which("soffice.exe")) else "not installed (only needed for old .doc/.ppt/.xls files)")
    ic = lib.db.integrity_check()
    add("database integrity", ic["sqlite"] == "ok", ic["sqlite"]); add("full-text index integrity", ic["fts"] == "ok", ic["fts"])
    free = shutil.disk_usage(lib.cfg.home).free / 1048576
    add("free disk space", free > lib.cfg["min_free_disk_mb"], f"{free:.0f} MB")
    man = os.path.join(lib.cfg.home, "models", "manifest.json")
    if os.path.exists(man):
        for rel, want in json.load(open(man)).items():
            p = os.path.join(lib.cfg.home, "models", rel)
            add(f"model {rel}", os.path.exists(p) and sha256(p) == want, "checksum matches" if os.path.exists(p) else "missing")
    else:
        add("model manifest (models/manifest.json)", True, "none present: using system Tesseract data")
    rep["ok"] = all(c["ok"] for c in rep["checks"])
    return rep


def write_model_manifest(models_dir):
    out = {}
    for root, _, files in os.walk(models_dir):
        for f in files:
            if f != "manifest.json":
                p = os.path.join(root, f); out[os.path.relpath(p, models_dir).replace("\\", "/")] = sha256(p)
    json.dump(out, open(os.path.join(models_dir, "manifest.json"), "w"), indent=2)
    return out


def backup(lib, dest_zip):
    """Backs up the index database (consistent snapshot), configuration and profiles into one zip."""
    tmp = os.path.join(lib.cfg.home, "index.snapshot.db")
    lib.db.backup_to(tmp)
    with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmp, "index.db")
        if os.path.exists(lib.cfg.path): z.write(lib.cfg.path, "config.json")
    os.remove(tmp)
    return dest_zip


def restore(home, src_zip):
    os.makedirs(home, exist_ok=True)
    with zipfile.ZipFile(src_zip) as z:
        for n in ("index.db", "config.json"):
            if n in z.namelist():
                if os.path.exists(os.path.join(home, n)):
                    shutil.copy2(os.path.join(home, n), os.path.join(home, n + f".before_restore_{time.strftime('%Y%m%d_%H%M%S')}"))
                z.extract(n, home)
    for ext in ("-wal", "-shm"):
        p = os.path.join(home, "index.db" + ext)
        if os.path.exists(p): os.remove(p)
