"""Command-line interface (same engine as the GUI). Run:  python -m docintel <command> --help"""
import argparse, json, os, sys, time

from .library import Library, JobControl
from . import search as S, extraction as E, excel_export as XL, compare as C, diagnostics as D, drawings


def main(argv=None):
    ap = argparse.ArgumentParser(prog="docintel", description="Offline document search & Excel extraction")
    ap.add_argument("--home", help="data folder (default: %%APPDATA%%\\DocIntel or ~/.docintel)")
    sp = ap.add_subparsers(dest="cmd")
    a = sp.add_parser("add-root"); a.add_argument("paths", nargs="+")
    sp.add_parser("roots")
    a = sp.add_parser("remove-root"); a.add_argument("id", type=int)
    a = sp.add_parser("scan"); a.add_argument("--root", type=int, nargs="*"); a.add_argument("--full", action="store_true"); a.add_argument("--subpath")
    a = sp.add_parser("index"); a.add_argument("--root", type=int, nargs="*"); a.add_argument("--limit", type=int)
    a = sp.add_parser("update", help="scan + index"); a.add_argument("--root", type=int, nargs="*")
    a = sp.add_parser("search"); a.add_argument("query"); a.add_argument("--mode", default="text", choices=["text", "word", "all", "regex", "fuzzy"])
    a.add_argument("--root", type=int, nargs="*"); a.add_argument("--ext", nargs="*"); a.add_argument("--limit", type=int, default=50)
    a = sp.add_parser("profile-save"); a.add_argument("json_file")
    sp.add_parser("profiles")
    a = sp.add_parser("extract"); a.add_argument("profile")
    a = sp.add_parser("review"); a.add_argument("run", type=int)
    a = sp.add_parser("export"); a.add_argument("run", type=int); a.add_argument("--out", required=True)
    a.add_argument("--template"); a.add_argument("--sheet"); a.add_argument("--allow-unreviewed", action="store_true")
    a.add_argument("--preview", action="store_true"); a.add_argument("--in-place", action="store_true")
    sp.add_parser("duplicates")
    sp.add_parser("doctor"); sp.add_parser("dashboard")
    a = sp.add_parser("backup"); a.add_argument("zip")
    a = sp.add_parser("restore"); a.add_argument("zip")
    a = sp.add_parser("gui"); a.add_argument("--smoke-test", metavar="REPORT.json", help=argparse.SUPPRESS)
    args = ap.parse_args(argv)
    if args.cmd == "gui" or args.cmd is None:
        from .gui import run_gui; return run_gui(args.home, getattr(args, "smoke_test", None))
    if args.cmd == "restore":
        from .config import app_dir; D.restore(args.home or app_dir(), args.zip); print("restored"); return 0
    lib = Library(args.home)
    if lib.cfg["offline_mode"]: D.enforce_offline()
    pr = lambda *x: print(*x, flush=True)
    if args.cmd == "add-root":
        for r in lib.add_roots(args.paths): pr("added root id" if isinstance(r, int) else "!", r)
    elif args.cmd == "roots":
        for r in lib.roots(): pr(r["id"], "ON " if r["enabled"] else "off", "avail" if r["available"] else "UNAVAILABLE", r["name"], r["path"])
    elif args.cmd == "remove-root": lib.remove_root(args.id); pr("removed from index (files on disk untouched)")
    elif args.cmd == "scan": pr(json.dumps(lib.scan(args.root, args.subpath, args.full), indent=1))
    elif args.cmd == "index": pr(lib.index(args.root, limit=args.limit))
    elif args.cmd == "update":
        pr(json.dumps(lib.scan(args.root), indent=1)); pr(lib.index(args.root))
    elif args.cmd == "search":
        for h in S.search(lib.db, args.query, args.mode, args.root, args.ext, limit=args.limit):
            pr(f"{h.path} [{h.loc}] ({h.method}, conf {h.confidence:.2f})\n    {h.excerpt}")
    elif args.cmd == "profile-save": pr(E.save_profile(lib.db, json.load(open(args.json_file, encoding="utf-8")))["name"])
    elif args.cmd == "profiles": pr("\n".join(E.list_profiles(lib.db)))
    elif args.cmd == "extract":
        rid = E.run_profile(lib, E.load_profile(lib.db, args.profile)); n = lib.db.one("SELECT COUNT(DISTINCT record_key) FROM vals WHERE run_id=?", (rid,))[0]
        pr(f"run {rid}: {n} records; {len(E.review_queue(lib.db, rid))} values need review")
    elif args.cmd == "review":
        for v in E.review_queue(lib.db, args.run): pr(v["id"], v["field"], repr(v["raw"]), "->", v["normalized"], v["issues"], v["abspath"], v["loc"])
    elif args.cmd == "export":
        prof = json.loads(lib.db.one("SELECT params FROM runs WHERE id=?", (args.run,))[0])
        fields = [f["name"] for f in prof["fields"]]
        recs, held = E.records_for_export(lib.db, args.run, args.allow_unreviewed)
        if held: pr(f"{len(held)} record(s) held back: values still need review (use `review`, or --allow-unreviewed)")
        if args.template:
            hdr = XL.read_headers(args.template, args.sheet)
            mapping = prof.get("excel", {}).get("mapping") or XL.auto_mapping(fields, hdr["headers"])
            if args.preview:
                pr(json.dumps(XL.preview(args.template, recs, mapping, args.sheet), indent=1, default=str)); return 0
            res = XL.apply(lib.db, args.run, args.template, recs, mapping, args.sheet, out_path=None if args.in_place else args.out, in_place=args.in_place)
            pr(json.dumps(res, indent=1, default=str))
        elif args.out.lower().endswith((".csv", ".tsv")):
            pr(XL.export_csv(recs, fields, args.out, "\t" if args.out.endswith(".tsv") else ","))
        else: pr(XL.export_new(lib.db, args.run, recs, fields, args.out))
    elif args.cmd == "duplicates":
        pr(json.dumps(C.exact_duplicate_files(lib.db), indent=1))
    elif args.cmd == "doctor":
        rep = D.doctor(lib)
        for c in rep["checks"]: pr("[OK] " if c["ok"] else "[!!] ", c["name"], c["detail"])
        return 0 if rep["ok"] else 1
    elif args.cmd == "dashboard": pr(json.dumps(lib.dashboard(), indent=1, default=str))
    elif args.cmd == "backup": pr(D.backup(lib, args.zip))
    return 0
