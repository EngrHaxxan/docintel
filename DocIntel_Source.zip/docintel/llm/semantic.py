"""Meaning-based search with a LOCAL embedding model (Milestone 9). Rows of extracted tables and pieces of page text are turned into vectors once
(incrementally: unchanged text is not embedded again) and a question is matched by cosine similarity - so 'who is responsible for cable
approvals' can find a row that says 'Submittal: power cable ... R/A' even when no word is the same, and across languages if the model is multilingual.
Different embedding models keep separate vectors (switching models is safe)."""
from __future__ import annotations
import array, hashlib, json, re, time
from ..retrieval import Retriever, Record, Passage
from ..tables import store


def _vec_bytes(v):
    return array.array("f", v).tobytes()


def _bytes_vec(b):
    a = array.array("f"); a.frombytes(b); return a


class SemanticIndex:
    CHUNK = 900

    def __init__(self, lib, provider):
        self.lib, self.db, self.provider = lib, lib.db, provider
        self.model = getattr(provider, "embed_model", "") or provider.name

    # ---- what could be embedded
    def _units(self):
        for r in self.db.q("SELECT s.id, s.text, s.file_id FROM segments s JOIN files f ON f.id=s.file_id WHERE f.missing_since IS NULL AND length(s.text)>20"):
            t = r["text"]
            for k in range(0, min(len(t), 40 * self.CHUNK), self.CHUNK):
                yield "passage", r["id"] * 1000 + k // self.CHUNK, t[k:k + self.CHUNK]
        for t in self.db.q("SELECT d.id FROM doc_tables d JOIN files f ON f.id=d.file_id WHERE f.missing_since IS NULL"):
            tb = store.load_table(self.db, t["id"]); names = [h.name for h in tb.headers]
            for i, r in enumerate(tb.rows, 1):
                txt = "; ".join(f"{n}: {v}" for n, v in zip(names, r.norm) if str(v).strip())
                if txt:
                    yield "record", t["id"] * 100000 + i, (tb.section + " | " if tb.section else "") + txt

    def pending(self):
        have = {(r["kind"], r["ref_id"]): r["text_hash"] for r in self.db.q("SELECT kind, ref_id, text_hash FROM embeddings WHERE model=?", (self.model,))}
        out = []
        for kind, ref, text in self._units():
            h = hashlib.md5(text.encode("utf-8")).hexdigest()
            if have.get((kind, ref)) != h:
                out.append((kind, ref, text, h))
        return out

    def stats(self):
        n = self.db.one("SELECT COUNT(*) n FROM embeddings WHERE model=?", (self.model,))["n"]
        return {"model": self.model, "vectors": n}

    def build(self, control=None, progress=None, batch=24):
        """Embed new / changed units only. Returns the number of units embedded."""
        todo = self.pending(); done = 0
        for i in range(0, len(todo), batch):
            if control is not None:
                control.wait_if_paused()
                if control.cancelled:
                    break
            chunk = todo[i:i + batch]
            vecs = self.provider.embed([t[2][:2000] for t in chunk])
            with self.db.conn:
                for (kind, ref, text, h), v in zip(chunk, vecs):
                    self.db.conn.execute("INSERT OR REPLACE INTO embeddings(kind, ref_id, model, dim, vec, text_hash) VALUES(?,?,?,?,?,?)", (kind, ref, self.model, len(v), _vec_bytes(v), h))
            done += len(chunk)
            if progress:
                progress(done, len(todo), "")
        return done

    # ---- search
    def search(self, query, k=20, kinds=("record", "passage")):
        rows = self.db.q("SELECT kind, ref_id, vec, dim FROM embeddings WHERE model=? AND kind IN (%s)" % ",".join("?" * len(kinds)), (self.model,) + tuple(kinds))
        if not rows:
            return []
        q = self.provider.embed([query])[0]
        try:
            import numpy as np
            M = np.array([np.frombuffer(r["vec"], dtype="float32") for r in rows]); qv = np.array(q, dtype="float32")
            sims = (M @ qv) / ((np.linalg.norm(M, axis=1) * np.linalg.norm(qv)) + 1e-9)
            order = np.argsort(-sims)[:k]
            scored = [(float(sims[i]), rows[int(i)]) for i in order]
        except ImportError:
            import math
            nq = math.sqrt(sum(x * x for x in q)) or 1.0
            def cos(b):
                v = _bytes_vec(b); return sum(x * y for x, y in zip(v, q)) / ((math.sqrt(sum(x * x for x in v)) or 1.0) * nq)
            scored = sorted(((cos(r["vec"]), r) for r in rows), key=lambda x: -x[0])[:k]
        return [(sc, self._resolve(r["kind"], r["ref_id"])) for sc, r in scored if self._resolve(r["kind"], r["ref_id"]) is not None]

    def _resolve(self, kind, ref):
        if kind == "record":
            tid, row = divmod(ref, 100000)
            return Retriever(self.lib).record_at(tid, row)
        sid, chunk = divmod(ref, 1000)
        s = self.db.one("SELECT s.loc, s.text, f.id fid, f.name, f.abspath FROM segments s JOIN files f ON f.id=s.file_id WHERE s.id=?", (sid,))
        if s is None:
            return None
        m = re.match(r"p(\d+)$", s["loc"] or "")
        return Passage(s["fid"], s["name"], s["abspath"], int(m.group(1)) if m else 1, s["text"][chunk * self.CHUNK:(chunk + 1) * self.CHUNK][:700])
