"""Milestone 2: value classification, database storage, corrections, Excel options. Run: python -m unittest tests.test_tables_store"""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from openpyxl import load_workbook
from docintel.library import Library
from docintel.db import DB
from docintel.tables import store
from docintel.tables.values import suggest, KINDS
from docintel.tables.export import export_tables_xlsx

HERE = os.path.dirname(os.path.abspath(__file__))
DAILY = os.path.join(HERE, "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")


class Values(unittest.TestCase):
    def test_examples_from_requirements(self):
        exp = {"65%": "percentage", "0.25": "decimal", "-12.5": "decimal", "110/13.8 kV": "unit_value", "EHV.SWGXX.SF6.TEST": "identifier",
               "DTS-022": "identifier", "&": "special", "/": "special", "#": "special", "N/A": "text", "48 V": "unit_value",
               "24 hours": "duration", "001": "identifier", "01.02": "identifier", "05-May-26": "date", "": "empty", "Completed": "text",
               "Tan \u2202": "text", "ملاحظة": "text", "TRUE": "boolean"}
        for raw, kind in exp.items():
            self.assertEqual(suggest(raw)[0], kind, raw)
            self.assertIn(suggest(raw)[0], KINDS)

    def test_never_rejects_anything(self):
        for raw in ["\u202e??", "\u0650", "@@@", "1e5x", "((", "١٢٣", "a\tb", "x" * 5000, "0%", "-", "N/A "]:
            k, p, n = suggest(raw)
            self.assertIn(k, KINDS)

    def test_ambiguous_dates_not_converted(self):
        self.assertEqual(suggest("12/05/2026")[:2], ("date", None))
        self.assertIsNotNone(suggest("25/05/2026")[1])


class Store(unittest.TestCase):
    def setUp(self):                                   # fresh library for every test (tests must not share state)
        self.tmp = tempfile.mkdtemp()
        self.docs = os.path.join(self.tmp, "docs"); os.makedirs(self.docs)
        shutil.copy(DAILY, os.path.join(self.docs, "report_a.pdf"))
        shutil.copy(DAILY, os.path.join(self.docs, "report_b.pdf"))
        open(os.path.join(self.docs, "notes.docx"), "wb").write(b"x")
        self.lib = Library(os.path.join(self.tmp, "home"))
        self.lib.add_root(self.docs); self.lib.scan()
        self.res = self.lib.extract_tables()
        self.fids = sorted(self.res)

    def test_extracted_and_listed(self):
        self.assertEqual(len(self.fids), 2)                      # the .docx is not offered
        for fid in self.fids:
            self.assertEqual(self.res[fid]["status"], "extracted")
        ts = store.list_tables(self.lib.db)
        self.assertEqual(len(ts), 14)
        c = [t for t in ts if t["section"].startswith("CONSTRUCTION")]
        self.assertEqual([t["rows"] for t in c], [4, 4])

    def test_roundtrip_matches_engine(self):
        from docintel.tables import analyze_pdf
        ref = analyze_pdf(DAILY)
        t = next(t for t in store.list_tables(self.lib.db) if t["section"].startswith("ISSUES"))
        loaded = store.load_table(self.lib.db, t["id"])
        want = next(x for x in ref.tables if x.section.startswith("ISSUES"))
        self.assertEqual([r.orig for r in loaded.rows], [r.orig for r in want.rows])
        self.assertEqual(loaded.column_names, want.column_names)
        self.assertEqual(loaded.rows[1].pages, want.rows[1].pages)

    def test_unchanged_files_reused_and_force(self):
        again = self.lib.extract_tables()
        self.assertTrue(all(v["status"] == "reused" for v in again.values()))
        forced = self.lib.extract_tables(file_ids=[self.fids[0]], force=True)
        self.assertEqual(forced[self.fids[0]]["status"], "extracted")
        self.assertEqual(len(store.list_tables(self.lib.db)), 14)    # replaced, not duplicated

    def test_unsupported_and_missing_files_reported(self):
        from docintel.tables.service import extract_file_tables
        r = extract_file_tables(self.lib.db, {"id": 999, "abspath": "x.docx", "ext": "docx", "sha256": None})
        self.assertEqual(r["status"], "unsupported")
        r = extract_file_tables(self.lib.db, {"id": 999, "abspath": os.path.join(self.tmp, "nope.pdf"), "ext": "pdf", "sha256": None})
        self.assertEqual(r["status"], "failed"); self.assertNotIn("Traceback", r["message"])

    def test_corrections_keep_original(self):
        t = next(t for t in store.list_tables(self.lib.db, self.fids[1]) if t["section"].startswith("CONSTRUCTION"))
        store.set_correction(self.lib.db, t["id"], 0, 6, "75%")
        tb = store.load_table(self.lib.db, t["id"])
        self.assertEqual(tb.rows[0].orig[6], "75%"); self.assertEqual(tb.rows[0].raw_orig[6], "70%")
        self.assertTrue(any("corrected by user" in f for f in tb.rows[0].cell_flags[6]))
        raw = store.load_table(self.lib.db, t["id"], apply_corrections=False)
        self.assertEqual(raw.rows[0].orig[6], "70%")
        out = os.path.join(self.tmp, "corr.xlsx"); export_tables_xlsx([tb], out)
        ws = load_workbook(out)[load_workbook(out).sheetnames[1]]
        self.assertEqual(ws["G2"].value, "75%")
        hdr = [c.value for c in ws[1]]
        self.assertEqual(ws.cell(row=2, column=hdr.index("Corrected cells") + 1).value, 1)
        store.clear_correction(self.lib.db, t["id"], 0, 6)
        self.assertEqual(store.load_table(self.lib.db, t["id"]).rows[0].orig[6], "70%")

    def test_rename_and_hide_columns(self):
        t = next(t for t in store.list_tables(self.lib.db, self.fids[0]) if t["section"].startswith("ISSUES"))
        store.rename_header(self.lib.db, t["id"], 4, "Impact")
        store.set_hidden_columns(self.lib.db, t["id"], [9])
        tb = store.load_table(self.lib.db, t["id"])
        self.assertEqual(tb.headers[4].name, "Impact"); self.assertEqual(tb.headers[4].renamed_from, "Imapct")
        out = os.path.join(self.tmp, "ren.xlsx"); export_tables_xlsx([tb], out, modes=("orig",))
        ws = load_workbook(out)[load_workbook(out).sheetnames[1]]
        hdr = [c.value for c in ws[1]]
        self.assertIn("Impact", hdr); self.assertNotIn("Remarks", hdr[:10])

    def test_delete_file_removes_tables(self):
        fid = self.fids[1]
        self.lib.db.x("DELETE FROM files WHERE id=?", (fid,))
        self.assertEqual(store.list_tables(self.lib.db, fid), [])
        self.assertEqual(self.lib.db.one("SELECT COUNT(*) FROM table_cells")[0] > 0, True)   # file A cells remain

    def test_schema_upgrade_from_v1(self):
        p = os.path.join(self.tmp, "old.db")
        d = DB(p); d.x("DROP TABLE table_cells"); d.x("DROP TABLE table_rows"); d.x("DROP TABLE doc_tables"); d.x("DROP TABLE doc_sections")
        d.x("UPDATE meta SET value='1' WHERE key='schema_version'"); d.conn.close(); d._local.c = None
        d2 = DB(p)
        self.assertEqual(d2.one("SELECT value FROM meta WHERE key='schema_version'")[0], "2")
        self.assertEqual(d2.one("SELECT COUNT(*) FROM doc_tables")[0], 0)


class ExcelOptions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from docintel.tables import analyze_pdf
        cls.tmp = tempfile.mkdtemp()
        a = analyze_pdf(DAILY)
        cls.cons = next(t for t in a.tables if t.section.startswith("CONSTRUCTION"))
        cls.iss = next(t for t in a.tables if t.section.startswith("ISSUES"))

    def test_typed_mode_and_raw_companion(self):
        out = os.path.join(self.tmp, "typed.xlsx")
        export_tables_xlsx([self.cons], out, modes=("orig",), value_mode="typed")
        wb = load_workbook(out)
        self.assertEqual(len(wb.sheetnames), 3)                      # summary + typed + raw companion
        ws = wb[wb.sheetnames[1]]
        self.assertAlmostEqual(ws["G2"].value, 0.7); self.assertEqual(ws["G2"].number_format, "0.##%")
        self.assertEqual(ws["A2"].value, 1)                          # typed mode converts plain integers; codes like 001 stay text
        self.assertEqual(wb[wb.sheetnames[2]]["G2"].value, "70%")

    def test_raw_mode_is_exact_text(self):
        out = os.path.join(self.tmp, "raw.xlsx")
        export_tables_xlsx([self.cons], out, modes=("norm",))
        ws = load_workbook(out)[load_workbook(out).sheetnames[1]]
        self.assertEqual([ws.cell(row=r, column=7).value for r in range(2, 6)], ["70%", "0%", "70%", "0%"])

    def test_combined_stacks_same_columns(self):
        import copy
        c2 = copy.deepcopy(self.cons); c2.source = "other.pdf"
        out = os.path.join(self.tmp, "comb.xlsx")
        export_tables_xlsx([self.cons, c2, self.iss], out, modes=("orig",), combine="combined")
        wb = load_workbook(out)
        self.assertEqual(len(wb.sheetnames), 3)                      # summary + combined construction + issues
        self.assertEqual(wb[wb.sheetnames[1]].max_row, 9)            # header + 4 + 4
        ws = wb[wb.sheetnames[1]]
        col = [c.value for c in ws[1]].index("Source file")
        files = {r[col].value for r in ws.iter_rows(min_row=2)}
        self.assertEqual(len(files), 2)

    def test_row_limit_rollover(self):
        out = os.path.join(self.tmp, "roll.xlsx")
        export_tables_xlsx([self.cons], out, modes=("orig",), max_rows=3)    # 2 data rows per sheet
        names = load_workbook(out).sheetnames
        self.assertEqual(len([n for n in names if n != "Summary"]), 2)
        total = sum(load_workbook(out)[n].max_row - 1 for n in names if n != "Summary")
        self.assertEqual(total, 4)

    def test_leaf_header_style(self):
        out = os.path.join(self.tmp, "leaf.xlsx")
        export_tables_xlsx([self.cons], out, modes=("orig",), header_style="leaf")
        hdr = [c.value for c in load_workbook(out)[load_workbook(out).sheetnames[1]][1]]
        self.assertIn("07-Oct-2026", hdr)


if __name__ == "__main__":
    unittest.main()


class OldExtractionTypes(unittest.TestCase):
    def test_percentage_and_auto_types_never_reject(self):
        from docintel import cleaning
        self.assertEqual(cleaning.normalise("65%", "percentage")[0], 0.65)
        self.assertIsNone(cleaning.normalise("N/A", "percentage")[0])
        for raw in ["65%", "EHV.SWGXX.SF6.TEST", "Tan \u2202", "&", "N/A", "110/13.8 kV", "001"]:
            v, iss = cleaning.normalise(raw, "auto")
            self.assertTrue(v is not None)
        self.assertEqual(cleaning.normalise("001", "auto")[0], "001")
        self.assertEqual(cleaning.normalise("0.25", "auto")[0], 0.25)


class SingleWorksheet(unittest.TestCase):
    """Requests from real use: all days of a daily report in ONE sheet; whole RACI-style table with merged category headings."""
    @classmethod
    def setUpClass(cls):
        from docintel.tables import analyze_pdf
        cls.tmp = tempfile.mkdtemp()
        a = analyze_pdf(DAILY)
        cls.cons = next(t for t in a.tables if t.section.startswith("CONSTRUCTION"))
        cls.iss = next(t for t in a.tables if t.section.startswith("ISSUES"))

    def _days(self):
        import copy
        out = []
        for i, (d1, d2) in enumerate([("07-Oct-2026", "08-Oct-2026"), ("08-Oct-2026", "09-Oct-2026"), ("29-Sep-2026", "30-Sep-2026")]):
            t = copy.deepcopy(self.cons); t.source = f"day{i}.pdf"
            t.headers[6].name = f"Progress % / {d1}"; t.headers[7].name = f"Progress % / {d2}"
            out.append(t)
        return out

    def test_different_dates_in_headers_stack_into_one_sheet(self):
        out = os.path.join(self.tmp, "days.xlsx")
        export_tables_xlsx(self._days(), out, modes=("norm",), combine="combined")
        wb = load_workbook(out); ws = wb[wb.sheetnames[1]]
        self.assertEqual(len(wb.sheetnames), 2)                       # Summary + ONE combined sheet
        self.assertEqual(ws.max_row, 13)                              # header + 3 days x 4 rows
        hdr = [c.value for c in ws[1]]
        self.assertIn("Progress % / (date 1)", hdr); self.assertIn("Progress % / (date 2)", hdr)
        self.assertIn("Progress % / (date 1) - date", hdr)
        i = hdr.index("Progress % / (date 1) - date")
        self.assertEqual({r[i].value for r in ws.iter_rows(min_row=2)}, {"07-Oct-2026", "08-Oct-2026", "29-Sep-2026"})

    def test_everything_in_one_worksheet(self):
        out = os.path.join(self.tmp, "one.xlsx")
        export_tables_xlsx([self.cons, self.iss], out, modes=("norm",), combine="single")
        wb = load_workbook(out); ws = wb[wb.sheetnames[1]]
        self.assertEqual(len(wb.sheetnames), 2); self.assertEqual(ws.max_row, 1 + 4 + 3)
        hdr = [c.value for c in ws[1]]
        for n in ("Location", "Issue Type", "Section / table"):
            self.assertIn(n, hdr)
        sec = hdr.index("Section / table")
        self.assertEqual([r[sec].value for r in ws.iter_rows(min_row=2)], ["CONSTRUCTION ACTIVITIES"] * 4 + ["ISSUES & CONCERNS"] * 3)

    def test_wizard_suggests_stacking_for_days_and_single_sheet_option(self):
        from docintel.wizard import Session
        s = Session(None)
        from docintel.wizard import Entry
        s.preview = [Entry(f"d{i}.pdf", "x", t) for i, t in enumerate(self._days())]
        self.assertEqual(s.suggest_arrangement(), "stacked")


class RaciStyleTable(unittest.TestCase):
    """Table drawn with coloured cells (no ruling lines), category heading bands inside, continued over 5 pages."""
    @classmethod
    def setUpClass(cls):
        from docintel.tables import analyze_pdf
        cls.a = analyze_pdf(os.path.join(HERE, "real_pdfs", "RACI_Matrix_UGC_Submittals.pdf"))
        cls.t = max(cls.a.tables, key=lambda t: len(t.rows))

    def test_complete_table_in_order(self):
        t = self.t
        self.assertEqual([int(r.anchor.rstrip(".")) for r in t.rows], list(range(1, 135)))
        self.assertEqual((t.page_from, t.page_to), (2, 6))
        self.assertEqual(t.column_names[:4], ["SN", "Submittal Title", "Submittal Type", "Submittal Code"])
        self.assertEqual(len(t.headers), 10); self.assertTrue(t.column_names[-1] == "REMARKS")

    def test_values_and_groups(self):
        by = {int(r.anchor.rstrip(".")): r for r in self.t.rows}
        self.assertEqual(by[9].orig[1:4], ["NON-LINEAR RESISTANCE AND CALCULATIONS FOR GIS TERMINATION", "E", "E&DD-UGC-02.06"])
        self.assertEqual(by[59].orig[3], "E&DD-UGC-TR-01.01")                  # row after a heading band at the bottom of a page
        self.assertEqual(by[24].orig[1], "CABLE ENTRY PLAN")                    # last row of page 2
        self.assertTrue(by[1].group.startswith("HV/EHV UNDERGROUND CABLE - CATEGORY-1"))
        self.assertTrue(by[59].group.startswith("TRANSITION AREA"))
        self.assertTrue(by[110].group.endswith("TESAD SUBMITTALS"))
        self.assertTrue(all(sum(1 for v in r.orig if v == "R/A") == 1 for r in self.t.rows))
        self.assertTrue(by[115].orig[9].startswith("Special projects only"))

    def test_original_layout_with_heading_rows_in_single_sheet(self):
        out = os.path.join(tempfile.mkdtemp(), "raci.xlsx")
        export_tables_xlsx([self.t], out, modes=("orig",), group_rows=True)
        ws = load_workbook(out)[load_workbook(out).sheetnames[1]]
        groups = len({r.group for r in self.t.rows})
        self.assertEqual(ws.max_row, 1 + 134 + groups)
        self.assertTrue(str(ws["A2"].value).startswith("HV/EHV UNDERGROUND CABLE - CATEGORY-1"))
        self.assertEqual(ws["A3"].value, "1.")
