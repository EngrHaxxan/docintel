"""Plain-English explanations of errors, with a next step. The technical detail goes to the log, not the dialog."""
import errno, logging, sqlite3

log = logging.getLogger("docintel")


def explain(exc, context=""):
    """-> (title, message)"""
    from .diagnostics import OfflineViolation
    from .excel_export import RiskyTemplate
    log.error("%s: %r", context or "error", exc, exc_info=exc)
    if isinstance(exc, RiskyTemplate):
        return "This Excel file has items DocIntel can't keep", str(exc)
    if isinstance(exc, PermissionError) or (isinstance(exc, OSError) and getattr(exc, "winerror", None) in (5, 32, 33)):
        return "Windows would not allow access", ("DocIntel could not open or save a file. Most often the file is open in Excel or another program, "
                                                  "or you don't have permission for that folder. Close the file (or choose another folder) and try again.")
    if isinstance(exc, FileNotFoundError):
        return "File or folder not found", "A file or folder is no longer there (it may have been moved, renamed, or its drive is unplugged). Reconnect the drive, then click \"Update all\"."
    if isinstance(exc, OSError) and exc.errno == errno.ENOSPC:
        return "The disk is full", "There is not enough free space to continue. Free some space (or move the DocIntel data folder to a bigger drive) and try again."
    if isinstance(exc, sqlite3.OperationalError) and "locked" in str(exc).lower():
        return "DocIntel's data is busy", "Another DocIntel window or a backup program is using the index. Close the other window and try again."
    if isinstance(exc, sqlite3.DatabaseError):
        return "The index looks damaged", ("DocIntel's search index could not be read. Go to Settings & Diagnostics and click \"Rebuild search index\", "
                                           "or \"Re-extract everything from sources\". Your own documents are not affected.")
    if isinstance(exc, OfflineViolation):
        return "Offline mode blocked a network connection", "DocIntel is set to work offline and refused to connect to the internet. Nothing was sent."
    if isinstance(exc, RuntimeError) and "free in the index folder" in str(exc):
        return "Not enough disk space", str(exc)
    if isinstance(exc, ValueError):
        return "Please check your entry", str(exc)
    return "Something unexpected happened", ("DocIntel could not finish this task. Nothing was lost. Please try again; if it keeps happening, open "
                                             "Settings & Diagnostics > Show log and send that text to whoever supports you.\n\nDetail: " + f"{exc.__class__.__name__}: {exc}"[:300])


def guess_field(name):
    """Turn a plain field name typed by the user into a field definition (no AI: simple keyword rules)."""
    n = name.strip()
    low = n.lower()
    t = "text"
    if any(w in low for w in ("date", "تاريخ")):
        t = "date"
    elif any(w in low for w in ("invoice no", "number", " no", "id", "ref", "code", "tag", "drawing", "revision", "rev", "po ")) and not any(w in low for w in ("amount", "total", "price", "rate", "cost", "qty", "quantity")):
        t = "id"
    elif any(w in low for w in ("manpower", "workers", "headcount", "count")):
        t = "integer"
    elif any(w in low for w in ("amount", "total", "price", "rate", "cost", "value", "qty", "quantity", "tax", "vat", "weight", "length")):
        t = "number"
    labels = [n]
    short = low.replace("number", "no").strip()
    if short != low:
        labels.append(short.title())
    return {"name": n, "type": t, "labels": labels, "regex": None, "required": False, "min": None, "max": None, "always_review": t == "id" and any(w in low for w in ("rev", "tag"))}
