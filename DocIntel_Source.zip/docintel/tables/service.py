"""Glue between the table engine and the library database (cached per file content + engine version)."""
from __future__ import annotations
import os
from .engine import analyze_pdf
from .store import is_current, save_analysis, list_tables


def extract_file_tables(db, file_row, pages=None, force=False, progress=None, cancel=None):
    """file_row: sqlite row/dict of `files`. Returns dict(status, message, table_ids)."""
    fid, path = file_row["id"], file_row["abspath"]
    ext = (file_row["ext"] or os.path.splitext(path)[1]).lower().lstrip(".")
    if ext != "pdf":
        return {"status": "unsupported", "message": f"Table extraction from .{ext or '?'} files is not available yet.", "table_ids": []}
    if not os.path.exists(path):
        return {"status": "failed", "message": "The file could not be found. It may have been moved or deleted.", "table_ids": []}
    if not force and pages is None and is_current(db, fid, file_row["sha256"]):
        return {"status": "reused", "message": "Tables were already extracted from this unchanged file.",
                "table_ids": [t["id"] for t in list_tables(db, fid)]}
    try:
        an = analyze_pdf(path, pages=pages, progress=progress, cancel=cancel)
    except Exception as e:                                       # never show raw exceptions to the user
        import logging
        logging.getLogger("docintel").exception("table extraction failed for %s", path)
        return {"status": "failed", "message": "This PDF could not be read. It may be damaged or password-protected.", "table_ids": [],
                "detail": f"{type(e).__name__}: {e}"}
    if cancel and cancel():
        return {"status": "cancelled", "message": "Cancelled.", "table_ids": []}
    ids = save_analysis(db, fid, an, sha256=file_row["sha256"], replace=pages is None)
    if an.failures:
        msg = " ".join(m for _, m in an.failures)
        return {"status": "partial", "message": msg, "table_ids": ids}
    if not ids:
        return {"status": "no_tables", "message": "No table was found in this document.", "table_ids": []}
    return {"status": "extracted", "message": f"{len(ids)} table(s) found.", "table_ids": ids}
