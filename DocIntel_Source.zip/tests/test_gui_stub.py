"""Runs tools/gui_stub_check.py (guided screens against a stand-in for Tkinter) in its own process."""
import os, subprocess, sys

def test_guided_screens_python_level():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    r = subprocess.run([sys.executable, os.path.join(root, "tools", "gui_stub_check.py")], capture_output=True, text=True, timeout=300, cwd=root)
    assert r.returncode == 0 and "gui stub check OK" in r.stdout, (r.stdout[-800:], r.stderr[-1500:])
