"""Heading / section detection and fuzzy section matching (always shown to the user for confirmation)."""
from __future__ import annotations
import collections, difflib, re
from dataclasses import dataclass, field
from .geometry import visible_words

try:                                    # optional; difflib fallback keeps the core working everywhere
    from rapidfuzz import fuzz as _fuzz
except Exception:                       # pragma: no cover
    _fuzz = None

NUM_RE = re.compile(r"^(\d+(\.\d+){0,3})[.)]?\s+\S")


@dataclass
class Heading:
    text: str
    page: int
    bbox: tuple
    size: float
    bold: bool
    level: int = 1
    methods: list = field(default_factory=list)


def _lines(pd):
    ws = sorted(visible_words(pd), key=lambda w: ((w["top"] + w["bottom"]) / 2, w["x0"]))
    rows, cur, cy = [], [], None
    for w in ws:
        m = (w["top"] + w["bottom"]) / 2
        if cy is None or abs(m - cy) <= max(1.5, 0.5 * w["size"]):
            cur.append(w); cy = m if cy is None else (cy + m) / 2
        else:
            rows.append(cur); cur = [w]; cy = m
    if cur:
        rows.append(cur)
    runs = []
    for row in rows:
        row.sort(key=lambda w: w["x0"])
        r = [row[0]]
        for w in row[1:]:
            if w["x0"] - r[-1]["x1"] <= max(8.0, 2.5 * w["size"]):
                r.append(w)
            else:
                runs.append(r); r = [w]
        runs.append(r)
    return runs


def detect_headings(pages):
    sizes = collections.Counter()
    for pd in pages:
        for w in pd.words:
            sizes[round(w["size"], 1)] += len(w["text"])
    body = sizes.most_common(1)[0][0] if sizes else 10.0
    out = []
    for pd in pages:
        runs = _lines(pd)
        by_line = collections.defaultdict(list)
        for r in runs:
            by_line[round(r[0]["top"] / 3)].append(r)
        for r in runs:
            text = " ".join(w["text"] for w in r)
            n = len(r)
            if n > 14 or len(text) > 120 or len(text) < 3:
                continue
            size = sorted(w["size"] for w in r)[n // 2]
            bold = sum(1 for w in r if w["bold"]) / n >= 0.6
            alpha = sum(ch.isalpha() for ch in text)
            if alpha < 3 or text.endswith((".", ",", ";")) and not NUM_RE.match(text):
                continue
            m, big = [], size >= 1.18 * body
            if big:
                m.append("font size")
            if bold and text.isupper() and n <= 8 and size >= 0.95 * body:
                m.append("bold capitals")
            if NUM_RE.match(text) and (bold or size >= 1.05 * body):
                m.append("numbered heading")
            if not m:
                continue
            if sum(1 for x in by_line[round(r[0]["top"] / 3)] if x is not r and abs(x[0]["x0"] - r[-1]["x1"]) < 40) and "font size" not in m:
                continue
            if not bold and any(o is not r and abs(o[0]["size"] - size) < 0.3 and 0 < abs(o[0]["top"] - r[0]["top"]) <= 2.2 * size
                                and min(o[-1]["x1"], r[-1]["x1"]) - max(o[0]["x0"], r[0]["x0"]) > 0.2 * (r[-1]["x1"] - r[0]["x0"]) for o in runs):
                continue                                   # a line of a paragraph, not a heading
            if text[0].islower():
                continue
            bb = (min(w["x0"] for w in r), min(w["top"] for w in r), max(w["x1"] for w in r), max(w["bottom"] for w in r))
            out.append(Heading(text, pd.number, bb, size, bold, 1, m))
    sz = sorted({round(h.size, 1) for h in out}, reverse=True)
    for h in out:
        h.level = sz.index(round(h.size, 1)) + 1
    return out


def make_strips(pd, headings, carry_heading=None):
    """Split a page into vertical strips, one per heading (side-by-side headings split horizontally).
    Returns list of (bbox, heading_or_None)."""
    W, H = pd.width, pd.height
    hs = sorted([h for h in headings if h.page == pd.number], key=lambda h: (round(h.bbox[1] / 3), h.bbox[0]))
    if not hs:
        return [((0, 0, W, H), carry_heading)]
    lines = []
    for h in hs:
        if lines and abs(lines[-1][0].bbox[1] - h.bbox[1]) < 3:
            lines[-1].append(h)
        else:
            lines.append([h])
    strips = []
    first_top = min(h.bbox[1] for h in lines[0])
    if first_top > 20:
        strips.append(((0, 0, W, first_top), carry_heading))
    for i, ln in enumerate(lines):
        top = max(h.bbox[3] for h in ln) - 1
        bot = min(h.bbox[1] for h in lines[i + 1]) if i + 1 < len(lines) else H
        ln = sorted(ln, key=lambda h: h.bbox[0])
        for j, h in enumerate(ln):
            xl = 0 if j == 0 else (ln[j - 1].bbox[2] + h.bbox[0]) / 2
            xr = W if j == len(ln) - 1 else (h.bbox[2] + ln[j + 1].bbox[0]) / 2
            strips.append(((xl, top, xr, bot), h))
    return strips


def _norm(s):
    return re.sub(r"[^a-z0-9 ]+", " ", s.lower()).split()


_STOP = {"the", "of", "and", "a", "an", "for", "list"}


def heading_similarity(a: str, b: str) -> float:
    """0..100. Token-aware so 'Construction Activity' ~ 'Construction Activities' ~ 'Construction Progress' (lower)."""
    ta, tb = " ".join(_norm(a)), " ".join(_norm(b))
    if not ta or not tb:
        return 0.0
    if ta == tb:
        return 100.0
    stem = lambda t: " ".join(re.sub(r"(ies|y|es|s)$", "", w) for w in t.split() if w not in _STOP)
    sa, sb = stem(ta), stem(tb)
    if _fuzz:
        return max(_fuzz.token_set_ratio(sa, sb), _fuzz.ratio(sa, sb))
    return 100 * max(difflib.SequenceMatcher(None, sa, sb).ratio(), difflib.SequenceMatcher(None, " ".join(sorted(sa.split())), " ".join(sorted(sb.split()))).ratio())


def match_sections(query: str, tables, headings=None, min_score=60):
    """Candidates for a user-requested section name; never auto-confirmed. Returns sorted list of dicts."""
    seen, out = {}, []
    for t in tables:
        for name in {t.section, t.title} - {""}:
            sc = heading_similarity(query, name)
            if sc >= min_score:
                out.append({"heading": name, "score": round(sc, 1), "exact": sc >= 99.5, "table": t})
    out.sort(key=lambda d: (-d["score"], d["table"].page_from))
    return out
