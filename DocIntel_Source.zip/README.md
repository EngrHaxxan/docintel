# DocIntel - find information in your documents and send it to Excel

DocIntel reads PDFs, scanned pages, photos, Word, PowerPoint, Excel, CSV, HTML and DXF drawings from as many folders and drives as you
like, lets you search them all at once, and copies the information you choose into Excel with a record of where each value came from.
It runs entirely on your own Windows 11 computer, needs no internet, and never changes your documents.

## For ordinary users - what to do first
1. Open **START HERE - How to get your Windows app.pdf**. It explains, click by click, how a free online Windows computer builds your
   installer (`DocIntel_Setup.exe`) and portable zip. No programming, no commands.
2. When you have the installer: double-click it, then follow **DocIntel_User_Guide.pdf** (install, add folders, search, extract, review, Excel).

> **Honest status.** The Windows installer and portable package are **not built yet** - a Windows program can only be produced on a
> Windows machine, and I only have Linux. Everything needed to build and test them automatically on a real Windows machine is included
> and ready. The first Windows build has never run, so it may need one correction round (you would just send me the screenshot).
> See `TEST_REPORT.md` for exactly what has and has not been verified.

## What is in this package
| File | Purpose |
|---|---|
| START HERE - How to get your Windows app.pdf | click-by-click steps to obtain the installer |
| UPLOAD_TO_GITHUB/ | the two items you drag into GitHub (workflow + source zip) |
| DocIntel_User_Guide.pdf | everyday use of the program (11 pages) |
| DocIntel_Source.zip | complete source and build files |
| DocIntel_Offline_Resources.zip | the OCR language files (English, Arabic, orientation), already inside the app; only for repair |
| WINDOWS_BUILD_GUIDE.md | how the automated build works; troubleshooting (technical) |
| TEST_REPORT.md | actual test results, scenario status, limitations |
| CHANGELOG.md / LICENSES_AND_NOTICES.md | what changed; licences |

Files that will exist after your build: `DocIntel_Setup.exe`, `DocIntel_Portable_Windows_x64.zip`, `SHA256SUMS.txt`, `BUILD_RESULT.txt`.

## Features
Multiple folders with recursive indexing, filters and drag-and-drop; persistent local index with incremental updates (new, changed,
deleted, renamed files), pause/resume/cancel and crash recovery; exact, whole-word, all-terms, regular-expression and fuzzy search with
page previews; OCR for scans and photos in English and Arabic (deskew, denoise, rotation); tables from PDF/Office/HTML/OCR with an
editor; reusable extraction profiles, a "describe the fields I want" helper, cleaning/validation, review queue with source-region
preview; Excel export to new workbooks or existing templates with preview, backup, verification, provenance sheet and protection of
templates that contain charts/pictures/pivot tables; duplicate and conflict detection; DXF and PDF drawing support.

## Running from source (developers only)
`pip install -r requirements.txt` (+ Tesseract on PATH or in `tesseract/`), then `python -m docintel gui`. Tests: `python -m pytest tests -q`.
