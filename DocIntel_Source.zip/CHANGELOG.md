# 1.6.2-m6 - structured extraction from scanned tables (tested on Linux; Windows build pending)
- User feedback on build 16 exports: BoQ descriptions were separate rows, the pricing schedule came out as many fragments with `Column 1..8` headers and logo text as section/sheet names, Arabic scan unusable, the medical form gave no table.
- Rows: layouts where an item takes several bands (number + title line, description below) are now one record per item (running number or hierarchical code A.SS.1.2 as anchor); sub-total lines stay separate rows.
- Header: scanned pages have no bold/fill cues, so a band made of typical column-title words (Item, Number, Description, Qty, Unit, Price, Total, ... and Arabic equivalents) is a header; it is searched below a logo/title block; the repeated header on following pages is found below the repeated title block and dropped.
- Scans: no running-header detection (rows at the same height were cut out), fixed nominal text size (OCR noise no longer creates headings), no automatic headings on scanned pages, low-confidence OCR words dropped, one table across all pages.
- Result on the real English scans (Linux): BoQ = one record per item; pricing schedule pages 1-3 = ONE table, 131 rows, 120 unique item rows, no leaked title rows.

# 1.6.1-m6 - real scanned PDFs (tested on Linux; Windows build pending)
- Build 15 (v1.6.0) was all green on Windows. The user then sent 4 real scanned PDFs (image-only): Arabic civil-works BoQ (20 p), a bilingual medical form, an English BoQ (2 p), a 27-page pricing schedule.
- Scanned tables: ruling lines are detected from the image (numpy + Pillow only; cv2/scipy are not in the packaged app) and ERASED before OCR, then used as strokes for the normal grid reader. On the English BoQ scan this raised exact word hits from 12/32 to 32/32 and OCR confidence 0.84 -> 0.93.
- OCR word sizes are normalised (box height is noisy) so ordinary words are no longer taken for headings; the "from OCR" flag now survives page clipping.
- Engine fix (also for vector PDFs): a table with a very tall row (long description, > 90 pt without ruling lines) was cut in two; a vertical rule running through the gap now keeps it together.
- Regression tests with the real scans (tolerant assertions); the 27-page file is stored as its first 3 pages, the Arabic BoQ as its first 4.

# 1.6.0-m6 - Word/Excel/PowerPoint/HTML/CSV tables + scanned-PDF tables (tested on Linux; Windows build pending)
- New tables/office.py: Word (sections, merged cells), Excel (blocks, sheets, merged cells, percent/leading zeros), PowerPoint, HTML, CSV tables stored in the same store; wizard, batch and search use them. Unsupported types are still reported.
- New tables/ocrpage.py: scanned PDF pages are read with OCR and tables rebuilt by word alignment (marked as OCR, quality capped at 0.70).
- Old tests adapted: .docx is now a supported type (unsupported example is .dwg).

# 1.5.1-m5 - fix after Windows build 13
- Windows build 13: build, portable, offline, install checks passed; 2 tests failed. (1) Table-style field extraction from PDFs found 0 rows: the fast index no longer builds per-page tables. Now `extraction.ensure_pdf_tables` builds them on demand (table-style extraction, Tables tab for up to 25 matching PDFs) and stores them once. (2) Test cleanup problem on Windows (log file still open) - test uses separate folders now.

# 1.5.0-m5 - performance (tested on Linux; Windows build pending)
- PDF index uses pypdfium2 text instead of three pdfplumber passes; OCR only for pages without text; word boxes on demand (cached); legacy per-page PDF tables no longer built at index time (table cells of extracted PDFs are searchable instead).
- Process pool for PDFs/images with automatic fallback to threads; Settings > Processing speed (Balanced / Faster / Low resource usage).
- New tools/benchmark_pdf_index.py, tests/test_performance.py, docs/PERFORMANCE.md. Extractor version 2.

# 1.4.1-m4 - fix after Windows build 11
- Windows build 11: build, portable, offline and install checks passed; 1 test failed (RACI found by column names gave 138 rows, not 134). Cause: rapidfuzz (Windows only) let a 4-row title block match the column names. Finding a table by column names now uses a strict match (same words, typo allowed). New regression test imitates rapidfuzz on Linux.

# 1.4.0-m4 - saved extractions + batch jobs (tested on Linux; Windows build pending)
- New `docintel/batch.py`: reusable profiles (section / table-by-column-names / columns / row filter / export options; no page numbers), batch jobs with per-document status, continue-after-failure, cancel/resume, retry failed, add-new-documents-only, confirm similar headings, job report, export.
- DB schema v3 (additive): table_profiles, extraction_jobs, job_items.
- Screens: "Saved extractions && batch jobs" on Home; wizard step 5 "Save these choices"; History has a Batch jobs button.
- Excel export: optional "Job report" sheet. CLI: saved-extractions, batch, batch-jobs, batch-retry, batch-new.

# Changelog

## 1.3.1-m3 (feedback from build 9: single worksheet + colour-cell tables)
- NEW export arrangement **"Everything in ONE worksheet"** (columns merged by name, blanks where a table lacks a column, "Section / table" and source columns on every row) - for filtering across all tables of a document.
- IMPROVED stacking: dates written inside column names ("Progress % / 07-Oct-2026") no longer stop daily reports of different days from stacking; they become "Progress % / (date 1)", "(date 2)" plus real-date columns ("... - date"). The wizard now suggests stacking for such reports.
- NEW option: Original layout can show the PDF's merged heading bands (e.g. "CATEGORY - 2 ...") as their own rows; normalized layout keeps them in the Group column.
- Engine, tables drawn with coloured cells instead of lines (real RACI PDF): fall-back "fill-edge grid" used when the line-based pass explains little of the page; heading bands inside a table no longer cut it into pieces (group labels instead); repeated page-header/footer boxes and their border lines are ignored; numbered table rows are no longer mistaken for headings; unbordered columns (REMARKS) keep their text; header block detection skips titles/logos above the header; tables continuing across pages under a heading band stay one table; rows whose vertical borders are missing are split into cells; adaptive word spacing for small print (missing space characters).
- Real RACI PDF: 134/134 rows in order over pages 2-6, 10 columns, 7 group headings, remarks kept. SCAL (1000/1000) and daily-report results unchanged.
- Tests: +6 (`SingleWorksheet`, `RaciStyleTable`); real PDF added to `tests/real_pdfs/`.

## 1.3.0-m3 (Milestone 3: guided interface)
- NEW Home tab (first): six large actions - Add Documents, Search Documents, Extract to Excel, Review Results, Export to Excel, Extraction History. The ten classic tabs are kept; they are hidden behind "Show advanced tools" (any old button that jumps to a classic tab reveals it automatically). If the new screens cannot be built, the classic tabs simply stay visible.
- NEW 5-step "Extract to Excel" wizard (`docintel/gui_guided.py`, logic in `docintel/wizard.py`): select documents (all / folders / individual PDFs / exclude), choose what to extract (all tables, specific table, specific section, matching records, selected fields, all readable text, free-text request), identify the target (headings found, similar-heading search that must be confirmed, fields not found are left blank and flagged, never substituted), spreadsheet-like preview with correction / mark uncertain / rename / hide / open source, export (xlsx stacked / per table / one file per document, CSV, raw or typed values, layouts, source columns). Background reading with cancel.
- NEW `tests/test_wizard.py` (15), `tools/gui_stub_check.py` + `tests/test_gui_stub.py` (drives every screen against a Tkinter stand-in), `export_tables_csv`.
- Test expectations updated: classic tabs 10 -> 11 (Home added); the Windows smoke test now also reports `home_ok` and `wizard_ok`.

## 1.2.0-m2 (Milestone 2: stored tables, value model, Excel options)
- Database schema v2 (additive, old libraries upgrade automatically): `doc_sections`, `doc_tables`, `table_rows`, `table_cells` (raw original-layout and normalized text, suggested kind, flags, user correction stored apart, reviewed mark). Tables are cached per file content + engine version; unchanged files are reused.
- NEW `docintel/tables/store.py` (save/load/list, `set_correction` / `clear_correction` / `mark_reviewed`, `rename_header` keeps the PDF wording, hide columns) and `service.py`; NEW `Library.extract_tables(file_ids, force, control, progress)`. Friendly messages for unsupported / missing / unreadable files (technical detail only in the log).
- NEW `docintel/tables/values.py`: suggests a kind (text, integer, decimal, percentage, date, datetime, currency, duration, boolean, identifier, unit_value, special, empty); never rejects or changes the raw text; ambiguous dates are not converted.
- Old field extraction: new types `percentage` ("65%" -> 0.65, original kept) and `auto` (never rejects).
- Excel export v2: raw-text (default) or typed values (typed adds a raw-text companion sheet), original/normalized layouts, per-table or combined sheets (tables with identical columns stacked, source columns identify them), leaf or joined header names, hidden columns, user corrections included with a "Corrected cells" column, rollover to extra sheets at the Excel row limit, fast write-only writer, valid Excel tables.
- Tests: `tests/test_tables_store.py` (17).

## 1.1.0-m1 (Milestone 1: new table & section engine)
- NEW package `docintel/tables/`: general stroke-grid table reader (row bands from horizontal strokes, columns from vertical strokes, merged cells = missing separator strokes), header detection (bold/fill/row-number evidence, multi-level headers, rotated header text), cross-page stitching with repeated-header removal, rows split by page breaks, horizontal merges, running page-header boxes ignored, borderless tables by text alignment, heading/section detection with side-by-side headings, fuzzy section matching (always shown for confirmation).
- NEW Excel export (`docintel/tables/export.py`): per table an "Original layout" sheet (blanks where the PDF merges cells) and a "Normalized" sheet (merged values repeated), raw text preserved (cells formatted as text), source/page/section/method/review columns, Summary sheet.
- NEW CLI: `python -m docintel tables FILE.pdf [--section "Construction Activities"] [--pages 5-41] [--out result.xlsx]`.
- NEW tests `tests/test_tables_engine.py` (19) and `tools/table_accuracy.py`; real PDFs under `tests/real_pdfs/`.
- Not yet wired into the GUI/library/database (Milestones 2-4). Scanned-page table reconstruction (OCR geometry) is not part of Milestone 1.

## 1.0.1 (fixes after the first real Windows build)
- FIXED self-check reported failure when optional LibreOffice is absent (broke GUI smoke test and "doctor" on Windows).
- FIXED export row order depended on file scan order (records now ordered by source path, then position).
- FIXED packaged app could not read DXF: numpy was excluded from the build but ezdxf requires it (numpy now bundled and pinned).
- ADDED `prototypes/scal_spike2.py`: proof of method for complete extraction of the 41-page SCAL table (1,000/1,000 rows) - not yet part of the app.

## 1.0.0 (Windows release candidate) - changes since the first delivery
**Windows readiness**
- NEW `paths.py`: installed vs portable data folders, resource folders, safe long-path handling. Portable marker file `portable.txt`.
- FIXED scanner would have stored `\\?\`-prefixed paths and failed relative-path calculations on Windows long paths.
- FIXED Tesseract language path now passed via `TESSDATA_PREFIX` (quoted CLI option broke on spaces/backslashes); bundled Tesseract chosen per OS.
- NEW case-insensitive duplicate-root detection on Windows; no console windows for helper processes; DPI awareness; windowed-build stdout handling; UTF-8 CLI output.
- FIXED build spec (`docintel.spec`) had a comment swallowing the closing parenthesis - the earlier delivery's build script could not have worked.
- NEW app icon, GUI+CLI executables, Inno Setup installer (Start Menu, optional desktop icon, uninstall with optional data removal), portable zip.
- NEW GitHub Actions Windows pipeline (tests, build, portable/offline/installer checks, release), pinned Tesseract + language files by SHA-256, `constraints.txt`.
- NEW `tools/smoke_packaged.py` end-to-end test of packaged builds; `DocIntel.exe gui --smoke-test`.

**For non-technical users**
- NEW "Start here" page, first-run welcome and environment check, Help menu, plain-English error messages with next steps (`friendly.py`),
  drag-and-drop folders, "Describe fields I want" helper, indexing-complete prompt, 11-page User Guide PDF, click-by-click build guide.

**OCR**
- CORRECTED earlier finding: Arabic OCR was *not* poor; the earlier test image was generated incorrectly. With correctly shaped text, English+Arabic read at ~100 % on clean, skewed, low-resolution, blurred, JPEG-damaged and speckled images.
- NEW small-angle deskew (Pillow only), automatic denoise retry for low-confidence pages, removal of invisible bidi marks from OCR output.

**Excel**
- NEW templates containing charts, pictures/shapes, pivot tables, slicers or form controls are blocked from being rewritten unless the user chooses a safer results-only workbook or explicitly accepts losing those items (original is never changed).
- FIXED update-by-key matching when the key column holds real dates/numbers.

**Tests**: 43 automated tests (was 34) + 4 platform-specific skips.
