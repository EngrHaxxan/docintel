"""Builds 'START HERE - How to get your Windows app.pdf' (click-by-click, no technical knowledge needed)."""
import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak

ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=20, textColor=colors.HexColor("#1F4E78"), spaceAfter=8)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=13.5, textColor=colors.HexColor("#1F4E78"), spaceBefore=12, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=11, leading=16)
STEP = ParagraphStyle("S", parent=B, leftIndent=20, bulletIndent=2, spaceAfter=3)
NOTE = ParagraphStyle("N", parent=B, backColor=colors.HexColor("#FFF4D6"), borderPadding=7, spaceBefore=8, spaceAfter=10)
OK = ParagraphStyle("O", parent=B, backColor=colors.HexColor("#E6F4EA"), borderPadding=7, spaceBefore=8, spaceAfter=10)


def steps(items): return [Paragraph(t, STEP, bulletText=f"{i}.") for i, t in enumerate(items, 1)]


def build(out):
    d = SimpleDocTemplate(out, pagesize=A4, leftMargin=2.2 * cm, rightMargin=2.2 * cm, topMargin=2 * cm, bottomMargin=2 * cm, title="Start here - how to get your Windows app")
    s = [Paragraph("START HERE: how to get your Windows app", H1),
         Paragraph("DocIntel is ready, but a Windows program can only be created on a Windows computer. Instead of asking you to install programming tools, "
                   "you will use a free online Windows computer (GitHub) that builds the program for you, tests it, and gives you the finished installer. "
                   "You only click and drag; you do not type any commands. It takes about 15 minutes of your time plus about 30 minutes of waiting.", B),
         Paragraph("<b>Honest status:</b> the Windows installer does not exist yet. It will exist after you complete these steps. This build pipeline has been prepared and its parts tested on Linux, "
                   "but it has not yet run on Windows, so the <b>first run might stop with a red cross</b>. If so, just send me the screenshot or the text (Step 7) and I will fix it; you never have to fix code yourself.", NOTE),
         Paragraph("What you will upload", H2), Paragraph("Open the folder <b>UPLOAD_TO_GITHUB</b> that came with this package. It contains exactly two items: a folder called <b>.github</b> and a file called <b>DocIntel_Source.zip</b>. "
                                                          "Do <b>not</b> open or unzip the zip file. Your own documents are never uploaded - only the program's code.", B),
         Paragraph("Step 1 - Make a free GitHub account (once)", H2)] + steps([
        "Open <b>https://github.com/signup</b> in your browser (Edge or Chrome).", "Enter your email, a password and a username. Complete the puzzle and the email code. Choose the <b>Free</b> plan.",
        "If you already have an account, just sign in at https://github.com/login."]) + [
        Paragraph("Step 2 - Create a private place for the files", H2)] + steps([
        "At the top right, click the <b>+</b> icon, then <b>New repository</b>.", "In <b>Repository name</b> type: <b>docintel</b>", "Choose <b>Private</b> (only you can see it).",
        "Leave everything else alone and click the green <b>Create repository</b> button."]) + [
        Paragraph("Step 3 - Upload the two items", H2)] + steps([
        "On the new page, click the blue link <b>uploading an existing file</b>.", "Open Windows File Explorer, go into the <b>UPLOAD_TO_GITHUB</b> folder, press <b>Ctrl + A</b> to select both items.",
        "Drag them onto the browser page where it says \"Drag files here\". Wait until both names appear in the list (the zip is small; this takes seconds).",
        "Scroll down and click the green <b>Commit changes</b> button."]) + [
        Paragraph("If dragging the <b>.github</b> folder does not work in your browser: click <b>Add file > Create new file</b>, type <b>.github/workflows/build-windows.yml</b> as the name "
                  "(typing the slashes creates the folders), open the file <i>build-windows.yml</i> from the folder with Notepad, copy everything, paste it into the big box, and click <b>Commit changes</b>. Then upload only the zip.", NOTE),
        Paragraph("Step 4 - Wait while Windows builds your app", H2)] + steps([
        "Click the <b>Actions</b> tab at the top of the repository page.", "If GitHub shows a green button <b>\"I understand my workflows, go ahead and enable them\"</b>, click it.",
        "You will see <b>Build DocIntel for Windows</b> with a <b>yellow dot</b> (working). If nothing is running, click the workflow name on the left, then <b>Run workflow</b> (right side), then the green <b>Run workflow</b> button.",
        "Wait. It usually takes 20 to 40 minutes. You can close the browser; it keeps working. A <b>green tick</b> means success; a <b>red cross</b> means a problem (Step 7)."]) + [PageBreak()]
    s += [Paragraph("Step 5 - Download your app", H2)] + steps([
        "Click the <b>Code</b> tab (top left of the repository).", "On the right side, under <b>Releases</b>, click <b>DocIntel for Windows - build 1</b>.",
        "Scroll to <b>Assets</b> and click to download:<br/>&bull; <b>DocIntel_Setup.exe</b> - the installer (recommended)<br/>&bull; <b>DocIntel_Portable_Windows_x64.zip</b> - no installation needed<br/>&bull; <b>BUILD_RESULT.txt</b> - shows which checks passed on Windows",
        "(Backup place: on the <b>Actions</b> tab, click the finished run, scroll to <b>Artifacts</b>, click <b>DocIntel-Windows-build-1</b>; it downloads one zip containing the same files.)"]) + [
        Paragraph("Open <b>BUILD_RESULT.txt</b>: every line should say SUCCESS. That is your proof that the tests, the portable copy, the offline check and the install/uninstall check all ran on a real Windows machine.", OK),
        Paragraph("Step 6 - Install and use it", H2)] + steps([
        "Double-click <b>DocIntel_Setup.exe</b>. If Windows says <b>\"Windows protected your PC\"</b>, click <b>More info</b>, then <b>Run anyway</b>. (This appears for any new program from a small publisher.)",
        "Click Next, tick <i>Create a desktop shortcut</i> if you like, click Install, then Finish.", "Double-click the DocIntel icon. Then follow <b>DocIntel_User_Guide.pdf</b>.",
        "To give DocIntel to another person: send them <b>DocIntel_Setup.exe</b> (or the portable zip). They need nothing else."]) + [
        Paragraph("Step 7 - If the build shows a red cross", H2)] + steps([
        "Click the failed run (the line with the red cross), then click the red step name.", "Take a screenshot of the page (or select the red text and copy it) and send it to me with the words \"the build failed\".",
        "I will correct the project and give you a new <b>DocIntel_Source.zip</b>. To try again: in your repository click the file <b>DocIntel_Source.zip</b>, click the <b>...</b> menu, choose <b>Delete file</b>, commit, then upload the new zip the same way as Step 3. The build starts again by itself."]) + [
        Paragraph("Good to know", H2),
        Paragraph("&bull; <b>Cost:</b> free. A private repository includes enough free build time for several builds each month.<br/>"
                  "&bull; <b>Privacy:</b> the repository is private; only the program's code is uploaded, never your documents. GitHub's computers only build the program.<br/>"
                  "&bull; <b>Updates:</b> when I send an improved version, you repeat Step 3 with the new zip and download the new installer in Step 5.<br/>"
                  "&bull; <b>Windows warning:</b> the installer is not digitally signed (signing certificates cost money), which is why Windows asks you to confirm. Check the fingerprint in <i>SHA256SUMS.txt</i> if you want to be sure a copy was not altered.", B)]
    d.build(s)


if __name__ == "__main__":
    build(sys.argv[1])
