"""Engineering-drawing helpers: a ready-made title-block profile and dimension/tag recognisers.

Strategy: (1) vector text from PDF/DXF where available (exact), (2) OCR with word boxes otherwise (uncertain),
(3) label-based title-block extraction, (4) dimensions and tags always routed to the review queue with a
source-region preview. Dimensions are NEVER presented as verified.
"""

DIMENSION_RX = r"((?:[ØøΦ⌀R]\s?)?\d{1,5}(?:[.,]\d{1,3})?\s?(?:mm|cm|m|in|\")?\s?(?:[±]\s?\d+(?:[.,]\d+)?)?)"
TAG_RX = r"\b([A-Z]{1,4}-\d{2,5}[A-Z]?(?:-\d{1,3})?)\b"      # e.g. P-101A, TK-2001, HX-12-3


def title_block_profile(name="Drawing title block"):
    return {
        "name": name, "mode": "document", "description": "Drawing number, title, revision, scale, date from title blocks",
        "fields": [
            {"name": "Drawing number", "type": "id", "labels": ["Drawing No", "Drawing Number", "DWG No", "DWG. NO.", "Dwg Number"], "required": True},
            {"name": "Drawing title", "type": "text", "labels": ["Title", "Drawing Title"]},
            {"name": "Revision", "type": "id", "labels": ["Rev", "Revision", "REV."], "required": True, "always_review": True},
            {"name": "Scale", "type": "text", "labels": ["Scale"]},
            {"name": "Date", "type": "date", "labels": ["Date", "Issue Date"]},
            {"name": "Equipment tags", "type": "text", "regex": TAG_RX, "multi": True, "always_review": True},
        ],
        "key_fields": ["Drawing number", "Revision"], "duplicate_policy": "flag",
    }
