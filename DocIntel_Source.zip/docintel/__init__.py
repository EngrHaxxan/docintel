"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.7.0-m7"
