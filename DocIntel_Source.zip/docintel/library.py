"""Library: source roots, incremental scanning (new/changed/deleted/renamed/moved), resumable indexing jobs."""
import fnmatch, hashlib, json, logging, os, shutil, threading, time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

from .db import DB, jdump
from .config import Config
from . import extractors as X
from .paths import long_path as longpath

log = logging.getLogger("docintel")


def norm_ext(s):
    return {e.strip().lower().lstrip(".") for e in (s or "").replace(";", ",").split(",") if e.strip()}


def sha256_file(path, bufsize=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(bufsize)
            if not b: break
            h.update(b)
    return h.hexdigest()


class JobControl:
    def __init__(self):
        self._pause = threading.Event(); self._pause.set()
        self.cancelled = False
    def pause(self): self._pause.clear()
    def resume(self): self._pause.set()
    def cancel(self): self.cancelled = True; self._pause.set()
    @property
    def paused(self): return not self._pause.is_set()
    def wait_if_paused(self):
        while not self._pause.wait(0.2):
            if self.cancelled: return


class Library:
    def __init__(self, home=None):
        self.cfg = Config(home)
        self.db = DB(self.cfg.db_path)
        n = self.db.recover_interrupted()
        if n: log.info("recovered %d interrupted files back into the queue", n)
        _setup_logging(self.cfg.log_path)

    # ------------------------------------------------------------------ roots
    def add_root(self, path, name=None, include_ext="", exclude_globs=""):
        path = os.path.normpath(os.path.abspath(path))
        if os.name == "nt":      # Windows paths are case-insensitive: D:\Reports and d:\reports are the same source
            for r in self.roots():
                if os.path.normcase(r["path"]) == os.path.normcase(path):
                    raise ValueError(f"already registered: {path}")
        if not os.path.isdir(path):
            raise ValueError(f"not a directory (or currently unavailable): {path}")
        name = name or os.path.basename(path.rstrip("\\/")) or path
        try:
            cur = self.db.x("INSERT INTO roots(name,path,include_ext,exclude_globs) VALUES(?,?,?,?)",
                            (name, path, include_ext, exclude_globs))
        except Exception:
            raise ValueError(f"already registered: {path}")
        return cur.lastrowid

    def add_roots(self, paths):
        out = []
        for p in paths:
            try: out.append(self.add_root(p))
            except ValueError as e: out.append(str(e))
        return out

    def roots(self):
        return self.db.q("SELECT * FROM roots ORDER BY name")

    def update_root(self, root_id, **kw):
        allowed = {"name", "enabled", "include_ext", "exclude_globs", "min_mtime", "max_mtime", "path"}
        for k, v in kw.items():
            if k not in allowed: raise KeyError(k)
            self.db.x(f"UPDATE roots SET {k}=? WHERE id=?", (v, root_id))

    def remove_root(self, root_id):
        """Removes the root from the index only. Never touches the files on disk."""
        self.db.x("DELETE FROM roots WHERE id=?", (root_id,))

    # ------------------------------------------------------------------ scanning (cheap metadata pass)
    def scan(self, root_ids=None, subpath=None, full=False, control=None, progress=None):
        control = control or JobControl()
        rows = self.roots() if root_ids is None else [r for r in self.roots() if r["id"] in root_ids]
        totals = {}
        job = self.db.x("INSERT INTO jobs(kind,status,started,scope) VALUES('scan','running',?,?)",
                        (time.time(), jdump({"roots": [r["id"] for r in rows], "subpath": subpath}))).lastrowid
        for r in rows:
            if not r["enabled"] or control.cancelled: continue
            totals[r["name"]] = self._scan_root(r, subpath, full, control, progress)
        self.db.x("UPDATE jobs SET status=?, finished=?, stats=? WHERE id=?",
                  ("cancelled" if control.cancelled else "done", time.time(), jdump(totals), job))
        return totals

    def _scan_root(self, r, subpath, full, control, progress):
        stats = dict(new=0, changed=0, unchanged=0, missing=0, moved=0, errors=0, skipped=0, unavailable=False)
        root = r["path"]
        if not os.path.isdir(longpath(root)):
            # drive/share not reachable: do NOT treat files as deleted
            self.db.x("UPDATE roots SET available=0 WHERE id=?", (r["id"],))
            stats["unavailable"] = True
            return stats
        self.db.x("UPDATE roots SET available=1 WHERE id=?", (r["id"],))
        inc = norm_ext(r["include_ext"])
        excl = list(self.cfg["default_excludes"]) + [g.strip() for g in (r["exclude_globs"] or "").replace(";", ",").split(",") if g.strip()]
        max_bytes = self.cfg["max_file_mb"] * 1024 * 1024
        start = os.path.join(root, subpath) if subpath else root
        known = {row["relpath"]: row for row in self.db.q("SELECT * FROM files WHERE root_id=?", (r["id"],))}
        seen, visited = set(), set()
        stack = [start]
        batch = 0
        while stack:
            if control.cancelled: break
            control.wait_if_paused()
            d = stack.pop()
            try:
                real = os.path.realpath(d)
                if real in visited: continue      # symlink / junction loop guard
                visited.add(real)
                entries = list(os.scandir(longpath(d)))   # entry.name only; paths are rebuilt without any \\?\ prefix
            except (PermissionError, OSError) as e:
                stats["errors"] += 1
                log.warning("cannot read directory %s: %s", d, e.__class__.__name__)
                continue
            for e in entries:
                try:
                    if any(fnmatch.fnmatch(e.name, g) for g in excl):
                        continue
                    if e.is_dir(follow_symlinks=True):
                        stack.append(os.path.join(d, e.name)); continue
                    if not e.is_file(follow_symlinks=True): continue
                    ext = os.path.splitext(e.name)[1].lower().lstrip(".")
                    if inc and ext not in inc: continue
                    st = e.stat()
                    if r["min_mtime"] and st.st_mtime < r["min_mtime"]: continue
                    if r["max_mtime"] and st.st_mtime > r["max_mtime"]: continue
                    fpath = os.path.join(d, e.name)
                    rel = os.path.relpath(fpath, root)
                    seen.add(rel)
                    old = known.get(rel)
                    if old is not None and not full and old["size"] == st.st_size and abs((old["mtime"] or 0) - st.st_mtime) < 1e-3 \
                            and old["status"] != "missing":
                        stats["unchanged"] += 1; continue
                    if old is not None and old["status"] == "missing":
                        pass  # reappeared
                    supported = ext in X.SUPPORTED
                    status = "pending"
                    err = None
                    if st.st_size > max_bytes:
                        status, err = "skipped", f"larger than {self.cfg['max_file_mb']} MB limit"
                        stats["skipped"] += 1
                    elif not supported:
                        status, err = "unsupported", f"unsupported file type .{ext}"
                    try:
                        h = sha256_file(longpath(fpath)) if status == "pending" or old is None else (old["sha256"] if old else None)
                    except OSError:
                        h = None
                    if old is not None:
                        if old["sha256"] and h and old["sha256"] == h and old["status"] in ("indexed", "error", "unsupported"):
                            # touched but identical content: keep the index, refresh metadata
                            self.db.conn.execute("UPDATE files SET size=?, mtime=?, missing_since=NULL WHERE id=?", (st.st_size, st.st_mtime, old["id"]))
                            stats["unchanged"] += 1; continue
                        self.db.conn.execute("DELETE FROM segments WHERE file_id=?", (old["id"],))
                        self.db.conn.execute("DELETE FROM tables_ WHERE file_id=?", (old["id"],))
                        self.db.conn.execute("UPDATE files SET size=?,mtime=?,sha256=?,status=?,error=?,missing_since=NULL,abspath=? WHERE id=?",
                                             (st.st_size, st.st_mtime, h, status, err, fpath, old["id"]))
                        stats["changed"] += 1
                    else:
                        self.db.conn.execute(
                            "INSERT INTO files(root_id,relpath,abspath,name,ext,size,mtime,sha256,status,error) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (r["id"], rel, fpath, e.name, ext, st.st_size, st.st_mtime, h, status, err))
                        stats["new"] += 1
                    batch += 1
                    if batch % 500 == 0:
                        self.db.conn.commit()
                        if progress: progress("scan", r["name"], stats)
                except (PermissionError, OSError) as ex:
                    stats["errors"] += 1
                    log.warning("cannot stat %s: %s", os.path.join(d, e.name), ex.__class__.__name__)
        self.db.conn.commit()
        if not control.cancelled:
            self._reconcile_missing(r, known, seen, subpath, stats)
        self.db.x("UPDATE roots SET last_scan=?, last_scan_stats=? WHERE id=?", (time.time(), jdump(stats), r["id"]))
        return stats

    def _reconcile_missing(self, r, known, seen, subpath, stats):
        now = time.time()
        prefix = (subpath.rstrip("/\\") + os.sep) if subpath else ""
        gone = [row for rel, row in known.items() if rel not in seen and row["status"] != "missing" and (not prefix or rel.startswith(prefix))]
        # rename/move detection: a "new" file whose hash equals a vanished file's hash
        by_hash = {}
        for row in gone:
            if row["sha256"]: by_hash.setdefault(row["sha256"], []).append(row)
        fresh = self.db.q("SELECT id,sha256,relpath FROM files WHERE root_id=? AND indexed_at IS NULL AND status IN ('pending','unsupported','skipped')", (r["id"],))
        moved_ids = set()
        for f in fresh:
            cands = by_hash.get(f["sha256"] or "")
            if cands:
                old = cands.pop()
                # keep the already-extracted data: transplant segments/tables to the new row, drop the old row
                self.db.conn.execute("UPDATE segments SET file_id=? WHERE file_id=?", (f["id"], old["id"]))
                self.db.conn.execute("UPDATE tables_ SET file_id=? WHERE file_id=?", (f["id"], old["id"]))
                self.db.conn.execute("UPDATE files SET status=?, indexed_at=?, error=?, warnings=?, extractor_version=? WHERE id=?",
                                     (old["status"], old["indexed_at"], old["error"], old["warnings"], old["extractor_version"], f["id"]))
                self.db.conn.execute("DELETE FROM files WHERE id=?", (old["id"],))
                moved_ids.add(old["id"]); stats["moved"] += 1; stats["new"] = max(0, stats["new"] - 1)
        for row in gone:
            if row["id"] in moved_ids: continue
            self.db.conn.execute("UPDATE files SET status='missing', missing_since=? WHERE id=?", (now, row["id"]))
            stats["missing"] += 1
        self.db.conn.commit()

    # ------------------------------------------------------------------ indexing (expensive pass)
    def _free_mb(self):
        try: return shutil.disk_usage(self.cfg.home).free / 1048576
        except Exception: return 1e9

    def index(self, root_ids=None, control=None, progress=None, limit=None, only_ids=None):
        control = control or JobControl()
        if self._free_mb() < self.cfg["min_free_disk_mb"]:
            raise RuntimeError(f"less than {self.cfg['min_free_disk_mb']} MB free in the index folder; aborting to protect the database")
        q = "SELECT f.id FROM files f JOIN roots r ON r.id=f.root_id WHERE f.status='pending' AND r.enabled=1 AND r.available=1"
        args = []
        if root_ids:
            q += f" AND f.root_id IN ({','.join('?' * len(root_ids))})"; args += list(root_ids)
        if only_ids:
            q += f" AND f.id IN ({','.join('?' * len(only_ids))})"; args += list(only_ids)
        q += " ORDER BY f.size"                      # small files first: results become searchable early
        ids = [x[0] for x in self.db.q(q, args)]
        if limit: ids = ids[:limit]
        stats = dict(total=len(ids), done=0, indexed=0, errors=0, unsupported=0, t0=time.time())
        job = self.db.x("INSERT INTO jobs(kind,status,started,scope) VALUES('index','running',?,?)",
                        (time.time(), jdump({"roots": root_ids}))).lastrowid
        ocr_holder = {}
        def ocr_factory():
            if "o" not in ocr_holder: ocr_holder["o"] = X.OCR(self.cfg)
            return ocr_holder["o"]
        def work(fid):
            control.wait_if_paused()
            if control.cancelled: return fid, "cancelled", None
            # worker threads each get their own sqlite connection via DB.conn
            row = self.db.one("SELECT * FROM files WHERE id=?", (fid,))
            if row is None: return fid, "gone", None
            self.db.x("UPDATE files SET status='processing' WHERE id=?", (fid,))
            try:
                res = X.extract_file(longpath(row["abspath"]), self.cfg, ocr_factory)
                self._store(fid, res)
                return fid, "indexed", None
            except X.Unsupported as e:
                self._fail(fid, "unsupported", str(e)); return fid, "unsupported", str(e)
            except X.Corrupted as e:
                self._fail(fid, "error", "corrupted: " + str(e)[:300]); return fid, "error", str(e)
            except X.Encrypted as e:
                self._fail(fid, "error", "encrypted: " + str(e)); return fid, "error", str(e)
            except FileNotFoundError:
                self.db.x("UPDATE files SET status='missing', missing_since=? WHERE id=?", (time.time(), fid)); return fid, "missing", None
            except Exception as e:
                log.exception("extract failed for file id %s", fid)
                self._fail(fid, "error", f"{e.__class__.__name__}: {e}"[:500]); return fid, "error", str(e)
        with ThreadPoolExecutor(max_workers=max(1, int(self.cfg["workers"]))) as ex:
            it = iter(ids); pending = set()
            def submit_more():
                while len(pending) < self.cfg["workers"] * 2 and not control.cancelled:
                    try: pending.add(ex.submit(work, next(it)))
                    except StopIteration: break
            submit_more()
            while pending:
                done, _ = wait(pending, return_when=FIRST_COMPLETED)
                for f in done:
                    pending.discard(f)
                    fid, st, _e = f.result()
                    if st == "cancelled": continue
                    stats["done"] += 1
                    stats[{"indexed": "indexed", "unsupported": "unsupported"}.get(st, "errors")] += 1
                    if progress: progress("index", fid, dict(stats))
                control.wait_if_paused()
                submit_more()
        # anything we marked 'processing' but never finished (cancel) returns to the queue
        self.db.x("UPDATE files SET status='pending' WHERE status='processing'")
        stats["elapsed"] = round(time.time() - stats.pop("t0"), 2)
        self.db.x("UPDATE jobs SET status=?, finished=?, stats=? WHERE id=?",
                  ("cancelled" if control.cancelled else "done", time.time(), jdump(stats), job))
        return stats

    def _store(self, fid, res):
        c = self.db.conn
        with c:   # one transaction per file: either fully indexed or not at all
            c.execute("DELETE FROM segments WHERE file_id=?", (fid,))
            c.execute("DELETE FROM tables_ WHERE file_id=?", (fid,))
            for s in res.segments:
                c.execute("INSERT INTO segments(file_id,kind,loc,text,method,confidence,words_json,page_w,page_h) VALUES(?,?,?,?,?,?,?,?,?)",
                          (fid, s.kind, s.loc, s.text, s.method, s.confidence, jdump(s.words) if s.words else None, s.page_w, s.page_h))
            for t in res.tables:
                c.execute("INSERT INTO tables_(file_id,loc,idx,rows_json,method,confidence,note) VALUES(?,?,?,?,?,?,?)",
                          (fid, t.loc, t.idx, jdump(t.rows), t.method, t.confidence, t.note))
            c.execute("UPDATE files SET status='indexed', error=NULL, warnings=?, indexed_at=?, extractor_version=? WHERE id=?",
                      (jdump(res.warnings) if res.warnings else None, time.time(), X.EXTRACTOR_VERSION, fid))

    def _fail(self, fid, status, msg):
        c = self.db.conn
        with c:
            c.execute("DELETE FROM segments WHERE file_id=?", (fid,))
            c.execute("UPDATE files SET status=?, error=?, indexed_at=? WHERE id=?", (status, msg, time.time(), fid))

    def retry_failed(self, root_ids=None):
        q = "UPDATE files SET status='pending', error=NULL WHERE status='error'"
        return self.db.x(q).rowcount

    def reindex_all(self):
        """Full rebuild from the original sources (index is a cache; sources are the truth)."""
        self.db.x("UPDATE files SET status='pending' WHERE status IN ('indexed','error','processing')")
        self.db.x("DELETE FROM segments"); self.db.x("DELETE FROM tables_")
        self.db.rebuild_fts()

    # ------------------------------------------------------------------ stats
    def dashboard(self):
        d = {"roots": []}
        for r in self.roots():
            s = {x["status"]: x["n"] for x in self.db.q("SELECT status, COUNT(*) n FROM files WHERE root_id=? GROUP BY status", (r["id"],))}
            d["roots"].append({"id": r["id"], "name": r["name"], "path": r["path"], "enabled": bool(r["enabled"]),
                               "available": bool(r["available"]), "last_scan": r["last_scan"], "files": s})
        d["totals"] = {x["status"]: x["n"] for x in self.db.q("SELECT status, COUNT(*) n FROM files GROUP BY status")}
        d["segments"] = self.db.one("SELECT COUNT(*) FROM segments")[0]
        d["tables"] = self.db.one("SELECT COUNT(*) FROM tables_")[0]
        d["db_mb"] = round(os.path.getsize(self.cfg.db_path) / 1048576, 2) if os.path.exists(self.cfg.db_path) else 0
        return d


def _setup_logging(path):
    if any(isinstance(h, logging.FileHandler) and getattr(h, "baseFilename", "") == os.path.abspath(path) for h in log.handlers):
        return
    h = logging.FileHandler(path, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(h); log.setLevel(logging.INFO)
