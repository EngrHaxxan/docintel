"""Guided extraction logic (no GUI code, so it is fully testable): select documents -> choose what to extract ->
identify target -> preview/correct -> export. The Tkinter screens (gui_guided.py) are thin views over this class."""
from __future__ import annotations
import copy, json, os, re, time
from dataclasses import dataclass, field
from .tables import analyze_pdf, store
from .tables.model import Table, Row, Header
from .tables.sections import heading_similarity, _norm
from .tables.export import export_tables_xlsx, export_tables_csv

MODES = [("all_tables", "Extract all tables", "Every table found in the selected documents."),
         ("table", "Extract a specific table", "Pick one table from a list of what was found."),
         ("section", "Extract a specific section", "Pick a section heading (for example Construction Activities)."),
         ("records", "Extract matching records", "Only the rows that contain a word or phrase you type."),
         ("fields", "Extract selected fields", "Only the columns you choose."),
         ("text", "Extract all readable text", "The text of every page, one row per page."),
         ("custom", "Describe what I want", "Type your request in normal language.")]
_STOP = {"the", "a", "an", "of", "and", "all", "from", "in", "to", "for", "with", "each", "every", "reports", "report", "documents"}


def _stem(w):
    return re.sub(r"(ies|y|es|s)$", "", w.lower())


def _tokens(s):
    return [_stem(w) for w in re.findall(r"[A-Za-z0-9]+", s) if w.lower() not in _STOP]


@dataclass
class Entry:
    label: str                      # document name
    path: str
    table: Table
    db_id: int | None = None
    file_id: int | None = None
    col_map: list | None = None     # source column of each visible column (None = not found), set when fields were selected

    @property
    def heading(self):
        return (self.table.section or self.table.title or "").strip()

    def describe(self):
        t = self.table
        return f"{self.label} | {self.heading or 'untitled'} | pages {t.page_from}-{t.page_to} | {len(t.rows)} rows x {len(t.headers)} cols"


def match_columns(name: str, headers, threshold=60.0):
    """Which header columns does a requested field name refer to? Several columns may match (e.g. two progress dates)."""
    scores = []
    toks = set(_tokens(name))
    for i, h in enumerate(headers):
        cand = max(heading_similarity(name, h.name), heading_similarity(name, h.leaf or h.name), heading_similarity(name, h.parent or ""))
        ht = set(_tokens(h.name))
        if toks and ht:
            cand = max(cand, 100.0 * len(toks & ht) / len(toks) * (0.9 if len(toks & ht) < len(toks) else 1.0))
        scores.append((cand, i))
    best = max((s for s, _ in scores), default=0)
    if best < threshold:
        return []
    return [i for s, i in scores if s >= max(threshold, 0.92 * best)]


def parse_request(text: str, catalog_headings=()):
    """Offline, rule-based reading of a request such as 'Extract every issue from the Issues & Concerns section, including
    description, urgency, owner'. Returns {section, fields, all_columns, filter}. Nothing is invented: the user confirms the result."""
    t = text.strip()
    low = t.lower()
    out = {"section": "", "fields": [], "all_columns": False, "filter": ""}
    rt = set(_tokens(t))
    best, bs = "", 0.0
    for h in catalog_headings:
        ht = _tokens(h)
        if not ht:
            continue
        cov = len(set(ht) & rt) / len(set(ht))
        if cov > bs or (cov == bs and len(ht) > len(_tokens(best))):
            best, bs = h, cov
    if bs >= 0.99:
        out["section"] = best
    m = re.search(r"\b(?:including|include|with|containing|showing|columns?|fields?)\b[:\s]+(.+)$", t, re.I | re.S)
    if m:
        parts = re.split(r",|;|\band\b|&", m.group(1))
        out["fields"] = [re.sub(r"^(the|its|their)\s+", "", p.strip(" .\n"), flags=re.I) for p in parts if p.strip(" .\n")]
    if re.search(r"\ball (the )?columns\b|\bcomplete\b|\bwith all\b", low) and not out["fields"]:
        out["all_columns"] = True
    m = re.search(r"\b(?:containing|that contain|matching|mentioning)\s+[\"“']?([^\"”']+)[\"”']?\s*$", t, re.I)
    if m and not out["fields"]:
        out["filter"] = m.group(1).strip()
    return out


class Session:
    def __init__(self, lib):
        self.lib = lib
        self.file_ids: list[int] = []
        self.adhoc: list[str] = []
        self.excluded: set = set()
        self.catalog: list[Entry] = []
        self.status: dict = {}          # label -> (status, message)
        self.mode = "all_tables"
        self.params: dict = {}
        self.preview: list[Entry] = []
        self.warnings: list[str] = []

    # -------------------------------------------------- step 1: documents
    def pdf_files(self, root_ids=None):
        sql = "SELECT id, name, abspath, root_id FROM files WHERE lower(ext) IN ('pdf','.pdf') AND missing_since IS NULL"
        args = ()
        if root_ids:
            sql += f" AND root_id IN ({','.join('?' * len(root_ids))})"; args = tuple(root_ids)
        return [dict(r) for r in self.lib.db.q(sql + " ORDER BY name", args)]

    def select_roots(self, root_ids):
        self.file_ids = [f["id"] for f in self.pdf_files(root_ids)]

    def select_all(self):
        self.file_ids = [f["id"] for f in self.pdf_files()]

    def select_files(self, ids):
        self.file_ids = list(dict.fromkeys(ids))

    def add_adhoc(self, paths):
        for p in paths:
            if p not in self.adhoc and os.path.isfile(p):
                self.adhoc.append(p)

    def exclude(self, label_or_id, on=True):
        (self.excluded.add if on else self.excluded.discard)(label_or_id)

    def selected_count(self):
        return len([i for i in self.file_ids if i not in self.excluded]) + len([p for p in self.adhoc if p not in self.excluded])

    # -------------------------------------------------- step 2/3: scan, identify
    def prepare(self, progress=None, control=None, force=False):
        """Make sure every selected document has its tables detected (cached in the library). Fills self.catalog."""
        self.catalog, self.status = [], {}
        ids = [i for i in self.file_ids if i not in self.excluded]
        res = self.lib.extract_tables(file_ids=ids, force=force, control=control, progress=progress) if ids else {}
        for fid in ids:
            r = res.get(fid)
            row = self.lib.db.one("SELECT name, abspath FROM files WHERE id=?", (fid,))
            if row is None:
                continue
            self.status[row["name"]] = (r["status"] if r else "skipped", r["message"] if r else "Not processed.")
            for t in store.list_tables(self.lib.db, fid):
                self.catalog.append(Entry(row["name"], row["abspath"], store.load_table(self.lib.db, t["id"]), t["id"], fid))
        for i, p in enumerate([p for p in self.adhoc if p not in self.excluded]):
            if control is not None and control.cancelled:
                break
            name = os.path.basename(p)
            try:
                an = analyze_pdf(p)
                for t in an.tables:
                    self.catalog.append(Entry(name, p, t))
                self.status[name] = ("extracted" if an.tables else "no_tables", f"{len(an.tables)} table(s) found." if an.tables else "No table was found in this document.")
            except Exception:
                self.status[name] = ("failed", "This file could not be read.")
            if progress:
                progress(i + 1, len(self.adhoc), name)
        return self.catalog

    def headings(self):
        """Distinct section headings found, with how many documents have each (for the 'identify target' step)."""
        g = {}
        for e in self.catalog:
            h = e.heading
            if h:
                d = g.setdefault(h.lower(), {"heading": h, "docs": set(), "tables": 0})
                d["docs"].add(e.label); d["tables"] += 1
        return sorted(({"heading": v["heading"], "documents": len(v["docs"]), "tables": v["tables"]} for v in g.values()), key=lambda d: (-d["documents"], d["heading"]))

    def candidates(self, query):
        """Headings similar to the request, best first. The user must confirm - a similar name is never assumed identical."""
        out = []
        for h in self.headings():
            sc = heading_similarity(query, h["heading"])
            if sc >= 60:
                out.append({**h, "score": round(sc, 1), "exact": sc >= 99.5})
        return sorted(out, key=lambda d: -d["score"])

    # -------------------------------------------------- step 3/4: build the preview
    def build(self, mode, **params):
        self.mode, self.params, self.warnings = mode, params, []
        ents = list(self.catalog)
        if mode == "custom":
            req = parse_request(params.get("text", ""), [h["heading"] for h in self.headings()])
            self.params["parsed"] = req
            sec = params.get("section") or req["section"]
            if sec:
                params = {**params, "headings": [sec] if isinstance(sec, str) else sec}
            if params.get("fields") is None and req["fields"]:
                params = {**params, "fields": req["fields"]}
            if req["filter"] and not params.get("text_filter"):
                params = {**params, "text_filter": req["filter"]}
            mode = "section" if params.get("headings") else ("fields" if params.get("fields") else "all_tables")
            if not params.get("headings") and not params.get("fields"):
                self.warnings.append("No section or field name in your request matched the documents. Showing all tables - choose what you need.")
        if mode == "all_tables":
            self.preview = ents
        elif mode == "table":
            keep = set(params.get("indices", []))
            self.preview = [e for i, e in enumerate(ents) if i in keep]
        elif mode in ("section", "records", "fields") and params.get("headings"):
            hs = {h.lower() for h in params["headings"]}
            self.preview = [e for e in ents if e.heading.lower() in hs]
            have = {e.label for e in self.preview}
            for lab in self.status:
                if lab not in have and self.status[lab][0] in ("extracted", "reused", "partial", "no_tables"):
                    self.warnings.append(f"{', '.join(params['headings'])} was not found in {lab}.")
        else:
            self.preview = ents
        if mode == "text":
            self.preview = self._text_entries()
        if params.get("fields") and mode != "text":
            self.preview = [self._select_fields(e, params["fields"]) for e in self.preview]
        flt = params.get("text_filter") or (params.get("text") if mode == "records" else "")
        if flt:
            self.preview = [self._filter_rows(e, flt) for e in self.preview]
            self.preview = [e for e in self.preview if e.table.rows]
        return self.preview

    def _select_fields(self, e: Entry, wanted):
        """Keep only the wanted columns (in the requested order). A requested field that does not exist stays as a blank,
        flagged column - nothing is invented and no other column is substituted silently."""
        t = e.table
        cmap, hs = [], []
        for w in wanted:
            idx = match_columns(w, t.headers)
            if idx:
                for i in idx:
                    cmap.append(i); hs.append(copy.deepcopy(t.headers[i]))
            else:
                cmap.append(None); hs.append(Header(w, flags=["review: requested field not found in this table"]))
                self.warnings.append(f"'{w}' was not found in {e.label} ({e.heading or 'table'}); the column is left blank.")
        nt = copy.deepcopy(t)
        nt.headers = hs
        for r_old, r_new in zip(t.rows, nt.rows):
            r_new.orig = [r_old.orig[c] if c is not None else "" for c in cmap]
            r_new.norm = [r_old.norm[c] if c is not None else "" for c in cmap]
            r_new.cell_flags = {j: list(r_old.cell_flags[c]) for j, c in enumerate(cmap) if c is not None and r_old.cell_flags.get(c)}
        nt.hidden_cols, nt.anchor_col = [], None
        ne = Entry(e.label, e.path, nt, e.db_id, e.file_id, cmap)
        ne.row_map = getattr(e, "row_map", None)
        return ne

    def _filter_rows(self, e: Entry, text):
        t = copy.deepcopy(e.table)
        needle = text.lower()
        keep = [i for i, r in enumerate(t.rows) if any(needle in (v or "").lower() for v in r.norm + r.orig)]
        t.rows = [t.rows[i] for i in keep]
        ne = Entry(e.label, e.path, t, e.db_id, e.file_id, e.col_map)
        ne.row_map = keep
        return ne

    def _text_entries(self):
        out = []
        sel = [i for i in self.file_ids if i not in self.excluded]
        for fid in sel:
            f = self.lib.db.one("SELECT name, abspath FROM files WHERE id=?", (fid,))
            rows = self.lib.db.q("SELECT loc, text FROM segments WHERE file_id=? ORDER BY id", (fid,))
            t = Table(title="Readable text", section="Text", headers=[Header("Page / location"), Header("Text")], method="indexed text", source=f["abspath"])
            for r in rows:
                t.rows.append(Row(0, [r["loc"] or "", r["text"] or ""], [r["loc"] or "", r["text"] or ""]))
            if t.rows:
                out.append(Entry(f["name"], f["abspath"], t, None, fid))
        return out

    # -------------------------------------------------- step 4: review and corrections
    def _src_col(self, e: Entry, col):
        return e.col_map[col] if e.col_map else col

    def edit_cell(self, e: Entry, row, col, value):
        """Correct a value. The original text stays stored; the cell is marked reviewed."""
        r = e.table.rows[row]
        src_row = getattr(e, "row_map", None)
        db_row = src_row[row] if src_row else row
        sc = self._src_col(e, col)
        if e.col_map is not None and sc is None:
            raise ValueError("This column was not found in the document, so there is nothing to correct.")
        if e.db_id and sc is not None:
            store.set_correction(self.lib.db, e.db_id, db_row, sc, value)
        for lay in ("orig", "norm"):
            getattr(r, lay)[col] = value
        r.cell_flags.setdefault(col, []).append("info: corrected by user (original value kept)")
        r.cell_flags[col] = [f for f in r.cell_flags[col] if not f.startswith("review")]

    def mark_uncertain(self, e: Entry, row, col, on=True):
        r = e.table.rows[row]
        fl = [f for f in r.cell_flags.get(col, []) if f != "review: marked uncertain by user"]
        if on:
            fl.append("review: marked uncertain by user")
        if fl:
            r.cell_flags[col] = fl
        else:
            r.cell_flags.pop(col, None)

    def rename_column(self, e: Entry, col, name):
        h = e.table.headers[col]
        if not h.renamed_from:
            h.renamed_from = h.name
        h.name = name
        sc = self._src_col(e, col)
        if e.db_id and sc is not None:
            store.rename_header(self.lib.db, e.db_id, sc, name)

    def hide_column(self, e: Entry, col, on=True):
        hc = set(getattr(e.table, "hidden_cols", []) or [])
        (hc.add if on else hc.discard)(col)
        e.table.hidden_cols = sorted(hc)

    def review_count(self):
        return sum(1 for e in self.preview for r in e.table.rows if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl))

    # -------------------------------------------------- step 5: export
    def suggest_arrangement(self):
        """Sensible default: stack tables that share the same columns across several documents, else one sheet per table."""
        names = {tuple(h.name.lower() for h in e.table.headers) for e in self.preview}
        docs = {e.label for e in self.preview}
        return "stacked" if len(docs) > 1 and len(names) < len(self.preview) else "per_table"

    def export(self, path, fmt="xlsx", arrangement=None, layouts=("norm",), value_mode="raw", header_style="joined", include_source=True):
        tables = [e.table for e in self.preview]
        if not tables:
            raise ValueError("There is nothing to export.")
        arrangement = arrangement or self.suggest_arrangement()
        out = []
        if fmt == "csv":
            out = export_tables_csv(tables, path, layout=layouts[0], include_source=include_source, header_style=header_style)
        elif arrangement == "per_document_files":
            os.makedirs(path, exist_ok=True)
            by = {}
            for e in self.preview:
                by.setdefault(e.label, []).append(e.table)
            for lab, ts in by.items():
                p = os.path.join(path, re.sub(r"[^\w.\- ]", "_", os.path.splitext(lab)[0]) + ".xlsx")
                export_tables_xlsx(ts, p, modes=layouts, value_mode=value_mode, header_style=header_style, include_source=include_source); out.append(p)
        else:
            export_tables_xlsx(tables, path, modes=layouts, value_mode=value_mode, header_style=header_style, include_source=include_source,
                               combine="combined" if arrangement == "stacked" else "per_table"); out = [path]
        self.lib.db.x("INSERT INTO exports(ts,run_id,target,sheet,audit_json) VALUES(?,?,?,?,?)",
                      (time.time(), None, path, "tables", json.dumps({"mode": self.mode, "tables": len(tables), "documents": len({e.label for e in self.preview}),
                                                                       "rows": sum(len(t.rows) for t in tables), "files": out, "arrangement": arrangement,
                                                                       "format": fmt, "layouts": list(layouts), "value_mode": value_mode})))
        return out
