"""A tiny stand-in for a local model server (Ollama / LM Studio / llama.cpp style) so the AI layer can be tested end to end WITHOUT a real model.
It is rule based: it copies 'Label: value' lines for field extraction, cites the first evidence record for questions, makes hashed word vectors
for embeddings. mode='hallucinate' makes it invent a value, to test that DocIntel catches values that are not in the document."""
import hashlib, http.server, json, math, re, threading


def vec(text, dim=64):
    v = [0.0] * dim
    for w in re.findall(r"\w+", text.lower()):
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        v[h % dim] += 1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


class Fake:
    def __init__(self, mode="good"):
        self.mode, self.log = mode, []
        outer = self

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200):
                b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                if self.path.endswith("/models"):
                    self._send({"data": [{"id": "fake-chat"}, {"id": "fake-embed"}]})
                elif self.path.endswith("/api/tags"):
                    self._send({"models": [{"name": "fake-chat:latest"}]})
                else:
                    self._send({"error": {"message": "not found"}}, 404)

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
                outer.log.append((self.path, body))
                if outer.mode == "down500":
                    return self._send({"error": {"message": "model not loaded"}}, 500)
                if self.path.endswith("/embeddings"):
                    inp = body["input"] if isinstance(body["input"], list) else [body["input"]]
                    return self._send({"data": [{"index": i, "embedding": vec(t)} for i, t in enumerate(inp)]})
                msgs = body.get("messages", []); system = msgs[0]["content"] if msgs else ""; user = msgs[-1]["content"] if msgs else ""
                self._send({"choices": [{"message": {"content": outer.answer(system, user, body)}}]})

        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.srv.server_address[1]
        self.url = f"http://127.0.0.1:{self.port}/v1"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def stop(self):
        self.srv.shutdown(); self.srv.server_close()

    # ---- the rule based "model"
    def answer(self, system, user, body):
        if "single word OK" in user:
            return "OK"
        if "EXPAND KEYWORDS" in system:
            return json.dumps({"keywords": [w for w in re.findall(r"\w{4,}", user)][:3] + ["notes"]})
        if "EXTRACT FIELDS" in system:
            fields = [f.strip() for f in re.search(r"FIELDS:\s*(.+)", user).group(1).split(",")]
            pages = re.split(r"\[PAGE (\d+)\]", user.split("DOCUMENT TEXT:")[-1])
            out = {}
            for f in fields:
                out[f] = None
                for k in range(1, len(pages) - 1, 2):
                    m = re.search(re.escape(f) + r"\s*[:\-]\s*([^\n]+)", pages[k + 1], re.I)
                    if m:
                        out[f] = {"value": m.group(1).strip(), "page": int(pages[k])}; break
            if self.mode == "hallucinate" and fields:
                out[fields[0]] = {"value": "INV-999999", "page": 1}
            return "Here is the JSON:\n" + json.dumps(out)
        if "EXTRACT ROWS" in system:
            cols = [c.strip() for c in re.search(r"COLUMNS:\s*(.+)", user).group(1).split(",")]
            rows = []
            for page, text in re.findall(r"\[PAGE (\d+)\]([^\[]*)", user.split("DOCUMENT TEXT:")[-1]):
                for line in text.splitlines():
                    parts = [p.strip() for p in line.split("|")]
                    if len(parts) == len(cols) and parts[0].lower() != cols[0].lower():
                        rows.append({"page": int(page), "values": dict(zip(cols, parts))})
            if self.mode == "hallucinate" and rows:
                rows[0]["values"][cols[-1]] = "9999.99"
            return json.dumps({"rows": rows})
        ids = re.findall(r"\[(E\d+)\]", user)
        if ids:
            return f"According to the records: {ids[0]} says so [{ids[0]}]."
        return "Not found in the selected records."
