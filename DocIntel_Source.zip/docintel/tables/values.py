"""Value interpretation: SUGGESTS a kind for a raw string. The raw text is never changed or rejected."""
from __future__ import annotations
import datetime, re

KINDS = ("text", "integer", "decimal", "percentage", "date", "datetime", "currency", "duration",
         "boolean", "identifier", "unit_value", "special", "empty")
_MON = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_NUM = r"[-+]?\d+(?:\.\d+)?"
_RX = {
    "pct": re.compile(rf"^({_NUM})\s?%$"),
    "int": re.compile(r"^[-+]?(?:0|[1-9]\d{0,14})$"),
    "dec": re.compile(r"^[-+]?(?:0|[1-9]\d*)\.\d+$"),
    "date_mon": re.compile(r"^(\d{1,2})[-/ ]([A-Za-z]{3})[a-z]*[-/ ,]*(\d{2}|\d{4})$"),
    "date_iso": re.compile(r"^(\d{4})-(\d{2})-(\d{2})$"),
    "date_slash": re.compile(r"^(\d{1,2})[/.](\d{1,2})[/.](\d{4}|\d{2})$"),
    "dt": re.compile(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$"),
    "cur": re.compile(rf"^(?:[$€£﷼]\s?|(?:SAR|SR|USD|EUR|AED|GBP)\s?)(-?[\d,]+(?:\.\d+)?)$|^(-?[\d,]+(?:\.\d+)?)\s?(?:SAR|SR|USD|EUR|AED|GBP)$", re.I),
    "dur": re.compile(rf"^({_NUM})\s?(hours?|hrs?|h|days?|d|minutes?|mins?|weeks?|months?)$", re.I),
    "bool": re.compile(r"^(yes|no|true|false)$", re.I),
    "unit": re.compile(rf"^{_NUM}(?:/{_NUM})?\s?(?:[A-Za-zµΩ°][A-Za-z0-9µΩ°/²³.\-]*)$"),
    "code": re.compile(r"^(?=.*[A-Za-z0-9])[#A-Za-z0-9][A-Za-z0-9._\-/#]*$"),
}


def _year(y):
    y = int(y)
    return y + 2000 if y < 100 else y


def suggest(raw: str):
    """-> (kind, parsed_value_or_None, note). parsed is only given when interpretation is unambiguous."""
    s = (raw or "").strip()
    if not s:
        return "empty", None, ""
    m = _RX["pct"].match(s)
    if m:
        return "percentage", float(m.group(1)) / 100.0, ""
    if _RX["int"].match(s):
        return "integer", int(s), ""
    if re.fullmatch(r"[-+]?0\d+", s):
        return "identifier", None, "leading zero kept as text"
    if s.lower() in ("n/a", "na", "n.a.", "tbd", "-", "--", "nil", "none"):
        return "text", None, "not available"
    if re.fullmatch(r"[-+]?\d{1,3}(?:,\d{3})+(?:\.\d+)?", s):
        return "decimal", float(s.replace(",", "")), "thousands separator"
    if _RX["dec"].match(s):
        return "decimal", float(s), ""
    if re.fullmatch(r"\d+\.\d+\.\d+.*|0\d+\.\d+", s):
        return "identifier", None, "looks like a code, kept as text"
    m = _RX["dt"].match(s)
    if m:
        try:
            return "datetime", datetime.datetime(*[int(x) if x else 0 for x in m.groups()]), ""
        except ValueError:
            return "datetime", None, "not a valid date/time"
    m = _RX["date_iso"].match(s)
    if m:
        try:
            return "date", datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))), ""
        except ValueError:
            return "date", None, "not a valid date"
    m = _RX["date_mon"].match(s)
    if m and m.group(2).lower() in _MON:
        try:
            return "date", datetime.date(_year(m.group(3)), _MON[m.group(2).lower()], int(m.group(1))), ""
        except ValueError:
            return "date", None, "not a valid date"
    m = _RX["date_slash"].match(s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), _year(m.group(3))
        if a > 12 and b <= 12:
            return "date", datetime.date(y, b, a), ""
        if b > 12 and a <= 12:
            return "date", datetime.date(y, a, b), ""
        return "date", None, "day/month order is ambiguous"
    m = _RX["cur"].match(s)
    if m:
        try:
            return "currency", float((m.group(1) or m.group(2)).replace(",", "")), ""
        except ValueError:
            pass
    if _RX["dur"].match(s):
        return "duration", None, ""
    if _RX["bool"].match(s):
        return "boolean", s.lower() in ("yes", "true"), ""
    if _RX["unit"].match(s):
        return "unit_value", None, ""
    if not any(ch.isalnum() for ch in s):
        return "special", None, ""
    if " " not in s and _RX["code"].match(s) and re.search(r"[A-Za-z]", s) and re.search(r"[\d._\-/#]", s):
        return "identifier", None, ""
    if " " not in s and re.fullmatch(r"[A-Za-z]{1,6}[.\-/][A-Za-z0-9.\-/]+", s):
        return "identifier", None, ""
    return "text", None, ""


def kind_of(raw):
    return suggest(raw)[0]
