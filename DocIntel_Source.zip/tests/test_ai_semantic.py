"""Milestone 9: meaning-based search + hybrid evidence for the assistant (fake local server: hashed word vectors, NO real model)."""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fake_llm_server import Fake
from test_ai_extract import pdf
from docintel.library import Library
from docintel.llm.provider import OpenAICompatProvider
from docintel.llm.semantic import SemanticIndex
from docintel.llm.assistant import Assistant
import test_office_tables as OT


class Sem(unittest.TestCase):
    def setUp(self):
        self.srv = Fake(); self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "s"); os.makedirs(self.src)
        pdf(os.path.join(self.src, "notes.pdf"), ["Meeting notes of the site committee", "The crane inspection certificate expires next month and must be renewed by the safety officer."])
        pdf(os.path.join(self.src, "inv.pdf"), ["Invoice No: INV-00013", "Total: 980.50", "Payment terms thirty days"])
        OT.build(self.src)
        self.lib = Library(os.path.join(self.tmp, "h")); self.lib.cfg.set("workers", 1); self.lib.add_root(self.src); self.lib.scan(); self.lib.index(); self.lib.extract_tables()
        self.prov = OpenAICompatProvider(self.srv.url, "fake-chat", embed_model="fake-embed", name="fake")

    def tearDown(self):
        self.srv.stop(); shutil.rmtree(self.tmp, ignore_errors=True)

    def n_embed_calls(self):
        return len([b for b in self.srv.log if b[0].endswith("/embeddings")])

    def test_build_is_incremental_and_search_finds_by_content(self):
        ix = SemanticIndex(self.lib, self.prov)
        n = ix.build(); self.assertGreater(n, 5); self.assertEqual(ix.stats()["vectors"], n)
        calls = self.n_embed_calls(); self.assertEqual(ix.build(), 0); self.assertEqual(self.n_embed_calls(), calls)          # nothing changed: nothing embedded again
        top = ix.search("crane inspection certificate safety officer", k=3)
        self.assertTrue(top and top[0][1].file == "notes.pdf")
        rec = [x for sc, x in ix.search("Backfilling Done piling task status", k=10) if hasattr(x, "cells")]
        self.assertTrue(rec and rec[0].cells)                                                    # table rows come back as records with their cells
        pdf(os.path.join(self.src, "late.pdf"), ["A brand new document about scaffolding permits and inspection"]); self.lib.scan(); self.lib.index()
        self.assertGreaterEqual(ix.build(), 1); self.assertLess(ix.build(), 1 + 1)               # only the new text was embedded

    def test_switching_embedding_model_keeps_separate_vectors(self):
        a = SemanticIndex(self.lib, self.prov); a.build()
        other = OpenAICompatProvider(self.srv.url, "fake-chat", embed_model="other-embed", name="other"); b = SemanticIndex(self.lib, other)
        self.assertEqual(b.stats()["vectors"], 0); b.build(); self.assertEqual(a.stats()["vectors"], b.stats()["vectors"])

    def test_assistant_uses_records_and_page_text_and_expansion(self):
        SemanticIndex(self.lib, self.prov).build()
        a = Assistant(self.lib, self.prov)
        pack, prev = a.prepare("When does the crane inspection certificate expire?")
        files = {i.record.file for i in pack.items}
        self.assertIn("notes.pdf", files)                                                          # page text is evidence too, not only table rows
        self.assertTrue(any("crane" in i.text.lower() for i in pack.items))
        self.assertFalse(prev["leaves_computer"])                                                  # local model: nothing leaves the computer
        ans = a.ask("When does the crane inspection certificate expire?", pack, prev)
        self.assertTrue(ans.cited and not ans.warnings)


if __name__ == "__main__":
    unittest.main()
