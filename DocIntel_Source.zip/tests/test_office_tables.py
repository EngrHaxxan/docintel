"""Milestone 6: Word / Excel / PowerPoint / HTML / CSV tables in the same store, search, batch and export as PDF tables."""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from openpyxl import Workbook, load_workbook
from docintel.library import Library
from docintel.tables import store
from docintel.batch import BatchRunner, new_profile
from docintel import search as S


def build(folder):
    import docx
    from pptx import Presentation
    from pptx.util import Inches
    d = docx.Document()
    d.add_heading("Construction Activities", 1)
    t = d.add_table(rows=4, cols=3); t.style = "Table Grid"
    for i, h in enumerate(["Location", "Activity", "Progress %"]):
        t.cell(0, i).text = h
    t.cell(1, 0).text = "Substation"; t.cell(1, 1).text = "Backfilling"; t.cell(1, 2).text = "70%"
    t.cell(2, 1).text = "Compaction"; t.cell(2, 2).text = "0%"
    t.cell(3, 0).text = "Cable room"; t.cell(3, 1).text = "EHV.SWGXX.SF6.TEST"; t.cell(3, 2).text = "N/A"
    t.cell(1, 0).merge(t.cell(2, 0))                                     # vertical merge: Substation covers rows 1-2
    d.add_heading("Issues & Concerns", 1)
    t2 = d.add_table(rows=2, cols=2)
    t2.cell(0, 0).text = "Issue"; t2.cell(0, 1).text = "Urgency"; t2.cell(1, 0).text = "UGC input"; t2.cell(1, 1).text = "High"
    d.save(os.path.join(folder, "report.docx"))
    wb = Workbook(); ws = wb.active; ws.title = "Progress"
    ws.append(["Daily progress"]); ws.append(["Zone", "Task", "Done"]); ws.append(["North", "Piling", 0.65]); ws.append([None, "Fencing", 0.9]); ws.append([None, None, None])
    ws.append(["Issues"]); ws.append(["Id", "Text"]); ws.append(["001", "Delay"]); ws.append(["002", "Rain"])
    ws.merge_cells("A3:A4")
    for r in (3, 4):
        ws.cell(r, 3).number_format = "0%"
    wb.save(os.path.join(folder, "book.xlsx"))
    with open(os.path.join(folder, "data.csv"), "w", encoding="utf-8") as f:
        f.write("Code,Qty,Note\nDTS-022,5,a/b\n01.02,7,#x\n")
    with open(os.path.join(folder, "page.html"), "w", encoding="utf-8") as f:
        f.write("<html><body><h2>Stock</h2><table><tr><th>Item</th><th>Qty</th></tr><tr><td>Bolt</td><td>10</td></tr><tr><td>Nut</td><td>20</td></tr></table></body></html>")
    p = Presentation(); s = p.slides.add_slide(p.slide_layouts[5])
    sh = s.shapes.add_table(3, 2, Inches(1), Inches(1), Inches(4), Inches(2)).table
    for r, row in enumerate([["Item", "Status"], ["Crane", "Ready"], ["Truck", "Hold"]]):
        for c, v in enumerate(row):
            sh.cell(r, c).text = v
    p.save(os.path.join(folder, "deck.pptx"))


class Office(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "s"); os.makedirs(self.src); build(self.src)
        self.lib = Library(os.path.join(self.tmp, "h")); self.lib.add_root(self.src); self.lib.scan(); self.lib.index()
        self.res = self.lib.extract_tables()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def table(self, fname, n=0):
        fid = self.lib.db.one("SELECT id FROM files WHERE name=?", (fname,))["id"]
        return store.load_table(self.lib.db, store.list_tables(self.lib.db, fid)[n]["id"])

    def test_all_formats_extracted(self):
        st = {self.lib.db.one("SELECT name FROM files WHERE id=?", (k,))["name"]: v["status"] for k, v in self.res.items()}
        for n in ("report.docx", "book.xlsx", "data.csv", "page.html", "deck.pptx"):
            self.assertEqual(st[n], "extracted", (n, st))

    def test_docx_sections_and_merged_cells(self):
        t = self.table("report.docx", 0)
        self.assertEqual(t.section, "Construction Activities")
        self.assertEqual([h.name for h in t.headers], ["Location", "Activity", "Progress %"])
        self.assertEqual([r.orig[0] for r in t.rows], ["Substation", "", "Cable room"])        # original layout keeps the blank
        self.assertEqual([r.norm[0] for r in t.rows], ["Substation", "Substation", "Cable room"])  # normalized repeats it
        self.assertEqual([r.orig[2] for r in t.rows], ["70%", "0%", "N/A"])                      # text preserved as written
        self.assertEqual(self.table("report.docx", 1).section, "Issues & Concerns")

    def test_xlsx_blocks_merges_and_percent(self):
        a, b = self.table("book.xlsx", 0), self.table("book.xlsx", 1)
        self.assertEqual([h.name for h in a.headers], ["Zone", "Task", "Done"]); self.assertEqual(a.section, "Daily progress")
        self.assertEqual([r.norm[0] for r in a.rows], ["North", "North"]); self.assertEqual([r.orig[0] for r in a.rows], ["North", ""])
        self.assertEqual([r.orig[2] for r in a.rows], ["65%", "90%"])
        self.assertEqual([r.orig[0] for r in b.rows], ["001", "002"])                           # codes keep their leading zeros
        self.assertEqual(b.section, "Issues")

    def test_csv_html_pptx(self):
        c = self.table("data.csv"); self.assertEqual([r.orig[0] for r in c.rows], ["DTS-022", "01.02"]); self.assertEqual(c.rows[1].orig[2], "#x")
        self.assertEqual(len(self.table("page.html").rows), 2); self.assertEqual(self.table("deck.pptx").rows[1].orig, ["Truck", "Hold"])

    def test_batch_finds_word_section_across_formats_and_search(self):
        r = BatchRunner(self.lib)
        jid = r.run(new_profile("c", section={"heading": "Construction Activities", "aliases": []}), root_ids=[self.lib.roots()[0]["id"]])
        by = {i["name"]: i for i in r.items(jid)}
        self.assertEqual(by["report.docx"]["status"], "processed"); self.assertEqual(by["report.docx"]["records"], 3)
        self.assertEqual(by["book.xlsx"]["status"], "section_not_found")
        hits = [h for h in S.search(self.lib.db, "Backfilling", "text", limit=20) if h.kind == "table"]
        self.assertTrue(any(h.name == "report.docx" for h in hits))
        out = os.path.join(self.tmp, "o.xlsx"); r.export_job(jid, out)
        self.assertIn("Job report", load_workbook(out).sheetnames)


if __name__ == "__main__":
    unittest.main()
