# Windows build guide (technical)

Non-technical route: see `START HERE - How to get your Windows app.pdf`. This file explains what that route does.

## How the automated build works
`.github/workflows/build-windows.yml` runs on GitHub's `windows-2022` runner whenever files are pushed or "Run workflow" is clicked:

| # | Stage | Detail |
|---|---|---|
| 1 | Source | checkout; if `DocIntel_Source.zip` is present it is unpacked over the repository (lets a user upload just two items) |
| 2 | Python | 64-bit 3.12; libraries pinned by `constraints.txt` (falls back to unpinned if a pin is unavailable) |
| 3 | Tesseract | `tools/fetch_tesseract.ps1` downloads the official Tesseract 5.5.3 Windows installer, **verifies its SHA-256**, unpacks it with 7-Zip (no install) |
| 4 | Languages | `tools/download_models.py` fetches `eng`, `osd`, `ara` (tessdata_fast, pinned commit) and verifies each SHA-256 (`resources/models.json`) |
| 5 | Tests | full pytest suite on Windows incl. Windows-only tests (long paths, case-insensitive roots, locked files); non-blocking so artifacts are still produced |
| 6 | Build | `tools/make_release.py`: PyInstaller one-folder build (`build/docintel.spec`: `DocIntel.exe` GUI + `docintel-cli.exe`), bundles `tesseract\` (program, DLLs, configs, languages), asserts `tesseract --list-langs` shows eng/ara/osd, adds docs/notices/samples, creates the portable zip (`portable.txt` marker), offline-resources zip, Inno Setup installer, `SHA256SUMS.txt` |
| 7 | Portable check | unzip into `C:\Test Area\Portable Copy` (spaces) and run `tools/smoke_packaged.py --expect-portable` |
| 8 | Offline check | Windows Firewall rules block in/out traffic of `DocIntel.exe`, `docintel-cli.exe`, `tesseract.exe`; smoke test repeated on a fresh data folder |
| 9 | Installer check | silent install to a path with spaces, Start Menu + desktop shortcuts verified, smoke test of the installed app (data must land in `%LOCALAPPDATA%\DocIntel`), silent uninstall, program files removed |
| 10 | Publish | artifacts (90 days) and a GitHub Release with the files and `BUILD_RESULT.txt`; the job is marked failed (but files are still published, flagged pre-release) if any check failed |

`tools/smoke_packaged.py` exercises the packaged app only through its executables: self-check (OCR eng+ara), index 3 roots, OCR search, Arabic
search, restart persistence, profile extraction, export to new workbook and to a template (formulas/format kept), unplugged drive,
hard-killed batch resumed, inaccessible directory (Windows ACL), GUI launch (`DocIntel.exe gui --smoke-test`).

## Design decisions for Windows
* User data: installed = `%LOCALAPPDATA%\DocIntel`; portable (file `portable.txt` beside the exe) = `DocIntel_Data` beside the exe (falls back to the profile if read-only). Nothing is written to Program Files.
* Tesseract is located relative to the executable (`tesseract\`), language path passed through `TESSDATA_PREFIX` (no quoting problems with spaces/Unicode/UNC).
* Paths: the `\\?\` long-path prefix is only used for I/O on paths near 260 characters and is never stored.
* No console flashes (`CREATE_NO_WINDOW`), per-monitor DPI awareness, windowed build tolerates missing stdout.
* No downloads at run time; `offline_mode` blocks non-loopback sockets in-process.
* Antivirus/SmartScreen: one-folder build (no self-extracting temp unpack), no UPX, unsigned (a code-signing certificate is the only real cure).

## If a stage fails
Open the run > the red step > copy the red lines. Common causes: a pinned library version without a Windows wheel (workflow falls back automatically);
Chocolatey/Inno Setup download hiccup (re-run); a Windows-specific test failure (tests are non-blocking; `BUILD_RESULT.txt` and `test-results-windows.xml` list it).

## Building on your own Windows PC instead
Install Python 3.12 x64 and Inno Setup 6; run PowerShell: `pip install -r requirements-dev.txt`, unpack the Tesseract installer with 7-Zip, then
`python tools/make_release.py --tess-dir <unpacked folder>`. (The older `build\build_windows.bat` is kept for reference only.)

## Alternatives considered
* **Wine on Linux**: could produce a Windows-format exe but not the installer (Inno Setup cannot be downloaded in this environment), and a Wine run proves little about real Windows; rejected.
* **Code signing**: not done (cost). Installer is unsigned.
