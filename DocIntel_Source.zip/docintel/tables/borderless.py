"""Tables without ruling lines: columns come from whitespace gutters shared by many lines (alignment)."""
from __future__ import annotations
import re
from .geometry import PageData, visible_words
from .grid import PageGrid, Block


def _line_cells(ws, size):
    gap = max(2.2 * size, 7.0)
    cells, cur = [], [ws[0]]
    for w in ws[1:]:
        if w["x0"] - cur[-1]["x1"] > gap:
            cells.append(cur); cur = [w]
        else:
            cur.append(w)
    cells.append(cur)
    return cells


def find_borderless(pd: PageData, bbox, exclude=()):
    x0, top, x1, bot = bbox
    def free(w):
        cx, cy = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
        if not (x0 <= cx <= x1 and top <= cy <= bot):
            return False
        return not any(b[0] - 2 <= cx <= b[2] + 2 and b[1] - 2 <= cy <= b[3] + 2 for b in exclude)
    ws = sorted([w for w in visible_words(pd) if free(w)], key=lambda w: ((w["top"] + w["bottom"]) / 2, w["x0"]))
    lines, cur, cy = [], [], None
    for w in ws:
        m = (w["top"] + w["bottom"]) / 2
        if cy is None or abs(m - cy) <= max(1.6, 0.5 * w["size"]):
            cur.append(w); cy = m if cy is None else (cy + m) / 2
        else:
            lines.append(cur); cur = [w]; cy = m
    if cur:
        lines.append(cur)
    info = []
    for ln in lines:
        ln.sort(key=lambda w: w["x0"])
        size = sorted(w["size"] for w in ln)[len(ln) // 2]
        info.append((ln, len(_line_cells(ln, size)), size))
    runs, run = [], []
    for i, (ln, nc, size) in enumerate(info):
        tab = nc >= 3
        wrapped = nc == 1 and run and i + 1 < len(info) and info[i + 1][1] >= 3 and ln[0]["top"] - run[-1][0][0]["bottom"] < 1.2 * size
        if tab or wrapped:
            run.append(info[i])
        else:
            if len([r for r in run if r[1] >= 3]) >= 3:
                runs.append(run)
            run = []
    if len([r for r in run if r[1] >= 3]) >= 3:
        runs.append(run)
    return [_grid_from_run(pd, r) for r in runs if _grid_from_run(pd, r) is not None]


def _grid_from_run(pd, run):
    words = [w for ln, _, _ in run for w in ln]
    xs0, xs1 = min(w["x0"] for w in words), max(w["x1"] for w in words)
    W = int(xs1 - xs0) + 2
    cover = [0] * W
    for w in words:
        for x in range(max(0, int(w["x0"] - xs0)), min(W, int(w["x1"] - xs0) + 1)):
            cover[x] += 1
    size = sorted(w["size"] for w in words)[len(words) // 2]
    mingap = max(3.0, 0.9 * size)
    edges, x = [xs0 - 1.0], 0
    while x < W:
        if cover[x] == 0:
            s = x
            while x < W and cover[x] == 0:
                x += 1
            if x - s >= mingap and s > 0 and x < W:
                edges.append(xs0 + (s + x) / 2)
        else:
            x += 1
    edges.append(xs1 + 1.0)
    nc = len(edges) - 1
    if nc < 3:
        return None
    import bisect
    bands, blocks, block_of, texts = [], [], {}, []
    n_in = 0
    for k, (ln, _, sz) in enumerate(run):
        top_k, bot_k = min(w["top"] for w in ln) - 0.5, max(w["bottom"] for w in ln) + 0.5
        bands.append((top_k, bot_k))
        cells = [[] for _ in range(nc)]
        for w in ln:
            c = min(max(bisect.bisect_right(edges, (w["x0"] + w["x1"]) / 2) - 1, 0), nc - 1)
            cells[c].append(w); n_in += 1
        for c in range(nc):
            b = Block(k, k, c, c, (edges[c], top_k, edges[c + 1], bot_k))
            cw = cells[c]
            b.text = re.sub(r"\s+", " ", " ".join(w["text"] for w in cw)).strip()
            b.n_words = len(cw)
            b.bold = sum(1 for w in cw if w["bold"]) / len(cw) if cw else 0.0
            blocks.append(b); block_of[(k, c)] = len(blocks) - 1
    nb = len(bands)
    band_bold = []
    for k in range(nb):
        bs = [blocks[block_of[(k, c)]] for c in range(nc) if blocks[block_of[(k, c)]].text]
        tot = sum(b.n_words for b in bs)
        band_bold.append(sum(b.bold * b.n_words for b in bs) / tot if tot else 0.0)
    g = PageGrid(pd.number, (edges[0], bands[0][0], edges[-1], bands[-1][1]), edges, bands, blocks, block_of,
                 [""] * nb, [not any(blocks[block_of[(k, c)]].text for c in range(nc)) for k in range(nb)],
                 band_bold, [None] * nb, [False] * nc, [False] * nc, n_in, len(words), 0)
    g.notes.append("borderless table: columns inferred from text alignment")
    return g
