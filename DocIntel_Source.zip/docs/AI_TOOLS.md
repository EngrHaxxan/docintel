# AI tools with a local model (v1.9.0-m9)
DocIntel works completely without AI. With an open model running on your own computer (Ollama, LM Studio, llama.cpp server - anything offering the common OpenAI-style local web interface) it can also:
- **Ask Documents**: records and page text are found by DocIntel (keywords + optional meaning-based search + query expansion); only those are given to the model; the answer must cite them [E1]...
- **Extract with AI (bulk)**: fields (one record per document) or table rows (many per document) from many documents. Every value is checked against the document text; values not found are marked for review. Results are stored as normal tables (ai-fields / ai-rows): searchable, reviewable, exportable, with job report, retry and add-new-documents.
- **Meaning-based search**: local embedding model; incremental; separate vectors per embedding model.
- **Compare models** on your own documents (confirmed values %, time, agreement).
Models are saved in the AI settings (several, one active, switch in one click). No key is stored (an optional environment variable name can be given). Local = host localhost/127.0.0.1/::1: allowed in offline mode. Remote = blocked in offline mode, needs a per-send confirmation of the exact records, logged.
Tested with a rule-based fake local server (protocol, verification, bulk, retry, incremental, offline guard). NOT tested with a real model: accuracy, speed, Arabic, JSON discipline of small models.
