"""Normalisation + validation. Raw values are always kept next to the normalised value by the caller."""
import re
from datetime import date, datetime

AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
AR_SEP = str.maketrans({"٫": ".", "٬": ",", "،": ","})
OCR_NUM_FIX = str.maketrans({"O": "0", "o": "0", "l": "1", "I": "1", "|": "1", "S": "5", "B": "8", "Z": "2"})

MONTHS = {m: i for i, ms in enumerate(
    ["jan january", "feb february", "mar march", "apr april", "may", "jun june", "jul july", "aug august",
     "sep sept september", "oct october", "nov november", "dec december"], 1) for m in ms.split()}


def to_ascii_digits(s):
    return (s or "").translate(AR_DIGITS).translate(AR_SEP)


def trim(s):
    return re.sub(r"\s+", " ", (s or "").replace("\u00a0", " ")).strip()


def parse_date(s, day_first=True):
    """Returns (iso_date or None, issues[]). Ambiguous d/m vs m/d is flagged, never silently guessed."""
    s0 = trim(to_ascii_digits(s))
    issues = []
    if not s0: return None, issues
    m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s0)
    if m:
        y, mo, d = map(int, m.groups())
    else:
        m = re.fullmatch(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})", s0)
        if m:
            a, b, y = map(int, m.groups())
            if y < 100: y += 2000 if y < 70 else 1900
            if a > 12 and b <= 12: d, mo = a, b
            elif b > 12 and a <= 12: mo, d = a, b
            else:
                d, mo = (a, b) if day_first else (b, a)
                if a != b: issues.append("ambiguous date order (day/month) - verify")
        else:
            m = re.fullmatch(r"(\d{1,2})[\s\-/.]*([A-Za-z]{3,9})\.?,?[\s\-/.]*(\d{2,4})", s0) or None
            if m:
                d, mon, y = int(m.group(1)), m.group(2).lower(), int(m.group(3))
                mo = MONTHS.get(mon)
                if not mo: return None, ["unrecognised month name"]
                if y < 100: y += 2000
            else:
                m = re.fullmatch(r"([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", s0)
                if not m: return None, ["unrecognised date format"]
                mo = MONTHS.get(m.group(1).lower()); d, y = int(m.group(2)), int(m.group(3))
                if not mo: return None, ["unrecognised month name"]
    try:
        return date(y, mo, d).isoformat(), issues
    except ValueError:
        return None, issues + ["impossible calendar date"]


def parse_number(s, ocr_fix=False):
    """Returns (float|None, issues[]). Handles 1,234.56 / 1.234,56 / (123) / trailing minus / currency / Arabic digits."""
    raw = trim(to_ascii_digits(s))
    issues = []
    if not raw: return None, issues
    t = re.sub(r"(?i)\b(sar|usd|eur|aed|sr|ر\.?س|ريال|\$|€|£)\b|[$€£]", "", raw).strip()
    neg = False
    if t.startswith("(") and t.endswith(")"): neg, t = True, t[1:-1]
    if t.endswith("-"): neg, t = True, t[:-1]
    if t.startswith("-"): neg, t = True, t[1:]
    t = t.replace(" ", "")
    if ocr_fix and re.search(r"\d", t) and re.search(r"[OolI|SBZ]", t):
        fixed = t.translate(OCR_NUM_FIX)
        if fixed != t:
            issues.append(f"OCR-style characters corrected ({t} -> {fixed})"); t = fixed
    if "," in t and "." in t:
        if t.rfind(",") > t.rfind("."): t = t.replace(".", "").replace(",", ".")
        else: t = t.replace(",", "")
    elif "," in t:
        parts = t.split(",")
        if len(parts) > 2 or len(parts[-1]) == 3: t = t.replace(",", "")
        else:
            t = t.replace(",", "."); issues.append("comma treated as decimal separator - verify")
    if not re.fullmatch(r"\d+(\.\d+)?", t):
        return None, issues + ["not a valid number"]
    v = float(t)
    return (-v if neg else v), issues


def normalise(value, ftype="text", day_first=True, ocr_fix=False):
    """-> (normalised_value, issues). Identifiers (type 'id') keep leading zeros and are never converted to numbers."""
    if value is None: return None, []
    v = trim(value)
    if ftype in ("any", "auto"):                      # never rejects: typed value when unambiguous, otherwise the text itself
        from .tables.values import suggest
        kind, parsed, note = suggest(v)
        return (parsed if parsed is not None else v), ([note] if note and parsed is None and kind == "date" else [])
    if ftype == "percentage":                         # '65%' -> 0.65 (the original '65%' stays in the raw field)
        m = re.fullmatch(r"\s*([-+]?[\d.,]+)\s*%\s*", to_ascii_digits(v))
        if not m:
            return None, ["no % sign found - original text kept"]
        n, iss = parse_number(m.group(1))
        return (None if n is None else n / 100.0), iss
    if ftype == "date": return parse_date(v, day_first)
    if ftype in ("number", "integer", "currency"):
        n, iss = parse_number(v, ocr_fix)
        if n is not None and ftype == "integer":
            if n != int(n): iss.append("non-integer value")
            n = int(n)
        return n, iss
    if ftype == "id":
        return re.sub(r"\s+", "", to_ascii_digits(v)) if re.fullmatch(r"[\w\s\-./]+", v) else v, []
    return v, []


def validate(field, norm, raw):
    """field: dict with required/min/max/pattern/choices. Returns issues[]."""
    issues = []
    empty = norm in (None, "")
    if empty:
        if field.get("required"): issues.append("required value missing")
        return issues
    if isinstance(norm, (int, float)):
        if field.get("min") is not None and norm < field["min"]: issues.append(f"below minimum {field['min']}")
        if field.get("max") is not None and norm > field["max"]: issues.append(f"above maximum {field['max']}")
    if field.get("pattern") and not re.fullmatch(field["pattern"], str(norm)):
        issues.append("does not match expected pattern")
    if field.get("choices") and str(norm) not in field["choices"]:
        issues.append("not one of the allowed values")
    return issues
