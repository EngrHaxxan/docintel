"""Builds the distributable packages. Runs on Windows (full result) and on Linux (everything except Tesseract bundling + installer).

    python tools/make_release.py --version 1.0.0 [--tess-dir "C:\\Program Files\\Tesseract-OCR"] [--out dist]

Produces in <out>/:  DocIntel/ (installer source)   DocIntel_Portable_Windows_x64.zip   DocIntel_Offline_Resources.zip
                     DocIntel_Setup.exe (if Inno Setup is installed)   SHA256SUMS.txt"""
import argparse, glob, hashlib, json, os, shutil, subprocess, sys, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import download_models


def run(cmd, **kw):
    print(">", " ".join(map(str, cmd)), flush=True); subprocess.run(cmd, check=True, **kw)


def find_iscc():
    for p in (shutil.which("iscc"), r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe", r"C:\Program Files\Inno Setup 6\ISCC.exe"):
        if p and os.path.exists(p): return p


def zipdir(src, dst, top):
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for a, _, fs in os.walk(src):
            for f in fs:
                fp = os.path.join(a, f); z.write(fp, os.path.join(top, os.path.relpath(fp, src)))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--version", default="1.0.0"); ap.add_argument("--tess-dir"); ap.add_argument("--out", default="dist"); a = ap.parse_args()
    out = os.path.abspath(a.out); work = os.path.join(ROOT, "build", "work"); app = os.path.join(out, "DocIntel")
    shutil.rmtree(out, ignore_errors=True); os.makedirs(out)
    models = download_models.fetch(os.path.join(ROOT, "build", "models"))
    run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--distpath", out, "--workpath", work, os.path.join(ROOT, "build", "docintel.spec")], cwd=ROOT)
    assert os.path.isdir(app), "PyInstaller did not produce the app folder"

    # ---- Tesseract (Windows): program + DLLs + only the language files we ship, verified by checksum
    tdst = os.path.join(app, "tesseract")
    if a.tess_dir:
        os.makedirs(os.path.join(tdst, "tessdata"), exist_ok=True)
        shutil.copy2(os.path.join(a.tess_dir, "tesseract.exe"), tdst)          # only the OCR program, not the training tools
        for f in glob.glob(os.path.join(a.tess_dir, "*.dll")):
            shutil.copy2(f, tdst)
        for sub in ("configs", "tessconfigs"):
            s = os.path.join(a.tess_dir, "tessdata", sub)
            if os.path.isdir(s): shutil.copytree(s, os.path.join(tdst, "tessdata", sub), dirs_exist_ok=True)
        for f in os.listdir(models): shutil.copy2(os.path.join(models, f), os.path.join(tdst, "tessdata", f))
        for lic in ("LICENSE", "LICENSE.txt", "doc\\LICENSE"):
            p = os.path.join(a.tess_dir, lic)
            if os.path.exists(p): shutil.copy2(p, os.path.join(tdst, "TESSERACT_LICENSE.txt")); break
        if os.name == "nt":
            r = subprocess.run([os.path.join(tdst, "tesseract.exe"), "--list-langs"], capture_output=True, text=True, env={**os.environ, "TESSDATA_PREFIX": os.path.join(tdst, "tessdata")})
            print(r.stdout, r.stderr)
            assert all(l in r.stdout for l in ("eng", "ara", "osd")), "bundled Tesseract does not list eng/ara/osd"
        else:
            print("NOTE: not on Windows - bundled tesseract.exe cannot be executed here; layout only")
    else:
        print("NOTE: no --tess-dir: Tesseract is not bundled (Linux/dev build)")
    # ---- docs, notices, samples
    for f in ("LICENSE", "THIRD_PARTY_NOTICES.md"): shutil.copy2(os.path.join(ROOT, f), app)
    shutil.copytree(os.path.join(ROOT, "samples"), os.path.join(app, "samples"), dirs_exist_ok=True)
    guide = os.path.join(ROOT, "docs", "DocIntel_User_Guide.pdf")
    if os.path.exists(guide): shutil.copy2(guide, os.path.join(app, "User Guide.pdf"))
    open(os.path.join(app, "READ ME FIRST.txt"), "w", encoding="utf-8").write(
        "DocIntel - find information in your documents and send it to Excel.\r\n\r\nTo start: double-click DocIntel.exe\r\n"
        "(If Windows shows 'Windows protected your PC', click 'More info' then 'Run anyway'. This happens for any new program that is not\r\n"
        "from a large publisher; DocIntel does not connect to the internet.)\r\n\r\nSee 'User Guide.pdf' for step-by-step instructions.\r\n")
    # ---- offline resources
    off = os.path.join(out, "DocIntel_Offline_Resources.zip")
    with zipfile.ZipFile(off, "w", zipfile.ZIP_DEFLATED) as z:
        for f in os.listdir(models): z.write(os.path.join(models, f), "tessdata/" + f)
        z.write(os.path.join(ROOT, "resources", "models.json"), "tessdata/SOURCES_AND_SHA256.json")
        z.writestr("README.txt", "Optional. The OCR language files (English, Arabic, orientation) are ALREADY inside DocIntel.\r\n"
                   "Use this only to repair or replace them: copy the files from 'tessdata' into <DocIntel folder>\\tesseract\\tessdata.\r\n"
                   "Checksums are in SOURCES_AND_SHA256.json.\r\n")
    # ---- portable zip (marker file makes data live inside the folder)
    port = os.path.join(out, "_portable_stage"); shutil.copytree(app, os.path.join(port, "DocIntel"))
    open(os.path.join(port, "DocIntel", "portable.txt"), "w").write("Delete this file to store data in the user profile instead of next to the program.\n")
    zipdir(os.path.join(port, "DocIntel"), os.path.join(out, "DocIntel_Portable_Windows_x64.zip"), "DocIntel"); shutil.rmtree(port)
    # ---- installer
    iscc = find_iscc()
    if iscc:
        run([iscc, f"/DAppVersion={a.version}", f"/DSourceDir={app}", f"/O{out}", os.path.join(ROOT, "build", "installer.iss")])
    else:
        print("NOTE: Inno Setup not found - DocIntel_Setup.exe not built")
    with open(os.path.join(out, "SHA256SUMS.txt"), "w") as s:
        for f in sorted(os.listdir(out)):
            p = os.path.join(out, f)
            if os.path.isfile(p) and f != "SHA256SUMS.txt": s.write(hashlib.sha256(open(p, "rb").read()).hexdigest() + "  " + f + "\n")
    print(open(os.path.join(out, "SHA256SUMS.txt")).read())


if __name__ == "__main__":
    main()
