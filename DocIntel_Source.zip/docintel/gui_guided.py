"""Simple guided screens: Home (6 big actions) and the 5-step extraction wizard. All logic lives in wizard.py (tested);
this file only draws widgets. Everything here is wrapped so a problem can never stop the classic tabs from opening."""
import json, os, queue, threading, time, traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from . import friendly, paths
from .library import JobControl
from .wizard import Session, MODES
from .tables import store

FONT = "Segoe UI"
PREVIEW_LIMIT = 3000


def _open(path):
    try:
        if os.name == "nt":
            os.startfile(path)
        else:
            import subprocess
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


# ===================================================================== Home
class HomeFrame(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master, padding=16)
        self.app = app
        ttk.Label(self, text="DocIntel", font=(FONT, 24, "bold")).pack(anchor="w")
        ttk.Label(self, text="Find information in your documents and send it to Excel. Everything stays on this computer.",
                  font=(FONT, 11)).pack(anchor="w", pady=(0, 12))
        self.summary = tk.StringVar()
        ttk.Label(self, textvariable=self.summary, font=(FONT, 10)).pack(anchor="w", pady=(0, 10))
        grid = ttk.Frame(self); grid.pack(fill="x")
        items = [("1  Add Documents", "Add folders that hold your documents.", self.add_documents),
                 ("2  Search Documents", "Look for a word, code or number in all your documents.", self.search),
                 ("3  Extract to Excel", "Guided steps: choose documents, choose what to extract, preview, export.", self.extract),
                 ("4  Review Results", "Look at tables already extracted, correct values.", self.review),
                 ("5  Export to Excel", "Export the results of your last extraction again.", self.export),
                 ("6  Extraction History", "See your previous exports.", self.history)]
        for i, (t, d, cmd) in enumerate(items):
            box = ttk.Frame(grid, padding=6); box.grid(row=i // 3, column=i % 3, sticky="nsew", padx=6, pady=6)
            grid.columnconfigure(i % 3, weight=1, uniform="home")
            b = ttk.Button(box, text=t, command=self._safe(cmd)); b.pack(fill="x", ipady=18)
            ttk.Label(box, text=d, wraplength=300, justify="left").pack(anchor="w", pady=(4, 0))
        bottom = ttk.Frame(self); bottom.pack(fill="x", pady=(18, 0))
        self.adv_btn = ttk.Button(bottom, text="Show advanced tools", command=self.toggle_advanced); self.adv_btn.pack(side="left")
        ttk.Label(bottom, text="  (settings, drives, field extraction, compare, diagnostics)").pack(side="left")
        ttk.Button(bottom, text="Saved extractions && batch jobs", command=self._safe(self.batch)).pack(side="right")
        self.last_session = None

    def _safe(self, fn):
        def run():
            try:
                fn()
            except Exception as e:
                try:
                    title, msg = friendly.explain(e, "Home")
                except Exception:
                    title, msg = "Something went wrong", "Please try again. Details were saved in the log file."
                import logging
                logging.getLogger("docintel").exception("home action failed")
                messagebox.showerror(title, msg, parent=self)
        return run

    def refresh(self):
        try:
            n = self.app.lib.db.one("SELECT COUNT(*) FROM files WHERE missing_since IS NULL")[0]
            p = self.app.lib.db.one("SELECT COUNT(*) FROM files WHERE lower(ext) IN ('pdf','.pdf') AND missing_since IS NULL")[0]
            r = len(self.app.lib.roots())
            self.summary.set(f"{r} folder(s) added  -  {n} document(s) known  -  {p} PDF file(s) available for table extraction" if r else
                             "No folders yet. Click 'Add Documents' to start.")
        except Exception:
            self.summary.set("")

    def add_documents(self):
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Add one folder...", command=self._safe(self.app.add_folder))
        m.add_command(label="Add several folders...", command=self._safe(self.app.add_many))
        m.tk_popup(self.winfo_pointerx(), self.winfo_pointery())

    def search(self):
        self.app.show_tab("Search")

    def extract(self):
        w = WizardWindow(self.app, self)
        w.focus_set()

    def review(self):
        ReviewWindow(self.app, self)

    def export(self):
        s = self.last_session
        if s is None or not s.preview:
            messagebox.showinfo("Export to Excel", "There is no extraction to export yet. Use '3  Extract to Excel' first, or '4  Review Results' to open stored tables.", parent=self)
            return
        ExportDialog(self, s)

    def history(self):
        HistoryWindow(self.app, self)

    def batch(self):
        BatchWindow(self.app, self)

    def toggle_advanced(self):
        on = self.app.toggle_advanced()
        self.adv_btn.config(text="Hide advanced tools" if on else "Show advanced tools")


# ===================================================================== preview panel (step 4 and Review Results)
class PreviewPanel(ttk.Frame):
    def __init__(self, master, session):
        super().__init__(master)
        self.s = session
        self.cur = None
        self.cell = None
        self.layout = tk.StringVar(value="norm")
        top = ttk.Frame(self); top.pack(fill="x")
        ttk.Label(top, text="Table:").pack(side="left")
        self.combo = ttk.Combobox(top, state="readonly", width=100); self.combo.pack(side="left", padx=6, fill="x", expand=True)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.show(self.combo.current()))
        lay = ttk.Frame(self); lay.pack(fill="x", pady=2)
        ttk.Radiobutton(lay, text="Normalized (merged values repeated)", variable=self.layout, value="norm", command=self.redraw).pack(side="left")
        ttk.Radiobutton(lay, text="Original layout (blank where the PDF merges cells)", variable=self.layout, value="orig", command=self.redraw).pack(side="left", padx=12)
        self.info = tk.StringVar(); ttk.Label(self, textvariable=self.info, justify="left").pack(anchor="w")
        body = ttk.Frame(self); body.pack(fill="both", expand=True)
        self.tv = ttk.Treeview(body, show="headings", selectmode="browse", height=14)
        ys = ttk.Scrollbar(body, orient="vertical", command=self.tv.yview); xs = ttk.Scrollbar(body, orient="horizontal", command=self.tv.xview)
        self.tv.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y"); xs.pack(side="bottom", fill="x"); self.tv.pack(fill="both", expand=True)
        self.tv.tag_configure("review", background="#FFE9C7"); self.tv.tag_configure("fixed", background="#DCEBFA")
        self.tv.bind("<Button-1>", self.on_click); self.tv.bind("<Double-1>", self.on_edit)
        self.detail = tk.StringVar(); ttk.Label(self, textvariable=self.detail, wraplength=1000, justify="left").pack(anchor="w", pady=2)
        bar = ttk.Frame(self); bar.pack(fill="x")
        for text, cmd in [("Correct value...", self.on_edit), ("Mark uncertain / clear", self.on_mark), ("Rename column...", self.on_rename),
                          ("Hide / show column", self.on_hide), ("Open source PDF", self.on_open)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=3, pady=3)
        self.warn = tk.StringVar(); ttk.Label(self, textvariable=self.warn, foreground="#9C5700", wraplength=1000, justify="left").pack(anchor="w")

    def load(self):
        ents = self.s.preview
        self.combo["values"] = [e.describe() for e in ents]
        if ents:
            self.combo.current(0); self.show(0)
        else:
            self.cur = None; self.tv.delete(*self.tv.get_children()); self.info.set("Nothing was found for this choice.")
        w = self.s.warnings
        self.warn.set(("Notes: " + " | ".join(w[:6]) + (" ..." if len(w) > 6 else "")) if w else "")

    def show(self, i):
        if not (0 <= i < len(self.s.preview)):
            return
        self.cur = self.s.preview[i]; self.cell = None; self.redraw()

    def redraw(self):
        e = self.cur
        if e is None:
            return
        t = e.table
        self.tv.delete(*self.tv.get_children())
        cols = [f"c{i}" for i in range(len(t.headers))]
        self.tv["columns"] = cols
        for i, h in enumerate(t.headers):
            self.tv.heading(cols[i], text=h.name); self.tv.column(cols[i], width=max(70, min(260, 9 * len(h.name) + 30)), stretch=False)
        hidden = set(getattr(t, "hidden_cols", []) or [])
        self.tv["displaycolumns"] = [c for i, c in enumerate(cols) if i not in hidden] or cols
        lay = self.layout.get()
        for n, r in enumerate(t.rows[:PREVIEW_LIMIT]):
            vals = list(r.orig if lay == "orig" else r.norm)
            tags = []
            if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl):
                tags.append("review")
            elif any("corrected by user" in f for fl in r.cell_flags.values() for f in fl):
                tags.append("fixed")
            self.tv.insert("", "end", iid=str(n), values=[v.replace("\n", " ") for v in vals], tags=tags)
        more = f"  (showing the first {PREVIEW_LIMIT} rows; the export contains all {len(t.rows)})" if len(t.rows) > PREVIEW_LIMIT else ""
        review = sum(1 for r in t.rows if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl))
        notes = ("; ".join(t.quality_notes[:3])) if t.quality_notes else "none"
        self.info.set(f"{e.label}  |  {e.heading or 'untitled table'}  |  pages {t.page_from}-{t.page_to}  |  {len(t.rows)} rows  |  method: {t.method}  |  "
                      f"quality: {t.quality:.0%}  |  rows to review: {review} (orange)  |  corrected: blue  |  notes: {notes}{more}")
        self.detail.set("Click a cell to see its full value. Double-click to correct it.")

    def _hit(self, ev):
        row = self.tv.identify_row(ev.y); col = self.tv.identify_column(ev.x)
        if not row or not col:
            return None
        disp = list(self.tv["displaycolumns"]) if self.tv["displaycolumns"] else list(self.tv["columns"])
        cols = list(self.tv["columns"])
        try:
            name = disp[int(col[1:]) - 1] if disp and disp[0] != "#all" else cols[int(col[1:]) - 1]
            return int(row), cols.index(name)
        except Exception:
            return None

    def on_click(self, ev):
        h = self._hit(ev)
        if h is None or self.cur is None:
            return
        self.cell = h
        r, c = h
        row = self.cur.table.rows[r]
        v = (row.orig if self.layout.get() == "orig" else row.norm)[c]
        fl = row.cell_flags.get(c, [])
        src = f"page {row.page}" if len(row.pages) <= 1 else f"pages {row.pages[0]}-{row.pages[-1]}"
        self.detail.set(f"[{self.cur.table.headers[c].name}]  {v}\n{src}" + (("   |   " + "; ".join(f.split(': ', 1)[-1] for f in fl)) if fl else ""))

    def on_edit(self, ev=None):
        if self.cur is None or self.cell is None:
            messagebox.showinfo("Correct value", "Click a cell first.", parent=self); return
        r, c = self.cell
        row = self.cur.table.rows[r]
        old = (row.orig if self.layout.get() == "orig" else row.norm)[c]
        new = simpledialog.askstring("Correct value", f"New value for '{self.cur.table.headers[c].name}' (row {r + 1}).\nThe original text from the PDF stays stored.", initialvalue=old, parent=self)
        if new is None or new == old:
            return
        try:
            self.s.edit_cell(self.cur, r, c, new)
        except ValueError as e:
            messagebox.showinfo("Correct value", str(e), parent=self); return
        self.redraw(); self.tv.selection_set(str(r))

    def on_mark(self):
        if self.cur is None or self.cell is None:
            return
        r, c = self.cell
        on = not any("marked uncertain" in f for f in self.cur.table.rows[r].cell_flags.get(c, []))
        self.s.mark_uncertain(self.cur, r, c, on); self.redraw()

    def on_rename(self):
        if self.cur is None or self.cell is None:
            messagebox.showinfo("Rename column", "Click a cell in the column first.", parent=self); return
        c = self.cell[1]
        h = self.cur.table.headers[c]
        new = simpledialog.askstring("Rename column", f"New name for '{h.name}':\n(the wording found in the PDF is remembered)", initialvalue=h.name, parent=self)
        if new:
            self.s.rename_column(self.cur, c, new.strip()); self.redraw()

    def on_hide(self):
        if self.cur is None or self.cell is None:
            return
        c = self.cell[1]
        self.s.hide_column(self.cur, c, c not in (self.cur.table.hidden_cols or [])); self.redraw()

    def on_open(self):
        if self.cur is not None:
            _open(self.cur.path)


# ===================================================================== wizard
class WizardWindow(tk.Toplevel):
    TITLES = ["Select documents", "What do you want to extract?", "Identify the target", "Preview and correct", "Export"]

    def __init__(self, app, home=None):
        super().__init__(app)
        self.app, self.home = app, home
        self.title("Extract to Excel"); self.geometry("1120x720"); self.minsize(900, 600)
        self.s = Session(app.lib)
        self.step = 0
        self.mode = tk.StringVar(value="all_tables")
        self.q = queue.Queue(); self.control = None; self.busy = False
        self.head = ttk.Label(self, font=(FONT, 15, "bold")); self.head.pack(anchor="w", padx=14, pady=(12, 0))
        self.body = ttk.Frame(self, padding=14); self.body.pack(fill="both", expand=True)
        nav = ttk.Frame(self, padding=(14, 0, 14, 12)); nav.pack(fill="x")
        self.msg = tk.StringVar(); ttk.Label(nav, textvariable=self.msg).pack(side="left")
        self.btn_next = ttk.Button(nav, text="Next >", command=self.next); self.btn_next.pack(side="right")
        self.btn_back = ttk.Button(nav, text="< Back", command=self.back); self.btn_back.pack(side="right", padx=6)
        self.btn_cancel = ttk.Button(nav, text="Cancel work", command=self.cancel_work, state="disabled"); self.btn_cancel.pack(side="right", padx=6)
        self.after(150, self._poll)
        self.show_step(0)

    # ---- plumbing
    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def show_step(self, n):
        self.step = n
        self.head.config(text=f"Step {n + 1} of 5:  {self.TITLES[n]}")
        self.clear(); self.msg.set("")
        getattr(self, f"step{n + 1}")()
        self.btn_back.config(state="normal" if n > 0 else "disabled")
        self.btn_next.config(text="Close" if n == 4 else "Next >")

    def back(self):
        if not self.busy and self.step > 0:
            self.show_step(self.step - 1)

    def next(self):
        if self.busy:
            return
        try:
            ok = getattr(self, f"leave{self.step + 1}", lambda: True)()
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Extraction"), parent=self); return
        if ok is False:
            return
        if self.step == 4:
            self.destroy(); return
        if ok != "wait":
            self.show_step(self.step + 1)

    def run_bg(self, label, fn, done):
        self.busy = True; self.control = JobControl(); self.btn_cancel.config(state="normal"); self.msg.set(label + " ...")
        def work():
            try:
                res = fn(self.control)
                self.q.put(("done", res, done))
            except Exception as e:
                self.q.put(("error", e, traceback.format_exc()))
        threading.Thread(target=work, daemon=True).start()

    def cancel_work(self):
        if self.control:
            self.control.cancel()

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "progress":
                    self.msg.set(m[1])
                    continue
                self.busy = False; self.btn_cancel.config(state="disabled")
                if m[0] == "done":
                    self.msg.set("")
                    m[2](m[1])
                else:
                    import logging
                    logging.getLogger("docintel").error("wizard job failed\n%s", m[2])
                    self.msg.set(""); messagebox.showerror(*friendly.explain(m[1], "Extraction"), parent=self)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass

    # ---- step 1: documents
    def step1(self):
        b = self.body
        ttk.Label(b, text="Which documents should DocIntel read?", font=(FONT, 11)).pack(anchor="w")
        self.src = tk.StringVar(value="all")
        r = ttk.Frame(b); r.pack(fill="x", pady=6)
        ttk.Radiobutton(r, text="All documents in my library", variable=self.src, value="all", command=self._src_changed).pack(anchor="w")
        ttk.Radiobutton(r, text="Only the folders selected below", variable=self.src, value="roots", command=self._src_changed).pack(anchor="w")
        mid = ttk.Frame(b); mid.pack(fill="both", expand=True)
        left = ttk.Frame(mid); left.pack(side="left", fill="y")
        ttk.Label(left, text="Folders").pack(anchor="w")
        self.roots = tk.Listbox(left, selectmode="extended", height=10, width=40, exportselection=False); self.roots.pack(fill="y")
        self._root_rows = self.app.lib.roots()
        for rr in self._root_rows:
            self.roots.insert("end", rr["name"])
        self.roots.bind("<<ListboxSelect>>", lambda e: (self.src.set("roots"), self._src_changed()))
        ttk.Button(left, text="Add a folder...", command=self._add_folder).pack(fill="x", pady=2)
        ttk.Button(left, text="Add individual PDF files...", command=self._add_files).pack(fill="x", pady=2)
        right = ttk.Frame(mid); right.pack(side="left", fill="both", expand=True, padx=12)
        ttk.Label(right, text="Selected documents (select rows and click Exclude to leave them out)").pack(anchor="w")
        self.docs = tk.Listbox(right, selectmode="extended", height=14, exportselection=False); self.docs.pack(fill="both", expand=True)
        ttk.Button(right, text="Exclude selected documents", command=self._exclude).pack(anchor="w", pady=2)
        self.count = tk.StringVar(); ttk.Label(b, textvariable=self.count, font=(FONT, 11, "bold")).pack(anchor="w", pady=6)
        self._src_changed()

    def _src_changed(self):
        if self.src.get() == "roots":
            ids = [self._root_rows[i]["id"] for i in self.roots.curselection()]
            self.s.select_roots(ids) if ids else self.s.select_files([])
        else:
            self.s.select_all()
        self._refresh_docs()

    def _refresh_docs(self):
        self.docs.delete(0, "end"); self._doc_keys = []
        by = {f["id"]: f for f in self.s.pdf_files()}
        for i in self.s.file_ids:
            if i in by:
                self.docs.insert("end", by[i]["name"]); self._doc_keys.append(i)
        for p in self.s.adhoc:
            self.docs.insert("end", os.path.basename(p) + "   (individual file)"); self._doc_keys.append(p)
        for k in range(len(self._doc_keys)):
            if self._doc_keys[k] in self.s.excluded:
                self.docs.itemconfig(k, foreground="#999999")
        self.count.set(f"{self.s.selected_count()} document(s) selected" + ("   (only PDF files can be read for tables right now)" if self.s.selected_count() == 0 else ""))

    def _exclude(self):
        for i in self.docs.curselection():
            self.s.exclude(self._doc_keys[i])
        self._refresh_docs()

    def _add_folder(self):
        p = filedialog.askdirectory(title="Choose a folder to add", parent=self)
        if p:
            try:
                self.app.lib.add_root(p); self.app.lib.scan()
            except ValueError as e:
                messagebox.showinfo("Folder", "That folder is already in DocIntel." if "already" in str(e) else "That folder could not be added.", parent=self)
            self.show_step(0)

    def _add_files(self):
        ps = filedialog.askopenfilenames(title="Choose PDF files", filetypes=[("PDF files", "*.pdf")], parent=self)
        if ps:
            self.s.add_adhoc(list(ps)); self._refresh_docs()

    def leave1(self):
        if self.s.selected_count() == 0:
            messagebox.showinfo("Select documents", "Choose at least one PDF document first.", parent=self); return False
        return True

    # ---- step 2: what to extract
    def step2(self):
        ttk.Label(self.body, text="Choose one:", font=(FONT, 11)).pack(anchor="w", pady=(0, 6))
        for key, title, desc in MODES:
            f = ttk.Frame(self.body); f.pack(fill="x", pady=3)
            ttk.Radiobutton(f, text=title, variable=self.mode, value=key, width=34).pack(side="left")
            ttk.Label(f, text=desc).pack(side="left")

    # ---- step 3: identify target (reads the documents first)
    def leave2(self):
        self.run_bg("Reading documents", lambda ctl: self.s.prepare(progress=lambda i, n, name: self.q.put(("progress", f"Reading {i} of {n}: {name}")), control=ctl), self._prepared)
        return "wait"

    def _prepared(self, cat):
        self.show_step(2)

    def step3(self):
        b, mode = self.body, self.mode.get()
        found = len(self.s.catalog)
        bad = [(k, v[1]) for k, v in self.s.status.items() if v[0] in ("failed", "unsupported", "no_tables", "partial")]
        ttk.Label(b, text=f"{found} table(s) found in {len(self.s.status) or self.s.selected_count()} document(s)." + (f"  {len(bad)} document(s) need attention (see below)." if bad else ""),
                  font=(FONT, 11, "bold")).pack(anchor="w")
        self.p = {}
        if mode == "all_tables":
            ttk.Label(b, text="All tables will be extracted. Click Next to preview them.").pack(anchor="w", pady=6)
        elif mode == "table":
            self.tbl_list = tk.Listbox(b, selectmode="extended", height=12, exportselection=False); self.tbl_list.pack(fill="both", expand=True, pady=4)
            for e in self.s.catalog:
                self.tbl_list.insert("end", e.describe())
            ttk.Label(b, text="Select one or more tables.").pack(anchor="w")
        elif mode in ("section", "records", "fields"):
            self._heading_picker(b, optional=(mode != "section"))
            if mode == "records":
                row = ttk.Frame(b); row.pack(fill="x", pady=4); ttk.Label(row, text="Show only rows containing:").pack(side="left")
                self.p["text"] = tk.StringVar(); ttk.Entry(row, textvariable=self.p["text"], width=40).pack(side="left", padx=6)
            if mode == "fields":
                self._field_picker(b)
        elif mode == "text":
            ttk.Label(b, text="The text of every page will be listed, one row per page. (Documents must be indexed first.)").pack(anchor="w", pady=6)
        elif mode == "custom":
            ttk.Label(b, text="Describe what you want, for example: Extract every issue from the Issues & Concerns section, including description, urgency, owner and status.", wraplength=900).pack(anchor="w")
            self.req = tk.Text(b, height=4, wrap="word"); self.req.pack(fill="x", pady=4)
            ttk.Button(b, text="Understand my request", command=self._parse_req).pack(anchor="w")
            self.req_out = tk.StringVar(); ttk.Label(b, textvariable=self.req_out, wraplength=900, justify="left").pack(anchor="w", pady=4)
            self._heading_picker(b, optional=True)
        if bad:
            ttk.Label(b, text="Documents that need attention:", font=(FONT, 10, "bold")).pack(anchor="w", pady=(8, 0))
            t = tk.Text(b, height=4, wrap="word"); t.pack(fill="x"); t.insert("1.0", "\n".join(f"{k}: {m}" for k, m in bad)); t.config(state="disabled")

    def _heading_picker(self, b, optional):
        self._hs = self.s.headings()
        ttk.Label(b, text="Section headings found (select the ones you want" + (" - leave empty for all):" if optional else "):")).pack(anchor="w", pady=(8, 0))
        row = ttk.Frame(b); row.pack(fill="x")
        ttk.Label(row, text="Type a name to find similar headings:").pack(side="left")
        self.hq = tk.StringVar(); e = ttk.Entry(row, textvariable=self.hq, width=34); e.pack(side="left", padx=6)
        ttk.Button(row, text="Find", command=self._find_heading).pack(side="left")
        self.hlist = tk.Listbox(b, selectmode="extended", height=7, exportselection=False); self.hlist.pack(fill="x", pady=4)
        for h in self._hs:
            self.hlist.insert("end", f"{h['heading']}   -   in {h['documents']} document(s), {h['tables']} table(s)")
        self.hnote = tk.StringVar(); ttk.Label(b, textvariable=self.hnote, foreground="#9C5700").pack(anchor="w")

    def _find_heading(self):
        q = self.hq.get().strip()
        if not q:
            return
        c = self.s.candidates(q)
        self.hlist.selection_clear(0, "end")
        names = [h["heading"] for h in self._hs]
        for x in c:
            if x["heading"] in names:
                self.hlist.selection_set(names.index(x["heading"]))
        self.hnote.set(("Similar headings are selected: " + ", ".join(f"{x['heading']} ({x['score']:.0f}% match)" for x in c[:4]) + ".  Please check they are what you mean.") if c else "No similar heading found.")

    def _field_picker(self, b):
        names = {}
        for e in self.s.catalog:
            for h in e.table.headers:
                names[h.name] = names.get(h.name, 0) + 1
        self._fields = sorted(names, key=lambda n: (-names[n], n))
        ttk.Label(b, text="Columns (select the ones you want; you can also type a name that is not in the list):").pack(anchor="w", pady=(8, 0))
        self.flist = tk.Listbox(b, selectmode="extended", height=7, exportselection=False); self.flist.pack(fill="x")
        for n in self._fields:
            self.flist.insert("end", f"{n}   ({names[n]} table(s))")
        row = ttk.Frame(b); row.pack(fill="x", pady=3); ttk.Label(row, text="Extra field names (comma separated):").pack(side="left")
        self.p["extra"] = tk.StringVar(); ttk.Entry(row, textvariable=self.p["extra"], width=50).pack(side="left", padx=6)

    def _parse_req(self):
        from .wizard import parse_request
        r = parse_request(self.req.get("1.0", "end"), [h["heading"] for h in self.s.headings()])
        self.req_out.set(f"Section: {r['section'] or '(not recognised)'}    Fields: {', '.join(r['fields']) or '(all columns)'}"
                         + (f"    Rows containing: {r['filter']}" if r["filter"] else "") + "\nChange the heading selection below if this is not what you meant.")
        if r["section"]:
            names = [h["heading"] for h in self._hs]
            self.hlist.selection_clear(0, "end")
            if r["section"] in names:
                self.hlist.selection_set(names.index(r["section"]))

    def _chosen_headings(self):
        return [self._hs[i]["heading"] for i in self.hlist.curselection()] if hasattr(self, "hlist") else []

    def leave3(self):
        mode = self.mode.get()
        if mode == "table":
            idx = list(self.tbl_list.curselection())
            if not idx:
                messagebox.showinfo("Identify the target", "Select at least one table.", parent=self); return False
            self.s.build("table", indices=idx)
        elif mode == "section":
            hs = self._chosen_headings()
            if not hs:
                messagebox.showinfo("Identify the target", "Select the section heading you want.", parent=self); return False
            self.s.build("section", headings=hs)
        elif mode == "records":
            t = self.p["text"].get().strip()
            if not t:
                messagebox.showinfo("Identify the target", "Type the word or phrase to look for.", parent=self); return False
            self.s.build("records", text=t, headings=self._chosen_headings() or None)
        elif mode == "fields":
            sel = [self._fields[i] for i in self.flist.curselection()]
            extra = [x.strip() for x in self.p["extra"].get().split(",") if x.strip()]
            if not sel and not extra:
                messagebox.showinfo("Identify the target", "Select at least one column.", parent=self); return False
            self.s.build("fields", fields=sel + extra, headings=self._chosen_headings() or None)
        elif mode == "custom":
            txt = self.req.get("1.0", "end").strip()
            if not txt:
                messagebox.showinfo("Identify the target", "Type what you want.", parent=self); return False
            hs = self._chosen_headings()
            self.s.build("custom", text=txt, **({"section": hs} if hs else {}))
        elif mode == "text":
            self.s.build("text")
        else:
            self.s.build("all_tables")
        return True

    # ---- step 4: preview
    def step4(self):
        self.panel = PreviewPanel(self.body, self.s); self.panel.pack(fill="both", expand=True)
        self.panel.load()
        if self.home is not None:
            self.home.last_session = self.s

    def leave4(self):
        if not self.s.preview:
            messagebox.showinfo("Preview", "Nothing to export. Go back and choose something else.", parent=self); return False
        if self.home is not None:
            self.home.last_session = self.s
        n = self.s.review_count()
        if n and not messagebox.askyesno("Rows need review", f"{n} row(s) are marked for review (orange). Export anyway?", parent=self):
            return False
        return True

    # ---- step 5: export
    def step5(self):
        ExportPanel(self.body, self.s, self).pack(fill="both", expand=True)
        bar = ttk.Frame(self.body); bar.pack(fill="x", pady=(6, 0))
        ttk.Button(bar, text="Save these choices as a reusable extraction...", command=self.save_profile).pack(side="left")
        ttk.Label(bar, text="  (then run it on hundreds of reports from 'Saved extractions && batch jobs' on the Home screen)").pack(side="left")

    def save_profile(self):
        from . import batch
        name = simpledialog.askstring("Save extraction", "Give this extraction a name (for example: Daily report - Construction):", parent=self)
        if not name or not name.strip():
            return
        try:
            p = batch.profile_from_session(self.s, name.strip())
            batch.save_profile(self.app.lib.db, p)
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Save extraction"), parent=self); return
        messagebox.showinfo("Saved", "Saved. It looks for the section or table by name, so it works on other documents too (page numbers are not used).", parent=self)

    def selftest(self):
        """Used by the automated Windows smoke test: draw every step with an empty selection; return True if nothing raised."""
        for n in range(5):
            self.show_step(n)
        self.show_step(0)
        return True


class ExportPanel(ttk.Frame):
    def __init__(self, master, session, owner):
        super().__init__(master)
        self.s, self.owner = session, owner
        n = sum(len(e.table.rows) for e in session.preview)
        ttk.Label(self, text=f"{len(session.preview)} table(s), {n} row(s) from {len({e.label for e in session.preview})} document(s) will be exported.", font=(FONT, 11, "bold")).pack(anchor="w")
        self.fmt = tk.StringVar(value="xlsx"); self.arr = tk.StringVar(value=session.suggest_arrangement() if session.preview else "per_table")
        self.lay_norm = tk.BooleanVar(value=True); self.lay_orig = tk.BooleanVar(value=False)
        self.val = tk.StringVar(value="raw"); self.hdr = tk.StringVar(value="joined"); self.src = tk.BooleanVar(value=True)
        def group(title):
            f = ttk.LabelFrame(self, text=title, padding=6); f.pack(fill="x", pady=4); return f
        f = group("File type")
        ttk.Radiobutton(f, text="Excel workbook (.xlsx)", variable=self.fmt, value="xlsx").pack(anchor="w")
        ttk.Radiobutton(f, text="CSV files (one per table)", variable=self.fmt, value="csv").pack(anchor="w")
        f = group("Arrangement (Excel)")
        ttk.Radiobutton(f, text="Stack tables with the same columns together (best for many reports)", variable=self.arr, value="stacked").pack(anchor="w")
        ttk.Radiobutton(f, text="Everything in ONE worksheet (all tables, columns merged by name) - best for filtering", variable=self.arr, value="single_sheet").pack(anchor="w")
        ttk.Radiobutton(f, text="One worksheet per table", variable=self.arr, value="per_table").pack(anchor="w")
        ttk.Radiobutton(f, text="One Excel file per document", variable=self.arr, value="per_document_files").pack(anchor="w")
        f = group("Layout")
        ttk.Checkbutton(f, text="Normalized (merged cells repeated on every row - best for filtering)", variable=self.lay_norm).pack(anchor="w")
        ttk.Checkbutton(f, text="Original layout (blank where the PDF merges cells)", variable=self.lay_orig).pack(anchor="w")
        self.grp_rows = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Original layout: show the PDF's merged heading bands (e.g. CATEGORY ...) as their own rows", variable=self.grp_rows).pack(anchor="w")
        f = group("Values and columns")
        ttk.Radiobutton(f, text="Exact text as in the document (recommended: keeps 001, 65%, 01.02 unchanged)", variable=self.val, value="raw").pack(anchor="w")
        ttk.Radiobutton(f, text="Convert clear numbers, percentages and dates to Excel values (exact text kept on a second sheet)", variable=self.val, value="typed").pack(anchor="w")
        ttk.Radiobutton(f, text="Full column names (e.g. Progress % / 07-Oct-2026)", variable=self.hdr, value="joined").pack(anchor="w")
        ttk.Radiobutton(f, text="Short column names (lowest header level only, when unique)", variable=self.hdr, value="leaf").pack(anchor="w")
        ttk.Checkbutton(f, text="Add source columns (file, page, section, review notes)", variable=self.src).pack(anchor="w")
        self.big = ttk.Button(self, text="Export to Excel", command=self.go); self.big.pack(pady=10, ipadx=30, ipady=10)
        self.result = tk.StringVar(); ttk.Label(self, textvariable=self.result, wraplength=900, justify="left").pack(anchor="w")

    def go(self):
        s = self.s
        layouts = tuple(x for x, v in (("norm", self.lay_norm.get()), ("orig", self.lay_orig.get())) if v) or ("norm",)
        fmt, arr = self.fmt.get(), self.arr.get()
        stamp = time.strftime("%Y-%m-%d_%H%M")
        if fmt == "csv" or arr == "per_document_files":
            path = filedialog.askdirectory(title="Choose a folder for the exported files", parent=self.winfo_toplevel())
            if path:
                path = os.path.join(path, f"DocIntel export {stamp}")
        else:
            path = filedialog.asksaveasfilename(title="Save the Excel file", defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")],
                                                initialfile=f"DocIntel extraction {stamp}.xlsx", parent=self.winfo_toplevel())
        if not path:
            return
        try:
            files = s.export(path, fmt=fmt, arrangement=arr, layouts=layouts, value_mode=self.val.get(), header_style=self.hdr.get(), include_source=self.src.get(), group_rows=self.grp_rows.get())
        except PermissionError:
            messagebox.showerror("Export", "The file could not be written. If it is open in Excel, close it and try again.", parent=self.winfo_toplevel()); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Export"), parent=self.winfo_toplevel()); return
        self.result.set(f"Done. {len(files)} file(s) written:\n" + "\n".join(files[:5]))
        if messagebox.askyesno("Export finished", "Open the folder with the exported file(s)?", parent=self.winfo_toplevel()):
            _open(os.path.dirname(files[0]) if os.path.isfile(files[0]) else files[0])


class ExportDialog(tk.Toplevel):
    def __init__(self, master, session):
        super().__init__(master)
        self.title("Export to Excel"); self.geometry("820x620")
        ExportPanel(self, session, self).pack(fill="both", expand=True, padx=12, pady=12)


# ===================================================================== review stored tables
class ReviewWindow(tk.Toplevel):
    def __init__(self, app, home):
        super().__init__(app)
        self.title("Review Results"); self.geometry("1150x700")
        self.app, self.home = app, home
        self.s = Session(app.lib)
        top = ttk.Frame(self, padding=8); top.pack(fill="x")
        ttk.Label(top, text="Tables already extracted. Choose one or more, then click Open.").pack(side="left")
        self.lb = tk.Listbox(self, selectmode="extended", height=8, exportselection=False); self.lb.pack(fill="x", padx=8)
        self.rows = store.list_tables(app.lib.db)
        for r in self.rows:
            self.lb.insert("end", f"{r['file_name']} | {r['section'] or r['title'] or 'untitled'} | pages {r['page_from']}-{r['page_to']} | {r['rows']} rows")
        if not self.rows:
            self.lb.insert("end", "No stored tables yet. Use '3  Extract to Excel' first.")
        ttk.Button(self, text="Open selected", command=self.open).pack(anchor="w", padx=8, pady=4)
        self.panel = PreviewPanel(self, self.s); self.panel.pack(fill="both", expand=True, padx=8, pady=4)

    def open(self):
        from .wizard import Entry
        ents = []
        for i in self.lb.curselection():
            if i < len(self.rows):
                r = self.rows[i]
                ents.append(Entry(r["file_name"], r["abspath"], store.load_table(self.app.lib.db, r["id"]), r["id"], r["file_id"]))
        self.s.preview = ents; self.s.warnings = []
        self.panel.load()
        self.home.last_session = self.s


class HistoryWindow(tk.Toplevel):
    def __init__(self, app, home):
        super().__init__(app)
        self.title("Extraction History"); self.geometry("980x460")
        cols = ("When", "What", "Tables", "Rows", "Documents", "File")
        self.tv = ttk.Treeview(self, columns=cols, show="headings", height=14)
        for c, w in zip(cols, (140, 130, 60, 70, 90, 440)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=8, pady=8)
        self.items = {}
        for r in app.lib.db.q("SELECT id, ts, target, audit_json FROM exports ORDER BY ts DESC LIMIT 500"):
            try:
                a = json.loads(r["audit_json"] or "{}")
            except Exception:
                a = {}
            what = a.get("mode") or "field export"
            iid = self.tv.insert("", "end", values=(time.strftime("%Y-%m-%d %H:%M", time.localtime(r["ts"] or 0)), what, a.get("tables", ""), a.get("rows", ""), a.get("documents", ""), r["target"]))
            self.items[iid] = r["target"]
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bar, text="Open file / folder", command=self.open).pack(side="left")
        ttk.Button(bar, text="Batch jobs...", command=lambda: BatchWindow(app, home)).pack(side="left", padx=8)
        if not self.items:
            ttk.Label(bar, text="  Nothing exported yet.").pack(side="left")

    def open(self):
        sel = self.tv.selection()
        if sel and os.path.exists(self.items[sel[0]]):
            _open(self.items[sel[0]])
        else:
            messagebox.showinfo("Open", "That file no longer exists.", parent=self)


# ===================================================================== saved extractions + batch jobs (Milestone 4)
ARRANGEMENTS = [("Stack tables with the same columns together", "stacked"), ("Everything in ONE worksheet", "single_sheet"),
                ("One worksheet per table", "per_table"), ("One Excel file per document", "per_document_files")]
LAYOUTS = [("Normalized (merged cells repeated)", ["norm"]), ("Original layout (blanks where merged)", ["orig"]), ("Both", ["norm", "orig"])]


def _split(txt):
    return [x.strip() for x in (txt or "").split(",") if x.strip()]


class ProfileDialog(tk.Toplevel):
    """Create or edit a saved extraction. Plain words only: which section / table, which columns, how to export."""
    def __init__(self, master, profile, on_save):
        super().__init__(master)
        from . import batch
        self.batch, self.on_save, self.p = batch, on_save, batch.normalize_profile(profile)
        self.title("Saved extraction"); self.geometry("760x560")
        f = ttk.Frame(self, padding=12); f.pack(fill="both", expand=True)
        P = self.p
        self.v = {k: tk.StringVar(value=val) for k, val in (
            ("name", P["name"]), ("heading", P["section"]["heading"]), ("aliases", ", ".join(P["section"]["aliases"])),
            ("headers", ", ".join(P["table"]["headers"])), ("fields", ", ".join(P["fields"])), ("filter", P["text_filter"]),
            ("request", P["request"]))}
        rows = [("Name", "name", "The name you will pick later."),
                ("Section heading", "heading", "Example: Construction Activities. Leave empty to search by column names instead."),
                ("Other headings that mean the same", "aliases", "Comma separated. Headings you confirmed as identical."),
                ("Column names of the table", "headers", "Optional, comma separated. Finds the table whose columns match, in any document and on any page."),
                ("Only these columns", "fields", "Optional, comma separated. Empty = all columns."),
                ("Only rows containing", "filter", "Optional word or phrase."),
                ("Or describe it in words", "request", "Optional, used only when no heading or column names are given.")]
        for i, (lab, key, hint) in enumerate(rows):
            ttk.Label(f, text=lab).grid(row=2 * i, column=0, sticky="w", pady=(6, 0))
            ttk.Entry(f, textvariable=self.v[key], width=70).grid(row=2 * i, column=1, sticky="we", pady=(6, 0))
            ttk.Label(f, text=hint, foreground="#555").grid(row=2 * i + 1, column=1, sticky="w")
        f.columnconfigure(1, weight=1)
        o = P["output"]
        r = 2 * len(rows)
        self.arr = tk.StringVar(value=next((l for l, c in ARRANGEMENTS if c == o["arrangement"]), ARRANGEMENTS[0][0]))
        self.lay = tk.StringVar(value=next((l for l, c in LAYOUTS if c == o["layouts"]), LAYOUTS[0][0]))
        self.val = tk.StringVar(value="Exact text as in the document" if o["value_mode"] == "raw" else "Convert clear numbers and dates")
        for j, (lab, var, vals) in enumerate((("Excel arrangement", self.arr, [l for l, _ in ARRANGEMENTS]), ("Layout", self.lay, [l for l, _ in LAYOUTS]),
                                              ("Values", self.val, ["Exact text as in the document", "Convert clear numbers and dates"]))):
            ttk.Label(f, text=lab).grid(row=r + j, column=0, sticky="w", pady=(8, 0))
            ttk.Combobox(f, textvariable=var, values=vals, state="readonly", width=48).grid(row=r + j, column=1, sticky="w", pady=(8, 0))
        bar = ttk.Frame(self, padding=12); bar.pack(fill="x")
        ttk.Button(bar, text="Save", command=self.save).pack(side="right")
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right", padx=6)

    def save(self):
        v = {k: x.get().strip() for k, x in self.v.items()}
        P = self.p
        P["name"], P["request"], P["text_filter"] = v["name"], v["request"], v["filter"]
        P["section"] = {"heading": v["heading"], "aliases": _split(v["aliases"])}
        P["table"]["headers"], P["fields"] = _split(v["headers"]), _split(v["fields"])
        P["output"]["arrangement"] = dict(ARRANGEMENTS).get(self.arr.get(), "stacked")
        P["output"]["layouts"] = dict(LAYOUTS).get(self.lay.get(), ["norm"])
        P["output"]["value_mode"] = "raw" if self.val.get().startswith("Exact") else "typed"
        try:
            self.batch.save_profile(self.master.app.lib.db, P)
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Save extraction"), parent=self); return
        self.on_save(); self.destroy()


class BatchWindow(tk.Toplevel):
    """Saved extractions (left) and batch jobs (right/bottom): run on many documents, see what worked, retry, add new documents, export."""
    def __init__(self, app, home=None):
        super().__init__(app)
        from . import batch
        self.batch, self.app, self.home = batch, app, home
        self.runner = batch.BatchRunner(app.lib)
        self.title("Saved extractions and batch jobs"); self.geometry("1150x760")
        self.q = queue.Queue(); self.control = None; self.busy = False
        top = ttk.LabelFrame(self, text="1. Saved extractions", padding=8); top.pack(fill="x", padx=10, pady=(10, 4))
        self.lb = tk.Listbox(top, height=6, exportselection=False); self.lb.pack(side="left", fill="x", expand=True)
        bt = ttk.Frame(top); bt.pack(side="left", padx=8)
        for t, c in (("Run on documents...", self.run_profile), ("New...", self.new_profile), ("Edit...", self.edit_profile), ("Delete", self.del_profile)):
            ttk.Button(bt, text=t, command=c).pack(fill="x", pady=1)
        mid = ttk.LabelFrame(self, text="2. Batch jobs", padding=8); mid.pack(fill="both", expand=True, padx=10, pady=4)
        cols = ("Job", "When", "Saved extraction", "State", "Result")
        self.tv = ttk.Treeview(mid, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (50, 130, 220, 90, 600)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True)
        bar = ttk.Frame(mid); bar.pack(fill="x", pady=(6, 0))
        for t, c in (("Show documents", self.show_docs), ("Export to Excel", self.export_job), ("Retry failed", self.retry),
                     ("Add new documents", self.add_new), ("Continue", self.resume), ("Delete job", self.del_job)):
            ttk.Button(bar, text=t, command=c).pack(side="left", padx=(0, 6))
        nav = ttk.Frame(self, padding=(10, 0, 10, 10)); nav.pack(fill="x")
        self.msg = tk.StringVar(); ttk.Label(nav, textvariable=self.msg).pack(side="left")
        self.btn_cancel = ttk.Button(nav, text="Cancel work", command=self.cancel, state="disabled"); self.btn_cancel.pack(side="right")
        self.profiles, self.jobs = [], []
        self.reload()
        self.after(150, self._poll)

    # ---- lists
    def reload(self):
        self.profiles = self.batch.list_profiles(self.app.lib.db)
        self.lb.delete(0, "end")
        for p in self.profiles:
            self.lb.insert("end", ("(example)  " if p.get("_starter") else "") + p["name"])
        for i in self.tv.get_children():
            self.tv.delete(i)
        self.jobs = self.runner.list_jobs()
        for j in self.jobs:
            self.tv.insert("", "end", values=(j["id"], time.strftime("%Y-%m-%d %H:%M", time.localtime(j["started"] or 0)), j["profile_name"] or j["title"],
                                              {"done": "Finished", "cancelled": "Stopped", "running": "Unfinished", "interrupted": "Interrupted"}.get(j["status"], j["status"]),
                                              self.runner.summary_text(j["id"])))

    def _profile(self):
        sel = self.lb.curselection()
        if not sel:
            messagebox.showinfo("Saved extractions", "Choose a saved extraction in the list first.", parent=self); return None
        return self.profiles[sel[0]]

    def _job(self):
        sel = self.tv.selection()
        if not sel:
            messagebox.showinfo("Batch jobs", "Choose a job in the list first.", parent=self); return None
        return int(self.tv.item(sel[0])["values"][0]) if isinstance(self.tv.item(sel[0]), dict) else None

    # ---- background plumbing
    def run_bg(self, label, fn, done=None):
        if self.busy:
            return
        self.busy = True; self.control = JobControl(); self.btn_cancel.config(state="normal"); self.msg.set(label + " ...")
        def prog(i, n, name):
            self.q.put((("progress", f"{label}: {i} of {n}  -  {name}"),))
        def work():
            try:
                self.q.put((("done", fn(self.control, prog), done),))
            except Exception as e:
                import logging
                logging.getLogger("docintel").exception("batch window job failed")
                self.q.put((("error", e),))
        threading.Thread(target=work, daemon=True).start()

    def cancel(self):
        if self.control:
            self.control.cancel()

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()[0]
                if m[0] == "progress":
                    self.msg.set(m[1]); continue
                self.busy = False; self.btn_cancel.config(state="disabled"); self.msg.set("")
                if m[0] == "done":
                    self.reload()
                    if m[2]:
                        m[2](m[1])
                else:
                    messagebox.showerror(*friendly.explain(m[1], "Batch extraction"), parent=self)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass

    # ---- saved extractions
    def new_profile(self):
        ProfileDialog(self, self.batch.new_profile(""), self.reload)

    def edit_profile(self):
        p = self._profile()
        if p:
            p = dict(p); p.pop("_starter", None)
            ProfileDialog(self, p, self.reload)

    def del_profile(self):
        p = self._profile()
        if p and not p.get("_starter") and messagebox.askyesno("Delete", f"Delete the saved extraction '{p['name']}'? Finished jobs are kept.", parent=self):
            self.batch.delete_profile(self.app.lib.db, p["name"]); self.reload()
        elif p and p.get("_starter"):
            messagebox.showinfo("Example", "This is a built-in example. Use 'Edit...' to save your own copy.", parent=self)

    def run_profile(self):
        p = self._profile()
        if not p:
            return
        roots = self.app.lib.roots()
        if not roots:
            messagebox.showinfo("Run", "Add a folder of documents first ('Add Documents' on the Home screen).", parent=self); return
        dlg = tk.Toplevel(self); dlg.title("Which folders?"); dlg.geometry("560x340")
        ttk.Label(dlg, text=f"Run '{p['name']}' on the documents of these folders:", padding=8).pack(anchor="w")
        lb = tk.Listbox(dlg, selectmode="extended", exportselection=False); lb.pack(fill="both", expand=True, padx=8)
        for r in roots:
            lb.insert("end", f"{r['name']}   ({r['path']})")
        lb.select_set(0, "end")
        def go():
            ids = [roots[i]["id"] for i in lb.curselection()]
            dlg.destroy()
            if not ids:
                return
            prof = dict(p); prof.pop("_starter", None)
            self.run_bg("Extracting", lambda ctl, pg: self.runner.run(prof, root_ids=ids, control=ctl, progress=pg), self._after_run)
        ttk.Button(dlg, text="Start", command=go).pack(pady=8)

    def _after_run(self, jid):
        s = self.runner.summary(jid)
        extra = "\n\nSome documents have a similar but not identical heading. Open 'Show documents' to confirm them." if s["needs_confirmation"] else ""
        messagebox.showinfo("Finished", self.runner.summary_text(jid) + extra, parent=self)

    # ---- jobs
    def show_docs(self):
        j = self._job()
        if j:
            JobDocsWindow(self, j)

    def export_job(self):
        j = self._job()
        if not j:
            return
        arr = self.runner.job_profile(j)["output"]["arrangement"]
        stamp = time.strftime("%Y-%m-%d_%H%M")
        if arr == "per_document_files":
            path = filedialog.askdirectory(title="Choose a folder for the exported files", parent=self)
            path = os.path.join(path, f"DocIntel batch {stamp}") if path else None
        else:
            path = filedialog.asksaveasfilename(title="Save the Excel file", defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")],
                                                initialfile=f"DocIntel batch {stamp}.xlsx", parent=self)
        if not path:
            return
        try:
            files = self.runner.export_job(j, path)
        except PermissionError:
            messagebox.showerror("Export", "The file could not be written. If it is open in Excel, close it and try again.", parent=self); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Export"), parent=self); return
        if messagebox.askyesno("Export finished", "Done. The workbook has a 'Job report' sheet listing every document and its result.\n\nOpen the folder?", parent=self):
            _open(os.path.dirname(files[0]) if os.path.isfile(files[0]) else files[0])

    def retry(self):
        j = self._job()
        if j:
            self.run_bg("Retrying", lambda ctl, pg: self.runner.retry(j, control=ctl, progress=pg), lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self))

    def add_new(self):
        j = self._job()
        if j:
            def done(s):
                messagebox.showinfo("Finished", f"{s.get('new_documents', 0)} new and {s.get('changed_documents', 0)} changed document(s) processed. Unchanged documents were not processed again.\n\n" + self.runner.summary_text(j), parent=self)
            def work(ctl, pg):
                try:
                    self.app.lib.scan(control=ctl)               # pick up files added to the folders since last time
                except Exception:
                    pass
                return self.runner.add_new_documents(j, control=ctl, progress=pg)
            self.run_bg("Processing new documents", work, done)

    def resume(self):
        j = self._job()
        if j:
            self.run_bg("Continuing", lambda ctl, pg: self.runner.resume(j, control=ctl, progress=pg), lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self))

    def del_job(self):
        j = self._job()
        if j and messagebox.askyesno("Delete job", "Delete this job and its results list? Your documents and exported files are not touched.", parent=self):
            self.runner.delete_job(j); self.reload()


class JobDocsWindow(tk.Toplevel):
    def __init__(self, owner, job_id):
        super().__init__(owner)
        self.owner, self.job_id, self.runner = owner, job_id, owner.runner
        self.title(f"Job {job_id}: documents"); self.geometry("1100x560")
        cols = ("Document", "Result", "Details", "Records", "Need review")
        self.tv = ttk.Treeview(self, columns=cols, show="headings", height=18)
        for c, w in zip(cols, (240, 220, 520, 70, 90)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=8, pady=8)
        self.items = self.runner.items(job_id)
        from .batch import STATUS_TEXT
        for it in self.items:
            self.tv.insert("", "end", values=(it["name"], STATUS_TEXT.get(it["status"], it["status"]), it["message"] or "", it["records"], it["review_rows"]))
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bar, text="This heading is the same section...", command=self.confirm).pack(side="left")
        ttk.Button(bar, text="Open document", command=self.open).pack(side="left", padx=8)

    def _selected(self):
        sel = self.tv.selection()
        if not sel:
            return None
        try:
            idx = int(self.tv.index(sel[0]))
        except (TypeError, ValueError):
            idx = 0
        return self.items[idx] if 0 <= idx < len(self.items) else None

    def confirm(self):
        it = self._selected()
        cands = json.loads(it["candidates_json"] or "[]") if it and it["status"] == "needs_confirmation" else []
        if not cands:
            messagebox.showinfo("Confirm", "Select a document marked 'Similar heading found' first.", parent=self); return
        h = cands[0]["heading"]
        if messagebox.askyesno("Confirm", f"Treat '{h}' as the same section as the one you asked for?\n\nIt will be remembered for all documents of this job.", parent=self):
            j = self.job_id
            self.destroy()
            self.owner.run_bg("Applying", lambda ctl, pg: self.runner.confirm_section(j, h, control=ctl, progress=pg),
                              lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self.owner))

    def open(self):
        it = self._selected()
        if it and os.path.exists(it["path"] or ""):
            _open(it["path"])


# ===================================================================== installation into the main window
def install_home(app):
    """Add the Home tab first and keep the classic tabs available under 'advanced tools'. Called once from App.__init__."""
    nb = app.nb
    home = HomeFrame(nb, app)
    nb.insert(0, home, text="Home")
    app.tabs["Home"] = home
    app.home = home
    classic = [t for t in nb.tabs() if str(t) != str(home)]
    app._advanced_on = False
    orig_select = nb.select

    def select(tab=None):                      # old buttons call nb.select(<hidden tab>): show it first
        if tab is not None and str(tab) in [str(x) for x in app._hidden]:
            nb.add(tab); app._hidden = [x for x in app._hidden if str(x) != str(tab)]
        return orig_select(tab) if tab is not None else orig_select()

    app._hidden = []
    nb.select = select

    def toggle():
        app._advanced_on = not app._advanced_on
        if app._advanced_on:
            for t in list(app._hidden):
                nb.add(t)
            app._hidden = []
        else:
            for t in classic:
                try:
                    nb.hide(t); app._hidden.append(t)
                except tk.TclError:
                    pass
            orig_select(home)
        return app._advanced_on

    app.toggle_advanced = toggle

    def show_tab(name):
        nb.select(app.tabs[name])
    app.show_tab = show_tab
    app._advanced_on = True
    toggle()                                   # start with the classic tabs hidden
    orig_select(home)
    home.refresh()
    return home
