"""Synthetic PDFs for table-engine tests (Test D). Each returns the path; expected values are in the tests."""
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.pdfgen import canvas

ST = getSampleStyleSheet()
_D = "/usr/share/fonts/truetype/dejavu/"
try:
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    pdfmetrics.registerFont(TTFont("DJ", _D + "DejaVuSans.ttf")); pdfmetrics.registerFont(TTFont("DJB", _D + "DejaVuSans-Bold.ttf"))
    _F, _FB = "DJ", "DJB"
except Exception:                                   # fall back to base-14 fonts (Unicode tests then differ)
    _F, _FB = "Helvetica", "Helvetica-Bold"
CELL = ParagraphStyle("c", fontSize=8, leading=10, fontName=_F)
HEAD = ParagraphStyle("h", fontSize=8, leading=10, fontName=_FB)
P = lambda t: Paragraph(t, CELL)
HP = lambda t: Paragraph(t, HEAD)
GRID = [("GRID", (0, 0), (-1, -1), 0.6, colors.black), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]


def lined_special(path):
    """Different columns, multi-line headers, %, codes, specials, empty cells, wrapped description."""
    data = [[HP("Item<br/>No."), HP("Test Code"), HP("Description of the<br/>work item"), HP("Done %"), HP("Rating"), HP("Note")],
            [P("001"), P("EHV.SWGXX.SF6.TEST"), P("SF6 gas purity and dew point measurement of the whole compartment, repeated for every bay"), P("65%"), P("110/13.8 kV"), P("")],
            [P("002"), P("DTS-022"), P("Tan ∂ test &amp; insulation"), P("0.25"), P("-12.5"), P("N/A")],
            [P("01.02"), P("#A-1"), P("24 hours soak"), P("100%"), P("48 V"), P("ملاحظة 24")]]
    SimpleDocTemplate(path, pagesize=A4).build([Paragraph("Test Register", ST["Heading2"]), Table(data, style=GRID, colWidths=[40, 125, 160, 45, 70, 50])])
    return path


def lined_multipage(path, n=90):
    data = [[HP("No."), HP("Name"), HP("Qty"), HP("Remark")]] + [[P(str(i)), P(f"Item {i} with a long enough text to wrap around once in a while {i}" if i % 7 == 0 else f"Item {i}"), P(f"{i % 13}%"), P("" if i % 5 else "ok")] for i in range(1, n + 1)]
    SimpleDocTemplate(path, pagesize=A4).build([Paragraph("Long List", ST["Heading2"]), Table(data, style=GRID, colWidths=[40, 260, 50, 80], repeatRows=1)])
    return path


def merged_cells(path):
    data = [[HP("Sr."), HP("Group"), HP("Group Code"), HP("Activity"), HP("Hours")],
            ["1", "Battery Bank", "SBB", "Scheme check", "12"], ["2", "", "", "Component check", "6"], ["3", "", "", "Insulation", "2"],
            ["4", "Panel", "ACDB", "Scheme check", "16"], ["5", "", "", "Component check", "4"]]
    style = GRID + [("SPAN", (1, 1), (1, 3)), ("SPAN", (2, 1), (2, 3)), ("SPAN", (1, 4), (1, 5)), ("SPAN", (2, 4), (2, 5)), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]
    SimpleDocTemplate(path, pagesize=A4).build([Paragraph("Merged", ST["Heading2"]), Table(data, style=style, colWidths=[30, 90, 70, 150, 40])])
    return path


def two_tables_one_page(path):
    t1 = [[HP("Id"), HP("Issue"), HP("Urgency")], ["1", "Late drawings", "High"], ["2", "Missing cable", "Low"]]
    t2 = [[HP("Sr"), HP("Equipment"), HP("Vendor"), HP("Status"), HP("Progress %")], ["1", "Transformer", "ABB", "Ordered", "40%"], ["2", "Breaker", "Siemens", "Delivered", "100%"]]
    SimpleDocTemplate(path, pagesize=A4).build([Paragraph("Issues", ST["Heading2"]), Table(t1, style=GRID, colWidths=[30, 150, 60]), Spacer(1, 30),
                                                Paragraph("Equipment", ST["Heading2"]), Table(t2, style=GRID, colWidths=[30, 100, 80, 70, 70])])
    return path


def borderless(path):
    c = canvas.Canvas(path, pagesize=A4)
    c.setFont("Helvetica-Bold", 14); c.drawString(50, 800, "Material Delivery")
    cols = [50, 90, 250, 330, 420]
    rows = [["No", "Material", "Qty", "Unit", "Delivered %"], ["1", "Cable 3x185", "120", "m", "65%"], ["2", "Cable gland", "40", "pcs", "0%"],
            ["3", "Earth rod", "15", "pcs", "100%"], ["4", "Lug 185 mm2", "300", "pcs", "12.5%"]]
    y = 760
    for i, r in enumerate(rows):
        c.setFont("Helvetica-Bold" if i == 0 else "Helvetica", 9)
        for x, v in zip(cols, r):
            c.drawString(x, y, v)
        y -= 16
    c.save(); return path


def all_synthetic(d):
    os.makedirs(d, exist_ok=True)
    return {n: f(os.path.join(d, n + ".pdf")) for n, f in [("lined_special", lined_special), ("lined_multipage", lined_multipage), ("merged_cells", merged_cells), ("two_tables", two_tables_one_page), ("borderless", borderless)]}
