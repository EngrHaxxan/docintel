"""Generates a deterministic synthetic corpus with known ground truth (tests/ground_truth.json is returned/written)."""
import json, os, random, shutil, sys

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "C:\\Windows\\Fonts\\arial.ttf"]


def font(size):
    for f in FONT_CANDIDATES:
        if os.path.exists(f):
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()


def text_image(lines, size=(1600, 1000), fsize=34, path=None, rotate=0, scale=1.0):
    im = Image.new("RGB", size, "white"); d = ImageDraw.Draw(im); y = 40
    for l in lines:
        d.text((60, y), l, fill="black", font=font(fsize)); y += fsize + 18
    if rotate: im = im.rotate(rotate, expand=True, fillcolor="white")
    if scale != 1.0: im = im.resize((int(im.width * scale), int(im.height * scale)))
    if path: im.save(path)
    return im


def build(root):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    import docx, openpyxl
    from pptx import Presentation
    if os.path.exists(root): shutil.rmtree(root)
    A, B, C = (os.path.join(root, p) for p in ("driveA/reports/2026/Muna-1/daily", "driveB/invoices", "driveC/drawings/deep/er/still/nested/folder"))
    for p in (A, B, C, os.path.join(root, "driveB/dup"), os.path.join(root, "driveA/reports/2026/Muzdalifah/daily")):
        os.makedirs(p, exist_ok=True)
    gt = {"daily": [], "invoices": [], "drawings": []}

    # --- native PDF daily reports (same filename in two directories, different content)
    for i, (proj, d, mp, deli) in enumerate([("Muna-1", "2026-03-14", 120, "Rain 2h"), ("Muzdalifah", "2026-03-15", 85, "None")]):
        folder = os.path.join(root, "driveA/reports/2026", proj, "daily")
        c = canvas.Canvas(os.path.join(folder, "Daily_Report.pdf"), pagesize=A4)
        c.setFont("Helvetica", 12)
        y = 800
        for l in [f"DAILY REPORT", f"Date: {d}", f"Project: {proj}", "Contractor: Al-Bina Contracting", f"Manpower: {mp}",
                  f"Delays: {deli}", "Remarks: Concrete pour completed on grid C4"]:
            c.drawString(60, y, l); y -= 22
        c.save()
        gt["daily"].append({"Date": d, "Project": proj, "Manpower": mp, "path_end": f"{proj}/daily/Daily_Report.pdf"})

    # --- invoice with table spanning two pages (native PDF)
    st = getSampleStyleSheet()
    items = [("%03d" % n, f"Steel bar {n} mm", n, "ton", 100.5 + n, round(n * (100.5 + n), 2)) for n in range(1, 41)]
    doc = SimpleDocTemplate(os.path.join(B, "INV-00123.pdf"), pagesize=A4)
    data = [["Item", "Description", "Quantity", "Unit", "Unit rate", "Amount"]] + [list(map(str, r)) for r in items]
    t = Table(data, repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black), ("FONTSIZE", (0, 0), (-1, -1), 10)]))
    doc.build([Paragraph("TAX INVOICE", st["Title"]), Paragraph("Invoice No: INV-00123", st["Normal"]),
               Paragraph("Date: 05/04/2026", st["Normal"]), Spacer(1, 12), t])
    gt["invoices"].append({"file": "INV-00123.pdf", "rows": len(items), "items": items})

    # --- scanned PDF (image only) + PNG screenshot + rotated + low-res
    lines = ["INVOICE", "Invoice No: INV-00777", "Date: 21/04/2026", "Supplier: Gulf Steel Co", "Total: 15,250.75"]
    im = text_image(lines, path=os.path.join(B, "screenshot_invoice.png"))
    im.save(os.path.join(B, "scan_invoice.pdf"), "PDF", resolution=150)
    text_image(lines, path=os.path.join(B, "rotated_invoice.png"), rotate=90)
    text_image(lines, path=os.path.join(B, "lowres_invoice.png"), scale=0.45, fsize=34)
    gt["invoices"].append({"file": "screenshot_invoice.png", "Invoice No": "INV-00777", "Total": 15250.75})

    # --- corrupted + encrypted pdf + unknown type
    open(os.path.join(B, "corrupted.pdf"), "wb").write(b"%PDF-1.4\n garbage not a real pdf")
    from pypdf import PdfReader, PdfWriter
    w = PdfWriter(); w.append(PdfReader(os.path.join(root, "driveA/reports/2026/Muna-1/daily/Daily_Report.pdf"))); w.encrypt("secret")
    w.write(open(os.path.join(B, "encrypted.pdf"), "wb"))
    open(os.path.join(B, "notes.xyz"), "w").write("unsupported")

    # --- Word with table + Arabic, PPTX with table, XLSX, CSV, TXT, HTML
    d = docx.Document(); d.add_paragraph("Meeting minutes"); d.add_paragraph("Project: Muna-1")
    d.add_paragraph("الموقع: مشروع منى")      # Arabic
    tb = d.add_table(rows=3, cols=3); 
    for r, row in enumerate([["Item", "Qty", "Unit"], ["Cement", "50", "bag"], ["Sand", "12", "m3"]]):
        for c_, v in enumerate(row): tb.cell(r, c_).text = v
    d.save(os.path.join(root, "driveA/reports/minutes.docx"))
    p = Presentation(); s = p.slides.add_slide(p.slide_layouts[5]); s.shapes.title.text = "Progress Q1"
    tbs = s.shapes.add_table(2, 2, 0, 1500000, 6000000, 800000).table
    tbs.cell(0, 0).text = "Phase"; tbs.cell(0, 1).text = "Percent"; tbs.cell(1, 0).text = "Foundations"; tbs.cell(1, 1).text = "85"
    p.save(os.path.join(root, "driveA/reports/progress.pptx"))
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Register"
    ws.append(["PO Number", "Supplier", "Amount"]); ws.append(["PO-1001", "Gulf Steel Co", 5000]); ws.append(["PO-1002", "Al Rajhi Cement", 7500.5])
    wb.save(os.path.join(root, "driveB/dup/register.xlsx"))
    open(os.path.join(root, "driveB/dup/register_copy.xlsx"), "wb").write(open(os.path.join(root, "driveB/dup/register.xlsx"), "rb").read())
    open(os.path.join(root, "driveB/dup/data.csv"), "w", encoding="utf-8").write("Date,Project,Manpower\n2026-03-16,Muna-1,130\n")
    open(os.path.join(root, "driveB/dup/عربي_ملاحظات.txt"), "w", encoding="utf-8").write("تقرير يومي\nالمشروع: منى\nعدد العمال: ١٢٠\n")
    open(os.path.join(root, "driveB/dup/page.html"), "w").write("<html><body><h1>Spec</h1><table><tr><th>Tag</th><th>Value</th></tr><tr><td>P-101A</td><td>45 kW</td></tr></table></body></html>")

    # --- DXF drawing + PDF drawing with title block text
    import ezdxf
    dx = ezdxf.new("R2010"); msp = dx.modelspace()
    blk = dx.blocks.new("TITLEBLOCK")
    blk.add_attdef("DWG_NO", (0, 0)); blk.add_attdef("TITLE", (0, 5)); blk.add_attdef("REV", (0, 10))
    ins = msp.add_blockref("TITLEBLOCK", (100, 20)); ins.add_auto_attribs({"DWG_NO": "A-2045", "TITLE": "Pump Room Layout", "REV": "C"})
    msp.add_text("TK-2001 storage tank", dxfattribs={"insert": (10, 10), "height": 2.5})
    msp.add_linear_dim(base=(0, -5), p1=(0, 0), p2=(2500, 0)).render()
    dx.saveas(os.path.join(C, "A-2045.dxf"))
    c = canvas.Canvas(os.path.join(C, "A-3001_rev2.pdf"), pagesize=(842, 595)); c.setFont("Helvetica", 11)
    c.line(30, 30, 812, 30); c.drawString(40, 300, "PUMP P-101A  DN150  L=2500 mm")
    for k, (lab, val) in enumerate([("Drawing No", "A-3001"), ("Title", "Chilled Water Piping"), ("Rev", "2"), ("Scale", "1:50"), ("Date", "12/02/2026")]):
        c.drawString(560, 120 - k * 16, f"{lab}: {val}")
    c.save()
    gt["drawings"] = [{"Drawing number": "A-3001", "Revision": "2"}, {"Drawing number": "A-2045", "Revision": "C"}]

    # --- Excel template with formulas + formatting
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Log"
    ws.append(["Date", "Project", "Manpower", "Total x2"])
    from openpyxl.styles import Font, PatternFill
    for c_ in ws[1]: c_.font = Font(bold=True, color="FFFFFF"); c_.fill = PatternFill("solid", fgColor="305496")
    ws.append(["2026-03-01", "Existing", 10, "=C2*2"]); ws["C2"].number_format = "#,##0"
    ws.cell(2, 4).number_format = "0.0"
    wb.save(os.path.join(root, "template.xlsx"))

    json.dump(gt, open(os.path.join(root, "ground_truth.json"), "w"), indent=1)
    return gt


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "corpus")
    print("ok")
