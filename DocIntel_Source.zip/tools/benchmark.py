"""Reproducible benchmark: python tools/benchmark.py [N_text_files] -> prints a JSON report."""
import json, os, platform, random, shutil, sys, tempfile, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import psutil
from docintel.library import Library
from docintel import search as S


def main(n_txt=5000):
    random.seed(1); tmp = tempfile.mkdtemp(); root = os.path.join(tmp, "src"); rep = {}
    import docx
    from reportlab.pdfgen import canvas
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tests")); from make_corpus import text_image
    for i in range(n_txt):
        d = os.path.join(root, f"a{i % 50}", f"b{i % 7}", f"c{i % 3}"); os.makedirs(d, exist_ok=True)
        open(os.path.join(d, f"r{i}.txt"), "w").write(f"Report {i}\nDate: 2026-01-{i % 28 + 1:02d}\nProject: P{i % 40}\nManpower: {i % 300}\n" + "lorem ipsum dolor sit amet " * 40)
    for i in range(300):
        d = os.path.join(root, "docs"); os.makedirs(d, exist_ok=True)
        x = docx.Document(); x.add_paragraph(f"Minutes {i} Project: P{i % 40}"); t = x.add_table(rows=3, cols=3); x.save(os.path.join(d, f"m{i}.docx"))
    for i in range(200):
        d = os.path.join(root, "pdf"); os.makedirs(d, exist_ok=True)
        c = canvas.Canvas(os.path.join(d, f"p{i}.pdf")); c.drawString(72, 700, f"Invoice No: INV-{i:05d}"); c.drawString(72, 680, "Total: 1,000.00 " + "word " * 30); c.save()
    for i in range(40):
        d = os.path.join(root, "img"); os.makedirs(d, exist_ok=True)
        text_image([f"Scan {i}", f"Invoice No: INV-9{i:04d}", "Total: 2,500.00"], path=os.path.join(d, f"s{i}.png"))
    nfiles = sum(len(f) for _, _, f in os.walk(root))
    lib = Library(os.path.join(tmp, "home")); lib.cfg.set("workers", 2); lib.add_root(root)
    proc = psutil.Process(); peak = [0]
    def prog(*a): peak[0] = max(peak[0], proc.memory_info().rss)
    t0 = time.time(); lib.scan(progress=prog); rep["scan_s"] = round(time.time() - t0, 2)
    t0 = time.time(); st = lib.index(progress=prog); rep["index_s"] = round(time.time() - t0, 2)
    rep["files"] = nfiles; rep["indexed"] = st["indexed"]; rep["errors"] = st["errors"]
    rep["files_per_s_overall"] = round(nfiles / (rep["scan_s"] + rep["index_s"]), 1)
    rep["peak_rss_mb"] = round(max(peak[0], proc.memory_info().rss) / 1048576)
    rep["index_db_mb"] = round(os.path.getsize(lib.cfg.db_path) / 1048576, 1)
    rep["source_mb"] = round(sum(os.path.getsize(os.path.join(a, f)) for a, _, fs in os.walk(root) for f in fs) / 1048576, 1)
    for label, q, m in [("exact_identifier", "INV-00123", "text"), ("substring", "ipsum dolor", "text"), ("regex", r"INV-\d{5}", "regex"), ("fuzzy", "Manpowr", "fuzzy")]:
        t0 = time.time(); h = S.search(lib.db, q, m, limit=500); rep[f"search_{label}_ms"] = round((time.time() - t0) * 1000); rep[f"search_{label}_hits"] = len(h)
    t0 = time.time(); lib.scan(); rep["rescan_unchanged_s"] = round(time.time() - t0, 2)
    ocr = lib.db.q("SELECT COUNT(*) n FROM files WHERE ext='png' AND status='indexed'")[0]["n"]; rep["ocr_images_indexed"] = ocr
    rep["hardware"] = {"cpu_count": os.cpu_count(), "ram_gb": round(psutil.virtual_memory().total / 1e9, 1), "platform": platform.platform(), "python": platform.python_version()}
    shutil.rmtree(tmp, ignore_errors=True)
    print(json.dumps(rep, indent=1))


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 5000)
