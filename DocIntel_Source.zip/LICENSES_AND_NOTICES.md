# Licences and third-party notices

DocIntel's own code: MIT (see LICENSE). Components (licences as understood at build time - re-check before commercial redistribution):

| Component | Use | Licence |
|---|---|---|
| Python, Tkinter | runtime, GUI | PSF |
| SQLite (FTS5) | index | public domain |
| Tesseract OCR 5.5.3 (official Windows build, bundled `tesseract.exe` and DLLs) | OCR | Apache 2.0; bundled DLLs (e.g. libcurl, libarchive, cairo, freetype, harfbuzz, leptonica) carry their own permissive/LGPL licences, shipped with the installer package of that build |
| tessdata_fast `eng`, `osd`, `ara` | OCR languages | Apache 2.0 |
| pytesseract | wrapper | Apache 2.0 |
| pdfplumber / pdfminer.six | PDF text and tables | MIT |
| pypdfium2 (PDFium) | PDF rendering | Apache 2.0 / BSD-3 |
| pypdf | encryption check | BSD-3 |
| python-docx, python-pptx, openpyxl | Office files | MIT |
| Pillow | images | HPND |
| ezdxf | DXF | MIT |
| rapidfuzz | fuzzy search | MIT |
| watchdog | folder monitoring | Apache 2.0 |
| tkinterdnd2 (tkdnd) | drag-and-drop | MIT / BSD-style |
| PyInstaller (build only) | packaging | GPL-2.0 with bootloader exception (output may be distributed under any licence) |
| Inno Setup (build only) | installer | Inno Setup licence (free) |
| 7-Zip (build only) | unpack Tesseract installer | LGPL |
| reportlab (build only) | PDF guides | BSD |

Deliberately not used: PyMuPDF/MuPDF (AGPL), DWG libraries (ODA/LibreDWG). Optional, not bundled: LibreOffice (MPL 2.0) for legacy .doc/.ppt/.xls.
