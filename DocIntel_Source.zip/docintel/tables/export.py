"""Excel export of extracted tables: Original-layout and Normalized worksheets, raw text preserved."""
from __future__ import annotations
import datetime, os, re
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table as XlTable, TableStyleInfo

_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
MAX_ROWS = 1_048_000


def _safe_sheet(name, used):
    base = re.sub(r"[\[\]\*\?/\\:]", "_", name)[:28] or "Table"
    n, i = base, 1
    while n.lower() in used:
        i += 1; n = f"{base[:25]}_{i}"
    used.add(n.lower())
    return n


def _clean(v):
    return _BAD.sub("", v) if isinstance(v, str) else v


def _write_sheet(ws, table, mode, include_source=True, stamp=""):
    names = [h.name for h in table.headers]
    extra = []
    if table.has_groups:
        extra.append("Group")
    meta = ["Source file", "Page", "Section / table", "Extraction method", "Needs review", "Review notes", "Extracted on"] if include_source else []
    ws.append(names + extra + meta)
    sect = table.section or table.title
    for r in table.rows:
        vals = list(r.orig if mode == "orig" else r.norm)
        row = [_clean(v) for v in vals]
        if table.has_groups:
            row.append(_clean(r.group))
        if include_source:
            pages = f"{r.pages[0]}-{r.pages[-1]}" if len(r.pages) > 1 else str(r.page)
            notes = "; ".join(sorted({f"{names[c]}: {f.split(': ', 1)[-1]}" for c, fl in r.cell_flags.items() for f in fl if f.startswith("review")}))
            review = "Yes" if (notes or any(f.startswith("review") for f in r.flags)) else ""
            row += [os.path.basename(table.source), pages, sect, table.method, review, notes, stamp]
        ws.append(row)
    n, m = len(table.rows) + 1, len(names) + len(extra) + len(meta)
    for row in ws.iter_rows(min_row=1, max_row=n, max_col=m):
        for c in row:
            if c.row > 1 or True:
                c.number_format = "@"                    # exact text; never reinterpret 001, 65%, 01.02 ...
            c.alignment = Alignment(wrap_text=True, vertical="top")
    hdr_fill = PatternFill("solid", fgColor="1F4E78")
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = hdr_fill
    ws.freeze_panes = "A2"
    for ci in range(1, m + 1):
        mx = max((len(str(ws.cell(row=r, column=ci).value or "")) for r in range(1, min(n, 200) + 1)), default=8)
        ws.column_dimensions[get_column_letter(ci)].width = max(8, min(50, mx + 2))
    if n >= 2:
        ref = f"A1:{get_column_letter(m)}{n}"
        try:
            xt = XlTable(displayName=re.sub(r"\W", "_", ws.title)[:20] + "_t" + str(id(ws) % 1000), ref=ref)
            xt.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
            ws.add_table(xt)
        except Exception:
            ws.auto_filter.ref = ref


def export_tables_xlsx(tables, path, modes=("orig", "norm"), include_source=True):
    """One workbook; per table an 'Original layout' and/or 'Normalized' sheet plus a Summary sheet."""
    wb = Workbook()
    summ = wb.active; summ.title = "Summary"
    summ.append(["Table", "Section", "Source file", "Pages", "Columns", "Rows", "Rows needing review", "Quality", "Method", "Notes"])
    used = {"summary"}
    stamp = datetime.date.today().isoformat()
    for i, t in enumerate(tables, 1):
        base = (t.title or t.section or f"Table p{t.page_from}-{t.page_to}")
        for mode in modes:
            label = "Original" if mode == "orig" else "Normalized"
            ws = wb.create_sheet(_safe_sheet(f"{base} - {label}", used))
            if len(t.rows) + 1 > MAX_ROWS:
                raise ValueError("table exceeds Excel's row limit; split it first")
            _write_sheet(ws, t, mode, include_source, stamp)
        rev = len([r for r in t.rows if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl) or any(f.startswith("review") for f in r.flags)])
        summ.append([base, t.section, os.path.basename(t.source), f"{t.page_from}-{t.page_to}", len(t.headers), len(t.rows), rev,
                     round(t.quality, 2), t.method, "; ".join(t.quality_notes)])
    for c in summ[1]:
        c.font = Font(bold=True)
    for ci, w in enumerate([34, 30, 36, 8, 8, 8, 12, 8, 12, 60], 1):
        summ.column_dimensions[get_column_letter(ci)].width = w
    wb.save(path)
    return path
