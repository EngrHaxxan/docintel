"""Providers: the only place that talks to a language model. Default = NoProvider (nothing connected, nothing sent).
A LOCAL model is any open-weight model run on this computer by a model server (Ollama, LM Studio, llama.cpp server, vLLM ...) that offers the
common OpenAI-style web interface on this machine (localhost). Nothing leaves the computer and no company is involved."""
from __future__ import annotations
import json, os, time, urllib.error, urllib.request


class ProviderError(Exception):
    pass


class ProviderUnavailable(ProviderError):
    pass


LOOPBACK = ("localhost", "127.0.0.1", "::1", "[::1]")

# how a model server is usually started (shown to the user as a hint; check the tool's own documentation)
SERVER_TYPES = {
    "ollama": {"label": "Ollama (local)", "base_url": "http://localhost:11434/v1"},
    "lmstudio": {"label": "LM Studio (local)", "base_url": "http://localhost:1234/v1"},
    "llamacpp": {"label": "llama.cpp server (local)", "base_url": "http://localhost:8080/v1"},
    "other": {"label": "Other OpenAI-compatible server", "base_url": "http://localhost:8000/v1"},
}


class Provider:
    name = "none"
    kind = "none"                  # "local" (stays on this computer) | "remote" (leaves the computer) | "none"
    can_embed = False

    def available(self):
        return False

    def complete(self, system, user, max_tokens=800):
        raise ProviderUnavailable("No AI model is connected. Search, extraction and Excel export work without it.")

    def embed(self, texts):
        raise ProviderUnavailable("No embedding model is connected.")


class NoProvider(Provider):
    pass


class CallableProvider(Provider):
    """Wraps a Python function (a test double, or an in-process model). kind='local' means nothing leaves the computer."""
    def __init__(self, fn, name="callable", kind="local", embed_fn=None):
        self.fn, self.name, self.kind, self.embed_fn = fn, name, kind, embed_fn
        self.can_embed = embed_fn is not None

    def available(self):
        return True

    def complete(self, system, user, max_tokens=800):
        return self.fn(system, user)

    def embed(self, texts):
        if not self.embed_fn:
            raise ProviderUnavailable("This model cannot make embeddings.")
        return self.embed_fn(texts)


class OpenAICompatProvider(Provider):
    """Any server speaking /v1/chat/completions (+ /v1/models, /v1/embeddings). The API key (rarely needed for local servers) is read from an
    environment variable the user names; it is never stored by DocIntel."""
    def __init__(self, base_url, model, key_env="", embed_model="", timeout=180, name="", temperature=0.0):
        self.base_url, self.model, self.key_env = base_url.rstrip("/"), model, key_env
        self.embed_model, self.timeout, self.temperature = embed_model, timeout, temperature
        host = self.base_url.split("//", 1)[-1].split("/", 1)[0]
        host = host[1:host.index("]")] if host.startswith("[") else host.rsplit(":", 1)[0] if host.count(":") == 1 else host
        self.kind = "local" if host in ("localhost", "127.0.0.1", "::1") else "remote"
        self.name = name or f"{self.kind}:{host}/{model}"
        self.can_embed = bool(embed_model)

    def available(self):
        return bool(self.base_url and self.model)

    # ---- plumbing
    def _call(self, path, body=None, timeout=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.base_url + path, data=data, headers={"Content-Type": "application/json"}, method="POST" if body is not None else "GET")
        key = os.environ.get(self.key_env, "") if self.key_env else ""
        if key:
            req.add_header("Authorization", "Bearer " + key)
        try:
            with urllib.request.urlopen(req, timeout=timeout or self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
            except Exception:
                pass
            raise ProviderError(f"The model server answered with an error ({e.code}). {detail}".strip()) from e
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            raise ProviderError(f"Cannot reach the model server at {self.base_url}. Is it running (Ollama / LM Studio / llama.cpp server)? ({type(e).__name__})") from e

    # ---- chat
    def complete(self, system, user, max_tokens=800):
        out = self._call("/chat/completions", {"model": self.model, "max_tokens": max_tokens, "temperature": self.temperature, "stream": False,
                                               "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        try:
            return out["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as e:
            raise ProviderError("The model server answered in an unexpected format.") from e

    # ---- embeddings (for meaning-based search)
    def embed(self, texts):
        if not self.embed_model:
            raise ProviderUnavailable("No embedding model is set for this connection.")
        out = self._call("/embeddings", {"model": self.embed_model, "input": list(texts)})
        try:
            return [d["embedding"] for d in sorted(out["data"], key=lambda d: d.get("index", 0))]
        except (KeyError, TypeError) as e:
            raise ProviderError("The model server returned embeddings in an unexpected format.") from e

    # ---- helpers for the settings screen
    def list_models(self):
        """Names of the models the server offers (OpenAI-style /models, or Ollama's /api/tags)."""
        try:
            out = self._call("/models", timeout=15)
            return sorted(m["id"] for m in out.get("data", []))
        except ProviderError:
            root = self.base_url[:-3] if self.base_url.endswith("/v1") else self.base_url
            req = urllib.request.Request(root + "/api/tags")
            try:
                with urllib.request.urlopen(req, timeout=15) as r:
                    return sorted(m["name"] for m in json.loads(r.read().decode("utf-8")).get("models", []))
            except Exception as e:
                raise ProviderError(f"Cannot reach the model server at {self.base_url}. Is it running? ({type(e).__name__})") from e

    def test(self):
        """(ok, message, seconds): one tiny question to the model."""
        t = time.time()
        try:
            ans = self.complete("You are a connection test.", "Reply with the single word OK.", max_tokens=8)
        except ProviderError as e:
            return False, str(e), time.time() - t
        return True, f"The model answered: {ans.strip()[:40]!r}", time.time() - t


def provider_from_model(m):
    """m: a saved model description {name, type, base_url, model, key_env, embed_model, timeout}."""
    if not m:
        return NoProvider()
    return OpenAICompatProvider(m.get("base_url") or SERVER_TYPES.get(m.get("type", "other"), SERVER_TYPES["other"])["base_url"], m.get("model", ""),
                                m.get("key_env", ""), m.get("embed_model", ""), int(m.get("timeout", 180) or 180), m.get("name", ""))


def provider_from_config(cfg):
    """Older style settings (llm_provider / llm_base_url / llm_model) are still honoured when no model was chosen in the AI settings screen."""
    if (cfg.get("llm_provider") or "none") == "openai-compatible" and cfg.get("llm_base_url") and cfg.get("llm_model"):
        return OpenAICompatProvider(cfg["llm_base_url"], cfg["llm_model"], cfg.get("llm_key_env", ""))
    return NoProvider()
