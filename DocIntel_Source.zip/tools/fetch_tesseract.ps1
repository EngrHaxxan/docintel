# Gets the Windows Tesseract OCR program onto the build machine (no install needed: the official installer is unpacked with 7-Zip).
# The installer is pinned by SHA-256; a different file makes the build stop.
$ErrorActionPreference = "Stop"
$url  = "https://github.com/tesseract-ocr/tesseract/releases/download/5.5.3/tesseract-ocr-w64-setup-5.5.3.20260724.exe"
$sha  = "bee9e3434bd94fd65387d9be28cd467a41f61b1275383b55b0f59a1331270ae4"
$exe  = Join-Path $env:RUNNER_TEMP "tesseract-setup.exe"
$dest = Join-Path $env:RUNNER_TEMP "tesseract-unpacked"
Invoke-WebRequest $url -OutFile $exe
$got = (Get-FileHash $exe -Algorithm SHA256).Hash.ToLower()
if ($got -ne $sha) { throw "Tesseract installer checksum mismatch: $got" }
$7z = "C:\Program Files\7-Zip\7z.exe"
if (-not (Test-Path $7z)) { choco install 7zip -y --no-progress --limit-output }
& $7z x -y "-o$dest" $exe | Out-Null
if (-not (Test-Path "$dest\tesseract.exe")) { throw "tesseract.exe not found after unpacking" }
& "$dest\tesseract.exe" --version
"TESS_DIR=$dest" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
