"""Duplicate detection and cross-document comparison. Nothing here merges or resolves anything automatically."""
import json, re
from difflib import unified_diff


def exact_duplicate_files(db, root_ids=None):
    """Groups of files with identical content (SHA-256) - across all roots, shown with full paths."""
    q = ("SELECT f.sha256, GROUP_CONCAT(f.abspath, '\n') paths, COUNT(*) n, MAX(f.size) size FROM files f JOIN roots r ON r.id=f.root_id "
         "WHERE f.sha256 IS NOT NULL AND f.status!='missing' AND r.enabled=1 ")
    args = []
    if root_ids:
        q += f"AND f.root_id IN ({','.join('?' * len(root_ids))}) "; args = list(root_ids)
    q += "GROUP BY f.sha256 HAVING n>1 ORDER BY size DESC"
    return [{"sha256": r["sha256"], "count": r["n"], "size": r["size"], "paths": r["paths"].split("\n")} for r in db.q(q, args)]


def _shingles(text, k=5):
    t = re.sub(r"\W+", " ", text.lower()).split()
    return {" ".join(t[i:i + k]) for i in range(max(1, len(t) - k + 1))} if t else set()


def near_duplicate_files(db, threshold=0.85, root_ids=None, max_files=3000):
    """Near-duplicates by Jaccard similarity of word 5-gram shingles (MinHash-free; fine up to a few thousand files).
    Exact duplicates (same hash) are excluded - use exact_duplicate_files for those."""
    q = ("SELECT f.id, f.abspath, f.sha256, GROUP_CONCAT(s.text, ' ') txt FROM files f JOIN segments s ON s.file_id=f.id "
         "JOIN roots r ON r.id=f.root_id WHERE f.status='indexed' AND r.enabled=1 ")
    args = []
    if root_ids:
        q += f"AND f.root_id IN ({','.join('?' * len(root_ids))}) "; args = list(root_ids)
    q += "GROUP BY f.id LIMIT ?"
    rows = db.q(q, args + [max_files])
    sh = [(r["id"], r["abspath"], r["sha256"], _shingles(r["txt"] or "")) for r in rows]
    inv = {}
    for i, (_, _, _, s) in enumerate(sh):
        for g in s: inv.setdefault(g, []).append(i)
    out, seen = [], set()
    for i, (_, p, h, s) in enumerate(sh):
        if len(s) < 5: continue
        counts = {}
        for g in s:
            lst = inv[g]
            if len(lst) > 50: continue
            for j in lst:
                if j > i: counts[j] = counts.get(j, 0) + 1
        for j, c in counts.items():
            if sh[j][2] == h: continue
            u = len(s) + len(sh[j][3]) - c
            sim = c / u if u else 0
            if sim >= threshold and (i, j) not in seen:
                seen.add((i, j)); out.append({"a": p, "b": sh[j][1], "similarity": round(sim, 3)})
    return sorted(out, key=lambda d: -d["similarity"])


def conflicting_records(db, run_id, key_fields):
    """Records (possibly from different directories) sharing the same key but holding different values.
    Returns each conflict with the competing values and their sources - the user decides."""
    rows = db.q("SELECT * FROM vals WHERE run_id=? ORDER BY record_key, id", (run_id,))
    recs = {}
    for r in rows:
        d = recs.setdefault(r["record_key"], {"values": {}, "src": {}, "path": r["abspath"]})
        d["values"][r["field"]] = r["correction"] if r["correction"] not in (None, "") else r["normalized"]
        d["src"][r["field"]] = (r["abspath"], r["loc"], r["raw"])
    groups = {}
    for k, d in recs.items():
        key = tuple(d["values"].get(f) for f in key_fields)
        if all(v in (None, "") for v in key): continue
        groups.setdefault(key, []).append((k, d))
    out = []
    for key, items in groups.items():
        if len(items) < 2: continue
        fields = sorted({f for _, d in items for f in d["values"]} - set(key_fields))
        diffs = []
        for f in fields:
            vals = {str(d["values"].get(f)) for _, d in items}
            if len(vals) > 1:
                diffs.append({"field": f, "values": [{"record": k, "value": d["values"].get(f), "source": d["src"].get(f)} for k, d in items]})
        out.append({"key": dict(zip(key_fields, key)), "records": [k for k, _ in items],
                    "status": "CONFLICT" if diffs else "duplicate (identical values)", "differences": diffs})
    return out


def diff_files(db, file_a, file_b, context=2):
    """Line-level text diff between two indexed documents (for comparing revisions / reports)."""
    def text(fid):
        return "\n".join(r["text"] for r in db.q("SELECT text FROM segments WHERE file_id=? ORDER BY id", (fid,))).splitlines()
    return "\n".join(unified_diff(text(file_a), text(file_b), "A", "B", lineterm="", n=context))


def compare_tables(rows_a, rows_b, key_col=0):
    """Cell-level comparison of two tables keyed by a column; reports added/removed rows and changed cells."""
    ka = {r[key_col]: r for r in rows_a[1:] if len(r) > key_col}
    kb = {r[key_col]: r for r in rows_b[1:] if len(r) > key_col}
    hdr = rows_a[0] if rows_a else []
    res = {"added": [kb[k] for k in kb if k not in ka], "removed": [ka[k] for k in ka if k not in kb], "changed": []}
    for k in ka.keys() & kb.keys():
        for ci in range(max(len(ka[k]), len(kb[k]))):
            a = ka[k][ci] if ci < len(ka[k]) else ""; b = kb[k][ci] if ci < len(kb[k]) else ""
            if a != b:
                res["changed"].append({"key": k, "column": hdr[ci] if ci < len(hdr) else ci, "a": a, "b": b})
    return res
