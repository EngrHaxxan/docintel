"""Turn page grids into one Table: headers, records, merged-cell logic, cross-page stitching, quality."""
from __future__ import annotations
import difflib, re
from .model import Table, Row, Header
from .grid import PageGrid, detect_header


def _blocks_in_band(g, k):
    seen, out = set(), []
    for c in range(g.ncol):
        i = g.block_of[(k, c)]
        if i not in seen:
            seen.add(i); out.append(g.blocks[i])
    return out


def band_text(g, k):
    return " ".join(b.text for b in _blocks_in_band(g, k) if b.text)


def make_headers(g: PageGrid, k0: int, h: int, note: str = ""):
    nc = g.ncol
    if h == 0:
        return [Header(f"Column {c + 1}", flags=["review: no header row found - generic column names"]) for c in range(nc)]
    hb = {}
    for c in range(nc):
        seen, lst = set(), []
        for k in range(k0, k0 + h):
            i = g.block_of[(k, c)]
            if i not in seen:
                seen.add(i); lst.append(g.blocks[i])
        hb[c] = lst
    heads, used = [], {}
    for c in range(nc):
        pieces, flags = [], []
        for b in hb[c]:
            if b.text and b.text not in pieces:
                pieces.append(b.text)
        # span without own child: only this block covers the column group
        for b in hb[c]:
            if b.c1 > b.c0 and b.text and len(hb[c]) == 1 and c > b.c0:
                pieces = [f"{b.text} (column {c - b.c0 + 1} of {b.c1 - b.c0 + 1})"]
                flags.append(f"review: header '{b.text}' spans {b.c1 - b.c0 + 1} columns; this column has no header text of its own")
        if any(b.c1 > b.c0 and b.text and len(hb[c]) > 1 for b in hb[c]):
            flags.append("info: column sits under a header that spans several columns")
        if note and c == 0:
            flags.append("review: " + note)
        if not pieces:
            pieces = [f"Column {c + 1}"]; flags.append("review: empty header cell")
        name = " / ".join(pieces)
        if name in used:
            used[name] += 1; name = f"{name} ({used[name]})"; flags.append("review: duplicate header name")
        else:
            used[name] = 1
        heads.append(Header(name, parent=" / ".join(pieces[:-1]), leaf=pieces[-1], original=list(pieces), flags=flags))
    return heads


def _anchor_col(grids, starts, ncol):
    best = None
    for c in range(min(3, ncol)):
        vals, nonempty = [], 0
        for g, s in zip(grids, starts):
            for k in range(s, g.nb):
                if g.band_empty[k] or (g.band_label[k]):
                    continue
                nonempty += 1
                b = g.blocks[g.block_of[(k, c)]]
                if b.r0 == k and b.text and len(b.text) <= 8 and b.c0 == b.c1:
                    vals.append(b.text)
        if nonempty < 2 or not vals:
            continue
        shortid = sum(1 for v in vals if re.fullmatch(r"[A-Za-z]{0,2}\d{1,6}[A-Za-z]?\.?", v)) / len(vals)
        if len(vals) / nonempty >= 0.6 and shortid >= 0.8 and len(set(vals)) >= 0.9 * len(vals):
            return c
    return None


def _join(a, b):
    return (a + " " + b).strip() if a and b else (a or b)


def _same_header(g, k, h, headers):
    target = re.sub(r"\W+", "", " ".join(x.name for x in headers).lower())
    got = re.sub(r"\W+", "", " ".join(band_text(g, j) for j in range(k, min(g.nb, k + h))).lower())
    if not target or not got:
        return False
    # header pieces may be joined as 'Parent / Child'; compare token sets loosely
    r = difflib.SequenceMatcher(None, target, got).ratio()
    tw = set(re.findall(r"\w+", " ".join(x.name for x in headers).lower()))
    gw = set(re.findall(r"\w+", " ".join(band_text(g, j) for j in range(k, min(g.nb, k + h))).lower()))
    return r >= 0.8 or (tw and len(tw & gw) / len(tw | gw) >= 0.7)


def assemble(grids, first_header, source="", method="stroke-grid"):
    """grids: PageGrid list for consecutive pages of ONE table; first_header = detect_header(grids[0])."""
    g0 = grids[0]
    title, h, k0, note = first_header
    headers = make_headers(g0, k0, h, note)
    nc = g0.ncol
    starts = [k0 + h]
    for g in grids[1:]:
        s = 0
        while s < g.nb and g.band_empty[s]:
            s += 1
        if h and s < g.nb and _same_header(g, s, h, headers):
            s += h
        starts.append(s)
    anchor = _anchor_col(grids, starts, nc)
    # a column is a "group column" when most of its filled cells are vertically merged (e.g. Main Activity Name);
    # only such columns may continue over a page break. Ordinary columns (Remarks, Unit ...) are never filled down.
    tot, vmc = [0] * nc, [0] * nc
    for g, s in zip(grids, starts):
        for b in g.blocks:
            if b.r0 >= s and b.c0 == b.c1 and b.text:
                tot[b.c0] += 1
                vmc[b.c0] += 1 if b.r1 > b.r0 else 0
    col_vm = [vmc[c] >= 3 and vmc[c] / max(1, tot[c]) >= 0.5 for c in range(nc)]
    rows, prev, group, has_groups = [], None, "", False
    for g, s in zip(grids, starts):
        recs, cur, carry = [], None, []
        rec_of = {}
        for k in range(s, g.nb):
            if g.band_label[k] and g.blocks[g.block_of[(k, 0)]].c1 == nc - 1:
                group, has_groups, cur = g.band_label[k], True, None
                continue
            if g.band_empty[k]:
                if cur is not None:
                    cur["bands"].append(k); rec_of[k] = cur
                continue
            new = True
            if anchor is not None:
                b = g.blocks[g.block_of[(k, anchor)]]
                new = bool(b.text) and b.r0 == k
            if new:
                cur = {"bands": [k], "group": group, "row": None}; recs.append(cur); rec_of[k] = cur
            elif cur is not None:
                cur["bands"].append(k); rec_of[k] = cur
            else:
                carry.append(k)
        ex, top0 = g.edges, None
        for rec in recs:
            b0, b1 = rec["bands"][0], rec["bands"][-1]
            rec["row"] = Row(g.page, [""] * nc, [""] * nc, bbox=(ex[0], g.bands[b0][0], ex[-1], g.bands[b1][1]),
                             pages=[g.page], group=rec["group"])
            if anchor is not None:
                rec["row"].anchor = g.blocks[g.block_of[(b0, anchor)]].text
        carry_set = set(carry)
        for b in g.blocks:
            if b.r1 < s or (b.c0 == 0 and b.c1 == nc - 1 and g.band_label[b.r0]):
                continue
            if not b.text and not any(k in rec_of or k in carry_set for k in range(max(b.r0, s), b.r1 + 1)):
                continue
            c = b.c0
            covered, seen = [], set()
            for k in range(max(b.r0, s), b.r1 + 1):
                r = rec_of.get(k)
                if r is not None and id(r) not in seen:
                    seen.add(id(r)); covered.append(r)
            in_carry = any(k in carry_set for k in range(b.r0, b.r1 + 1))
            if in_carry and prev is not None:
                if b.text:
                    prev.orig[c] = _join(prev.orig[c], b.text); prev.norm[c] = _join(prev.norm[c], b.text)
                    if g.page not in prev.pages:
                        prev.pages.append(g.page)
                    prev.cell_flags.setdefault(c, []).append(f"info: text continues on page {g.page}")
                for r in covered:
                    r["row"].norm[c] = prev.norm[c]
                    r["row"].cell_flags.setdefault(c, []).append("info: merged cell continues from previous page")
                continue
            if b.c1 > b.c0 and covered and b.text:
                covered[0]["row"].cell_flags.setdefault(c, []).append(
                    f"info: text spans columns {headers[b.c0].name} .. {headers[b.c1].name} (merged across columns)")
            for r in covered:
                r["row"].norm[c] = _join(r["row"].norm[c], b.text)
            if covered:
                covered[0]["row"].orig[c] = _join(covered[0]["row"].orig[c], b.text)
            if b.low_conf and covered:
                covered[0]["row"].cell_flags.setdefault(c, []).append("review: text crosses the column boundary")
        # merged cell continuing over a page break with no text on this page
        if prev is not None and recs and not carry:
            first = recs[0]
            for c in range(nc):
                if not col_vm[c] or first["row"].norm[c] or not prev.norm[c]:
                    continue
                bl = g.blocks[g.block_of[(first["bands"][0], c)]]
                if bl.text or bl.r0 > s or bl.c0 != bl.c1:
                    continue
                sev = "info" if g.top_open[c] else "review"
                for r in recs:
                    if any(g.block_of[(k, c)] == g.block_of[(first["bands"][0], c)] for k in r["bands"]):
                        r["row"].norm[c] = prev.norm[c]
                        r["row"].cell_flags.setdefault(c, []).append(
                            f"{sev}: value repeated from the previous page (merged cell assumed to continue)")
        for rec in recs:
            rows.append(rec["row"])
        if recs:
            prev = recs[-1]["row"]
    t = Table(title=title, page_from=grids[0].page, page_to=grids[-1].page, headers=headers, rows=rows,
              method=method, col_edges=[round(e, 1) for e in g0.edges], has_groups=has_groups, anchor_col=anchor, source=source)
    t.page_bboxes = {g.page: tuple(round(v, 1) for v in g.bbox) for g in grids}
    _quality(t, grids, starts)
    return t


def _quality(t: Table, grids, starts):
    notes, score = [], 0.0
    h_ok = not any("no header row" in f for hd in t.headers for f in hd.flags)
    score += 0.2 if h_ok else 0.0
    if not h_ok:
        notes.append("no header row detected")
    tot = sum(g.n_words_total for g in grids); cap = sum(g.n_words_in for g in grids)
    cov = cap / tot if tot else 1.0
    score += 0.25 * cov
    if cov < 0.97:
        notes.append(f"{round((1 - cov) * 100)}% of words in the table area were not captured in a cell")
    if t.anchor_col is not None:
        nums = [int(r.anchor) for r in t.rows if r.anchor.isdigit()]
        if len(nums) >= 2:
            inc = sum(1 for a, b in zip(nums, nums[1:]) if b == a + 1) / (len(nums) - 1)
            score += 0.25 * inc
            if inc < 1.0:
                notes.append(f"row numbers are not strictly sequential ({round(inc * 100)}% of steps)")
        else:
            score += 0.15
    else:
        score += 0.12
        notes.append("no row-number column found; every non-empty band is treated as one row")
    cells = sum(len(r.norm) for r in t.rows) or 1
    empty = sum(1 for r in t.rows for v in r.norm if not v) / cells
    score += 0.1 * (1 - min(1.0, empty * 1.5))
    lc = sum(1 for r in t.rows for fl in r.cell_flags.values() for f in fl if f.startswith("review")) / cells
    score += 0.2 * (1 - min(1.0, lc * 20))
    if lc:
        notes.append("some cells are flagged for review")
    t.quality = max(0.0, min(1.0, score))
    t.quality_notes = notes
    t.stats = {"rows": len(t.rows), "columns": len(t.headers), "pages": t.page_to - t.page_from + 1,
               "word_coverage": round(cov, 4), "empty_cell_ratio": round(empty, 3)}
