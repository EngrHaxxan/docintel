"""Document-grounded questions: retrieve records -> build an evidence pack -> consent gate -> provider -> check citations.
The model only ever sees the selected records, numbered E1..En; an answer must cite them, and uncited answers are flagged."""
from __future__ import annotations
import hashlib, json, re, time
from dataclasses import dataclass, field
from ..retrieval import Retriever, build_pack
from .provider import ProviderError, ProviderUnavailable, NoProvider

SYSTEM = ("You answer questions about construction/engineering documents using ONLY the numbered evidence records provided. "
          "After every statement write the record numbers it comes from, like [E3]. If the evidence does not contain the answer, say "
          "'Not found in the selected records.' Never invent values, quantities, dates or names. Do not use outside knowledge.")


class ConsentRequired(ProviderError):
    def __init__(self, preview):
        super().__init__("Sending these records to an external AI service needs your confirmation.")
        self.preview = preview


class ProviderBlocked(ProviderError):
    pass


@dataclass
class Answer:
    text: str
    cited: list = field(default_factory=list)          # Evidence items that the answer refers to
    evidence: list = field(default_factory=list)       # everything that was sent
    warnings: list = field(default_factory=list)
    provider: str = ""


class Assistant:
    def __init__(self, lib, provider=None):
        self.lib, self.db = lib, lib.db
        self.provider = provider or lib.ai_models().provider()
        self.retriever = Retriever(lib)

    def available(self):
        return self.provider.available()

    def expand(self, question):
        """Search words and their translations (English <-> Arabic) from the model, to find evidence written differently from the question."""
        if not self.provider.available() or self.provider.kind != "local" or self.lib.cfg.get("ai_expand_queries", True) is False:      # never send a question outside before the user confirmed
            return []
        try:
            import json as _j
            from .extract import parse_json
            ans = parse_json(self.provider.complete("EXPAND KEYWORDS. Reply with ONLY JSON: {\"keywords\": [up to 8 short search words or phrases, including translations into Arabic or English and common synonyms]}.", question, max_tokens=120))
            return [str(k) for k in ans.get("keywords", [])][:8] if isinstance(ans.get("keywords"), list) else []
        except Exception:
            return []

    # ---- step 1: what would be sent (nothing is sent here)
    def prepare(self, question, query="", filters=(), **scope):
        if query or filters or scope:
            recs = self.retriever.find_records(query, filters, limit=60, **scope)
        else:
            recs = self.retriever.keyword_records(question + " " + " ".join(self.expand(question)), limit=40)
            seen = {(getattr(r, "table_id", 0), getattr(r, "row_no", 0)) for r in recs}
            try:                                              # meaning-based candidates (only when an embedding model is connected and the index is built)
                if self.provider.can_embed:
                    from .semantic import SemanticIndex
                    for sc, x in SemanticIndex(self.lib, self.provider).search(question, k=12):
                        key = (getattr(x, "table_id", 0), getattr(x, "row_no", 0))
                        if key == (0, 0) or key not in seen:
                            recs.append(x); seen.add(key)
            except ProviderError:
                pass
            recs += self.retriever.passages(question + " " + " ".join(self.expand(question)), limit=8)
        pack = build_pack(question, recs)
        preview = {"provider": self.provider.name, "leaves_computer": self.provider.kind == "remote", "records": len(pack.items),
                   "chars": pack.chars(), "files": sorted({i.record.file for i in pack.items}), "truncated": pack.truncated,
                   "token": hashlib.sha256((pack.fingerprint() + self.provider.name).encode()).hexdigest()[:16], "manifest": pack.manifest()}
        return pack, preview

    # ---- step 2: ask (remote providers need the token from the preview = the user confirmed THIS content)
    def ask(self, question, pack, preview, consent=None):
        if not self.provider.available():
            raise ProviderUnavailable("No AI assistant is connected. Search, extraction and Excel export work without it.")
        if not pack.items:
            return Answer("Not found in the selected records.", warnings=["No extracted records matched the question; nothing was sent."], provider=self.provider.name)
        if self.provider.kind == "remote":
            if not self.lib.cfg.get("allow_network", False) or self.lib.cfg.get("offline_mode", True):
                raise ProviderBlocked("External AI is switched off (offline mode). Turn off offline mode in Settings and allow external AI to use it.")
            if consent != preview["token"]:
                raise ConsentRequired(preview)
        self._audit(question, pack, consent)
        text = self.provider.complete(SYSTEM, pack.prompt())
        return self._check(text, pack)

    def _audit(self, question, pack, consent):
        self.db.x("INSERT INTO llm_audit(ts, provider, kind, records, chars, question_hash, consent) VALUES(?,?,?,?,?,?,?)",
                  (time.time(), self.provider.name, self.provider.kind, len(pack.items), pack.chars(),
                   hashlib.sha256(question.encode()).hexdigest()[:16], consent or ""))

    def _check(self, text, pack):
        ids = re.findall(r"\[(E\d+)\]", text)
        known = {i.id: i for i in pack.items}
        warn = []
        if not ids:
            warn.append("The answer does not refer to any source record: treat it as unverified.")
        bad = sorted({i for i in ids if i not in known})
        if bad:
            warn.append("The answer cites records that were not provided (" + ", ".join(bad) + "): ignore those statements.")
        cited = [known[i] for i in dict.fromkeys(ids) if i in known]
        return Answer(text, cited, list(pack.items), warn, self.provider.name)
