import json, os, shutil, socket, sys, threading, time, zipfile

import openpyxl
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from docintel.library import Library, JobControl
from docintel import search as S, extraction as E, excel_export as XL, compare as C, diagnostics as D, cleaning
import make_corpus


@pytest.fixture(scope="session")
def corpus(tmp_path_factory):
    root = str(tmp_path_factory.mktemp("corpus") / "c")
    gt = make_corpus.build(root)
    return root, gt


@pytest.fixture()
def lib(tmp_path):
    return Library(str(tmp_path / "home"))


@pytest.fixture()
def indexed(corpus, tmp_path):
    root, gt = corpus
    work = str(tmp_path / "w")
    shutil.copytree(root, work)           # tests may modify files
    l = Library(str(tmp_path / "home"))
    for d in ("driveA", "driveB", "driveC"):
        l.add_root(os.path.join(work, d))
    l.scan(); l.index()
    return l, work, gt


def status(l, name):
    return l.db.one("SELECT status,error FROM files WHERE name=?", (name,))


# ------------------------------------------------------------------ roots, scanning, duplicates names
def test_multiple_roots_and_duplicate_filenames(indexed):
    l, work, gt = indexed
    assert len(l.roots()) == 3
    hits = S.search(l.db, "Daily report", "text") or S.search(l.db, "DAILY REPORT", "text")
    paths = {h.path for h in hits if h.name == "Daily_Report.pdf"}
    assert len(paths) == 2                                    # same filename, two locations, both distinct
    assert any("Muna-1" in p for p in paths) and any("Muzdalifah" in p for p in paths)


def test_deep_nesting_indexed(indexed):
    l, work, gt = indexed
    r = l.db.one("SELECT abspath,status FROM files WHERE name='A-2045.dxf'")
    assert r["status"] == "indexed" and r["abspath"].count(os.sep) > 12


def test_root_removal_never_deletes_files(indexed):
    l, work, gt = indexed
    rid = l.roots()[0]["id"]; l.remove_root(rid)
    assert os.path.exists(os.path.join(work, "driveA/reports/minutes.docx"))
    assert l.db.one("SELECT COUNT(*) FROM files WHERE root_id=?", (rid,))[0] == 0


def test_unavailable_root_is_not_deletion(indexed):
    l, work, gt = indexed
    before = l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0]
    os.rename(os.path.join(work, "driveB"), os.path.join(work, "driveB_unplugged"))
    st = l.scan()
    assert st["driveB"]["unavailable"] is True
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0] == before      # nothing marked missing
    assert l.db.one("SELECT available FROM roots WHERE name='driveB'")[0] == 0
    assert S.search(l.db, "INV-00777")                                                     # still searchable
    os.rename(os.path.join(work, "driveB_unplugged"), os.path.join(work, "driveB"))
    l.scan()
    assert l.db.one("SELECT available FROM roots WHERE name='driveB'")[0] == 1
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='missing'")[0] == 0


def test_incremental_new_modified_deleted_renamed(indexed):
    l, work, gt = indexed
    a = os.path.join(work, "driveA")
    # unchanged rescan does no work
    st = l.scan()["driveA"]
    assert st["new"] == 0 and st["changed"] == 0 and st["unchanged"] > 0
    # new
    open(os.path.join(a, "new_note.txt"), "w").write("freshly added zebra-token-991")
    # modified
    p = os.path.join(a, "reports/minutes.docx")
    import docx
    d = docx.Document(p); d.add_paragraph("amended paragraph quokka-42"); d.save(p)
    # renamed (content identical)
    os.rename(os.path.join(a, "reports/progress.pptx"), os.path.join(a, "reports/progress_renamed.pptx"))
    # deleted
    os.remove(os.path.join(a, "reports/2026/Muzdalifah/daily/Daily_Report.pdf"))
    st = l.scan()["driveA"]
    assert st["new"] == 1 and st["changed"] == 1 and st["moved"] == 1 and st["missing"] == 1
    l.index()
    assert S.search(l.db, "zebra-token-991") and S.search(l.db, "quokka-42")
    r = l.db.one("SELECT status,indexed_at FROM files WHERE name='progress_renamed.pptx'")
    assert r["status"] == "indexed"                                   # renamed file kept its extracted data, not re-processed
    assert l.db.one("SELECT COUNT(*) FROM files WHERE name='progress.pptx'")[0] == 0
    assert S.search(l.db, "Foundations")                               # content still found under new name
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='missing'")[0] == 1
    assert not [h for h in S.search(l.db, "Muzdalifah") if h.name == "Daily_Report.pdf"]   # missing files hidden by default


def test_symlink_loop_safe(corpus, tmp_path):
    if os.name == "nt": pytest.skip("symlinks need privileges on Windows")
    d = tmp_path / "loop"; (d / "sub").mkdir(parents=True); (d / "a.txt").write_text("hello loop")
    os.symlink(str(d), str(d / "sub" / "back"))
    l = Library(str(tmp_path / "h")); l.add_root(str(d)); st = l.scan()["loop"]
    assert st["new"] == 1


def test_unreadable_directory_does_not_stop_batch(tmp_path):
    if os.name == "nt" or os.geteuid() == 0: pytest.skip("permission test needs non-root POSIX")
    d = tmp_path / "r"; (d / "locked").mkdir(parents=True); (d / "ok.txt").write_text("fine"); (d / "locked" / "x.txt").write_text("x")
    os.chmod(d / "locked", 0)
    try:
        l = Library(str(tmp_path / "h")); l.add_root(str(d)); st = l.scan()["r"]
        assert st["new"] == 1 and st["errors"] == 1
    finally:
        os.chmod(d / "locked", 0o755)


# ------------------------------------------------------------------ extraction per format
def test_native_pdf_text_and_positions(indexed):
    l, work, gt = indexed
    row = l.db.one("SELECT s.* FROM segments s JOIN files f ON f.id=s.file_id WHERE f.name='A-3001_rev2.pdf'")
    assert row["method"] == "native" and "Chilled Water Piping" in row["text"] and row["words_json"]


@pytest.mark.parametrize("name", ["scan_invoice.pdf", "screenshot_invoice.png", "rotated_invoice.png", "lowres_invoice.png"])
def test_ocr_identifier_exact(indexed, name):
    l, work, gt = indexed
    hits = [h for h in S.search(l.db, "INV-00777", "text") if h.name == name]
    assert hits, f"critical identifier not found by OCR in {name}"
    assert hits[0].method == "ocr"
    assert [h for h in S.search(l.db, "15,250.75", "text") if h.name == name]


def test_office_formats_and_tables(indexed):
    l, work, gt = indexed
    for needle, fname in [("Cement", "minutes.docx"), ("Foundations", "progress.pptx"), ("Al Rajhi Cement", "register.xlsx"), ("P-101A", "page.html"), ("Muna-1", "data.csv")]:
        assert [h for h in S.search(l.db, needle) if h.name == fname], (needle, fname)
    t = l.db.one("SELECT rows_json FROM tables_ t JOIN files f ON f.id=t.file_id WHERE f.name='minutes.docx'")
    assert json.loads(t[0])[1] == ["Cement", "50", "bag"]


def test_arabic_native_text(indexed):
    l, work, gt = indexed
    assert [h for h in S.search(l.db, "منى") if h.name in ("عربي_ملاحظات.txt", "minutes.docx")]
    assert cleaning.parse_number("١٢٠")[0] == 120


def test_corrupted_encrypted_unsupported_handled(indexed):
    l, work, gt = indexed
    assert status(l, "corrupted.pdf")["status"] == "error"
    assert "password" in status(l, "encrypted.pdf")["error"]
    assert status(l, "notes.xyz")["status"] == "unsupported"
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0] > 15          # the batch still completed


def test_dxf_drawing_title_block(indexed):
    l, work, gt = indexed
    prof = {"name": "tb", "fields": [{"name": "Drawing number", "type": "id", "labels": ["DWG_NO", "Drawing No"], "required": True},
                                      {"name": "Revision", "type": "id", "labels": ["REV", "Rev"], "always_review": True},
                                      {"name": "Drawing title", "labels": ["TITLE", "Title"]}], "min_fields_matched": 2}
    rid = E.run_profile(l, E.save_profile(l.db, prof))
    recs, held = E.records_for_export(l.db, rid, True)
    got = {r["values"]["Drawing number"]: r["values"]["Revision"] for r in recs}
    assert got == {"A-2045": "C", "A-3001": "2"}
    assert all(v["status"] == "review" for v in l.db.q("SELECT status FROM vals WHERE run_id=? AND field='Revision'", (rid,)))   # dimensions/revisions never auto-trusted


def test_vector_dimension_in_dxf(indexed):
    l, work, gt = indexed
    assert [h for h in S.search(l.db, "2500", kinds=["drawing"])]


# ------------------------------------------------------------------ table extraction accuracy
def test_invoice_table_spanning_pages_accuracy(indexed):
    l, work, gt = indexed
    inv = json.load(open(os.path.join(work, "ground_truth.json")))["invoices"][0]
    prof = json.load(open(os.path.join(os.path.dirname(__file__), "..", "samples/profiles/invoice_lines.json")))
    rid = E.run_profile(l, E.save_profile(l.db, prof))
    recs, held = E.records_for_export(l.db, rid, True)
    assert len(recs) == inv["rows"]                                   # no lost or duplicated rows across the page break / repeated header
    exp = {str(r[0]): r for r in inv["items"]}
    cells = ok = 0
    for r in recs:
        e = exp[r["values"]["Item"]]
        for f, i in (("Description", 1), ("Quantity", 2), ("Unit", 3), ("Unit rate", 4), ("Amount", 5)):
            cells += 1
            got = r["values"][f]
            ok += (float(got) == float(e[i])) if f in ("Quantity", "Unit rate", "Amount") else (got == e[i])
    assert ok / cells >= 0.99, f"table cell accuracy {ok}/{cells}"


# ------------------------------------------------------------------ structured extraction + review + duplicates
def test_daily_report_profile_and_review_flow(indexed):
    l, work, gt = indexed
    prof = json.load(open(os.path.join(os.path.dirname(__file__), "..", "samples/profiles/daily_report.json")))
    rid = E.run_profile(l, E.save_profile(l.db, prof))
    recs, held = E.records_for_export(l.db, rid, True)
    got = sorted((r["values"]["Date"], r["values"]["Project"], r["values"]["Manpower"]) for r in recs)
    assert got == [("2026-03-14", "Muna-1", "120"), ("2026-03-15", "Muzdalifah", "85")]
    # force a review item, correct it, approve
    vid = l.db.one("SELECT id FROM vals WHERE run_id=? AND field='Manpower' LIMIT 1", (rid,))[0]
    E.set_value(l.db, vid, status="review")
    ok, held = E.records_for_export(l.db, rid)
    assert len(held) == 1 and len(ok) == 1                           # unreviewed record held back
    E.set_value(l.db, vid, correction="121")
    ok, held = E.records_for_export(l.db, rid)
    assert not held
    v = l.db.one("SELECT raw,normalized,correction FROM vals WHERE id=?", (vid,))
    assert v["correction"] == "121" and v["raw"] in ("120", "85")     # original raw text preserved


def test_duplicate_and_conflict_detection(indexed):
    l, work, gt = indexed
    ex = C.exact_duplicate_files(l.db)
    assert any(len(g["paths"]) == 2 and g["paths"][0].endswith("xlsx") for g in ex)
    near = C.near_duplicate_files(l.db, 0.5)
    assert isinstance(near, list)
    prof = {"name": "dup", "fields": [{"name": "Date", "type": "date", "labels": ["Date"]}, {"name": "Manpower", "type": "integer", "labels": ["Manpower"]}], "min_fields_matched": 2, "key_fields": ["Date"]}
    open(os.path.join(work, "driveA", "daily_report_dup.txt"), "w").write("Date: 2026-03-14\nManpower: 999\n")
    l.scan(); l.index()
    rid = E.run_profile(l, E.save_profile(l.db, prof), None)
    conf = C.conflicting_records(l.db, rid, ["Date"])
    assert conf and conf[0]["status"] == "CONFLICT" and conf[0]["differences"][0]["field"] == "Manpower"
    assert l.db.one("SELECT COUNT(*) FROM vals WHERE run_id=? AND status='review'", (rid,))[0] > 0     # duplicates routed to review, never merged


def test_cleaning_rules():
    assert cleaning.parse_date("13/02/2026") == ("2026-02-13", [])
    assert cleaning.parse_date("05/04/2026")[1]                                    # ambiguous flagged
    assert cleaning.parse_date("5 Apr 2026")[0] == "2026-04-05"
    assert cleaning.parse_date("31/02/2026")[0] is None
    assert cleaning.parse_number("1.234,56")[0] == 1234.56 and cleaning.parse_number("(1,500)")[0] == -1500
    assert cleaning.parse_number("1O5", ocr_fix=True)[0] == 105
    assert cleaning.normalise("00123", "id")[0] == "00123"                         # leading zeros preserved


# ------------------------------------------------------------------ search modes
def test_search_modes_precision_recall(indexed):
    l, work, gt = indexed
    def names(q, m): return {h.name for h in S.search(l.db, q, m)}
    assert "INV-00123.pdf" in names("INV-00123", "text")
    assert "INV-001234" not in names("INV-00123", "word")
    assert names(r"INV-\d{5}", "regex") >= {"INV-00123.pdf", "screenshot_invoice.png"}
    assert "screenshot_invoice.png" in names("Gulf Stel Co", "fuzzy")              # OCR-typo tolerant
    assert not S.search(l.db, "Gulf Stel Co", "text")                              # exact mode stays exact
    assert S.search(l.db, "P-", "text")                                            # 2-char query uses the LIKE path
    assert {h.root for h in S.search(l.db, "Muna-1")} >= {"driveA", "driveB"}
    only_c = S.search(l.db, "Pump", root_ids=[l.roots()[2]["id"]])
    assert only_c and all("driveC" in h.path for h in only_c)
    assert all(h.name.endswith("pdf") for h in S.search(l.db, "Rev", exts=["pdf"]))
    t = [h for h in S.search(l.db, "Al Rajhi") if h.kind == "table"]
    assert t and "r3c2" in t[0].loc


# ------------------------------------------------------------------ Excel
def test_excel_template_preserves_formulas_and_formats_and_never_overwrites(indexed, tmp_path):
    l, work, gt = indexed
    tpl = os.path.join(work, "template.xlsx"); before = open(tpl, "rb").read()
    prof = json.load(open(os.path.join(os.path.dirname(__file__), "..", "samples/profiles/daily_report.json")))
    rid = E.run_profile(l, E.save_profile(l.db, prof)); recs, _ = E.records_for_export(l.db, rid, True)
    mapping = {"Date": "Date", "Project": "Project", "Manpower": "Manpower"}
    plan = XL.preview(tpl, recs, mapping)
    assert [o["row"] for o in plan["ops"]] == [3, 4] and not plan["conflicts"]
    assert open(tpl, "rb").read() == before                          # preview wrote nothing
    res = XL.apply(l.db, rid, tpl, recs, mapping)
    assert open(tpl, "rb").read() == before                          # default = new file, original untouched
    ws = openpyxl.load_workbook(res["output"]).active
    assert ws["D2"].value == "=C2*2" and ws["D3"].value == "=C3*2" and ws["C2"].number_format == "#,##0"
    assert ws["A1"].font.bold and ws["C3"].value == 120 and ws["B4"].value == "Muzdalifah"
    assert res["audit"]["verified"] and len(res["audit"]["inserted"]) == 2
    # in-place: backup created
    r2 = XL.apply(l.db, rid, tpl, recs[:1], mapping, in_place=True)
    assert r2["backup"] and open(r2["backup"], "rb").read() == before
    # update mode: conflicting existing value is NOT silently overwritten
    recs[0]["values"]["Manpower"] = "777"
    r3 = XL.apply(l.db, rid, tpl, recs[:1], mapping, mode="update", key_columns=["Date", "Project"], in_place=True)
    assert r3["audit"]["rejected_conflicts"] and openpyxl.load_workbook(tpl).active["C3"].value == 120
    assert l.db.one("SELECT COUNT(*) FROM exports")[0] == 3


def test_excel_formula_injection_and_leading_zeros(tmp_path, lib):
    rec = {"key": "1:0", "values": {"Code": "00789", "Note": "=HYPERLINK(\"http://x\")"}, "src": {}, "types": {"Code": "id"}}
    out = str(tmp_path / "o.xlsx")
    XL.export_new(lib.db, 0 if False else None, [rec], ["Code", "Note"], out, include_provenance=False)
    ws = openpyxl.load_workbook(out).active
    assert ws["A2"].value == "00789" and ws["B2"].data_type != "f"


def test_xlsx_risk_detection(tmp_path):
    p = str(tmp_path / "c.xlsx")
    wb = openpyxl.Workbook(); ws = wb.active
    from openpyxl.chart import BarChart, Reference
    ws.append(["a", "b"]); ws.append([1, 2]); ch = BarChart(); ch.add_data(Reference(ws, min_col=2, min_row=1, max_row=2)); ws.add_chart(ch, "D2"); wb.save(p)
    assert "charts" in XL.workbook_risks(p)


# ------------------------------------------------------------------ jobs, recovery, offline, safety
def test_cancel_resume_and_crash_recovery(corpus, tmp_path):
    root, gt = corpus
    work = str(tmp_path / "w"); shutil.copytree(root, work)
    l = Library(str(tmp_path / "h")); l.add_root(work); l.scan()
    total = l.db.one("SELECT COUNT(*) FROM files WHERE status='pending'")[0]
    ctl = JobControl(); count = {"n": 0}
    def prog(kind, fid, st):
        count["n"] += 1
        if count["n"] == 4: ctl.cancel()
    l.index(control=ctl, progress=prog)
    done = l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0]
    assert 0 < done < total
    # simulate a hard crash: a file stuck in 'processing' and a 'running' job
    l.db.x("UPDATE files SET status='processing' WHERE id=(SELECT id FROM files WHERE status='pending' LIMIT 1)")
    l.db.x("INSERT INTO jobs(kind,status,started) VALUES('index','running',?)", (time.time(),))
    l2 = Library(str(tmp_path / "h"))                                     # restart
    assert l2.db.one("SELECT COUNT(*) FROM files WHERE status='processing'")[0] == 0
    assert l2.db.one("SELECT COUNT(*) FROM jobs WHERE status='running'")[0] == 0
    l2.index()
    assert l2.db.one("SELECT COUNT(*) FROM files WHERE status='pending'")[0] == 0
    assert l2.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0] >= done          # resumed, nothing lost


def test_pause_resume(corpus, tmp_path):
    root, gt = corpus
    l = Library(str(tmp_path / "h")); l.add_root(os.path.join(root, "driveA")); l.scan()
    ctl = JobControl(); ctl.pause()
    t = threading.Thread(target=lambda: l.index(control=ctl)); t.start(); time.sleep(1.0)
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0] == 0
    ctl.resume(); t.join(60)
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='indexed'")[0] == 4


def test_offline_enforcement():
    D.enforce_offline()
    try:
        s = socket.socket()
        with pytest.raises(D.OfflineViolation):
            s.connect(("93.184.216.34", 80))
        s.close()
    finally:
        socket.socket.connect = D._orig_connect


def test_backup_restore_and_rebuild(indexed, tmp_path):
    l, work, gt = indexed
    z = D.backup(l, str(tmp_path / "b.zip")); assert zipfile.is_zipfile(z)
    home2 = str(tmp_path / "home2"); D.restore(home2, z)
    l2 = Library(home2); assert S.search(l2.db, "INV-00777")
    assert l2.db.integrity_check() == {"sqlite": "ok", "fts": "ok"}
    l.db.rebuild_fts(); assert S.search(l.db, "INV-00777")
    l.reindex_all(); l.index(); assert S.search(l.db, "INV-00777")          # index fully rebuildable from sources


def test_oversized_file_skipped_and_reported(tmp_path):
    d = tmp_path / "r"; d.mkdir(); (d / "big.txt").write_bytes(b"x" * 2_000_000)
    l = Library(str(tmp_path / "h")); l.cfg.set("max_file_mb", 1); l.add_root(str(d)); l.scan()
    r = l.db.one("SELECT status,error FROM files"); assert r["status"] == "skipped" and "limit" in r["error"]


def test_zip_bomb_rejected(tmp_path):
    p = str(tmp_path / "bomb.docx")
    with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("word/document.xml", b"0" * 400_000_000)      # ~400 MB of zeros compresses ~1000:1
    from docintel import extractors as X
    with pytest.raises(X.Unsupported):
        X.check_zip_safe(p)


def test_xml_entity_rejected(tmp_path):
    from docintel import extractors as X
    p = tmp_path / "e.xml"; p.write_text('<!DOCTYPE a [<!ENTITY x "boom">]><a>&x;</a>')
    with pytest.raises(X.Unsupported):
        X.extract_xml(str(p), {}, None)


def test_macro_workbook_is_read_without_executing(tmp_path):
    from docintel import extractors as X
    p = str(tmp_path / "m.xlsm")
    wb = openpyxl.Workbook(); wb.active.append(["a", "b"]); wb.save(p)
    assert X.extract_xlsx(p, {}, None).tables


def test_large_batch_throughput(tmp_path):
    d = tmp_path / "big"
    for i in range(30):
        sub = d / f"f{i}" / "x" / "y"; sub.mkdir(parents=True)
        for j in range(40):
            (sub / f"r{j}.txt").write_text(f"report {i}-{j}\nProject: P{i}\nvalue: {i * j}\n")
    l = Library(str(tmp_path / "h")); l.cfg.set("workers", 2); l.add_root(str(d))
    t0 = time.time(); l.scan(); t1 = time.time(); st = l.index(); t2 = time.time()
    assert st["indexed"] == 1200 and st["errors"] == 0
    assert len(S.search(l.db, "Project: P7", "text", limit=2000)) == 40
    assert t1 - t0 < 30 and t2 - t1 < 120
    t3 = time.time(); l.scan(); assert time.time() - t3 < 10                # unchanged rescan is cheap (metadata only)
    assert l.db.one("SELECT COUNT(*) FROM files WHERE status='pending'")[0] == 0


def test_gui_smoke():
    if not os.environ.get("DISPLAY"): pytest.skip("no display (run under xvfb-run)")
    import tempfile
    from docintel.gui import App
    app = App(tempfile.mkdtemp()); app.update()
    assert len(app.nb.tabs()) == 11      # Home + the 10 classic tabs
    app.destroy()
