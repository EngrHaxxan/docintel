"""DocIntel table & section engine (Milestone 1)."""
from .engine import analyze_pdf, Analysis
from .model import Table, Row, Header, ENGINE_VERSION
from .sections import match_sections, heading_similarity
