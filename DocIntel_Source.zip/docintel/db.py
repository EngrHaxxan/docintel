"""SQLite persistence layer (WAL, FTS5 trigram index). Everything is rebuildable from the source files."""
import json, os, re, sqlite3, threading, time

SCHEMA_VERSION = 6
SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS roots(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 1, include_ext TEXT DEFAULT '', exclude_globs TEXT DEFAULT '',
  min_mtime REAL, max_mtime REAL, available INTEGER DEFAULT 1, last_scan REAL, last_scan_stats TEXT);
CREATE TABLE IF NOT EXISTS files(
  id INTEGER PRIMARY KEY, root_id INTEGER NOT NULL REFERENCES roots(id) ON DELETE CASCADE,
  relpath TEXT NOT NULL, abspath TEXT NOT NULL, name TEXT NOT NULL, ext TEXT, size INTEGER, mtime REAL,
  sha256 TEXT, status TEXT NOT NULL DEFAULT 'pending',
  error TEXT, warnings TEXT, indexed_at REAL, missing_since REAL, extractor_version INTEGER DEFAULT 0,
  UNIQUE(root_id, relpath));
CREATE INDEX IF NOT EXISTS ix_files_status ON files(status);
CREATE INDEX IF NOT EXISTS ix_files_hash ON files(sha256);
CREATE INDEX IF NOT EXISTS ix_files_name ON files(name);
CREATE TABLE IF NOT EXISTS segments(
  id INTEGER PRIMARY KEY, file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  kind TEXT, loc TEXT, text TEXT, method TEXT, confidence REAL, words_json TEXT, page_w REAL, page_h REAL);
CREATE INDEX IF NOT EXISTS ix_seg_file ON segments(file_id);
CREATE VIRTUAL TABLE IF NOT EXISTS seg_fts USING fts5(text, content='segments', content_rowid='id', tokenize='trigram');
CREATE TRIGGER IF NOT EXISTS seg_ai AFTER INSERT ON segments BEGIN INSERT INTO seg_fts(rowid,text) VALUES(new.id,new.text); END;
CREATE TRIGGER IF NOT EXISTS seg_ad AFTER DELETE ON segments BEGIN INSERT INTO seg_fts(seg_fts,rowid,text) VALUES('delete',old.id,old.text); END;
CREATE TABLE IF NOT EXISTS tables_(
  id INTEGER PRIMARY KEY, file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  loc TEXT, idx INTEGER, rows_json TEXT, method TEXT, confidence REAL, corrected_json TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_tab_file ON tables_(file_id);
CREATE TABLE IF NOT EXISTS jobs(
  id INTEGER PRIMARY KEY, kind TEXT, status TEXT, started REAL, finished REAL, stats TEXT, scope TEXT);
CREATE TABLE IF NOT EXISTS profiles(name TEXT PRIMARY KEY, json TEXT NOT NULL, updated REAL);
CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY, profile TEXT, started REAL, params TEXT);
CREATE TABLE IF NOT EXISTS vals(
  id INTEGER PRIMARY KEY, run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  record_key TEXT, file_id INTEGER, abspath TEXT, sha256 TEXT, field TEXT,
  raw TEXT, normalized TEXT, loc TEXT, bbox TEXT, method TEXT, confidence REAL,
  issues TEXT, status TEXT DEFAULT 'ok',
  correction TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_vals_run ON vals(run_id);
CREATE TABLE IF NOT EXISTS doc_sections(
  id INTEGER PRIMARY KEY, file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  page_from INTEGER, page_to INTEGER, title TEXT, level INTEGER, bbox TEXT, detected_by TEXT, confidence REAL);
CREATE INDEX IF NOT EXISTS ix_dsec_file ON doc_sections(file_id);
CREATE TABLE IF NOT EXISTS doc_tables(
  id INTEGER PRIMARY KEY, file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  section TEXT, section_level INTEGER, title TEXT, page_from INTEGER, page_to INTEGER, method TEXT, quality REAL,
  notes_json TEXT, headers_json TEXT, col_edges_json TEXT, bbox_json TEXT, anchor_col INTEGER, has_groups INTEGER,
  stats_json TEXT, hidden_cols TEXT DEFAULT '[]', extractor_version TEXT, file_sha256 TEXT, extracted_at REAL);
CREATE INDEX IF NOT EXISTS ix_dtab_file ON doc_tables(file_id);
CREATE TABLE IF NOT EXISTS table_rows(
  id INTEGER PRIMARY KEY, table_id INTEGER NOT NULL REFERENCES doc_tables(id) ON DELETE CASCADE,
  row_no INTEGER, page INTEGER, pages_json TEXT, bbox TEXT, group_label TEXT, anchor TEXT, flags_json TEXT);
CREATE INDEX IF NOT EXISTS ix_trow_table ON table_rows(table_id, row_no);
CREATE TABLE IF NOT EXISTS table_cells(
  id INTEGER PRIMARY KEY, row_id INTEGER NOT NULL REFERENCES table_rows(id) ON DELETE CASCADE,
  col_no INTEGER, raw_orig TEXT, raw_norm TEXT, kind TEXT, flags_json TEXT,
  corrected_orig TEXT, corrected_norm TEXT, corrected_at REAL, reviewed INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_tcell_row ON table_cells(row_id);
CREATE TABLE IF NOT EXISTS table_profiles(name TEXT PRIMARY KEY, json TEXT NOT NULL, created REAL, updated REAL);
CREATE TABLE IF NOT EXISTS extraction_jobs(
  id INTEGER PRIMARY KEY, profile_name TEXT, profile_json TEXT, title TEXT, scope_json TEXT, started REAL, finished REAL,
  status TEXT, stats_json TEXT, parent_id INTEGER);
CREATE TABLE IF NOT EXISTS job_items(
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES extraction_jobs(id) ON DELETE CASCADE,
  file_id INTEGER, name TEXT, path TEXT, sha256 TEXT, status TEXT DEFAULT 'pending', message TEXT, detail TEXT,
  tables INTEGER DEFAULT 0, records INTEGER DEFAULT 0, review_rows INTEGER DEFAULT 0, table_ids_json TEXT, candidates_json TEXT,
  heading TEXT, updated REAL, UNIQUE(job_id, file_id));
CREATE INDEX IF NOT EXISTS ix_item_job ON job_items(job_id, status);
CREATE TABLE IF NOT EXISTS llm_audit(id INTEGER PRIMARY KEY, ts REAL, provider TEXT, kind TEXT, records INTEGER, chars INTEGER, question_hash TEXT, consent TEXT);
CREATE TABLE IF NOT EXISTS manual_templates(name TEXT PRIMARY KEY, json TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS ai_models(name TEXT PRIMARY KEY, json TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS embeddings(id INTEGER PRIMARY KEY, kind TEXT, ref_id INTEGER, model TEXT, dim INTEGER, vec BLOB, text_hash TEXT, UNIQUE(kind, ref_id, model));
CREATE TABLE IF NOT EXISTS exports(
  id INTEGER PRIMARY KEY, ts REAL, run_id INTEGER, target TEXT, sheet TEXT, backup TEXT, audit_json TEXT);
"""

_rx_cache = {}
def _regexp(pat, s):
    if s is None:
        return 0
    r = _rx_cache.get(pat)
    if r is None:
        r = _rx_cache[pat] = re.compile(pat, re.I | re.M)
    return 1 if r.search(s) else 0


class DB:
    def __init__(self, path):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._local = threading.local()
        c = self.conn
        c.executescript(SCHEMA)
        c.execute("INSERT OR REPLACE INTO meta VALUES('schema_version',?)", (str(SCHEMA_VERSION),))   # v2 adds the doc_* / table_* tables (additive)
        c.commit()

    @property
    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=60)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA foreign_keys=ON")
            if self.path != ":memory:":
                c.execute("PRAGMA journal_mode=WAL")
                c.execute("PRAGMA synchronous=NORMAL")
            c.create_function("REGEXP", 2, _regexp, deterministic=True)
            self._local.c = c
        return c

    def q(self, sql, args=()):
        return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.conn.execute(sql, args).fetchone()

    def x(self, sql, args=()):
        cur = self.conn.execute(sql, args)
        self.conn.commit()
        return cur

    def integrity_check(self):
        ok = self.one("PRAGMA integrity_check")[0]
        try:
            self.conn.execute("INSERT INTO seg_fts(seg_fts) VALUES('integrity-check')")
            fts = "ok"
        except sqlite3.DatabaseError as e:
            fts = f"FTS problem: {e}"
        return {"sqlite": ok, "fts": fts}

    def rebuild_fts(self):
        self.conn.execute("INSERT INTO seg_fts(seg_fts) VALUES('rebuild')")
        self.conn.commit()

    def recover_interrupted(self):
        """Files left 'processing' by a crash go back to the queue; running jobs are marked interrupted."""
        n = self.x("UPDATE files SET status='pending' WHERE status='processing'").rowcount
        self.x("UPDATE jobs SET status='interrupted', finished=? WHERE status IN ('running','paused')", (time.time(),))
        return n

    def backup_to(self, dest):
        dst = sqlite3.connect(dest)
        with dst:
            self.conn.backup(dst)
        dst.close()


def jdump(o):
    return json.dumps(o, ensure_ascii=False)
