# Extract tables to Excel - the simple way (DocIntel 1.3)

Open DocIntel. The **Home** screen shows six big buttons. The older tabs (Settings, Compare, Field extraction ...) are still there:
click **Show advanced tools** at the bottom of Home.

1. **Add Documents** - add one or several folders. (Individual PDF files can be added inside the wizard.)
2. **Search Documents** - opens the search page.
3. **Extract to Excel** - the 5 guided steps:
   1. *Select documents* - all, only some folders, or individual PDFs; select rows and click **Exclude** to leave documents out. The number selected is shown.
   2. *What do you want?* - all tables, one table, one section, rows containing a word, chosen columns, all text, or a sentence describing what you want.
   3. *Identify the target* - DocIntel reads the documents (a progress message is shown; **Cancel work** stops it) and lists the section headings it found and in how many documents. Type a name and click **Find** to select similar headings - always check them, similar is not the same. Documents with a problem are listed with a plain explanation.
   4. *Preview and correct* - a spreadsheet-like preview. Orange rows need review, blue cells were corrected. Click a cell to see its full value, double-click to correct it (the original text stays stored), mark it uncertain, rename or hide a column, or open the source PDF. Switch between *Normalized* and *Original layout*.
   5. *Export* - one big **Export to Excel** button. Sensible choices are pre-selected: reports with the same columns are stacked into one sheet with source file and page on every row.
4. **Review Results** - open tables that were extracted earlier and correct them.
5. **Export to Excel** - export the last extraction again.
6. **Extraction History** - your previous exports; open the file or folder.

## Bulk example: Construction Activities from many daily reports
Add the folder -> Extract to Excel -> select all documents -> *Extract a specific section* -> Next -> select the heading
**CONSTRUCTION ACTIVITIES** (or type "Construction Activity" and click Find, then check) -> Next -> check the preview -> Next ->
keep "Stack tables with the same columns" -> Export to Excel. Documents where the section is missing are listed in the notes.

## If something is wrong
- "No table was found" - the document may be scanned (not supported in this version) or the table has no recognisable structure.
- Orange rows - a merged cell or a split row was assumed; check against the PDF (use *Open source PDF*).
- Technical details are never shown on screen; they are saved in the diagnostic log (Settings & Diagnostics).
