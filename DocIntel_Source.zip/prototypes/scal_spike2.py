"""SPIKE v2 (proof of method): complete SCAL main-table extraction with merged-cell detection.
Method: row bands from thin horizontal border strokes; merged cells = column spans where the border stroke is ABSENT between bands;
bands without a row number = continuation of the previous row (page break); both 'original layout' and 'normalised' output.
Validation invariant: Sr numbers must be exactly 1..1000, strictly sequential.
Status: proves the approach on one real document. Known gaps: horizontally merged cells (row 1000); header text assembly; sub-table detection."""
import sys, re, collections
import pdfplumber

COL_EDGES = [62.0, 78.5, 126.5, 171.5, 184.5, 198.5, 265.5, 337.5, 369.5, 401.5, 446.5, 473.5, 499.5, 558.5]
NCOL = 13


def thin_rects(page):
    return [r for r in page.rects if (r["bottom"] - r["top"]) < 1.5 and (r["x1"] - r["x0"]) > 10]


def bands_for(page, anchors, min_segments=4):
    thin = thin_rects(page)
    cnt = collections.Counter(round(r["top"], 1) for r in thin)
    ys = []
    for y in sorted(y for y, n in cnt.items() if n >= min_segments):
        if not ys or y - ys[-1] >= 1.5: ys.append(y)
    bands = list(zip(ys, ys[1:]))
    if anchors and (not bands or min(anchors) < bands[0][0]):          # first row on the page lies above the first strong border
        first = bands[0][0] if bands else max(anchors) + 10
        cand = [r["top"] for r in thin if r["top"] < min(anchors) and r["top"] > 60]
        top = max(cand) if cand else min(anchors) - 10
        bands.insert(0, (top, first))
    return bands, thin


def covered(thin, y, cx):
    return any(abs(r["top"] - y) < 1.8 and r["x0"] - 1 <= cx <= r["x1"] + 1 for r in thin)


def extract(pdf_path, first_page=5, last_page=40):
    rows = []                      # dict(page, orig[13], norm[13], flags[list])
    prev_open, prev_last = [False] * NCOL, None      # which columns' merged cells are still open at the bottom of the previous page
    with pdfplumber.open(pdf_path) as pdf:
        for pn in range(first_page, last_page + 1):
            page = pdf.pages[pn - 1]
            words = page.extract_words(x_tolerance=1.5, y_tolerance=1.5)
            ttop = 0
            if pn == first_page:
                ttop = max((w["top"] for w in words if w["text"] == "Sr." and w["x0"] < 80), default=0)
            anchors_w = [w for w in words if w["x0"] < 78 and 60 < w["x0"] and re.fullmatch(r"\d{1,4}", w["text"]) and w["top"] > ttop and w["top"] < 800]
            anchors = [(w["top"] + w["bottom"]) / 2 for w in anchors_w]
            bands, thin = bands_for(page, anchors)
            bands = [b for b in bands if b[0] >= ttop]
            if not bands: continue
            centers = [(COL_EDGES[c] + COL_EDGES[c + 1]) / 2 for c in range(NCOL)]
            # merge groups per column: consecutive bands joined when no border stroke separates them in that column
            group_of = [[0] * len(bands) for _ in range(NCOL)]
            for c in range(NCOL):
                g = 0
                for k in range(len(bands)):
                    if k > 0 and covered(thin, bands[k][0], centers[c]): g += 1
                    group_of[c][k] = g
            # text per (column, group)
            gtext = {}
            for c in range(NCOL):
                for g in set(group_of[c]):
                    ks = [k for k in range(len(bands)) if group_of[c][k] == g]
                    t, b = bands[ks[0]][0], bands[ks[-1]][1]
                    sel = [w for w in words if t <= (w["top"] + w["bottom"]) / 2 <= b and COL_EDGES[c] < (w["x0"] + w["x1"]) / 2 <= COL_EDGES[c + 1]
                           and not (c == 0 and False)]
                    lines = collections.defaultdict(list)
                    for w in sel: lines[round(w["top"])].append(w)
                    gtext[(c, g)] = " ".join(" ".join(x["text"] for x in sorted(l, key=lambda z: z["x0"])) for _, l in sorted(lines.items()))
            cont_map = {}
            col_merged = [len(set(group_of[c])) < len(bands) for c in range(NCOL)]      # column has multi-row merged cells on this page
            first_top_k = next((k for k, (t, b) in enumerate(bands) if any(t <= y <= b for y in anchors)), 0)
            # build rows
            for k, (t, b) in enumerate(bands):
                sr = gtext[(0, group_of[0][k])] if group_of[0][k] == group_of[0][k] else ""
                a_in = [y for y in anchors if t <= y <= b]
                first_of = [k == min(j for j in range(len(bands)) if group_of[c][j] == group_of[c][k]) for c in range(NCOL)]
                if a_in:
                    orig, norm, flags = [], [], []
                    for c in range(NCOL):
                        txt = gtext[(c, group_of[c][k])]
                        orig.append(txt if first_of[c] else "")
                        if c in cont_map and group_of[c][k] == cont_map[c][0]:      # merged cell that started on the previous page
                            txt = cont_map[c][1]["norm"][c]
                        elif (not txt) and col_merged[c] and prev_last is not None and prev_last["norm"][c] and group_of[c][k] == group_of[c][first_top_k]:
                            txt = prev_last["norm"][c]                               # border absent at the page bottom + no text here => same merged cell
                            flags.append(f"col {c}: value inherited from previous page (merged cell assumed to continue) - REVIEW")
                        norm.append(txt)
                    rows.append({"page": pn, "orig": orig, "norm": norm, "flags": flags, "inherit": [c for c in range(NCOL) if not first_of[c] and not txt]})
                elif rows:                                   # continuation band (row split by a page break)
                    prev = rows[-1]
                    for c in range(NCOL):
                        txt = gtext[(c, group_of[c][k])]
                        cont_map[c] = (group_of[c][k], prev)
                        if first_of[c] and txt:
                            prev["orig"][c] = (prev["orig"][c] + " " + txt).strip()
                            prev["norm"][c] = (prev["norm"][c] + " " + txt).strip()
                    prev["flags"].append(f"row continues from page {pn}")
            prev_last = rows[-1] if rows else prev_last          # remembered for merged cells that continue on the next page

    return rows


def finalize(pdf_path):
    rows = extract(pdf_path)
    return rows


if __name__ == "__main__":
    rows = finalize(sys.argv[1])
    nums = [int(r["orig"][0]) for r in rows]
    print("rows", len(rows), "unique", len(set(nums)), "range", min(nums), max(nums))
    print("missing", sorted(set(range(1, 1001)) - set(nums))[:20], "sequential", all(b == a + 1 for a, b in zip(nums, nums[1:])))
    by = {int(r["orig"][0]): r for r in rows}
    for k in (7, 8, 9, 10, 29, 31, 44, 180, 202):
        r = by.get(k)
        if r: print(k, "ORIG", [x[:14] for x in r["orig"][1:5]], "| NORM", [x[:22] for x in r["norm"][1:3]], r["flags"])
