# DocIntel final acceptance report

Run on: linux, Python 3.12.3. Measured on this machine only (not on a Windows PC with many cores).

## Scenario 1 - Daily construction reports -> one consolidated Excel table
- [PASS] every report processed, none failed - 30/30 in 14.7 s
- [PASS] 4 activity records per report (no unrelated sections) - 120 records
- [PASS] one worksheet holds all records (filterable) - 120 data rows
- [PASS] both progress dates are kept as separate columns (dates in column titles are masked so all days stack; the real dates are in their own columns) - ['Progress % / (date 1)', 'Progress % / (date 2)', 'Progress % / (date 1) - date', 'Progress % / (date 2) - date']
- [PASS] source document and page columns present - Extraction method, Needs review, Review notes, Corrected cells, Extracted on
- [PASS] values exact (70% / 100% / Completed / description kept) - 1 | MUNA-1 Substation  | Substation Area | CIVIL | Backfilling | Backfilling of the | 70% | 100% | Completed
- [PASS] Job report sheet lists every document

## Scenario 2 - Issues & Concerns
- [PASS] 3 issue records per report - 90 records
- [PASS] issue headers kept (Issue Type, Urgency, Owner, Status...) - S.No, Issue Type, Description, Urgency, Imapct, Start Date, Total Duration, Owner, Status, Remarks
- [PASS] values exact (High / Open / 05-May-26 / 156) - 1 | UGC Design input | Expedite SE response | High | Time Delay | 05-May-26 | 156 | SE | Open

## Scenario 3 - SCAL complete table (41 pages)
- [PASS] 1,000 of 1,000 rows extracted across all pages - 1000 rows, 22.5 s
- [PASS] Sr. runs 1..1000 in order (no missing, no duplicates)
- [PASS] row 1 spot check (Substation Battery Bank / SBB / SBBXX.TEST / 12.00 / 125 V) - 1 | Substation Bat | SBB | X | X | Substation Bat | SBBXX.TEST | 12.00 | Battery | 125 V | 0% | 100%
- [PASS] row 202 spot check (LCC Scheme Check, 20% Including All Typicals kept as text)
- [PASS] normalized layout: no blank Main Activity Name
- [PASS] original layout keeps blanks where cells are merged - 885 blank cells in the original-layout sheet

## Scenario 4 - Different table structures
- [PASS] RACI PDF (coloured cells, merged category bands, 5 pages): 134 of 134 rows - 134
- [PASS] Word, Excel, CSV, HTML, PowerPoint tables extracted
- [PASS] borderless table selected by hand: 4 columns, header, continuation line joined
- [PASS] scanned English BoQ (2 pages): one table, one record per item, header found - 10/10 items, 13 s, marked as OCR (quality 0.70)
- [PASS] scanned pricing schedule (3 pages): one table over all pages - 131 rows
- [NOT TESTED] scanned ARABIC tables: no Arabic OCR data here; see test report (known limitation).

## Scenario 5 - Unusual values are preserved
- [PASS] all 15 unusual values extracted exactly as written
- [PASS] Excel keeps them as text (65% stays 65%, 001 stays 001)

## Scenario 6 - Large folder, incremental indexing, responsiveness
- [PASS] initial index of 642 files, no errors - 3.4 s, peak memory 252 MB
- [PASS] re-index of unchanged files does (almost) nothing - 0.01 s
- [PASS] incremental: only the 25 new files are processed - 0.98 s
- [PASS] search finds a new file immediately - 1 ms
  (Baseline reported by the user: about 15 minutes for 1,500 documents. This run: 642 documents in 3.4 s on one core; a 1,500-document library on the user's own PC has not been measured.)

## Scenario 7 - Nontechnical operation
- [BY DESIGN, CHECKED ON WINDOWS BUILDS] Home screen with six buttons, five-step wizard, saved extractions and batch window, manual table selection and plain-language messages exist; the Windows builds (smoke test) construct them on a real Windows machine.
- [NOT TESTED] no real non-technical user has operated this yet; the user (a non-programmer) has used builds 9-18 for real exports. Plain-language user guide: docs/DocIntel_User_Guide.pdf.

## Scenario 8 - Offline operation
- [PASS] with offline mode on, connections to the internet are refused by the application
- [PASS] no AI provider is connected by default and nothing is sent
- [VERIFIED ON WINDOWS] every build also ran the packaged app with ALL network access blocked by the Windows firewall (builds 6-18: green).

## Scenario 9 - AI-assisted analysis with a LOCAL model (tested against a fake local model server, NOT a real language model)
- [PASS] the local model is reachable while offline mode is ON (this computer only)
- [PASS] bulk AI extraction: 40 documents -> 40 records, all values confirmed in the document text - 0.1 s
- [PASS] extracted values exact
- [PASS] an invented value is caught and marked for review
- [PASS] meaning-based search index built incrementally - 83 vectors
- [PASS] question answered from the documents with sources, nothing left this computer
- [NOT TESTED] real open-weight models (accuracy, speed, Arabic): the test uses a rule-based stand-in. Use AI tools > Compare models on your own documents.

## Summary

35 of 35 automated acceptance checks passed. Peak memory 254 MB.
