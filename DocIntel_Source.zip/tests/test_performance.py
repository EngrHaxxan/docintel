"""Milestone 5: fast PDF index, process pool, speed presets, search of engine tables. Run: python -m unittest tests.test_performance"""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from docintel.library import Library
from docintel import search as S
from docintel.extraction import words_for_segment
from docintel.batch import BatchRunner, new_profile

HERE = os.path.dirname(os.path.abspath(__file__))
DAILY = os.path.join(HERE, "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")


def make_pdfs(folder, n):
    from reportlab.pdfgen import canvas
    for i in range(n):
        c = canvas.Canvas(os.path.join(folder, f"inv_{i:03d}.pdf")); c.drawString(72, 700, f"Invoice No: INV-{i:05d}"); c.drawString(72, 680, "Total: 1,000.00 " + "word " * 20); c.save()


class Perf(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "src"); os.makedirs(self.src)
        make_pdfs(self.src, 6); shutil.copy(DAILY, os.path.join(self.src, "daily.pdf"))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _lib(self, **cfg):
        lib = Library(os.path.join(self.tmp, "home"))
        for k, v in cfg.items():
            lib.cfg.set(k, v)
        lib.add_root(self.src); lib.scan()
        return lib

    def test_fast_index_searchable_and_no_words_stored(self):
        lib = self._lib(workers=1)
        st = lib.index()
        self.assertEqual((st["indexed"], st["errors"]), (7, 0))
        self.assertTrue(S.search(lib.db, "INV-00003", "text", limit=10))
        self.assertTrue(S.search(lib.db, "Construction Activities", "text", limit=10))
        seg = lib.db.one("SELECT s.id, s.words_json, s.page_w FROM segments s JOIN files f ON f.id=s.file_id WHERE f.name='inv_001.pdf'")
        self.assertIsNone(seg["words_json"]); self.assertGreater(seg["page_w"], 100)
        w = words_for_segment(lib.db, seg["id"])
        self.assertTrue(w and any("INV-00001" in x[0] for x in w))                     # computed on demand, then cached
        self.assertIsNotNone(lib.db.one("SELECT words_json FROM segments WHERE id=?", (seg["id"],))["words_json"])

    def test_process_pool_gives_same_result_as_threads(self):
        a = self._lib(workers=1); a.index()
        ta = sorted((r["name"], r["text"]) for r in a.db.q("SELECT f.name, s.text FROM segments s JOIN files f ON f.id=s.file_id"))
        shutil.rmtree(os.path.join(self.tmp, "home"))
        b = self._lib(workers=2, use_processes=True); st = b.index()
        self.assertEqual((st["indexed"], st["errors"]), (7, 0))
        tb = sorted((r["name"], r["text"]) for r in b.db.q("SELECT f.name, s.text FROM segments s JOIN files f ON f.id=s.file_id"))
        self.assertEqual(ta, tb)

    def test_broken_and_encrypted_pdf_are_reported_not_crashing_the_pool(self):
        with open(os.path.join(self.src, "broken.pdf"), "wb") as f:
            f.write(b"%PDF-1.4 not a pdf")
        lib = self._lib(workers=2, use_processes=True); st = lib.index()
        self.assertEqual(st["errors"], 1); self.assertEqual(st["indexed"], 7)
        r = lib.db.one("SELECT status, error FROM files WHERE name='broken.pdf'")
        self.assertEqual(r["status"], "error"); self.assertIn("corrupted", r["error"])

    def test_incremental_only_new_or_changed(self):
        lib = self._lib(workers=1); lib.index()
        t = lib.db.one("SELECT MAX(indexed_at) m FROM files")["m"]
        self.assertEqual(lib.scan() and lib.index()["total"], 0)                        # nothing to do when nothing changed
        shutil.copy(DAILY, os.path.join(self.src, "daily2.pdf")); lib.scan()
        st = lib.index(); self.assertEqual(st["total"], 1)                              # only the new file
        self.assertEqual(lib.db.one("SELECT MAX(indexed_at) m FROM files WHERE name='daily.pdf'")["m"] <= t, True)

    def test_speed_presets(self):
        lib = self._lib()
        self.assertEqual(lib.apply_speed("low"), 1)
        n = os.cpu_count() or 1
        self.assertEqual(lib.apply_speed("balanced"), max(1, n // 2)); self.assertEqual(lib.apply_speed("faster"), max(1, n - 1))

    def test_table_cells_of_extracted_pdf_are_searchable(self):
        lib = self._lib(workers=1); lib.index()
        self.assertFalse([h for h in S.search(lib.db, "Backfilling", "text", limit=50) if h.kind == "table"])
        BatchRunner(lib).run(new_profile("c", section={"heading": "Construction Activities", "aliases": []}), root_ids=[lib.roots()[0]["id"]])
        hits = [h for h in S.search(lib.db, "Backfilling", "text", limit=50) if h.kind == "table"]
        self.assertTrue(hits and hits[0].name == "daily.pdf" and "table" in hits[0].loc)


if __name__ == "__main__":
    unittest.main()
