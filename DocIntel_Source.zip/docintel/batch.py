"""Milestone 4: reusable extraction profiles + batch jobs.

A *profile* describes WHAT to extract (section / table-by-headers / fields / row filter) and HOW to export it. It never
contains page numbers: the section or table is found again in every document. A *job* applies one profile to many documents,
keeps a status per document, never stops because one document fails, can be retried / resumed / extended with new documents,
and is stored in the library database (extraction_jobs, job_items) so it can be reviewed and exported later.
Pure logic - no GUI code - so it is fully testable."""
from __future__ import annotations
import copy, csv, json, os, re, time
from .tables import store
from .tables.sections import heading_similarity, _norm
from .tables.service import extract_file_tables
from .wizard import Session, Entry, parse_request, match_columns

OK_STATES = ("processed", "partial")
STATUS_TEXT = {"processed": "Done", "partial": "Done - some parts need attention", "failed": "Failed",
               "section_not_found": "Section not found", "table_not_found": "Table not found",
               "needs_confirmation": "Similar heading found - please confirm", "no_tables": "No table in document",
               "unsupported": "File type not supported yet", "pending": "Not processed yet"}

DEFAULT_OUTPUT = {"arrangement": "stacked", "layouts": ["norm"], "value_mode": "raw", "header_style": "joined",
                  "include_source": True, "group_rows": False, "format": "xlsx"}


# ============================================================================ profiles
def new_profile(name="", **kw):
    p = {"name": name, "description": "", "request": "",
         "section": {"heading": "", "aliases": []},
         "table": {"headers": [], "min_match": 0.6},
         "fields": [], "all_columns": False, "text_filter": "",
         "output": dict(DEFAULT_OUTPUT), "review": {"flag_below_quality": 0.5}}
    for k, v in kw.items():
        p[k] = v
    return normalize_profile(p)


def normalize_profile(p):
    """Fill every missing key so older / hand-made profiles keep working."""
    p = copy.deepcopy(p)
    p.setdefault("name", ""); p.setdefault("description", ""); p.setdefault("request", "")
    p.setdefault("section", {}); p["section"].setdefault("heading", ""); p["section"].setdefault("aliases", [])
    p.setdefault("table", {}); p["table"].setdefault("headers", []); p["table"].setdefault("min_match", 0.6)
    p.setdefault("fields", []); p.setdefault("all_columns", False); p.setdefault("text_filter", "")
    out = dict(DEFAULT_OUTPUT); out.update(p.get("output") or {}); p["output"] = out
    p.setdefault("review", {"flag_below_quality": 0.5})
    return p


STARTERS = [  # editable examples; the engine does not know these layouts, it only searches by heading / header words
    ("Daily report - Construction Activities", "Construction Activities from daily reports, all columns.", {"section": {"heading": "Construction Activities", "aliases": []}}),
    ("Daily report - Issues & Concerns", "Issues & Concerns from daily reports.", {"section": {"heading": "Issues & Concerns", "aliases": []}}),
    ("Daily report - Engineering Activities", "Engineering Activities (submittals) from daily reports.", {"section": {"heading": "Engineering Activities", "aliases": []}}),
    ("Daily report - Procurement Activities", "Procurement Activities from daily reports.", {"section": {"heading": "Procurement Activities", "aliases": []}}),
    ("Complete table by its column names (example: SCAL)", "Finds the table whose columns match these names, in any document, over all pages.",
     {"table": {"headers": ["Sr.", "Main Activity Name", "Main Activity Test Code", "Sub-Activity Name", "Sub-Activity Test Code", "Duration In Hours", "Unit", "Remarks"], "min_match": 0.6},
      "output": {"arrangement": "per_table", "layouts": ["norm", "orig"]}}),
]


def starter_profiles():
    return [new_profile(n, description=d, **kw) for n, d, kw in STARTERS]


def save_profile(db, p):
    p = normalize_profile(p)
    name = (p.get("name") or "").strip()
    if not name:
        raise ValueError("Please give the saved extraction a name.")
    now = time.time()
    old = db.one("SELECT created FROM table_profiles WHERE name=?", (name,))
    db.x("INSERT OR REPLACE INTO table_profiles(name,json,created,updated) VALUES(?,?,?,?)",
         (name, json.dumps(p, ensure_ascii=False), old["created"] if old else now, now))
    return p


def load_profile(db, name):
    r = db.one("SELECT json FROM table_profiles WHERE name=?", (name,))
    if r:
        return normalize_profile(json.loads(r["json"]))
    for p in starter_profiles():
        if p["name"] == name:
            return p
    return None


def list_profiles(db):
    """Saved profiles first (newest first), then the starter examples that have not been saved under the same name."""
    saved = [normalize_profile(json.loads(r["json"])) for r in db.q("SELECT json FROM table_profiles ORDER BY updated DESC")]
    names = {p["name"] for p in saved}
    for p in saved:
        p["_starter"] = False
    st = [dict(p, _starter=True) for p in starter_profiles() if p["name"] not in names]
    return saved + st


def delete_profile(db, name):
    db.x("DELETE FROM table_profiles WHERE name=?", (name,))


def profile_from_session(s, name, output=None):
    """Turn the choices made in the wizard (a Session after build()) into a reusable profile. Page numbers are never stored."""
    mode, params = s.mode, s.params or {}
    if mode == "text":
        raise ValueError("Reading all text cannot be saved as a reusable table extraction.")
    parsed = params.get("parsed") or {}
    heads = params.get("headings") or ([parsed["section"]] if parsed.get("section") else [])
    fields = params.get("fields") if params.get("fields") is not None else parsed.get("fields")
    p = new_profile(name)
    if heads:
        p["section"] = {"heading": heads[0], "aliases": list(heads[1:])}
    p["fields"] = list(fields or [])
    p["all_columns"] = bool(parsed.get("all_columns")) if not p["fields"] else False
    p["text_filter"] = params.get("text_filter") or (params.get("text") if mode == "records" else "") or parsed.get("filter", "")
    if mode == "custom":
        p["request"] = params.get("text", "")
    if mode == "table" and s.preview:
        e = s.preview[0]
        p["table"]["headers"] = [h.name for h in e.table.headers if h.name]
    p["description"] = f"Saved from the extraction wizard ({mode})."
    if output:
        p["output"].update(output)
    elif s.preview:
        p["output"]["arrangement"] = s.suggest_arrangement()
    return p


# ============================================================================ choosing tables for one document
def _key(h):
    return " ".join(_norm(h))


def _coverage(entry, names):
    if not names:
        return 1.0
    hit = sum(1 for n in names if match_columns(n, entry.table.headers))
    return hit / len(names)


def select_tables(profile, entries):
    """-> (chosen entries, status, message, candidates). Similar-but-not-identical headings are NEVER used silently:
    they produce 'needs_confirmation' with the candidate list, and only a confirmed alias makes them match."""
    sec, sig = profile["section"], profile["table"]["headers"]
    want = [h for h in [sec.get("heading", "")] + list(sec.get("aliases", [])) if h]
    if not entries:
        return [], "no_tables", "No table was found in this document.", []
    chosen, cands = list(entries), []
    if want:
        keys = {_key(h) for h in want}
        chosen = [e for e in entries if _key(e.heading) in keys]
        if not chosen:
            seen = {}
            for e in entries:
                if e.heading and _key(e.heading) not in keys:
                    sc = max(heading_similarity(w, e.heading) for w in want)
                    if sc >= 65:
                        seen[e.heading] = max(seen.get(e.heading, 0), round(sc))
            cands = [{"heading": h, "score": s} for h, s in sorted(seen.items(), key=lambda x: -x[1])]
            if cands:
                return [], "needs_confirmation", (f"'{want[0]}' was not found, but a similar heading was: "
                                                   + "; ".join(f"{c['heading']} ({c['score']}%)" for c in cands[:3]) + ". Please confirm whether it is the same section."), cands
            return [], "section_not_found", f"'{want[0]}' was not found in this document.", []
    if sig:
        mm = float(profile["table"].get("min_match", 0.6))
        chosen = [e for e in chosen if _coverage(e, sig) >= mm]
        if not chosen:
            return [], "table_not_found", "No table with the requested column names was found" + (f" under '{want[0]}'." if want else " in this document."), []
    return chosen, "ok", "", cands


def transform(sess, profile, entries):
    """Apply the field list and row filter. Missing requested fields stay blank and are reported (never substituted)."""
    out = list(entries)
    if profile["fields"] and not profile["all_columns"]:
        out = [sess._select_fields(e, profile["fields"]) for e in out]
    if profile["text_filter"]:
        out = [sess._filter_rows(e, profile["text_filter"]) for e in out]
        out = [e for e in out if e.table.rows]
    return out


def _has_review(r):
    return any(f.startswith("review") for fl in r.cell_flags.values() for f in fl) or any(f.startswith("review") for f in r.flags)


def apply_profile(lib, profile, entries):
    """Pure per-document step used by both the job run and the later reload. Returns a result dict."""
    eff = copy.deepcopy(profile)
    if not (eff["section"]["heading"] or eff["table"]["headers"]) and eff["request"]:        # request-only profile: read it per document
        req = parse_request(eff["request"], [e.heading for e in entries if e.heading])
        if req["section"]:
            eff["section"]["heading"] = req["section"]
        if not eff["fields"] and req["fields"]:
            eff["fields"] = req["fields"]
        if not eff["text_filter"] and req["filter"]:
            eff["text_filter"] = req["filter"]
        if req["all_columns"]:
            eff["all_columns"] = True
    chosen, status, msg, cands = select_tables(eff, entries)
    sess = Session(lib)
    if status != "ok":
        return {"status": status, "message": msg, "entries": [], "candidates": cands, "warnings": [], "heading": ""}
    ents = transform(sess, eff, chosen)
    quality_floor = float(eff.get("review", {}).get("flag_below_quality", 0) or 0)
    for e in ents:
        if quality_floor and e.table.quality < quality_floor and not any("low quality" in f for f in e.table.quality_notes):
            e.table.quality_notes = list(e.table.quality_notes) + ["review: low table quality"]
    return {"status": "ok", "message": "; ".join(dict.fromkeys(sess.warnings)), "entries": ents, "candidates": cands,
            "warnings": sess.warnings, "heading": chosen[0].heading if chosen else ""}


# ============================================================================ jobs
class BatchRunner:
    def __init__(self, lib):
        self.lib, self.db = lib, lib.db

    # ------------------------------------------------------------ scope
    def scope_files(self, scope):
        db = self.db
        if scope.get("file_ids"):
            rows = [r for fid in scope["file_ids"] for r in db.q("SELECT * FROM files WHERE id=? AND missing_since IS NULL", (fid,))]
        elif scope.get("root_ids"):
            ph = ",".join("?" * len(scope["root_ids"]))
            rows = db.q(f"SELECT * FROM files WHERE root_id IN ({ph}) AND missing_since IS NULL ORDER BY name", tuple(scope["root_ids"]))
        else:
            rows = db.q("SELECT * FROM files WHERE missing_since IS NULL ORDER BY name")
        return rows

    @staticmethod
    def _stamp(row):
        k = row.keys()
        return f"{row['sha256'] if 'sha256' in k and row['sha256'] else ''}|{row['size'] if 'size' in k else ''}|{row['mtime'] if 'mtime' in k else ''}"

    def _add_items(self, job_id, rows):
        for r in rows:
            self.db.conn.execute("INSERT OR IGNORE INTO job_items(job_id,file_id,name,path,sha256,status,updated) VALUES(?,?,?,?,?,'pending',?)",
                                 (job_id, r["id"], r["name"], r["abspath"], self._stamp(r), time.time()))
        self.db.conn.commit()

    def create_job(self, profile, root_ids=None, file_ids=None, title=None, parent=None):
        profile = normalize_profile(profile)
        scope = {"root_ids": list(root_ids or []), "file_ids": list(file_ids or [])}
        cur = self.db.x("INSERT INTO extraction_jobs(profile_name,profile_json,title,scope_json,started,status,parent_id) VALUES(?,?,?,?,?,'running',?)",
                        (profile["name"], json.dumps(profile, ensure_ascii=False), title or profile["name"] or "Extraction", json.dumps(scope), time.time(), parent))
        jid = cur.lastrowid
        self._add_items(jid, self.scope_files(scope))
        return jid

    def job_profile(self, job_id):
        r = self.db.one("SELECT profile_json FROM extraction_jobs WHERE id=?", (job_id,))
        return normalize_profile(json.loads(r["profile_json"])) if r else None

    # ------------------------------------------------------------ running
    def _set(self, item_id, **kw):
        kw["updated"] = time.time()
        self.db.x(f"UPDATE job_items SET {','.join(k + '=?' for k in kw)} WHERE id=?", tuple(kw.values()) + (item_id,))

    def _process_item(self, it, profile, force, control):
        row = self.db.one("SELECT * FROM files WHERE id=?", (it["file_id"],))
        if row is None:
            return self._set(it["id"], status="failed", message="The file is no longer in the library.", detail="")
        ext = (row["ext"] or os.path.splitext(row["abspath"])[1]).lower().lstrip(".")
        if ext != "pdf":
            return self._set(it["id"], status="unsupported", message=f"Table extraction from .{ext or '?'} files is not available yet.", sha256=self._stamp(row))
        r = extract_file_tables(self.db, row, force=force, cancel=(lambda: control.cancelled) if control else None)
        st = r["status"]
        if st == "cancelled":
            return
        if st in ("failed", "unsupported"):
            return self._set(it["id"], status=st, message=r["message"], detail=r.get("detail", ""), sha256=self._stamp(row))
        entries = [Entry(row["name"], row["abspath"], store.load_table(self.db, t["id"]), t["id"], row["id"]) for t in store.list_tables(self.db, row["id"])]
        res = apply_profile(self.lib, profile, entries)
        status = res["status"]
        msg = res["message"]
        if status == "ok":
            status = "partial" if (st == "partial" or res["warnings"]) else "processed"
            if st == "partial":
                msg = (r["message"] + " " + msg).strip()
        ents = res["entries"]
        self._set(it["id"], status=status, message=msg, detail="", tables=len(ents), records=sum(len(e.table.rows) for e in ents),
                  review_rows=sum(1 for e in ents for x in e.table.rows if _has_review(x)),
                  table_ids_json=json.dumps([e.db_id for e in ents if e.db_id]), candidates_json=json.dumps(res["candidates"]),
                  heading=res["heading"], sha256=self._stamp(row))

    def run_job(self, job_id, force=False, control=None, progress=None):
        """Process every pending item. One bad document never stops the others."""
        profile = self.job_profile(job_id)
        items = self.db.q("SELECT * FROM job_items WHERE job_id=? AND status='pending' ORDER BY id", (job_id,))
        for i, it in enumerate(items):
            if control is not None:
                control.wait_if_paused()
                if control.cancelled:
                    break
            try:
                self._process_item(it, profile, force, control)
            except Exception as e:                                           # technical detail goes to the log, not to the user
                import logging
                logging.getLogger("docintel").exception("batch item failed: %s", it["path"])
                self._set(it["id"], status="failed", message="This document could not be processed. You can retry it later.", detail=f"{type(e).__name__}: {e}")
            if progress:
                progress(i + 1, len(items), it["name"])
        left = self.db.one("SELECT COUNT(*) n FROM job_items WHERE job_id=? AND status='pending'", (job_id,))["n"]
        status = "cancelled" if left else "done"
        self.db.x("UPDATE extraction_jobs SET status=?, finished=?, stats_json=? WHERE id=?", (status, time.time(), json.dumps(self.summary(job_id)), job_id))
        return self.summary(job_id)

    def run(self, profile, root_ids=None, file_ids=None, title=None, force=False, control=None, progress=None):
        jid = self.create_job(profile, root_ids, file_ids, title)
        self.run_job(jid, force=force, control=control, progress=progress)
        return jid

    def retry(self, job_id, statuses=("failed", "partial"), control=None, progress=None):
        ph = ",".join("?" * len(statuses))
        self.db.x(f"UPDATE job_items SET status='pending', message=NULL, detail=NULL WHERE job_id=? AND status IN ({ph})", (job_id,) + tuple(statuses))
        return self.run_job(job_id, force=True, control=control, progress=progress)

    def resume(self, job_id, control=None, progress=None):
        """Continue a job that was cancelled or interrupted (e.g. the computer was switched off)."""
        self.db.x("UPDATE extraction_jobs SET status='running' WHERE id=?", (job_id,))
        return self.run_job(job_id, control=control, progress=progress)

    def add_new_documents(self, job_id, control=None, progress=None):
        """Re-run the same profile on documents added to the scope since the job ran (and on files whose content changed).
        Documents already processed and unchanged are NOT processed again."""
        scope = json.loads(self.db.one("SELECT scope_json FROM extraction_jobs WHERE id=?", (job_id,))["scope_json"])
        known = {r["file_id"]: r for r in self.db.q("SELECT * FROM job_items WHERE job_id=?", (job_id,))}
        new = changed = 0
        for r in self.scope_files(scope):
            it = known.get(r["id"])
            if it is None:
                self._add_items(job_id, [r]); new += 1
            elif it["sha256"] != self._stamp(r):
                self._set(it["id"], status="pending", message=None); changed += 1
        self.db.x("UPDATE extraction_jobs SET status='running' WHERE id=?", (job_id,))
        s = self.run_job(job_id, control=control, progress=progress)
        s["new_documents"], s["changed_documents"] = new, changed
        return s

    def confirm_section(self, job_id, heading, save_to_profile=True, control=None, progress=None):
        """The user confirms that `heading` is the same section as the profile's. Stored as an alias; the documents that were
        waiting for confirmation are then processed again (their tables are already stored, so this is fast)."""
        p = self.job_profile(job_id)
        if heading and _key(heading) not in {_key(a) for a in [p["section"]["heading"]] + p["section"]["aliases"]}:
            p["section"]["aliases"].append(heading)
        self.db.x("UPDATE extraction_jobs SET profile_json=? WHERE id=?", (json.dumps(p, ensure_ascii=False), job_id))
        if save_to_profile and p["name"] and self.db.one("SELECT 1 FROM table_profiles WHERE name=?", (p["name"],)):
            save_profile(self.db, p)
        self.db.x("UPDATE job_items SET status='pending', message=NULL WHERE job_id=? AND status IN ('needs_confirmation','section_not_found')", (job_id,))
        return self.run_job(job_id, control=control, progress=progress)

    # ------------------------------------------------------------ results
    def summary(self, job_id):
        c = {r["status"]: r["n"] for r in self.db.q("SELECT status, COUNT(*) n FROM job_items WHERE job_id=? GROUP BY status", (job_id,))}
        t = self.db.one("SELECT COALESCE(SUM(tables),0) t, COALESCE(SUM(records),0) r, COALESCE(SUM(review_rows),0) v FROM job_items WHERE job_id=?", (job_id,))
        g = lambda *k: sum(c.get(x, 0) for x in k)
        return {"total": sum(c.values()), "processed": g("processed"), "partial": g("partial"), "failed": g("failed"),
                "section_not_found": g("section_not_found", "table_not_found"), "needs_confirmation": g("needs_confirmation"),
                "no_tables": g("no_tables"), "unsupported": g("unsupported"), "pending": g("pending"),
                "tables": t["t"], "records": t["r"], "review_rows": t["v"]}

    def summary_text(self, job_id):
        s = self.summary(job_id)
        parts = [f"{s['total']} document(s)", f"{s['processed']} done"]
        for k, lab in (("partial", "partly done"), ("failed", "failed"), ("section_not_found", "section/table not found"),
                       ("needs_confirmation", "waiting for your confirmation"), ("no_tables", "without tables"),
                       ("unsupported", "unsupported"), ("pending", "not processed yet")):
            if s[k]:
                parts.append(f"{s[k]} {lab}")
        return ", ".join(parts) + f". {s['tables']} table(s), {s['records']} record(s), {s['review_rows']} row(s) need review."

    def list_jobs(self, limit=200):
        return [dict(r) for r in self.db.q("SELECT id, title, profile_name, started, finished, status, stats_json FROM extraction_jobs ORDER BY id DESC LIMIT ?", (limit,))]

    def items(self, job_id, statuses=None):
        sql, args = "SELECT * FROM job_items WHERE job_id=?", [job_id]
        if statuses:
            sql += f" AND status IN ({','.join('?' * len(statuses))})"; args += list(statuses)
        return [dict(r) for r in self.db.q(sql + " ORDER BY name", tuple(args))]

    def delete_job(self, job_id):
        self.db.x("DELETE FROM extraction_jobs WHERE id=?", (job_id,))

    def entries(self, job_id, statuses=OK_STATES):
        """The extracted tables of a job, rebuilt from the stored tables (so corrections made since are included)."""
        profile, out = self.job_profile(job_id), []
        for it in self.items(job_id, statuses):
            row = self.db.one("SELECT name, abspath FROM files WHERE id=?", (it["file_id"],))
            if row is None:
                continue
            ents = [Entry(row["name"], row["abspath"], store.load_table(self.db, t["id"]), t["id"], it["file_id"]) for t in store.list_tables(self.db, it["file_id"])]
            res = apply_profile(self.lib, profile, ents)
            out.extend(res["entries"])
        return out

    def report_rows(self, job_id):
        hdr = ["Document", "Folder", "Result", "Details", "Tables", "Records", "Rows needing review", "Section found"]
        rows = [hdr]
        for it in self.items(job_id):
            rows.append([it["name"], os.path.dirname(it["path"] or ""), STATUS_TEXT.get(it["status"], it["status"]), it["message"] or "",
                         it["tables"], it["records"], it["review_rows"], it["heading"] or ""])
        return rows

    def export_job(self, job_id, path, **opts):
        prof = self.job_profile(job_id)
        o = dict(prof["output"]); o.update(opts)
        ents = self.entries(job_id)
        if not ents:
            raise ValueError("This job has no extracted records to export yet.")
        s = Session(self.lib)
        s.preview, s.mode, s.params = ents, f"batch job {job_id}", {}
        return s.export(path, fmt=o["format"], arrangement=o["arrangement"], layouts=tuple(o["layouts"]), value_mode=o["value_mode"],
                        header_style=o["header_style"], include_source=o["include_source"], group_rows=o["group_rows"], report=self.report_rows(job_id))


def write_report_file(rows, folder, fmt="xlsx"):
    os.makedirs(folder, exist_ok=True)
    if fmt == "csv":
        p = os.path.join(folder, "Job report.csv")
        with open(p, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows(rows)
        return p
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Job report"
    for r in rows:
        ws.append(r)
    p = os.path.join(folder, "Job report.xlsx")
    wb.save(p)
    return p
