"""Cell-level accuracy of the table engine against hand-verified values (from the real PDFs).
Usage: python tools/table_accuracy.py  -> prints counts; exit code 1 if any cell is wrong/missing."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from docintel.tables import analyze_pdf
R = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests", "real_pdfs")
cons = [["1", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Backfilling", "Backfilling of the 5th layer for the Substation Building and Power Transformer Foundation.", "70%", "100%", "Completed", ""],
        ["2", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Compaction", "Compaction of the 5th layer for the Substation Building and Power Transformer Foundation.", "0%", "0%", "To be Started", ""],
        ["3", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Temporary Fencing", "Installation of plywood panels", "70%", "90%", "In-Progress", ""],
        ["4", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Temporary Project Signboard", "Supply and installation", "0%", "0%", "To be Started", ""]]
iss = [["1", "UGC Design input", "Expedite SE response in our request for the handover of as built for existing UGC data", "High", "Time Delay", "05-May-26", "156", "SE", "Open", ""],
       ["2", "UGC - Mashaer / MUNA-1 Circuits", "Existing UGC works by other contractor remain on hold, impacting design and execution.", "High", "Time Delay", "02-Aug-26", "67", "SE", "Open", ""],
       ["3", "UGC Input Data - Aziziah / MUNA-1 Circuits", "Pending design inputs are delaying design development and deliverables.", "High", "Time Delay", "02-Aug-26", "67", "SE", "Open", ""]]
# SCAL reference rows: column index -> value (normalized layout); only values verified against the PDF text
scal = {1: {1: "Substation Battery Bank", 2: "SBB", 5: "Substation Battery Bank", 6: "SBBXX.TEST", 7: "12.00", 8: "Battery", 9: "125 V", 10: "0%", 11: "100%", 12: "Testing - Batteries&Chargers"},
        15: {5: "Scheme Check", 6: "ACDBXX.SCH", 7: "16", 8: "Panel", 9: "To be witnessed during pre-check", 10: "100%", 11: "0%"},
        202: {5: "LCC Scheme Check", 6: "EHV.SWGXX.LCC.SCH", 7: "24.00", 8: "CB", 9: "", 10: "100%", 11: "20% Including All Typicals"},
        999: {5: "On Load Test For Phase Synchronizing Device", 6: "OLTXX.PSD", 7: "1.00", 8: "PSD", 9: "", 10: "0%", 11: "100%", 12: "Protection - MV Advanced Protection&Control IEDs"}}


def main():
    ok = bad = miss = extra = 0
    d = analyze_pdf(os.path.join(R, "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf"))
    for sec, exp in (("CONSTRUCTION", cons), ("ISSUES", iss)):
        t = next(t for t in d.tables if t.section.startswith(sec))
        extra += max(0, len(t.rows) - len(exp)); miss += max(0, len(exp) - len(t.rows)) * len(exp[0])
        for r, e in zip(t.rows, exp):
            for a, b in zip(r.orig, e):
                ok, bad = (ok + 1, bad) if a == b else (ok, bad + 1)
    s = analyze_pdf(os.path.join(R, "WI-NG-6460-001-001_SCAL_Rev03.pdf"))
    t = max(s.tables, key=lambda t: len(t.rows))
    by = {int(r.anchor): r for r in t.rows}
    for k, cols in scal.items():
        for c, v in cols.items():
            if k not in by: miss += 1
            elif by[k].norm[c] == v: ok += 1
            else: bad += 1; print("WRONG", k, c, repr(by[k].norm[c]), repr(v))
    rows_ok = len(t.rows) == 1000 and [int(r.anchor) for r in t.rows] == list(range(1, 1001))
    res = {"cells_correct": ok, "cells_incorrect": bad, "cells_missing": miss, "extra_rows": extra,
           "scal_rows": len(t.rows), "scal_rows_complete_and_sequential": rows_ok, "scal_columns": len(t.headers),
           "daily_construction_rows": 4, "daily_issue_rows": 3}
    print(json.dumps(res))
    return 0 if bad == 0 and miss == 0 and extra == 0 and rows_ok else 1


if __name__ == "__main__":
    sys.exit(main())
