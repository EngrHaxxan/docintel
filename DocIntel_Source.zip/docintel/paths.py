"""Where things live. Works the same for: source run, PyInstaller one-folder build, installed app, portable app.

- Program files (read-only is fine):   app_dir()   (folder containing DocIntel.exe, or the project folder when run from source)
- User data (database, settings, log): data_dir()  -> %LOCALAPPDATA%\\DocIntel  (installed)  |  <app>\\DocIntel_Data  (portable)
Portable mode is on when a file named `portable.txt` sits next to DocIntel.exe, or env DOCINTEL_HOME is set.
"""
import os, sys


def frozen():
    return bool(getattr(sys, "frozen", False))


def app_dir():
    if frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def resource_dir():
    """PyInstaller 6 puts bundled data in <app>/_internal (sys._MEIPASS)."""
    return getattr(sys, "_MEIPASS", app_dir())


def is_portable():
    return os.path.exists(os.path.join(app_dir(), "portable.txt"))


def writable(path):
    try:
        os.makedirs(path, exist_ok=True)
        t = os.path.join(path, ".w")
        open(t, "w").close(); os.remove(t)
        return True
    except OSError:
        return False


def data_dir():
    env = os.environ.get("DOCINTEL_HOME")
    if env:
        return env
    if is_portable():
        p = os.path.join(app_dir(), "DocIntel_Data")
        if writable(p):
            return p
        # portable folder on a read-only medium: fall back to the user profile rather than failing
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "DocIntel")
    return os.path.join(os.path.expanduser("~"), ".docintel")


def long_path(p):
    """Only paths near the 260-char Windows limit get the \\\\?\\ prefix; stored/displayed paths never carry it."""
    if os.name == "nt":
        p = os.path.abspath(p)
        if len(p) >= 240 and not p.startswith("\\\\?\\"):
            return "\\\\?\\UNC\\" + p[2:] if p.startswith("\\\\") else "\\\\?\\" + p
    return p


def no_window_flags():
    """subprocess creationflags that stop a console window flashing on Windows."""
    if os.name == "nt":
        import subprocess
        return getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    return 0
