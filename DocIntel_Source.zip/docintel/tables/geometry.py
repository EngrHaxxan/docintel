"""Page geometry: words, rotated text, strokes (borders), fills. Works on pdfplumber pages."""
from __future__ import annotations
import bisect, collections, re, unicodedata
from dataclasses import dataclass, field
from pdfplumber.utils import extract_words

H_THICK = 1.6      # a rect thinner than this is a border stroke
MIN_STROKE = 3.0


def cluster_1d(values, tol=1.5, weights=None):
    """Cluster numbers; return list of (centre, total_weight)."""
    if not values:
        return []
    ws = weights or [1.0] * len(values)
    items = sorted(zip(values, ws))
    out, cur = [], [items[0]]
    for v, w in items[1:]:
        if v - cur[-1][0] <= tol:
            cur.append((v, w))
        else:
            out.append(cur); cur = [(v, w)]
    out.append(cur)
    res = []
    for g in out:
        tw = sum(w for _, w in g)
        res.append((sum(v * w for v, w in g) / tw if tw else g[0][0], tw))
    return res


def merge_segments(segs, tol=1.5):
    """segs: list of (pos, a, b) collinear-capable segments -> merged (pos, a, b)."""
    if not segs:
        return []
    cl = cluster_1d([s[0] for s in segs], 0.8)
    centres = [c for c, _ in cl]
    groups = collections.defaultdict(list)
    for p, a, b in segs:
        i = min(range(len(centres)), key=lambda j: abs(centres[j] - p))
        groups[i].append((a, b))
    out = []
    for i, g in groups.items():
        g.sort()
        ca, cb = g[0]
        for a, b in g[1:]:
            if a <= cb + tol:
                cb = max(cb, b)
            else:
                out.append((centres[i], ca, cb)); ca, cb = a, b
        out.append((centres[i], ca, cb))
    return sorted(out)


def is_bold(fontname: str) -> bool:
    f = (fontname or "").lower()
    return "bold" in f or "black" in f or "heavy" in f or f.endswith("-bd") or ",bd" in f


@dataclass
class PageData:
    number: int
    width: float
    height: float
    words: list                      # upright words (dicts: text,x0,x1,top,bottom,size,bold)
    rot_chars: list                  # rotated chars
    hs: list                         # horizontal strokes (y, x0, x1), merged
    vs: list                         # vertical strokes (x, y0, y1), merged
    fills: list                      # (x0, top, x1, bottom, colour)
    body_size: float = 0.0
    ignore: list = field(default_factory=list)   # bboxes of running headers/footers

    def words_in(self, x0, top, x1, bottom):
        return [w for w in self.words if x0 - 0.5 <= (w["x0"] + w["x1"]) / 2 <= x1 + 0.5 and top <= (w["top"] + w["bottom"]) / 2 <= bottom]


def load_page(page, number, x_tol=1.5, y_tol=1.5) -> PageData:
    chars = page.chars
    up, rot = [], []
    prev = None
    for c in chars:
        t = c.get("text") or ""
        fn = c.get("fontname") or ""
        if len(fn) > 7 and fn[6] == "+":                 # font subset prefixes (ABCDEF+Arial) must not split words
            c["fontname"] = fn[7:]
        if prev is not None and len(t) == 1 and unicodedata.category(t) in ("Mn", "Me", "Cf"):
            c = dict(c); c["x0"] = prev["x0"] + 0.001; c["x1"] = prev["x1"]; c["top"], c["bottom"] = prev["top"], prev["bottom"]; c["fontname"], c["size"] = prev["fontname"], prev["size"]   # marks stick to the previous letter
        else:
            prev = c
        chars_fixed = c
        m = c.get("matrix") or (1, 0, 0, 1, 0, 0)
        (rot if abs(m[1]) > 0.5 or abs(m[2]) > 0.5 else up).append(chars_fixed)
    words = []
    if up:
        for w in extract_words(up, x_tolerance=x_tol, y_tolerance=y_tol, extra_attrs=["size", "fontname"]):
            w["bold"] = is_bold(w.get("fontname"))
            words.append(w)
    H, V, fills = [], [], []
    for r in page.rects:
        w, h = r["x1"] - r["x0"], r["bottom"] - r["top"]
        if h <= H_THICK and w >= MIN_STROKE:
            H.append(((r["top"] + r["bottom"]) / 2, r["x0"], r["x1"]))
        elif w <= H_THICK and h >= MIN_STROKE:
            V.append(((r["x0"] + r["x1"]) / 2, r["top"], r["bottom"]))
        elif w > H_THICK and h > H_THICK:
            fills.append((r["x0"], r["top"], r["x1"], r["bottom"], r.get("non_stroking_color") if r.get("fill") else None))
    for l in page.lines:
        if abs(l["top"] - l["bottom"]) <= 1 and l["x1"] - l["x0"] >= MIN_STROKE:
            H.append(((l["top"] + l["bottom"]) / 2, l["x0"], l["x1"]))
        elif abs(l["x0"] - l["x1"]) <= 1 and l["bottom"] - l["top"] >= MIN_STROKE:
            V.append(((l["x0"] + l["x1"]) / 2, l["top"], l["bottom"]))
    sizes = [round(w["size"], 1) for w in words for _ in range(max(1, len(w["text"]) // 3))]
    body = collections.Counter(sizes).most_common(1)[0][0] if sizes else 0.0
    return PageData(number, float(page.width), float(page.height), words, rot,
                    merge_segments(H), merge_segments(V), fills, body)


def find_running_text(pages):
    """Running headers/footers: text lines repeated (digits ignored) at the same height on many pages."""
    if len(pages) < 3:
        return
    key_pages = collections.defaultdict(set)
    lines_by_page = {}
    for pd in pages:
        lines = collections.defaultdict(list)
        for w in pd.words:
            if w["top"] < pd.height * 0.09 or w["bottom"] > pd.height * 0.93:
                lines[round((w["top"] + w["bottom"]) / 4)].append(w)
        lp = []
        for k, ws in lines.items():
            ws.sort(key=lambda w: w["x0"])
            txt = re.sub(r"\d+", "#", " ".join(w["text"] for w in ws))
            bb = (min(w["x0"] for w in ws), min(w["top"] for w in ws), max(w["x1"] for w in ws), max(w["bottom"] for w in ws))
            key = (txt, round(bb[1] / 3))
            key_pages[key].add(pd.number); lp.append((key, bb))
        lines_by_page[pd.number] = lp
    need = max(3, int(0.5 * len(pages)))
    for pd in pages:
        for key, bb in lines_by_page[pd.number]:
            if len(key_pages[key]) >= need:
                pd.ignore.append(bb)


def visible_words(pd: PageData):
    if not pd.ignore:
        return pd.words
    def ign(w):
        cx, cy = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
        return any(b[0] - 1 <= cx <= b[2] + 1 and b[1] - 1 <= cy <= b[3] + 1 for b in pd.ignore)
    return [w for w in pd.words if not ign(w)]


def assemble_rotated(chars):
    """Rotated text (headers): lines stack left->right for 90deg ccw text; read bottom->top."""
    if not chars:
        return ""
    ccw = sum(1 for c in chars if c["matrix"][1] > 0) >= len(chars) / 2
    size = sorted(c["size"] for c in chars)[len(chars) // 2] or 3.0
    cl = cluster_1d([c["x0"] for c in chars], max(1.0, 0.9 * size))
    centres = [c for c, _ in cl]
    lines = collections.defaultdict(list)
    for ch in chars:
        lines[min(range(len(centres)), key=lambda j: abs(centres[j] - ch["x0"]))].append(ch)
    order = sorted(lines) if ccw else sorted(lines, reverse=True)
    parts = []
    for i in order:
        cs = sorted(lines[i], key=lambda c: -c["top"] if ccw else c["top"])
        parts.append("".join(c["text"] for c in cs))
    return re.sub(r"\s+", " ", "".join(parts)).strip()


def clip_page(pd: PageData, bbox) -> PageData:
    """View of a page restricted to a horizontal strip x-range (strokes cropped, words filtered)."""
    x0, _, x1, _ = bbox
    if x0 <= 1 and x1 >= pd.width - 1:
        return pd
    hs = [(y, max(a, x0), min(b, x1)) for y, a, b in pd.hs if b > x0 and a < x1 and min(b, x1) - max(a, x0) >= MIN_STROKE]
    vs = [v for v in pd.vs if x0 - 1 <= v[0] <= x1 + 1]
    words = [w for w in pd.words if x0 <= (w["x0"] + w["x1"]) / 2 <= x1]
    rot = [c for c in pd.rot_chars if x0 <= (c["x0"] + c["x1"]) / 2 <= x1]
    fills = [f for f in pd.fills if f[2] > x0 and f[0] < x1]
    return PageData(pd.number, pd.width, pd.height, words, rot, hs, vs, fills, pd.body_size, pd.ignore)
