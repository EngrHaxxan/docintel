"""Stroke-grid table reader: row bands from horizontal strokes, columns from vertical strokes,
merged cells = places where the separating stroke is ABSENT. Generic: nothing here knows a specific document."""
from __future__ import annotations
import bisect, collections, re
from dataclasses import dataclass, field
from .geometry import PageData, cluster_1d, assemble_rotated, visible_words


@dataclass
class Block:
    r0: int; r1: int; c0: int; c1: int
    bbox: tuple
    text: str = ""
    n_words: int = 0
    bold: float = 0.0
    low_conf: bool = False


@dataclass
class PageGrid:
    page: int
    bbox: tuple
    edges: list
    bands: list
    blocks: list
    block_of: dict
    band_label: list      # text of a full-width merged block (group/title band) or ""
    band_empty: list
    band_bold: list
    band_fill: list
    top_open: list        # per column: no border at the top of the region (merged cell continuing from above)
    bottom_open: list
    n_words_in: int = 0
    n_words_total: int = 0
    n_rot: int = 0
    notes: list = field(default_factory=list)
    lead_label: str = ""

    @property
    def ncol(self): return len(self.edges) - 1
    @property
    def nb(self): return len(self.bands)


class _UF:
    def __init__(self, n): self.p = list(range(n))
    def f(self, a):
        while self.p[a] != a:
            self.p[a] = self.p[self.p[a]]; a = self.p[a]
        return a
    def u(self, a, b): self.p[self.f(a)] = self.f(b)


def _hseg_index(hs):
    idx = collections.defaultdict(list)
    return idx


def find_regions(pd: PageData, bbox, gap=90.0, min_len=8.0):
    """Candidate grid regions inside bbox (clusters of horizontal strokes that overlap in x)."""
    x0, top, x1, bot = bbox
    hs = [s for s in pd.hs if top - 1 <= s[0] <= bot + 1 and s[2] >= x0 and s[1] <= x1 and s[2] - s[1] >= min_len]
    n = len(hs)
    if n < 2:
        return []
    hs.sort()
    uf = _UF(n)
    for i in range(n):
        for j in range(i + 1, n):
            if hs[j][0] - hs[i][0] > gap:
                break
            if min(hs[i][2], hs[j][2]) - max(hs[i][1], hs[j][1]) >= 4:
                uf.u(i, j)
    comp = collections.defaultdict(list)
    for i in range(n):
        comp[uf.f(i)].append(hs[i])
    out = []
    for segs in comp.values():
        ys = cluster_1d([s[0] for s in segs], 1.2)
        if len(ys) < 2:
            continue
        rx0, rx1 = min(s[1] for s in segs), max(s[2] for s in segs)
        ry0, ry1 = min(s[0] for s in segs), max(s[0] for s in segs)
        edges = column_edges(pd, (rx0, ry0, rx1, ry1))
        if len(edges) < 3:
            continue
        out.append((rx0, ry0, rx1, ry1))
    out.sort(key=lambda b: (b[1], b[0]))
    return out


def column_edges(pd: PageData, bbox):
    x0, top, x1, bot = bbox
    xs, ws = [], []
    for x, a, b in pd.vs:
        if x0 - 2.5 <= x <= x1 + 2.5 and b >= top and a <= bot:
            xs.append(x); ws.append(min(b, bot) - max(a, top))
    cl = [(c, w) for c, w in cluster_1d(xs, 1.5, ws) if w >= max(8.0, 0.08 * (bot - top))]
    if cl:                                         # drop stray short lines (e.g. margin marks) relative to the typical edge
        med = sorted(w for _, w in cl)[len(cl) // 2]
        cl = [(c, w) for c, w in cl if w >= 0.4 * med]
    edges = [c for c, _ in cl]
    def text_between_pre(a, b):
        return any(a <= (w["x0"] + w["x1"]) / 2 <= b and top <= (w["top"] + w["bottom"]) / 2 <= bot for w in pd.words)
    i = 0
    while i < len(edges) - 1:                      # double border lines: keep the inner one, no text between
        if edges[i + 1] - edges[i] < 10 and not text_between_pre(edges[i] + 0.5, edges[i + 1] - 0.5):
            drop = i if i == 0 else (i + 1)
            if i + 1 == len(edges) - 1:
                drop = i + 1
            edges.pop(drop)
        else:
            i += 1
    def text_between(a, b):
        return any(a <= (w["x0"] + w["x1"]) / 2 <= b and top <= (w["top"] + w["bottom"]) / 2 <= bot for w in pd.words)
    if not edges or (edges[0] > x0 + 3 and (not edges or text_between(x0, edges[0] - 1))):
        edges.insert(0, x0)
    if edges[-1] < x1 - 3 and text_between(edges[-1] + 1, x1):
        edges.append(x1)
    return edges


def _has_h(hs_by_y, y, cx, tol=1.2):
    for yy, segs in hs_by_y:
        if abs(yy - y) <= tol:
            for a, b in segs:
                if a - 1 <= cx <= b + 1:
                    return True
    return False


def _has_v(vs, x, y, tol=1.6):
    for xx, a, b in vs:
        if abs(xx - x) <= tol and a - 1 <= y <= b + 1:
            return True
    return False


def build_grid(pd: PageData, bbox, extend_top=None, force_edges=None) -> PageGrid | None:
    x0, top, x1, bot = bbox
    edges = list(force_edges) if force_edges else column_edges(pd, bbox)
    if len(edges) < 3:
        return None
    def _col_has_text(a, b):
        return any(a <= (w["x0"] + w["x1"]) / 2 <= b and top <= (w["top"] + w["bottom"]) / 2 <= bot for w in visible_words(pd))
    while not force_edges and len(edges) > 3 and edges[-1] - edges[-2] < 20 and not _col_has_text(edges[-2], edges[-1]):    # empty margin strip (page frame)
        edges.pop()
    while not force_edges and len(edges) > 3 and edges[1] - edges[0] < 20 and not _col_has_text(edges[0], edges[1]):
        edges.pop(0)
    hs = [s for s in pd.hs if top - 1 <= s[0] <= bot + 1 and s[2] >= x0 and s[1] <= x1 and s[2] - s[1] >= 8]
    ys = [c for c, w in cluster_1d([s[0] for s in hs], 1.2)]
    if extend_top is not None and extend_top < ys[0] - 3:
        ys.insert(0, extend_top)
    bands = [(a, b) for a, b in zip(ys, ys[1:]) if b - a >= 2.5]
    if not bands:
        return None
    by_y = collections.defaultdict(list)
    for yy, a, b in hs:
        by_y[round(yy, 1)].append((a, b))
    hs_by_y = list(by_y.items())
    vs = [s for s in pd.vs if x0 - 2.5 <= s[0] <= x1 + 2.5 and s[2] >= top and s[1] <= bot]
    nc, nb = len(edges) - 1, len(bands)
    cx = [(edges[c] + edges[c + 1]) / 2 for c in range(nc)]
    uf = _UF(nb * nc)
    for k in range(nb):
        mid = (bands[k][0] + bands[k][1]) / 2
        for c in range(nc):
            if k > 0 and not _has_h(hs_by_y, bands[k][0], cx[c]):
                uf.u((k - 1) * nc + c, k * nc + c)
            if c > 0 and not _has_v(vs, edges[c], mid):
                uf.u(k * nc + c - 1, k * nc + c)
    comp = collections.defaultdict(list)
    for k in range(nb):
        for c in range(nc):
            comp[uf.f(k * nc + c)].append((k, c))
    blocks, block_of = [], {}
    for cells in comp.values():
        r0, r1 = min(k for k, _ in cells), max(k for k, _ in cells)
        c0, c1 = min(c for _, c in cells), max(c for _, c in cells)
        bb = (edges[c0], bands[r0][0], edges[c1 + 1], bands[r1][1])
        b = Block(r0, r1, c0, c1, bb)
        blocks.append(b)
    # a block that swallows most of the region (unbordered white space joined to everything) is background, not a cell:
    # split it into single cells so text in unbordered columns (e.g. REMARKS) still lands in the right row/column
    big = [b for b in blocks if (b.c1 - b.c0 + 1) >= 0.7 * nc and (b.r1 - b.r0 + 1) >= max(4, 0.4 * nb)]
    if big:
        for b in big:
            blocks.remove(b)
            for k in range(b.r0, b.r1 + 1):
                for c in range(b.c0, b.c1 + 1):
                    blocks.append(Block(k, k, c, c, (edges[c], bands[k][0], edges[c + 1], bands[k][1])))
    blocks.sort(key=lambda b: (b.r0, b.c0))
    # a full-width single-row block that starts with a row number and has text in several columns is a data row whose
    # vertical borders are missing, not a heading band: split it into cells
    wide = [b for b in blocks if b.c0 == 0 and b.c1 == nc - 1 and b.r0 == b.r1 and nc >= 3]
    if wide:
        vw = visible_words(pd)
        for b in wide:
            ws = [w for w in vw if b.bbox[0] <= (w["x0"] + w["x1"]) / 2 <= b.bbox[2] and b.bbox[1] <= (w["top"] + w["bottom"]) / 2 <= b.bbox[3]]
            if not ws:
                continue
            first = min(ws, key=lambda w: w["x0"])
            cols = {min(max(bisect.bisect_right(edges, (w["x0"] + w["x1"]) / 2) - 1, 0), nc - 1) for w in ws}
            if re.fullmatch(r"\d{1,5}\.?", first["text"]) and len(cols) >= 3:
                blocks.remove(b)
                for c in range(nc):
                    blocks.append(Block(b.r0, b.r0, c, c, (edges[c], b.bbox[1], edges[c + 1], b.bbox[3])))
        blocks.sort(key=lambda b: (b.r0, b.c0))
    for i, b in enumerate(blocks):
        for k in range(b.r0, b.r1 + 1):
            for c in range(b.c0, b.c1 + 1):
                block_of[(k, c)] = i
    # ---- words -> cells (by word centre)
    words = visible_words(pd)
    band_tops = [b[0] for b in bands]
    texts = collections.defaultdict(list)
    n_in = n_total = 0
    for w in words:
        cxw, cyw = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
        if not (x0 - 1 <= cxw <= x1 + 1 and bands[0][0] <= cyw <= bands[-1][1]):
            continue
        n_total += 1
        k = bisect.bisect_right(band_tops, cyw) - 1
        c = bisect.bisect_right(edges, cxw) - 1
        if 0 <= k < nb and 0 <= c < nc:
            texts[block_of[(k, min(c, nc - 1))]].append(w); n_in += 1
    rot = collections.defaultdict(list)
    for ch in pd.rot_chars:
        cxc, cyc = (ch["x0"] + ch["x1"]) / 2, (ch["top"] + ch["bottom"]) / 2
        if x0 - 1 <= cxc <= x1 + 1 and bands[0][0] <= cyc <= bands[-1][1]:
            k = bisect.bisect_right(band_tops, cyc) - 1
            c = min(bisect.bisect_right(edges, cxc) - 1, nc - 1)
            if 0 <= k < nb and 0 <= c:
                rot[block_of[(k, c)]].append(ch)
    n_rot = 0
    for i, b in enumerate(blocks):
        ws = texts.get(i, [])
        if ws:
            ws.sort(key=lambda w: (w["top"] + w["bottom"]) / 2)
            lines, cur, cy = [], [], None
            for w in ws:
                m = (w["top"] + w["bottom"]) / 2
                if cy is None or abs(m - cy) <= max(1.6, 0.55 * w["size"]):
                    cur.append(w); cy = m if cy is None else (cy + m) / 2
                else:
                    lines.append(cur); cur = [w]; cy = m
            lines.append(cur)
            txt = " ".join(" ".join(w["text"] for w in sorted(l, key=lambda w: w["x0"])) for l in lines)
            b.n_words = len(ws)
            b.bold = sum(1 for w in ws if w["bold"]) / len(ws)
            # text crossing the cell boundary is weak evidence for the column assignment
            for w in ws:
                if (w["x0"] < b.bbox[0] - 1.0 and w["x1"] > b.bbox[0] + 1.0 and (b.bbox[0] - w["x0"]) > 0.35 * (w["x1"] - w["x0"])) or \
                   (w["x1"] > b.bbox[2] + 1.0 and w["x0"] < b.bbox[2] - 1.0 and (w["x1"] - b.bbox[2]) > 0.35 * (w["x1"] - w["x0"])):
                    b.low_conf = True
        else:
            txt = ""
        if i in rot:
            rt = assemble_rotated(rot[i]); n_rot += len(rot[i])
            txt = (txt + " " + rt).strip() if txt else rt
            b.bold = max(b.bold, 1.0); b.n_words += 1
        b.text = re.sub(r"[ \t]+", " ", txt).strip()
    # ---- band descriptors
    fills = [f for f in pd.fills if f[4] is not None and f[2] >= x0 and f[0] <= x1 and f[3] >= top and f[1] <= bot]
    band_label, band_empty, band_bold, band_fill = [], [], [], []
    for k in range(nb):
        mid = (bands[k][0] + bands[k][1]) / 2
        bl = [blocks[block_of[(k, c)]] for c in range(nc)]
        uniq = {id(b): b for b in bl}.values()
        full = next((b for b in uniq if b.c0 == 0 and b.c1 == nc - 1 and b.text), None) if nc > 2 else None
        band_label.append(full.text if full and full.r0 == full.r1 == k else (full.text if full else ""))
        band_empty.append(not any(b.text for b in uniq))
        words_k = [b for b in uniq if b.text]
        tot = sum(b.n_words for b in words_k)
        band_bold.append(sum(b.bold * b.n_words for b in words_k) / tot if tot else 0.0)
        cnt = collections.Counter()
        for c in range(nc):
            for f in fills:
                if f[0] - 0.5 <= cx[c] <= f[2] + 0.5 and f[1] - 0.5 <= mid <= f[3] + 0.5:
                    cnt[tuple(round(v, 2) for v in f[4]) if isinstance(f[4], (tuple, list)) else f[4]] += 1
        band_fill.append(cnt.most_common(1)[0][0] if cnt else None)
    top_open = [not _has_h(hs_by_y, bands[0][0], cx[c]) for c in range(nc)]
    bottom_open = [not _has_h(hs_by_y, bands[-1][1], cx[c]) for c in range(nc)]
    return PageGrid(pd.number, (x0, bands[0][0], x1, bands[-1][1]), edges, bands, blocks, block_of,
                    band_label, band_empty, band_bold, band_fill, top_open, bottom_open, n_in, n_total, n_rot)


def _digit_ratio(s):
    s = re.sub(r"\s", "", s)
    return sum(ch.isdigit() for ch in s) / len(s) if s else 0.0


def _firsts(g, j):
    seen, out = set(), []
    for c in range(min(3, g.ncol)):
        i = g.block_of[(j, c)]
        if i not in seen:
            seen.add(i); out.append(g.blocks[i])
    return out


def _ntext(g, j):
    return len([b for b in {id(g.blocks[g.block_of[(j, c)]]): g.blocks[g.block_of[(j, c)]] for c in range(g.ncol)}.values() if b.text])


def _hdrlike(g, j, body_fill):
    texts = " ".join(b.text for b in {id(g.blocks[g.block_of[(j, c)]]): g.blocks[g.block_of[(j, c)]] for c in range(g.ncol)}.values())
    if any(re.fullmatch(r"\d{1,5}\.?", t) for t in [b.text for b in _firsts(g, j)]):      # a row number in the first cells = data row
        return False
    return g.band_bold[j] >= 0.5 or (g.band_fill[j] is not None and g.band_fill[j] != body_fill and _digit_ratio(texts) < 0.08)


def detect_header(g: PageGrid):
    """Return (title_text, header_band_count, first_header_band, note). Bands above the header that hold only a few merged
    text blocks (page title, logo, legend) are treated as the table's title/preamble."""
    nb = g.nb
    k, title = 0, []
    while k < nb - 1 and (g.band_empty[k] or (g.band_label[k] and not g.band_empty[k])):
        if g.band_label[k]:
            title.append(g.band_label[k])
        k += 1
    data = [j for j in range(nb) if any(re.fullmatch(r"\d{1,5}\.?", b.text) for b in _firsts(g, j))]
    body = collections.Counter(g.band_fill[j] for j in (data or [])).most_common(1)   # fill typical for DATA rows (None if the strip has none)
    if not data and nb >= 6:
        body = collections.Counter(g.band_fill[j] for j in range(nb // 2, nb)).most_common(1)
    body_fill = body[0][0] if body else None
    t = min(3, max(2, g.ncol // 3))
    if k < nb and _ntext(g, k) < t:                         # sparse start: look for a real header band further down
        for j in range(k, int(0.6 * nb) + 1):
            if j < nb and not g.band_label[j] and _ntext(g, j) >= t and _hdrlike(g, j, body_fill):
                for i in range(k, j):
                    if g.band_label[i] or any(b.text for b in {id(g.blocks[g.block_of[(i, c)]]): g.blocks[g.block_of[(i, c)]] for c in range(g.ncol)}.values()):
                        title.append(band_text_simple(g, i))
                k = j
                break
    h = 0
    while k + h < nb:
        j = k + h
        if g.band_label[j] or g.band_empty[j] or not _hdrlike(g, j, body_fill):
            break
        h += 1
    note = ""
    if h == 0 and nb - k >= 2:
        def txt(j): return " ".join(b.text for b in {id(g.blocks[g.block_of[(j, c)]]): g.blocks[g.block_of[(j, c)]] for c in range(g.ncol)}.values())
        if txt(k) and _digit_ratio(txt(k)) < 0.1 and _digit_ratio(txt(k + 1)) >= 0.1 and not any(re.fullmatch(r"\d{1,5}\.?", b.text) for b in _firsts(g, k)):
            h, note = 1, "header row assumed from the first row (no bold/fill evidence)"
    return " ".join(x for x in title if x), h, k, note


def band_text_simple(g, i):
    return " ".join(b.text for b in {id(g.blocks[g.block_of[(i, c)]]): g.blocks[g.block_of[(i, c)]] for c in range(g.ncol)}.values() if b.text)
