"""Search over the persistent index. Exact modes never use approximate matching; fuzzy is an explicit mode."""
import json, re
from dataclasses import dataclass


@dataclass
class Hit:
    file_id: int
    root: str
    path: str
    name: str
    loc: str
    kind: str
    method: str
    confidence: float
    excerpt: str
    match: str
    seg_id: int = 0
    score: float = 1.0


def _fts_phrase(t):
    return '"' + t.replace('"', '""') + '"'


def _filters(root_ids, exts, path_prefix, mtime_from, mtime_to, kinds, include_missing):
    where, args = ["r.enabled=1"], []
    if not include_missing:
        where.append("f.status!='missing'")
    if root_ids:
        where.append(f"f.root_id IN ({','.join('?' * len(root_ids))})"); args += list(root_ids)
    if exts:
        e = [x.lower().lstrip(".") for x in exts]
        where.append(f"f.ext IN ({','.join('?' * len(e))})"); args += e
    if path_prefix:
        where.append("f.abspath LIKE ? ESCAPE '\\'")
        args.append(path_prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    if mtime_from: where.append("f.mtime>=?"); args.append(mtime_from)
    if mtime_to: where.append("f.mtime<=?"); args.append(mtime_to)
    if kinds:
        where.append(f"s.kind IN ({','.join('?' * len(kinds))})"); args += list(kinds)
    return " AND ".join(where), args


def excerpt_around(text, start, end, width=90):
    a, b = max(0, start - width), min(len(text), end + width)
    ex = text[a:b].replace("\n", " ")
    return ("…" if a else "") + ex + ("…" if b < len(text) else "")


def search(db, query, mode="text", root_ids=None, exts=None, path_prefix=None, mtime_from=None, mtime_to=None,
           kinds=None, case_sensitive=False, include_tables=True, include_missing=False, limit=500,
           fuzzy_threshold=82, scope="segment"):
    """mode: text (substring/phrase) | word (whole word) | all (all terms, any order) | regex | fuzzy"""
    query = (query or "").strip()
    if not query:
        return []
    where, args = _filters(root_ids, exts, path_prefix, mtime_from, mtime_to, kinds, include_missing)
    base = ("SELECT s.id sid, s.file_id, s.loc, s.kind, s.method, s.confidence, s.text, f.abspath, f.name, r.name rname "
            "FROM segments s JOIN files f ON f.id=s.file_id JOIN roots r ON r.id=f.root_id")
    flags = 0 if case_sensitive else re.I
    hits = []

    def mk(row, m_start, m_end, matched, score=1.0):
        return Hit(row["file_id"], row["rname"], row["abspath"], row["name"], row["loc"], row["kind"], row["method"],
                   row["confidence"], excerpt_around(row["text"], m_start, m_end), matched, row["sid"], score)

    if mode in ("text", "word"):
        pat = re.escape(query)
        if mode == "word":
            pat = r"(?<![\w])" + pat + r"(?![\w])"
        rx = re.compile(pat, flags)
        if len(query) >= 3:
            sql = f"{base} WHERE s.id IN (SELECT rowid FROM seg_fts WHERE seg_fts MATCH ?) AND {where} LIMIT ?"
            rows = db.q(sql, [_fts_phrase(query)] + args + [limit * 20])
        else:
            sql = f"{base} WHERE s.text LIKE ? ESCAPE '\\' AND {where} LIMIT ?"
            rows = db.q(sql, ["%" + query.replace("%", "\\%").replace("_", "\\_") + "%"] + args + [limit * 20])
        for row in rows:
            m = rx.search(row["text"])
            if m: hits.append(mk(row, m.start(), m.end(), m.group(0)))
            if len(hits) >= limit: break
    elif mode == "all":
        terms = [t for t in re.split(r"\s+", query) if t]
        long_terms = [t for t in terms if len(t) >= 3]
        if scope == "file":
            hits = _all_in_file(db, terms, where, args, base, flags, limit, mk)
        else:
            fts = " AND ".join(_fts_phrase(t) for t in long_terms)
            if fts:
                rows = db.q(f"{base} WHERE s.id IN (SELECT rowid FROM seg_fts WHERE seg_fts MATCH ?) AND {where} LIMIT ?",
                            [fts] + args + [limit * 20])
            else:
                rows = db.q(f"{base} WHERE {where} LIMIT ?", args + [limit * 20])
            rxs = [re.compile(re.escape(t), flags) for t in terms]
            for row in rows:
                ms = [rx.search(row["text"]) for rx in rxs]
                if all(ms):
                    m = ms[0]; hits.append(mk(row, m.start(), m.end(), ", ".join(x.group(0) for x in ms)))
                if len(hits) >= limit: break
    elif mode == "regex":
        try:
            rx = re.compile(query, flags | re.M)
        except re.error as e:
            raise ValueError(f"invalid regular expression: {e}")
        rows = db.q(f"{base} WHERE {where}", args)      # full scan of filtered segments (regex cannot use trigram FTS)
        for row in rows:
            for m in rx.finditer(row["text"]):
                if m.end() > m.start():
                    hits.append(mk(row, m.start(), m.end(), m.group(0)))
                    if len(hits) >= limit: break
            if len(hits) >= limit: break
    elif mode == "fuzzy":
        from rapidfuzz import fuzz
        q = query if case_sensitive else query.lower()
        rows = db.q(f"{base} WHERE {where} LIMIT 300000", args)
        for row in rows:
            t = row["text"] if case_sensitive else row["text"].lower()
            al = fuzz.partial_ratio_alignment(q, t, score_cutoff=fuzzy_threshold)
            if al:
                hits.append(mk(row, al.dest_start, al.dest_end, row["text"][al.dest_start:al.dest_end], al.score / 100.0))
        hits.sort(key=lambda h: -h.score)
        hits = hits[:limit]
    else:
        raise ValueError("unknown search mode")

    if include_tables and mode in ("text", "word", "regex") and len(hits) < limit:
        hits += _table_hits(db, query, mode, flags, where, args, limit - len(hits), kinds)
    return hits


def _all_in_file(db, terms, where, args, base, flags, limit, mk):
    cand = None
    for t in terms:
        if len(t) >= 3:
            ids = {r[0] for r in db.q(f"SELECT DISTINCT s.file_id FROM segments s JOIN files f ON f.id=s.file_id JOIN roots r ON r.id=f.root_id "
                                      f"WHERE s.id IN (SELECT rowid FROM seg_fts WHERE seg_fts MATCH ?) AND {where}", [_fts_phrase(t)] + args)}
            cand = ids if cand is None else cand & ids
    hits = []
    for fid in sorted(cand or []):
        rows = db.q(f"{base} WHERE f.id=? AND {where}", [fid] + args)
        first = None
        for row in rows:
            m = re.search(re.escape(terms[0]), row["text"], flags)
            if m: first = (row, m); break
        if first: hits.append(mk(first[0], first[1].start(), first[1].end(), " + ".join(terms)))
        if len(hits) >= limit: break
    return hits


def _table_hits(db, query, mode, flags, where, args, room, kinds):
    """Search cells of stored tables (where-clause only references files/roots, since kinds filter returns early)."""
    if kinds or room <= 0:
        return []
    rows = db.q("SELECT t.id tid, t.file_id, t.loc, t.method, t.confidence, t.rows_json, f.abspath, f.name, r.name rname "
                "FROM tables_ t JOIN files f ON f.id=t.file_id JOIN roots r ON r.id=f.root_id WHERE " + where, args)
    pat = query if mode == "regex" else re.escape(query)
    if mode == "word":
        pat = r"(?<![\w])" + pat + r"(?![\w])"
    rx = re.compile(pat, flags)
    out = []
    for row in rows:
        data = json.loads(row["rows_json"])
        for ri, r in enumerate(data):
            for ci, cell in enumerate(r):
                m = rx.search(cell or "")
                if m:
                    out.append(Hit(row["file_id"], row["rname"], row["abspath"], row["name"],
                                   f"{row['loc']} table r{ri + 1}c{ci + 1}", "table", row["method"], row["confidence"],
                                   " | ".join(r)[:240], m.group(0), -row["tid"]))
                    if len(out) >= room:
                        return out
    return out
