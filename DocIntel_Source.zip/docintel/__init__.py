"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.5.1-m5"
