"""Persist extracted tables in the library database; corrections are stored apart from the original values."""
from __future__ import annotations
import json, time
from .model import Table, Row, Header, ENGINE_VERSION
from .values import kind_of


def _j(o):
    return json.dumps(o, ensure_ascii=False)


def is_current(db, file_id, sha256=None):
    """True when stored tables exist for this file and were made by this engine from the same content."""
    r = db.one("SELECT COUNT(*) n, MAX(extractor_version) v, MAX(file_sha256) h FROM doc_tables WHERE file_id=?", (file_id,))
    if not r or not r["n"]:
        return False
    return r["v"] == ENGINE_VERSION and (sha256 is None or r["h"] == sha256)


def delete_file_tables(db, file_id):
    db.conn.execute("DELETE FROM doc_tables WHERE file_id=?", (file_id,))
    db.conn.execute("DELETE FROM doc_sections WHERE file_id=?", (file_id,))


def save_analysis(db, file_id, analysis, sha256=None, replace=True):
    """Store sections + tables + rows + cells. Returns the new table ids. Corrections of an older extraction are dropped
    only when the content changed (replace=True re-extracts)."""
    c = db.conn
    now = time.time()
    ids = []
    try:
        if replace:
            delete_file_tables(db, file_id)
        for h in analysis.headings:
            c.execute("INSERT INTO doc_sections(file_id,page_from,page_to,title,level,bbox,detected_by,confidence) VALUES(?,?,?,?,?,?,?,?)",
                      (file_id, h.page, h.page, h.text, h.level, _j([round(v, 1) for v in h.bbox]), ", ".join(h.methods), None))
        for t in analysis.tables:
            cur = c.execute(
                "INSERT INTO doc_tables(file_id,section,section_level,title,page_from,page_to,method,quality,notes_json,headers_json,"
                "col_edges_json,bbox_json,anchor_col,has_groups,stats_json,extractor_version,file_sha256,extracted_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (file_id, t.section, t.section_level, t.title, t.page_from, t.page_to, t.method, t.quality, _j(t.quality_notes),
                 _j([{"name": h.name, "parent": h.parent, "leaf": h.leaf, "original": h.original, "flags": h.flags,
                      "renamed_from": h.renamed_from} for h in t.headers]),
                 _j(t.col_edges), _j({str(k): v for k, v in t.page_bboxes.items()}), t.anchor_col, int(t.has_groups),
                 _j(t.stats), t.engine_version, sha256, now))
            tid = cur.lastrowid
            ids.append(tid)
            for n, r in enumerate(t.rows):
                rc = c.execute("INSERT INTO table_rows(table_id,row_no,page,pages_json,bbox,group_label,anchor,flags_json) VALUES(?,?,?,?,?,?,?,?)",
                               (tid, n, r.page, _j(r.pages), _j([round(v, 1) for v in r.bbox]) if r.bbox else None, r.group, r.anchor, _j(r.flags)))
                rid = rc.lastrowid
                c.executemany("INSERT INTO table_cells(row_id,col_no,raw_orig,raw_norm,kind,flags_json) VALUES(?,?,?,?,?,?)",
                              [(rid, i, r.orig[i], r.norm[i], kind_of(r.norm[i] or r.orig[i]), _j(r.cell_flags.get(i, []))) for i in range(len(r.orig))])
        c.commit()
    except Exception:
        c.rollback()
        raise
    return ids


def list_tables(db, file_id=None):
    sql = ("SELECT t.id, t.file_id, f.name file_name, f.abspath, t.section, t.title, t.page_from, t.page_to, t.method, t.quality, "
           "(SELECT COUNT(*) FROM table_rows r WHERE r.table_id=t.id) rows, t.extractor_version "
           "FROM doc_tables t JOIN files f ON f.id=t.file_id")
    args = ()
    if file_id is not None:
        sql += " WHERE t.file_id=?"; args = (file_id,)
    return [dict(r) for r in db.q(sql + " ORDER BY f.name, t.page_from, t.id", args)]


def load_table(db, table_id, apply_corrections=True) -> Table:
    t = db.one("SELECT t.*, f.abspath FROM doc_tables t JOIN files f ON f.id=t.file_id WHERE t.id=?", (table_id,))
    if t is None:
        raise KeyError(f"table {table_id} not found")
    hs = [Header(h["name"], h.get("parent", ""), h.get("leaf", ""), h.get("original", []), h.get("flags", []), h.get("renamed_from", ""))
          for h in json.loads(t["headers_json"])]
    tbl = Table(title=t["title"] or "", section=t["section"] or "", section_level=t["section_level"] or 0, page_from=t["page_from"],
                page_to=t["page_to"], headers=hs, method=t["method"], quality=t["quality"] or 0.0,
                quality_notes=json.loads(t["notes_json"] or "[]"), col_edges=json.loads(t["col_edges_json"] or "[]"),
                has_groups=bool(t["has_groups"]), anchor_col=t["anchor_col"], stats=json.loads(t["stats_json"] or "{}"),
                source=t["abspath"], engine_version=t["extractor_version"] or "")
    tbl.page_bboxes = {int(k): tuple(v) for k, v in json.loads(t["bbox_json"] or "{}").items()}
    tbl.db_id, tbl.file_id = table_id, t["file_id"]
    tbl.hidden_cols = json.loads(t["hidden_cols"] or "[]")
    cells = {}
    for c in db.q("SELECT c.* FROM table_cells c JOIN table_rows r ON r.id=c.row_id WHERE r.table_id=? ORDER BY r.row_no, c.col_no", (table_id,)):
        cells.setdefault(c["row_id"], []).append(c)
    for r in db.q("SELECT * FROM table_rows WHERE table_id=? ORDER BY row_no", (table_id,)):
        cs = cells.get(r["id"], [])
        row = Row(r["page"], [], [], json.loads(r["flags_json"] or "[]"), {}, tuple(json.loads(r["bbox"])) if r["bbox"] else None,
                  json.loads(r["pages_json"] or "[]"), r["group_label"] or "", r["anchor"] or "")
        row.row_id, row.cell_ids, row.raw_orig, row.raw_norm = r["id"], [], [], []
        for c in cs:
            ro, rn = c["raw_orig"], c["raw_norm"]
            row.raw_orig.append(ro); row.raw_norm.append(rn); row.cell_ids.append(c["id"])
            eo = c["corrected_orig"] if apply_corrections and c["corrected_orig"] is not None else ro
            en = c["corrected_norm"] if apply_corrections and c["corrected_norm"] is not None else rn
            row.orig.append(eo); row.norm.append(en)
            fl = json.loads(c["flags_json"] or "[]")
            if c["corrected_orig"] is not None or c["corrected_norm"] is not None:
                fl = fl + ["info: corrected by user (original value kept)"]
            if c["reviewed"]:
                fl = [f for f in fl if not f.startswith("review")] + ["info: reviewed by user"]
            if fl:
                row.cell_flags[c["col_no"]] = fl
        tbl.rows.append(row)
    return tbl


def set_correction(db, table_id, row_no, col_no, value, layout="both"):
    """User correction: the original text stays in raw_*; the new value is stored apart and marks the cell reviewed."""
    cell = db.one("SELECT c.id FROM table_cells c JOIN table_rows r ON r.id=c.row_id WHERE r.table_id=? AND r.row_no=? AND c.col_no=?",
                  (table_id, row_no, col_no))
    if cell is None:
        raise KeyError("cell not found")
    sets, args = ["corrected_at=?", "reviewed=1"], [time.time()]
    if layout in ("both", "orig"):
        sets.append("corrected_orig=?"); args.append(value)
    if layout in ("both", "norm"):
        sets.append("corrected_norm=?"); args.append(value)
    db.x(f"UPDATE table_cells SET {', '.join(sets)} WHERE id=?", (*args, cell["id"]))


def clear_correction(db, table_id, row_no, col_no):
    db.x("UPDATE table_cells SET corrected_orig=NULL, corrected_norm=NULL, corrected_at=NULL WHERE id=("
         "SELECT c.id FROM table_cells c JOIN table_rows r ON r.id=c.row_id WHERE r.table_id=? AND r.row_no=? AND c.col_no=?)",
         (table_id, row_no, col_no))


def mark_reviewed(db, table_id, row_no, col_no, reviewed=True):
    db.x("UPDATE table_cells SET reviewed=? WHERE id=(SELECT c.id FROM table_cells c JOIN table_rows r ON r.id=c.row_id "
         "WHERE r.table_id=? AND r.row_no=? AND c.col_no=?)", (int(reviewed), table_id, row_no, col_no))


def rename_header(db, table_id, col_no, new_name):
    """Rename a column; the wording found in the PDF is kept in `renamed_from`."""
    r = db.one("SELECT headers_json FROM doc_tables WHERE id=?", (table_id,))
    hs = json.loads(r["headers_json"])
    if not (0 <= col_no < len(hs)):
        raise KeyError("column not found")
    if not hs[col_no].get("renamed_from"):
        hs[col_no]["renamed_from"] = hs[col_no]["name"]
    hs[col_no]["name"] = new_name
    db.x("UPDATE doc_tables SET headers_json=? WHERE id=?", (_j(hs), table_id))


def set_hidden_columns(db, table_id, cols):
    db.x("UPDATE doc_tables SET hidden_cols=? WHERE id=?", (_j(sorted(set(cols))), table_id))
