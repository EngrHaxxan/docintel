"""Simple guided screens: Home (6 big actions) and the 5-step extraction wizard. All logic lives in wizard.py (tested);
this file only draws widgets. Everything here is wrapped so a problem can never stop the classic tabs from opening."""
import json, os, queue, threading, time, traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from . import friendly, paths
from .library import JobControl
from .wizard import Session, MODES
from .tables import store

FONT = "Segoe UI"
PREVIEW_LIMIT = 3000


def _open(path):
    try:
        if os.name == "nt":
            os.startfile(path)
        else:
            import subprocess
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


# ===================================================================== Home
class HomeFrame(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master, padding=16)
        self.app = app
        ttk.Label(self, text="DocIntel", font=(FONT, 24, "bold")).pack(anchor="w")
        ttk.Label(self, text="Find information in your documents and send it to Excel. Everything stays on this computer.",
                  font=(FONT, 11)).pack(anchor="w", pady=(0, 12))
        self.summary = tk.StringVar()
        ttk.Label(self, textvariable=self.summary, font=(FONT, 10)).pack(anchor="w", pady=(0, 10))
        grid = ttk.Frame(self); grid.pack(fill="x")
        items = [("1  Add Documents", "Add folders that hold your documents.", self.add_documents),
                 ("2  Search Documents", "Look for a word, code or number in all your documents.", self.search),
                 ("3  Extract to Excel", "Guided steps: choose documents, choose what to extract, preview, export.", self.extract),
                 ("4  Review Results", "Look at tables already extracted, correct values.", self.review),
                 ("5  Export to Excel", "Export the results of your last extraction again.", self.export),
                 ("6  Extraction History", "See your previous exports.", self.history)]
        for i, (t, d, cmd) in enumerate(items):
            box = ttk.Frame(grid, padding=6); box.grid(row=i // 3, column=i % 3, sticky="nsew", padx=6, pady=6)
            grid.columnconfigure(i % 3, weight=1, uniform="home")
            b = ttk.Button(box, text=t, command=self._safe(cmd)); b.pack(fill="x", ipady=18)
            ttk.Label(box, text=d, wraplength=300, justify="left").pack(anchor="w", pady=(4, 0))
        bottom = ttk.Frame(self); bottom.pack(fill="x", pady=(18, 0))
        self.adv_btn = ttk.Button(bottom, text="Show advanced tools", command=self.toggle_advanced); self.adv_btn.pack(side="left")
        ttk.Label(bottom, text="  (settings, drives, field extraction, compare, diagnostics)").pack(side="left")
        ttk.Button(bottom, text="Saved extractions && batch jobs", command=self._safe(self.batch)).pack(side="right")
        ttk.Button(bottom, text="AI tools", command=self._safe(self.ai_tools)).pack(side="right", padx=8)
        self.ask_btn = ttk.Button(bottom, text="Ask Documents (AI)", command=self._safe(self.ask_docs))     # hidden until an AI assistant is connected
        self._bottom = bottom
        self.last_session = None

    def _safe(self, fn):
        def run():
            try:
                fn()
            except Exception as e:
                try:
                    title, msg = friendly.explain(e, "Home")
                except Exception:
                    title, msg = "Something went wrong", "Please try again. Details were saved in the log file."
                import logging
                logging.getLogger("docintel").exception("home action failed")
                messagebox.showerror(title, msg, parent=self)
        return run

    def ask_docs(self):
        AskWindow(self.app, self)

    def ai_tools(self):
        AIHubWindow(self.app, self)

    def _update_ask(self):
        try:
            on = bool(self.app.lib.ai_available())
        except Exception:
            on = False
        if on and not self.ask_btn.winfo_ismapped():
            self.ask_btn.pack(side="right", padx=8)
        elif not on and self.ask_btn.winfo_ismapped():
            self.ask_btn.pack_forget()

    def refresh(self):
        self._update_ask()
        try:
            n = self.app.lib.db.one("SELECT COUNT(*) FROM files WHERE missing_since IS NULL")[0]
            p = self.app.lib.db.one("SELECT COUNT(*) FROM files WHERE lower(ltrim(ext,'.')) IN ('pdf','docx','xlsx','xlsm','pptx','html','htm','csv','tsv') AND missing_since IS NULL")[0]
            r = len(self.app.lib.roots())
            self.summary.set(f"{r} folder(s) added  -  {n} document(s) known  -  {p} file(s) available for table extraction (PDF, Word, Excel, PowerPoint, HTML, CSV)" if r else
                             "No folders yet. Click 'Add Documents' to start.")
        except Exception:
            self.summary.set("")

    def add_documents(self):
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Add one folder...", command=self._safe(self.app.add_folder))
        m.add_command(label="Add several folders...", command=self._safe(self.app.add_many))
        m.tk_popup(self.winfo_pointerx(), self.winfo_pointery())

    def search(self):
        self.app.show_tab("Search")

    def extract(self):
        w = WizardWindow(self.app, self)
        w.focus_set()

    def review(self):
        ReviewWindow(self.app, self)

    def export(self):
        s = self.last_session
        if s is None or not s.preview:
            messagebox.showinfo("Export to Excel", "There is no extraction to export yet. Use '3  Extract to Excel' first, or '4  Review Results' to open stored tables.", parent=self)
            return
        ExportDialog(self, s)

    def history(self):
        HistoryWindow(self.app, self)

    def batch(self):
        BatchWindow(self.app, self)

    def toggle_advanced(self):
        on = self.app.toggle_advanced()
        self.adv_btn.config(text="Hide advanced tools" if on else "Show advanced tools")


# ===================================================================== preview panel (step 4 and Review Results)
class PreviewPanel(ttk.Frame):
    def __init__(self, master, session):
        super().__init__(master)
        self.s = session
        self.cur = None
        self.cell = None
        self.layout = tk.StringVar(value="norm")
        top = ttk.Frame(self); top.pack(fill="x")
        ttk.Label(top, text="Table:").pack(side="left")
        self.combo = ttk.Combobox(top, state="readonly", width=100); self.combo.pack(side="left", padx=6, fill="x", expand=True)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.show(self.combo.current()))
        lay = ttk.Frame(self); lay.pack(fill="x", pady=2)
        ttk.Radiobutton(lay, text="Normalized (merged values repeated)", variable=self.layout, value="norm", command=self.redraw).pack(side="left")
        ttk.Radiobutton(lay, text="Original layout (blank where the PDF merges cells)", variable=self.layout, value="orig", command=self.redraw).pack(side="left", padx=12)
        self.info = tk.StringVar(); ttk.Label(self, textvariable=self.info, justify="left").pack(anchor="w")
        body = ttk.Frame(self); body.pack(fill="both", expand=True)
        self.tv = ttk.Treeview(body, show="headings", selectmode="browse", height=14)
        ys = ttk.Scrollbar(body, orient="vertical", command=self.tv.yview); xs = ttk.Scrollbar(body, orient="horizontal", command=self.tv.xview)
        self.tv.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y"); xs.pack(side="bottom", fill="x"); self.tv.pack(fill="both", expand=True)
        self.tv.tag_configure("review", background="#FFE9C7"); self.tv.tag_configure("fixed", background="#DCEBFA")
        self.tv.bind("<Button-1>", self.on_click); self.tv.bind("<Double-1>", self.on_edit)
        self.detail = tk.StringVar(); ttk.Label(self, textvariable=self.detail, wraplength=1000, justify="left").pack(anchor="w", pady=2)
        bar = ttk.Frame(self); bar.pack(fill="x")
        for text, cmd in [("Correct value...", self.on_edit), ("Mark uncertain / clear", self.on_mark), ("Rename column...", self.on_rename),
                          ("Hide / show column", self.on_hide), ("Open source PDF", self.on_open)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=3, pady=3)
        self.warn = tk.StringVar(); ttk.Label(self, textvariable=self.warn, foreground="#9C5700", wraplength=1000, justify="left").pack(anchor="w")

    def load(self):
        ents = self.s.preview
        self.combo["values"] = [e.describe() for e in ents]
        if ents:
            self.combo.current(0); self.show(0)
        else:
            self.cur = None; self.tv.delete(*self.tv.get_children()); self.info.set("Nothing was found for this choice.")
        w = self.s.warnings
        self.warn.set(("Notes: " + " | ".join(w[:6]) + (" ..." if len(w) > 6 else "")) if w else "")

    def show(self, i):
        if not (0 <= i < len(self.s.preview)):
            return
        self.cur = self.s.preview[i]; self.cell = None; self.redraw()

    def redraw(self):
        e = self.cur
        if e is None:
            return
        t = e.table
        self.tv.delete(*self.tv.get_children())
        cols = [f"c{i}" for i in range(len(t.headers))]
        self.tv["columns"] = cols
        for i, h in enumerate(t.headers):
            self.tv.heading(cols[i], text=h.name); self.tv.column(cols[i], width=max(70, min(260, 9 * len(h.name) + 30)), stretch=False)
        hidden = set(getattr(t, "hidden_cols", []) or [])
        self.tv["displaycolumns"] = [c for i, c in enumerate(cols) if i not in hidden] or cols
        lay = self.layout.get()
        for n, r in enumerate(t.rows[:PREVIEW_LIMIT]):
            vals = list(r.orig if lay == "orig" else r.norm)
            tags = []
            if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl):
                tags.append("review")
            elif any("corrected by user" in f for fl in r.cell_flags.values() for f in fl):
                tags.append("fixed")
            self.tv.insert("", "end", iid=str(n), values=[v.replace("\n", " ") for v in vals], tags=tags)
        more = f"  (showing the first {PREVIEW_LIMIT} rows; the export contains all {len(t.rows)})" if len(t.rows) > PREVIEW_LIMIT else ""
        review = sum(1 for r in t.rows if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl))
        notes = ("; ".join(t.quality_notes[:3])) if t.quality_notes else "none"
        self.info.set(f"{e.label}  |  {e.heading or 'untitled table'}  |  pages {t.page_from}-{t.page_to}  |  {len(t.rows)} rows  |  method: {t.method}  |  "
                      f"quality: {t.quality:.0%}  |  rows to review: {review} (orange)  |  corrected: blue  |  notes: {notes}{more}")
        self.detail.set("Click a cell to see its full value. Double-click to correct it.")

    def _hit(self, ev):
        row = self.tv.identify_row(ev.y); col = self.tv.identify_column(ev.x)
        if not row or not col:
            return None
        disp = list(self.tv["displaycolumns"]) if self.tv["displaycolumns"] else list(self.tv["columns"])
        cols = list(self.tv["columns"])
        try:
            name = disp[int(col[1:]) - 1] if disp and disp[0] != "#all" else cols[int(col[1:]) - 1]
            return int(row), cols.index(name)
        except Exception:
            return None

    def on_click(self, ev):
        h = self._hit(ev)
        if h is None or self.cur is None:
            return
        self.cell = h
        r, c = h
        row = self.cur.table.rows[r]
        v = (row.orig if self.layout.get() == "orig" else row.norm)[c]
        fl = row.cell_flags.get(c, [])
        src = f"page {row.page}" if len(row.pages) <= 1 else f"pages {row.pages[0]}-{row.pages[-1]}"
        self.detail.set(f"[{self.cur.table.headers[c].name}]  {v}\n{src}" + (("   |   " + "; ".join(f.split(': ', 1)[-1] for f in fl)) if fl else ""))

    def on_edit(self, ev=None):
        if self.cur is None or self.cell is None:
            messagebox.showinfo("Correct value", "Click a cell first.", parent=self); return
        r, c = self.cell
        row = self.cur.table.rows[r]
        old = (row.orig if self.layout.get() == "orig" else row.norm)[c]
        new = simpledialog.askstring("Correct value", f"New value for '{self.cur.table.headers[c].name}' (row {r + 1}).\nThe original text from the PDF stays stored.", initialvalue=old, parent=self)
        if new is None or new == old:
            return
        try:
            self.s.edit_cell(self.cur, r, c, new)
        except ValueError as e:
            messagebox.showinfo("Correct value", str(e), parent=self); return
        self.redraw(); self.tv.selection_set(str(r))

    def on_mark(self):
        if self.cur is None or self.cell is None:
            return
        r, c = self.cell
        on = not any("marked uncertain" in f for f in self.cur.table.rows[r].cell_flags.get(c, []))
        self.s.mark_uncertain(self.cur, r, c, on); self.redraw()

    def on_rename(self):
        if self.cur is None or self.cell is None:
            messagebox.showinfo("Rename column", "Click a cell in the column first.", parent=self); return
        c = self.cell[1]
        h = self.cur.table.headers[c]
        new = simpledialog.askstring("Rename column", f"New name for '{h.name}':\n(the wording found in the PDF is remembered)", initialvalue=h.name, parent=self)
        if new:
            self.s.rename_column(self.cur, c, new.strip()); self.redraw()

    def on_hide(self):
        if self.cur is None or self.cell is None:
            return
        c = self.cell[1]
        self.s.hide_column(self.cur, c, c not in (self.cur.table.hidden_cols or [])); self.redraw()

    def on_open(self):
        if self.cur is not None:
            _open(self.cur.path)


# ===================================================================== wizard
class WizardWindow(tk.Toplevel):
    TITLES = ["Select documents", "What do you want to extract?", "Identify the target", "Preview and correct", "Export"]

    def __init__(self, app, home=None):
        super().__init__(app)
        self.app, self.home = app, home
        self.title("Extract to Excel"); self.geometry("1120x720"); self.minsize(900, 600)
        self.s = Session(app.lib)
        self.step = 0
        self.mode = tk.StringVar(value="all_tables")
        self.q = queue.Queue(); self.control = None; self.busy = False
        self.head = ttk.Label(self, font=(FONT, 15, "bold")); self.head.pack(anchor="w", padx=14, pady=(12, 0))
        self.body = ttk.Frame(self, padding=14); self.body.pack(fill="both", expand=True)
        nav = ttk.Frame(self, padding=(14, 0, 14, 12)); nav.pack(fill="x")
        self.msg = tk.StringVar(); ttk.Label(nav, textvariable=self.msg).pack(side="left")
        self.btn_next = ttk.Button(nav, text="Next >", command=self.next); self.btn_next.pack(side="right")
        self.btn_back = ttk.Button(nav, text="< Back", command=self.back); self.btn_back.pack(side="right", padx=6)
        self.btn_cancel = ttk.Button(nav, text="Cancel work", command=self.cancel_work, state="disabled"); self.btn_cancel.pack(side="right", padx=6)
        self.after(150, self._poll)
        self.show_step(0)

    # ---- plumbing
    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def show_step(self, n):
        self.step = n
        self.head.config(text=f"Step {n + 1} of 5:  {self.TITLES[n]}")
        self.clear(); self.msg.set("")
        getattr(self, f"step{n + 1}")()
        self.btn_back.config(state="normal" if n > 0 else "disabled")
        self.btn_next.config(text="Close" if n == 4 else "Next >")

    def back(self):
        if not self.busy and self.step > 0:
            self.show_step(self.step - 1)

    def next(self):
        if self.busy:
            return
        try:
            ok = getattr(self, f"leave{self.step + 1}", lambda: True)()
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Extraction"), parent=self); return
        if ok is False:
            return
        if self.step == 4:
            self.destroy(); return
        if ok != "wait":
            self.show_step(self.step + 1)

    def run_bg(self, label, fn, done):
        self.busy = True; self.control = JobControl(); self.btn_cancel.config(state="normal"); self.msg.set(label + " ...")
        def work():
            try:
                res = fn(self.control)
                self.q.put(("done", res, done))
            except Exception as e:
                self.q.put(("error", e, traceback.format_exc()))
        threading.Thread(target=work, daemon=True).start()

    def cancel_work(self):
        if self.control:
            self.control.cancel()

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "progress":
                    self.msg.set(m[1])
                    continue
                self.busy = False; self.btn_cancel.config(state="disabled")
                if m[0] == "done":
                    self.msg.set("")
                    m[2](m[1])
                else:
                    import logging
                    logging.getLogger("docintel").error("wizard job failed\n%s", m[2])
                    self.msg.set(""); messagebox.showerror(*friendly.explain(m[1], "Extraction"), parent=self)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass

    # ---- step 1: documents
    def step1(self):
        b = self.body
        ttk.Label(b, text="Which documents should DocIntel read?", font=(FONT, 11)).pack(anchor="w")
        self.src = tk.StringVar(value="all")
        r = ttk.Frame(b); r.pack(fill="x", pady=6)
        ttk.Radiobutton(r, text="All documents in my library", variable=self.src, value="all", command=self._src_changed).pack(anchor="w")
        ttk.Radiobutton(r, text="Only the folders selected below", variable=self.src, value="roots", command=self._src_changed).pack(anchor="w")
        mid = ttk.Frame(b); mid.pack(fill="both", expand=True)
        left = ttk.Frame(mid); left.pack(side="left", fill="y")
        ttk.Label(left, text="Folders").pack(anchor="w")
        self.roots = tk.Listbox(left, selectmode="extended", height=10, width=40, exportselection=False); self.roots.pack(fill="y")
        self._root_rows = self.app.lib.roots()
        for rr in self._root_rows:
            self.roots.insert("end", rr["name"])
        self.roots.bind("<<ListboxSelect>>", lambda e: (self.src.set("roots"), self._src_changed()))
        ttk.Button(left, text="Add a folder...", command=self._add_folder).pack(fill="x", pady=2)
        ttk.Button(left, text="Add individual PDF files...", command=self._add_files).pack(fill="x", pady=2)
        right = ttk.Frame(mid); right.pack(side="left", fill="both", expand=True, padx=12)
        ttk.Label(right, text="Selected documents (select rows and click Exclude to leave them out)").pack(anchor="w")
        self.docs = tk.Listbox(right, selectmode="extended", height=14, exportselection=False); self.docs.pack(fill="both", expand=True)
        ttk.Button(right, text="Exclude selected documents", command=self._exclude).pack(anchor="w", pady=2)
        self.count = tk.StringVar(); ttk.Label(b, textvariable=self.count, font=(FONT, 11, "bold")).pack(anchor="w", pady=6)
        self._src_changed()

    def _src_changed(self):
        if self.src.get() == "roots":
            ids = [self._root_rows[i]["id"] for i in self.roots.curselection()]
            self.s.select_roots(ids) if ids else self.s.select_files([])
        else:
            self.s.select_all()
        self._refresh_docs()

    def _refresh_docs(self):
        self.docs.delete(0, "end"); self._doc_keys = []
        by = {f["id"]: f for f in self.s.pdf_files()}
        for i in self.s.file_ids:
            if i in by:
                self.docs.insert("end", by[i]["name"]); self._doc_keys.append(i)
        for p in self.s.adhoc:
            self.docs.insert("end", os.path.basename(p) + "   (individual file)"); self._doc_keys.append(p)
        for k in range(len(self._doc_keys)):
            if self._doc_keys[k] in self.s.excluded:
                self.docs.itemconfig(k, foreground="#999999")
        self.count.set(f"{self.s.selected_count()} document(s) selected" + ("   (only PDF files can be read for tables right now)" if self.s.selected_count() == 0 else ""))

    def _exclude(self):
        for i in self.docs.curselection():
            self.s.exclude(self._doc_keys[i])
        self._refresh_docs()

    def _add_folder(self):
        p = filedialog.askdirectory(title="Choose a folder to add", parent=self)
        if p:
            try:
                self.app.lib.add_root(p); self.app.lib.scan()
            except ValueError as e:
                messagebox.showinfo("Folder", "That folder is already in DocIntel." if "already" in str(e) else "That folder could not be added.", parent=self)
            self.show_step(0)

    def _add_files(self):
        ps = filedialog.askopenfilenames(title="Choose PDF files", filetypes=[("PDF files", "*.pdf")], parent=self)
        if ps:
            self.s.add_adhoc(list(ps)); self._refresh_docs()

    def leave1(self):
        if self.s.selected_count() == 0:
            messagebox.showinfo("Select documents", "Choose at least one PDF document first.", parent=self); return False
        return True

    # ---- step 2: what to extract
    def step2(self):
        ttk.Label(self.body, text="Choose one:", font=(FONT, 11)).pack(anchor="w", pady=(0, 6))
        for key, title, desc in MODES:
            f = ttk.Frame(self.body); f.pack(fill="x", pady=3)
            ttk.Radiobutton(f, text=title, variable=self.mode, value=key, width=34).pack(side="left")
            ttk.Label(f, text=desc).pack(side="left")

    # ---- step 3: identify target (reads the documents first)
    def leave2(self):
        self.run_bg("Reading documents", lambda ctl: self.s.prepare(progress=lambda i, n, name: self.q.put(("progress", f"Reading {i} of {n}: {name}")), control=ctl), self._prepared)
        return "wait"

    def _prepared(self, cat):
        self.show_step(2)

    def step3(self):
        b, mode = self.body, self.mode.get()
        found = len(self.s.catalog)
        bad = [(k, v[1]) for k, v in self.s.status.items() if v[0] in ("failed", "unsupported", "no_tables", "partial")]
        ttk.Label(b, text=f"{found} table(s) found in {len(self.s.status) or self.s.selected_count()} document(s)." + (f"  {len(bad)} document(s) need attention (see below)." if bad else ""),
                  font=(FONT, 11, "bold")).pack(anchor="w")
        self.p = {}
        if mode == "all_tables":
            ttk.Label(b, text="All tables will be extracted. Click Next to preview them.").pack(anchor="w", pady=6)
        elif mode == "table":
            self.tbl_list = tk.Listbox(b, selectmode="extended", height=12, exportselection=False); self.tbl_list.pack(fill="both", expand=True, pady=4)
            for e in self.s.catalog:
                self.tbl_list.insert("end", e.describe())
            ttk.Label(b, text="Select one or more tables.").pack(anchor="w")
            row = ttk.Frame(b); row.pack(fill="x", pady=4)
            ttk.Label(row, text="Not sure which? Describe what you need:").pack(side="left")
            self.sq = tk.StringVar(); ttk.Entry(row, textvariable=self.sq, width=48).pack(side="left", padx=6)
            ttk.Button(row, text="Suggest tables", command=self._suggest).pack(side="left")
            self.sug = tk.StringVar(); ttk.Label(b, textvariable=self.sug, wraplength=900, justify="left").pack(anchor="w")
            ttk.Button(b, text="My table is not in the list - select it by hand...", command=self._manual).pack(anchor="w", pady=6)
        elif mode in ("section", "records", "fields"):
            self._heading_picker(b, optional=(mode != "section"))
            if mode == "records":
                row = ttk.Frame(b); row.pack(fill="x", pady=4); ttk.Label(row, text="Show only rows containing:").pack(side="left")
                self.p["text"] = tk.StringVar(); ttk.Entry(row, textvariable=self.p["text"], width=40).pack(side="left", padx=6)
            if mode == "fields":
                self._field_picker(b)
        elif mode == "text":
            ttk.Label(b, text="The text of every page will be listed, one row per page. (Documents must be indexed first.)").pack(anchor="w", pady=6)
        elif mode == "custom":
            ttk.Label(b, text="Describe what you want, for example: Extract every issue from the Issues & Concerns section, including description, urgency, owner and status.", wraplength=900).pack(anchor="w")
            self.req = tk.Text(b, height=4, wrap="word"); self.req.pack(fill="x", pady=4)
            ttk.Button(b, text="Understand my request", command=self._parse_req).pack(anchor="w")
            self.req_out = tk.StringVar(); ttk.Label(b, textvariable=self.req_out, wraplength=900, justify="left").pack(anchor="w", pady=4)
            self._heading_picker(b, optional=True)
        if bad:
            ttk.Label(b, text="Documents that need attention:", font=(FONT, 10, "bold")).pack(anchor="w", pady=(8, 0))
            t = tk.Text(b, height=4, wrap="word"); t.pack(fill="x"); t.insert("1.0", "\n".join(f"{k}: {m}" for k, m in bad)); t.config(state="disabled")

    def _suggest(self):
        res = self.s.discover(self.sq.get())
        if not res:
            self.sug.set("Nothing matched that description. Try other words (column titles, section names) or select the table by hand."); return
        best = res[0]; idx = {id(e): i for i, e in enumerate(self.s.catalog)}
        self.tbl_list.selection_clear(0, "end")
        for e in best["entries"]:
            self.tbl_list.selection_set(idx[id(e)])
        self.sug.set(f"Best match: {best['tables']} table(s) in {best['documents']} document(s), columns: " + ", ".join(best["headers"][:9]) +
                     ("  (matched: " + ", ".join(best["matched_columns"]) + ")" if best["matched_columns"] else "") +
                     (f".  {len(res) - 1} other layout(s) also look possible." if len(res) > 1 else "") + "  They are selected in the list - change the selection if needed.")

    def _manual(self):
        files = self.s.pdf_files() if hasattr(self.s, "pdf_files") else []
        files = [f for f in files if str(f["abspath"]).lower().endswith(".pdf")] if files else []
        if not files:
            messagebox.showinfo("Select by hand", "Select at least one PDF document in step 1 first.", parent=self); return
        dlg = tk.Toplevel(self); dlg.title("Which document?"); dlg.geometry("520x360")
        lb = tk.Listbox(dlg, exportselection=False); lb.pack(fill="both", expand=True, padx=8, pady=8)
        for f in files:
            lb.insert("end", f["name"])
        def go():
            sel = lb.curselection()
            if not sel:
                return
            f = files[sel[0]]; dlg.destroy()
            ManualTableWindow(self.app, f["abspath"], f["id"], on_saved=self._manual_saved)
        ttk.Button(dlg, text="Open", command=go).pack(pady=6)

    def _manual_saved(self):
        try:
            self.s.prepare()
        except Exception:
            pass
        self.show_step(3)

    def _heading_picker(self, b, optional):
        self._hs = self.s.headings()
        ttk.Label(b, text="Section headings found (select the ones you want" + (" - leave empty for all):" if optional else "):")).pack(anchor="w", pady=(8, 0))
        row = ttk.Frame(b); row.pack(fill="x")
        ttk.Label(row, text="Type a name to find similar headings:").pack(side="left")
        self.hq = tk.StringVar(); e = ttk.Entry(row, textvariable=self.hq, width=34); e.pack(side="left", padx=6)
        ttk.Button(row, text="Find", command=self._find_heading).pack(side="left")
        self.hlist = tk.Listbox(b, selectmode="extended", height=7, exportselection=False); self.hlist.pack(fill="x", pady=4)
        for h in self._hs:
            self.hlist.insert("end", f"{h['heading']}   -   in {h['documents']} document(s), {h['tables']} table(s)")
        self.hnote = tk.StringVar(); ttk.Label(b, textvariable=self.hnote, foreground="#9C5700").pack(anchor="w")

    def _find_heading(self):
        q = self.hq.get().strip()
        if not q:
            return
        c = self.s.candidates(q)
        self.hlist.selection_clear(0, "end")
        names = [h["heading"] for h in self._hs]
        for x in c:
            if x["heading"] in names:
                self.hlist.selection_set(names.index(x["heading"]))
        self.hnote.set(("Similar headings are selected: " + ", ".join(f"{x['heading']} ({x['score']:.0f}% match)" for x in c[:4]) + ".  Please check they are what you mean.") if c else "No similar heading found.")

    def _field_picker(self, b):
        names = {}
        for e in self.s.catalog:
            for h in e.table.headers:
                names[h.name] = names.get(h.name, 0) + 1
        self._fields = sorted(names, key=lambda n: (-names[n], n))
        ttk.Label(b, text="Columns (select the ones you want; you can also type a name that is not in the list):").pack(anchor="w", pady=(8, 0))
        self.flist = tk.Listbox(b, selectmode="extended", height=7, exportselection=False); self.flist.pack(fill="x")
        for n in self._fields:
            self.flist.insert("end", f"{n}   ({names[n]} table(s))")
        row = ttk.Frame(b); row.pack(fill="x", pady=3); ttk.Label(row, text="Extra field names (comma separated):").pack(side="left")
        self.p["extra"] = tk.StringVar(); ttk.Entry(row, textvariable=self.p["extra"], width=50).pack(side="left", padx=6)

    def _parse_req(self):
        from .wizard import parse_request
        r = parse_request(self.req.get("1.0", "end"), [h["heading"] for h in self.s.headings()])
        self.req_out.set(f"Section: {r['section'] or '(not recognised)'}    Fields: {', '.join(r['fields']) or '(all columns)'}"
                         + (f"    Rows containing: {r['filter']}" if r["filter"] else "") + "\nChange the heading selection below if this is not what you meant.")
        if r["section"]:
            names = [h["heading"] for h in self._hs]
            self.hlist.selection_clear(0, "end")
            if r["section"] in names:
                self.hlist.selection_set(names.index(r["section"]))

    def _chosen_headings(self):
        return [self._hs[i]["heading"] for i in self.hlist.curselection()] if hasattr(self, "hlist") else []

    def leave3(self):
        mode = self.mode.get()
        if mode == "table":
            idx = list(self.tbl_list.curselection())
            if not idx:
                messagebox.showinfo("Identify the target", "Select at least one table.", parent=self); return False
            self.s.build("table", indices=idx)
        elif mode == "section":
            hs = self._chosen_headings()
            if not hs:
                messagebox.showinfo("Identify the target", "Select the section heading you want.", parent=self); return False
            self.s.build("section", headings=hs)
        elif mode == "records":
            t = self.p["text"].get().strip()
            if not t:
                messagebox.showinfo("Identify the target", "Type the word or phrase to look for.", parent=self); return False
            self.s.build("records", text=t, headings=self._chosen_headings() or None)
        elif mode == "fields":
            sel = [self._fields[i] for i in self.flist.curselection()]
            extra = [x.strip() for x in self.p["extra"].get().split(",") if x.strip()]
            if not sel and not extra:
                messagebox.showinfo("Identify the target", "Select at least one column.", parent=self); return False
            self.s.build("fields", fields=sel + extra, headings=self._chosen_headings() or None)
        elif mode == "custom":
            txt = self.req.get("1.0", "end").strip()
            if not txt:
                messagebox.showinfo("Identify the target", "Type what you want.", parent=self); return False
            hs = self._chosen_headings()
            self.s.build("custom", text=txt, **({"section": hs} if hs else {}))
        elif mode == "text":
            self.s.build("text")
        else:
            self.s.build("all_tables")
        return True

    # ---- step 4: preview
    def step4(self):
        self.panel = PreviewPanel(self.body, self.s); self.panel.pack(fill="both", expand=True)
        self.panel.load()
        if self.home is not None:
            self.home.last_session = self.s

    def leave4(self):
        if not self.s.preview:
            messagebox.showinfo("Preview", "Nothing to export. Go back and choose something else.", parent=self); return False
        if self.home is not None:
            self.home.last_session = self.s
        n = self.s.review_count()
        if n and not messagebox.askyesno("Rows need review", f"{n} row(s) are marked for review (orange). Export anyway?", parent=self):
            return False
        return True

    # ---- step 5: export
    def step5(self):
        ExportPanel(self.body, self.s, self).pack(fill="both", expand=True)
        bar = ttk.Frame(self.body); bar.pack(fill="x", pady=(6, 0))
        ttk.Button(bar, text="Save these choices as a reusable extraction...", command=self.save_profile).pack(side="left")
        ttk.Label(bar, text="  (then run it on hundreds of reports from 'Saved extractions && batch jobs' on the Home screen)").pack(side="left")

    def save_profile(self):
        from . import batch
        name = simpledialog.askstring("Save extraction", "Give this extraction a name (for example: Daily report - Construction):", parent=self)
        if not name or not name.strip():
            return
        try:
            p = batch.profile_from_session(self.s, name.strip())
            batch.save_profile(self.app.lib.db, p)
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Save extraction"), parent=self); return
        messagebox.showinfo("Saved", "Saved. It looks for the section or table by name, so it works on other documents too (page numbers are not used).", parent=self)

    def selftest(self):
        """Used by the automated Windows smoke test: draw every step with an empty selection; return True if nothing raised."""
        for n in range(5):
            self.show_step(n)
        self.show_step(0)
        return True


class ExportPanel(ttk.Frame):
    def __init__(self, master, session, owner):
        super().__init__(master)
        self.s, self.owner = session, owner
        n = sum(len(e.table.rows) for e in session.preview)
        ttk.Label(self, text=f"{len(session.preview)} table(s), {n} row(s) from {len({e.label for e in session.preview})} document(s) will be exported.", font=(FONT, 11, "bold")).pack(anchor="w")
        self.fmt = tk.StringVar(value="xlsx"); self.arr = tk.StringVar(value=session.suggest_arrangement() if session.preview else "per_table")
        self.lay_norm = tk.BooleanVar(value=True); self.lay_orig = tk.BooleanVar(value=False)
        self.val = tk.StringVar(value="raw"); self.hdr = tk.StringVar(value="joined"); self.src = tk.BooleanVar(value=True)
        def group(title):
            f = ttk.LabelFrame(self, text=title, padding=6); f.pack(fill="x", pady=4); return f
        f = group("File type")
        ttk.Radiobutton(f, text="Excel workbook (.xlsx)", variable=self.fmt, value="xlsx").pack(anchor="w")
        ttk.Radiobutton(f, text="CSV files (one per table)", variable=self.fmt, value="csv").pack(anchor="w")
        f = group("Arrangement (Excel)")
        ttk.Radiobutton(f, text="Stack tables with the same columns together (best for many reports)", variable=self.arr, value="stacked").pack(anchor="w")
        ttk.Radiobutton(f, text="Everything in ONE worksheet (all tables, columns merged by name) - best for filtering", variable=self.arr, value="single_sheet").pack(anchor="w")
        ttk.Radiobutton(f, text="One worksheet per table", variable=self.arr, value="per_table").pack(anchor="w")
        ttk.Radiobutton(f, text="One Excel file per document", variable=self.arr, value="per_document_files").pack(anchor="w")
        f = group("Layout")
        ttk.Checkbutton(f, text="Normalized (merged cells repeated on every row - best for filtering)", variable=self.lay_norm).pack(anchor="w")
        ttk.Checkbutton(f, text="Original layout (blank where the PDF merges cells)", variable=self.lay_orig).pack(anchor="w")
        self.grp_rows = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Original layout: show the PDF's merged heading bands (e.g. CATEGORY ...) as their own rows", variable=self.grp_rows).pack(anchor="w")
        f = group("Values and columns")
        ttk.Radiobutton(f, text="Exact text as in the document (recommended: keeps 001, 65%, 01.02 unchanged)", variable=self.val, value="raw").pack(anchor="w")
        ttk.Radiobutton(f, text="Convert clear numbers, percentages and dates to Excel values (exact text kept on a second sheet)", variable=self.val, value="typed").pack(anchor="w")
        ttk.Radiobutton(f, text="Full column names (e.g. Progress % / 07-Oct-2026)", variable=self.hdr, value="joined").pack(anchor="w")
        ttk.Radiobutton(f, text="Short column names (lowest header level only, when unique)", variable=self.hdr, value="leaf").pack(anchor="w")
        ttk.Checkbutton(f, text="Add source columns (file, page, section, review notes)", variable=self.src).pack(anchor="w")
        self.big = ttk.Button(self, text="Export to Excel", command=self.go); self.big.pack(pady=10, ipadx=30, ipady=10)
        self.result = tk.StringVar(); ttk.Label(self, textvariable=self.result, wraplength=900, justify="left").pack(anchor="w")

    def go(self):
        s = self.s
        layouts = tuple(x for x, v in (("norm", self.lay_norm.get()), ("orig", self.lay_orig.get())) if v) or ("norm",)
        fmt, arr = self.fmt.get(), self.arr.get()
        stamp = time.strftime("%Y-%m-%d_%H%M")
        if fmt == "csv" or arr == "per_document_files":
            path = filedialog.askdirectory(title="Choose a folder for the exported files", parent=self.winfo_toplevel())
            if path:
                path = os.path.join(path, f"DocIntel export {stamp}")
        else:
            path = filedialog.asksaveasfilename(title="Save the Excel file", defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")],
                                                initialfile=f"DocIntel extraction {stamp}.xlsx", parent=self.winfo_toplevel())
        if not path:
            return
        try:
            files = s.export(path, fmt=fmt, arrangement=arr, layouts=layouts, value_mode=self.val.get(), header_style=self.hdr.get(), include_source=self.src.get(), group_rows=self.grp_rows.get())
        except PermissionError:
            messagebox.showerror("Export", "The file could not be written. If it is open in Excel, close it and try again.", parent=self.winfo_toplevel()); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Export"), parent=self.winfo_toplevel()); return
        self.result.set(f"Done. {len(files)} file(s) written:\n" + "\n".join(files[:5]))
        if messagebox.askyesno("Export finished", "Open the folder with the exported file(s)?", parent=self.winfo_toplevel()):
            _open(os.path.dirname(files[0]) if os.path.isfile(files[0]) else files[0])


class ExportDialog(tk.Toplevel):
    def __init__(self, master, session):
        super().__init__(master)
        self.title("Export to Excel"); self.geometry("820x620")
        ExportPanel(self, session, self).pack(fill="both", expand=True, padx=12, pady=12)


# ===================================================================== review stored tables
class ReviewWindow(tk.Toplevel):
    def __init__(self, app, home):
        super().__init__(app)
        self.title("Review Results"); self.geometry("1150x700")
        self.app, self.home = app, home
        self.s = Session(app.lib)
        top = ttk.Frame(self, padding=8); top.pack(fill="x")
        ttk.Label(top, text="Tables already extracted. Choose one or more, then click Open.").pack(side="left")
        self.lb = tk.Listbox(self, selectmode="extended", height=8, exportselection=False); self.lb.pack(fill="x", padx=8)
        self.rows = store.list_tables(app.lib.db)
        for r in self.rows:
            self.lb.insert("end", f"{r['file_name']} | {r['section'] or r['title'] or 'untitled'} | pages {r['page_from']}-{r['page_to']} | {r['rows']} rows")
        if not self.rows:
            self.lb.insert("end", "No stored tables yet. Use '3  Extract to Excel' first.")
        ttk.Button(self, text="Open selected", command=self.open).pack(anchor="w", padx=8, pady=4)
        self.panel = PreviewPanel(self, self.s); self.panel.pack(fill="both", expand=True, padx=8, pady=4)

    def open(self):
        from .wizard import Entry
        ents = []
        for i in self.lb.curselection():
            if i < len(self.rows):
                r = self.rows[i]
                ents.append(Entry(r["file_name"], r["abspath"], store.load_table(self.app.lib.db, r["id"]), r["id"], r["file_id"]))
        self.s.preview = ents; self.s.warnings = []
        self.panel.load()
        self.home.last_session = self.s


class HistoryWindow(tk.Toplevel):
    def __init__(self, app, home):
        super().__init__(app)
        self.title("Extraction History"); self.geometry("980x460")
        cols = ("When", "What", "Tables", "Rows", "Documents", "File")
        self.tv = ttk.Treeview(self, columns=cols, show="headings", height=14)
        for c, w in zip(cols, (140, 130, 60, 70, 90, 440)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=8, pady=8)
        self.items = {}
        for r in app.lib.db.q("SELECT id, ts, target, audit_json FROM exports ORDER BY ts DESC LIMIT 500"):
            try:
                a = json.loads(r["audit_json"] or "{}")
            except Exception:
                a = {}
            what = a.get("mode") or "field export"
            iid = self.tv.insert("", "end", values=(time.strftime("%Y-%m-%d %H:%M", time.localtime(r["ts"] or 0)), what, a.get("tables", ""), a.get("rows", ""), a.get("documents", ""), r["target"]))
            self.items[iid] = r["target"]
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bar, text="Open file / folder", command=self.open).pack(side="left")
        ttk.Button(bar, text="Batch jobs...", command=lambda: BatchWindow(app, home)).pack(side="left", padx=8)
        if not self.items:
            ttk.Label(bar, text="  Nothing exported yet.").pack(side="left")

    def open(self):
        sel = self.tv.selection()
        if sel and os.path.exists(self.items[sel[0]]):
            _open(self.items[sel[0]])
        else:
            messagebox.showinfo("Open", "That file no longer exists.", parent=self)


# ===================================================================== saved extractions + batch jobs (Milestone 4)
ARRANGEMENTS = [("Stack tables with the same columns together", "stacked"), ("Everything in ONE worksheet", "single_sheet"),
                ("One worksheet per table", "per_table"), ("One Excel file per document", "per_document_files")]
LAYOUTS = [("Normalized (merged cells repeated)", ["norm"]), ("Original layout (blanks where merged)", ["orig"]), ("Both", ["norm", "orig"])]


def _split(txt):
    return [x.strip() for x in (txt or "").split(",") if x.strip()]


class ProfileDialog(tk.Toplevel):
    """Create or edit a saved extraction. Plain words only: which section / table, which columns, how to export."""
    def __init__(self, master, profile, on_save):
        super().__init__(master)
        from . import batch
        self.batch, self.on_save, self.p = batch, on_save, batch.normalize_profile(profile)
        self.title("Saved extraction"); self.geometry("760x560")
        f = ttk.Frame(self, padding=12); f.pack(fill="both", expand=True)
        P = self.p
        self.v = {k: tk.StringVar(value=val) for k, val in (
            ("name", P["name"]), ("heading", P["section"]["heading"]), ("aliases", ", ".join(P["section"]["aliases"])),
            ("headers", ", ".join(P["table"]["headers"])), ("fields", ", ".join(P["fields"])), ("filter", P["text_filter"]),
            ("request", P["request"]))}
        rows = [("Name", "name", "The name you will pick later."),
                ("Section heading", "heading", "Example: Construction Activities. Leave empty to search by column names instead."),
                ("Other headings that mean the same", "aliases", "Comma separated. Headings you confirmed as identical."),
                ("Column names of the table", "headers", "Optional, comma separated. Finds the table whose columns match, in any document and on any page."),
                ("Only these columns", "fields", "Optional, comma separated. Empty = all columns."),
                ("Only rows containing", "filter", "Optional word or phrase."),
                ("Or describe it in words", "request", "Optional, used only when no heading or column names are given.")]
        for i, (lab, key, hint) in enumerate(rows):
            ttk.Label(f, text=lab).grid(row=2 * i, column=0, sticky="w", pady=(6, 0))
            ttk.Entry(f, textvariable=self.v[key], width=70).grid(row=2 * i, column=1, sticky="we", pady=(6, 0))
            ttk.Label(f, text=hint, foreground="#555").grid(row=2 * i + 1, column=1, sticky="w")
        f.columnconfigure(1, weight=1)
        o = P["output"]
        r = 2 * len(rows)
        self.arr = tk.StringVar(value=next((l for l, c in ARRANGEMENTS if c == o["arrangement"]), ARRANGEMENTS[0][0]))
        self.lay = tk.StringVar(value=next((l for l, c in LAYOUTS if c == o["layouts"]), LAYOUTS[0][0]))
        self.val = tk.StringVar(value="Exact text as in the document" if o["value_mode"] == "raw" else "Convert clear numbers and dates")
        for j, (lab, var, vals) in enumerate((("Excel arrangement", self.arr, [l for l, _ in ARRANGEMENTS]), ("Layout", self.lay, [l for l, _ in LAYOUTS]),
                                              ("Values", self.val, ["Exact text as in the document", "Convert clear numbers and dates"]))):
            ttk.Label(f, text=lab).grid(row=r + j, column=0, sticky="w", pady=(8, 0))
            ttk.Combobox(f, textvariable=var, values=vals, state="readonly", width=48).grid(row=r + j, column=1, sticky="w", pady=(8, 0))
        bar = ttk.Frame(self, padding=12); bar.pack(fill="x")
        ttk.Button(bar, text="Save", command=self.save).pack(side="right")
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right", padx=6)

    def save(self):
        v = {k: x.get().strip() for k, x in self.v.items()}
        P = self.p
        P["name"], P["request"], P["text_filter"] = v["name"], v["request"], v["filter"]
        P["section"] = {"heading": v["heading"], "aliases": _split(v["aliases"])}
        P["table"]["headers"], P["fields"] = _split(v["headers"]), _split(v["fields"])
        P["output"]["arrangement"] = dict(ARRANGEMENTS).get(self.arr.get(), "stacked")
        P["output"]["layouts"] = dict(LAYOUTS).get(self.lay.get(), ["norm"])
        P["output"]["value_mode"] = "raw" if self.val.get().startswith("Exact") else "typed"
        try:
            self.batch.save_profile(self.master.app.lib.db, P)
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Save extraction"), parent=self); return
        self.on_save(); self.destroy()


class BatchWindow(tk.Toplevel):
    """Saved extractions (left) and batch jobs (right/bottom): run on many documents, see what worked, retry, add new documents, export."""
    def __init__(self, app, home=None):
        super().__init__(app)
        from . import batch
        self.batch, self.app, self.home = batch, app, home
        self.runner = batch.BatchRunner(app.lib)
        self.title("Saved extractions and batch jobs"); self.geometry("1150x760")
        self.q = queue.Queue(); self.control = None; self.busy = False
        top = ttk.LabelFrame(self, text="1. Saved extractions", padding=8); top.pack(fill="x", padx=10, pady=(10, 4))
        self.lb = tk.Listbox(top, height=6, exportselection=False); self.lb.pack(side="left", fill="x", expand=True)
        bt = ttk.Frame(top); bt.pack(side="left", padx=8)
        for t, c in (("Run on documents...", self.run_profile), ("New...", self.new_profile), ("Edit...", self.edit_profile), ("Delete", self.del_profile)):
            ttk.Button(bt, text=t, command=c).pack(fill="x", pady=1)
        mid = ttk.LabelFrame(self, text="2. Batch jobs", padding=8); mid.pack(fill="both", expand=True, padx=10, pady=4)
        cols = ("Job", "When", "Saved extraction", "State", "Result")
        self.tv = ttk.Treeview(mid, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (50, 130, 220, 90, 600)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True)
        bar = ttk.Frame(mid); bar.pack(fill="x", pady=(6, 0))
        for t, c in (("Show documents", self.show_docs), ("Export to Excel", self.export_job), ("Retry failed", self.retry),
                     ("Add new documents", self.add_new), ("Continue", self.resume), ("Delete job", self.del_job)):
            ttk.Button(bar, text=t, command=c).pack(side="left", padx=(0, 6))
        nav = ttk.Frame(self, padding=(10, 0, 10, 10)); nav.pack(fill="x")
        self.msg = tk.StringVar(); ttk.Label(nav, textvariable=self.msg).pack(side="left")
        self.btn_cancel = ttk.Button(nav, text="Cancel work", command=self.cancel, state="disabled"); self.btn_cancel.pack(side="right")
        self.profiles, self.jobs = [], []
        self.reload()
        self.after(150, self._poll)

    # ---- lists
    def reload(self):
        self.profiles = self.batch.list_profiles(self.app.lib.db)
        self.lb.delete(0, "end")
        for p in self.profiles:
            self.lb.insert("end", ("(example)  " if p.get("_starter") else "") + p["name"])
        for i in self.tv.get_children():
            self.tv.delete(i)
        self.jobs = self.runner.list_jobs()
        for j in self.jobs:
            self.tv.insert("", "end", values=(j["id"], time.strftime("%Y-%m-%d %H:%M", time.localtime(j["started"] or 0)), j["profile_name"] or j["title"],
                                              {"done": "Finished", "cancelled": "Stopped", "running": "Unfinished", "interrupted": "Interrupted"}.get(j["status"], j["status"]),
                                              self.runner.summary_text(j["id"])))

    def _profile(self):
        sel = self.lb.curselection()
        if not sel:
            messagebox.showinfo("Saved extractions", "Choose a saved extraction in the list first.", parent=self); return None
        return self.profiles[sel[0]]

    def _job(self):
        sel = self.tv.selection()
        if not sel:
            messagebox.showinfo("Batch jobs", "Choose a job in the list first.", parent=self); return None
        return int(self.tv.item(sel[0])["values"][0]) if isinstance(self.tv.item(sel[0]), dict) else None

    # ---- background plumbing
    def run_bg(self, label, fn, done=None):
        if self.busy:
            return
        self.busy = True; self.control = JobControl(); self.btn_cancel.config(state="normal"); self.msg.set(label + " ...")
        def prog(i, n, name):
            self.q.put((("progress", f"{label}: {i} of {n}  -  {name}"),))
        def work():
            try:
                self.q.put((("done", fn(self.control, prog), done),))
            except Exception as e:
                import logging
                logging.getLogger("docintel").exception("batch window job failed")
                self.q.put((("error", e),))
        threading.Thread(target=work, daemon=True).start()

    def cancel(self):
        if self.control:
            self.control.cancel()

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()[0]
                if m[0] == "progress":
                    self.msg.set(m[1]); continue
                self.busy = False; self.btn_cancel.config(state="disabled"); self.msg.set("")
                if m[0] == "done":
                    self.reload()
                    if m[2]:
                        m[2](m[1])
                else:
                    messagebox.showerror(*friendly.explain(m[1], "Batch extraction"), parent=self)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass

    # ---- saved extractions
    def new_profile(self):
        ProfileDialog(self, self.batch.new_profile(""), self.reload)

    def edit_profile(self):
        p = self._profile()
        if p:
            p = dict(p); p.pop("_starter", None)
            ProfileDialog(self, p, self.reload)

    def del_profile(self):
        p = self._profile()
        if p and not p.get("_starter") and messagebox.askyesno("Delete", f"Delete the saved extraction '{p['name']}'? Finished jobs are kept.", parent=self):
            self.batch.delete_profile(self.app.lib.db, p["name"]); self.reload()
        elif p and p.get("_starter"):
            messagebox.showinfo("Example", "This is a built-in example. Use 'Edit...' to save your own copy.", parent=self)

    def run_profile(self):
        p = self._profile()
        if not p:
            return
        roots = self.app.lib.roots()
        if not roots:
            messagebox.showinfo("Run", "Add a folder of documents first ('Add Documents' on the Home screen).", parent=self); return
        dlg = tk.Toplevel(self); dlg.title("Which folders?"); dlg.geometry("560x340")
        ttk.Label(dlg, text=f"Run '{p['name']}' on the documents of these folders:", padding=8).pack(anchor="w")
        lb = tk.Listbox(dlg, selectmode="extended", exportselection=False); lb.pack(fill="both", expand=True, padx=8)
        for r in roots:
            lb.insert("end", f"{r['name']}   ({r['path']})")
        lb.select_set(0, "end")
        def go():
            ids = [roots[i]["id"] for i in lb.curselection()]
            dlg.destroy()
            if not ids:
                return
            prof = dict(p); prof.pop("_starter", None)
            self.run_bg("Extracting", lambda ctl, pg: self.runner.run(prof, root_ids=ids, control=ctl, progress=pg), self._after_run)
        ttk.Button(dlg, text="Start", command=go).pack(pady=8)

    def _after_run(self, jid):
        s = self.runner.summary(jid)
        extra = "\n\nSome documents have a similar but not identical heading. Open 'Show documents' to confirm them." if s["needs_confirmation"] else ""
        messagebox.showinfo("Finished", self.runner.summary_text(jid) + extra, parent=self)

    # ---- jobs
    def show_docs(self):
        j = self._job()
        if j:
            JobDocsWindow(self, j)

    def export_job(self):
        j = self._job()
        if not j:
            return
        arr = self.runner.job_profile(j)["output"]["arrangement"]
        stamp = time.strftime("%Y-%m-%d_%H%M")
        if arr == "per_document_files":
            path = filedialog.askdirectory(title="Choose a folder for the exported files", parent=self)
            path = os.path.join(path, f"DocIntel batch {stamp}") if path else None
        else:
            path = filedialog.asksaveasfilename(title="Save the Excel file", defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")],
                                                initialfile=f"DocIntel batch {stamp}.xlsx", parent=self)
        if not path:
            return
        try:
            files = self.runner.export_job(j, path)
        except PermissionError:
            messagebox.showerror("Export", "The file could not be written. If it is open in Excel, close it and try again.", parent=self); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Export"), parent=self); return
        if messagebox.askyesno("Export finished", "Done. The workbook has a 'Job report' sheet listing every document and its result.\n\nOpen the folder?", parent=self):
            _open(os.path.dirname(files[0]) if os.path.isfile(files[0]) else files[0])

    def _ai(self, j):
        """AI-assisted jobs are continued by the AI extractor (they need the connected model)."""
        if self.runner.job_profile(j).get("ai"):
            from .llm.extract import AIExtractor
            return AIExtractor(self.app.lib)
        return None

    def retry(self):
        j = self._job()
        if j:
            ai = self._ai(j)
            self.run_bg("Retrying", lambda ctl, pg: (ai or self.runner).retry(j, control=ctl, progress=pg) if ai else self.runner.retry(j, control=ctl, progress=pg), lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self))

    def add_new(self):
        j = self._job()
        if j:
            def done(s):
                messagebox.showinfo("Finished", f"{s.get('new_documents', 0)} new and {s.get('changed_documents', 0)} changed document(s) processed. Unchanged documents were not processed again.\n\n" + self.runner.summary_text(j), parent=self)
            def work(ctl, pg):
                try:
                    self.app.lib.scan(control=ctl)               # pick up files added to the folders since last time
                except Exception:
                    pass
                ai = self._ai(j)
                return (ai or self.runner).add_new_documents(j, control=ctl, progress=pg)
            self.run_bg("Processing new documents", work, done)

    def resume(self):
        j = self._job()
        if j:
            ai = self._ai(j)
            self.run_bg("Continuing", lambda ctl, pg: (ai.run_job(j, ctl, pg) if ai else self.runner.resume(j, control=ctl, progress=pg)), lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self))

    def del_job(self):
        j = self._job()
        if j and messagebox.askyesno("Delete job", "Delete this job and its results list? Your documents and exported files are not touched.", parent=self):
            self.runner.delete_job(j); self.reload()


class JobDocsWindow(tk.Toplevel):
    def __init__(self, owner, job_id):
        super().__init__(owner)
        self.owner, self.job_id, self.runner = owner, job_id, owner.runner
        self.title(f"Job {job_id}: documents"); self.geometry("1100x560")
        cols = ("Document", "Result", "Details", "Records", "Need review")
        self.tv = ttk.Treeview(self, columns=cols, show="headings", height=18)
        for c, w in zip(cols, (240, 220, 520, 70, 90)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=8, pady=8)
        self.items = self.runner.items(job_id)
        from .batch import STATUS_TEXT
        for it in self.items:
            self.tv.insert("", "end", values=(it["name"], STATUS_TEXT.get(it["status"], it["status"]), it["message"] or "", it["records"], it["review_rows"]))
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bar, text="This heading is the same section...", command=self.confirm).pack(side="left")
        ttk.Button(bar, text="Open document", command=self.open).pack(side="left", padx=8)

    def _selected(self):
        sel = self.tv.selection()
        if not sel:
            return None
        try:
            idx = int(self.tv.index(sel[0]))
        except (TypeError, ValueError):
            idx = 0
        return self.items[idx] if 0 <= idx < len(self.items) else None

    def confirm(self):
        it = self._selected()
        cands = json.loads(it["candidates_json"] or "[]") if it and it["status"] == "needs_confirmation" else []
        if not cands:
            messagebox.showinfo("Confirm", "Select a document marked 'Similar heading found' first.", parent=self); return
        h = cands[0]["heading"]
        if messagebox.askyesno("Confirm", f"Treat '{h}' as the same section as the one you asked for?\n\nIt will be remembered for all documents of this job.", parent=self):
            j = self.job_id
            self.destroy()
            self.owner.run_bg("Applying", lambda ctl, pg: self.runner.confirm_section(j, h, control=ctl, progress=pg),
                              lambda s: messagebox.showinfo("Finished", self.runner.summary_text(j), parent=self.owner))

    def open(self):
        it = self._selected()
        if it and os.path.exists(it["path"] or ""):
            _open(it["path"])


# ===================================================================== manual table selection (Milestone 8)
class ManualTableWindow(tk.Toplevel):
    """Show a page, let the user draw a rectangle around the table, optionally click the column lines, preview the rows, save the table.
    The selection can be saved as a template and applied to other documents of the same layout."""
    def __init__(self, app, path, file_id=None, on_saved=None):
        super().__init__(app)
        import base64, io
        self.app, self.path, self.file_id, self.on_saved = app, path, file_id, on_saved
        self.title("Select a table by hand - " + os.path.basename(path)); self.geometry("1150x800")
        self.box, self.cols, self.table, self.scale = None, [], None, 1.0
        self.q = queue.Queue(); self.mode = tk.StringVar(value="region"); self.page = tk.IntVar(value=1); self.hdr = tk.IntVar(value=1)
        bar = ttk.Frame(self, padding=6); bar.pack(fill="x")
        ttk.Label(bar, text="Page").pack(side="left"); ttk.Spinbox(bar, from_=1, to=9999, width=5, textvariable=self.page, command=self.load_page).pack(side="left", padx=4)
        ttk.Radiobutton(bar, text="1. Draw the table area", value="region", variable=self.mode).pack(side="left", padx=8)
        ttk.Radiobutton(bar, text="2. Click the column lines (optional; right-click removes)", value="cols", variable=self.mode).pack(side="left", padx=8)
        ttk.Label(bar, text="Header rows").pack(side="left"); ttk.Spinbox(bar, from_=0, to=5, width=3, textvariable=self.hdr).pack(side="left", padx=4)
        ttk.Button(bar, text="Find columns automatically", command=self.clear_cols).pack(side="left", padx=6)
        ttk.Button(bar, text="3. Preview", command=self.preview).pack(side="left", padx=6)
        mid = ttk.Panedwindow(self, orient="vertical"); mid.pack(fill="both", expand=True)
        fr = ttk.Frame(mid); mid.add(fr, weight=3)
        self.cv = tk.Canvas(fr, background="#888"); sy = ttk.Scrollbar(fr, orient="vertical", command=self.cv.yview); sx = ttk.Scrollbar(fr, orient="horizontal", command=self.cv.xview)
        self.cv.configure(yscrollcommand=sy.set, xscrollcommand=sx.set); sy.pack(side="right", fill="y"); sx.pack(side="bottom", fill="x"); self.cv.pack(fill="both", expand=True)
        self.cv.bind("<ButtonPress-1>", self._press); self.cv.bind("<B1-Motion>", self._drag); self.cv.bind("<ButtonRelease-1>", self._release); self.cv.bind("<Button-3>", self._remove_col)
        pv = ttk.Frame(mid); mid.add(pv, weight=2)
        self.tv = ttk.Treeview(pv, show="headings", height=8); self.tv.pack(fill="both", expand=True)
        nav = ttk.Frame(self, padding=6); nav.pack(fill="x")
        self.msg = tk.StringVar(value="Draw a rectangle around the table (drag with the mouse)."); ttk.Label(nav, textvariable=self.msg).pack(side="left")
        ttk.Button(nav, text="Save table", command=self.save).pack(side="right")
        ttk.Button(nav, text="Save selection and apply to other documents...", command=self.apply_others).pack(side="right", padx=8)
        self.load_page(); self.after(150, self._poll)

    # ---- page image
    def load_page(self):
        import base64, io
        import pypdfium2 as pdfium
        try:
            doc = pdfium.PdfDocument(self.path); n = max(1, min(int(self.page.get()), len(doc)))
            pg = doc[n - 1]; W, H = pg.get_size()
            self.scale = min(1000.0 / W, 1.6)
            img = pg.render(scale=self.scale).to_pil(); self.pw, self.ph = W, H
            buf = io.BytesIO(); img.save(buf, "PNG"); doc.close()
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Show page"), parent=self); return
        self.photo = tk.PhotoImage(data=base64.b64encode(buf.getvalue()))
        self.cv.delete("all"); self.cv.create_image(0, 0, anchor="nw", image=self.photo); self.cv.configure(scrollregion=(0, 0, img.width, img.height))
        self.box, self.cols, self.rect = None, [], None

    # ---- mouse
    def _pt(self, ev):
        return self.cv.canvasx(ev.x), self.cv.canvasy(ev.y)

    def _press(self, ev):
        x, y = self._pt(ev)
        if self.mode.get() == "region":
            self.start = (x, y); self.cv.delete("rect"); self.rect = self.cv.create_rectangle(x, y, x, y, outline="red", width=2, tags="rect")
        elif self.box and self.box[0] <= x <= self.box[2]:
            self.cols.append(x); self._redraw_cols()

    def _drag(self, ev):
        if self.mode.get() == "region" and self.rect:
            x, y = self._pt(ev); self.cv.coords(self.rect, self.start[0], self.start[1], x, y)

    def _release(self, ev):
        if self.mode.get() == "region" and self.rect:
            x, y = self._pt(ev)
            x0, x1, y0, y1 = min(self.start[0], x), max(self.start[0], x), min(self.start[1], y), max(self.start[1], y)
            if x1 - x0 > 20 and y1 - y0 > 10:
                self.box = (x0, y0, x1, y1); self.cols = []; self._redraw_cols()
                self.msg.set("Area selected. Click 'Preview' (columns are found automatically), or switch to step 2 to click the column lines.")

    def _remove_col(self, ev):
        x, _ = self._pt(ev)
        if self.cols:
            self.cols.remove(min(self.cols, key=lambda c: abs(c - x))); self._redraw_cols()

    def _redraw_cols(self):
        self.cv.delete("col")
        if self.box:
            for c in self.cols:
                self.cv.create_line(c, self.box[1], c, self.box[3], fill="blue", width=2, tags="col")

    def clear_cols(self):
        self.cols = []; self._redraw_cols()

    # ---- extraction (in a thread: scanned pages need OCR)
    def _pdf_box(self):
        x0, y0, x1, y1 = self.box
        return (x0 / self.scale, y0 / self.scale, x1 / self.scale, y1 / self.scale), [c / self.scale for c in self.cols]

    def preview(self):
        if not self.box:
            messagebox.showinfo("Select a table", "Draw a rectangle around the table first.", parent=self); return
        bbox, cols = self._pdf_box(); page, hdr = int(self.page.get()), int(self.hdr.get())
        self.msg.set("Reading the selected area ...")
        def work():
            from .tables.manual import manual_extract
            try:
                self.q.put(("ok", manual_extract(self.path, page, bbox, cols or None, hdr, ocr=self.app.lib.ocr_engine)))
            except Exception as e:
                self.q.put(("err", e))
        threading.Thread(target=work, daemon=True).start()

    def _poll(self):
        try:
            while True:
                k, v = self.q.get_nowait()
                if k == "err":
                    self.msg.set(""); messagebox.showinfo("Could not read the area", str(v) if isinstance(v, ValueError) else friendly.explain(v, "Read area")[1], parent=self)
                else:
                    self.table = v; self._show(v)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass

    def _show(self, t):
        names = [h.name for h in t.headers]
        self.tv.configure(columns=[f"c{i}" for i in range(len(names))])
        for i, n in enumerate(names):
            self.tv.heading(f"c{i}", text=n); self.tv.column(f"c{i}", width=max(70, 900 // max(1, len(names))))
        for i in self.tv.get_children():
            self.tv.delete(i)
        for r in t.rows[:200]:
            self.tv.insert("", "end", values=r.orig)
        self.msg.set(f"{len(t.rows)} row(s), {len(names)} column(s). " + ("; ".join(t.quality_notes[:1]) if t.quality_notes else "") + "  Looks right? Click 'Save table'.")

    # ---- keep the result
    def save(self):
        if self.table is None:
            messagebox.showinfo("Preview first", "Click 'Preview' to see the rows before saving.", parent=self); return None
        if self.file_id is None:
            messagebox.showinfo("Not in the library", "Add this document to your library first (Add Documents), then select the table.", parent=self); return None
        from .tables.manual import save_manual_table
        try:
            tid = save_manual_table(self.app.lib.db, self.file_id, self.table)
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Save table"), parent=self); return None
        messagebox.showinfo("Saved", "The table was saved with this document. It now appears in the list of tables (and is used by Export).", parent=self)
        if self.on_saved:
            self.on_saved()
        return tid

    def apply_others(self):
        if self.table is None:
            messagebox.showinfo("Preview first", "Click 'Preview' first.", parent=self); return
        name = simpledialog.askstring("Save selection", "Name for this selection (for example: Pricing schedule):", parent=self)
        if not name or not name.strip():
            return
        from .tables.manual import save_template
        tpl = self.table.stats["template"]; save_template(self.app.lib.db, name.strip(), tpl)
        files = [r for r in self.app.lib.db.q("SELECT id, name, abspath FROM files WHERE lower(ltrim(ext,'.'))='pdf' AND missing_since IS NULL ORDER BY name")]
        dlg = tk.Toplevel(self); dlg.title("Apply to which documents?"); dlg.geometry("560x420")
        ttk.Label(dlg, text="Read the same table area in these documents (check the results afterwards):", padding=8).pack(anchor="w")
        lb = tk.Listbox(dlg, selectmode="extended", exportselection=False); lb.pack(fill="both", expand=True, padx=8)
        for r in files:
            lb.insert("end", r["name"])
        def go():
            from .tables.manual import apply_template, save_manual_table
            ok, notes = 0, []
            for i in lb.curselection():
                r = files[i]
                try:
                    t, warn = apply_template(r["abspath"], tpl, ocr=self.app.lib.ocr_engine)
                    save_manual_table(self.app.lib.db, r["id"], t); ok += 1
                    notes += [f"{r['name']}: {w}" for w in warn if "differ" in w]
                except Exception as e:
                    notes.append(f"{r['name']}: {e}")
            dlg.destroy()
            messagebox.showinfo("Finished", f"{ok} table(s) read and saved." + ("\n\nPlease check:\n" + "\n".join(notes[:12]) if notes else ""), parent=self)
            if self.on_saved:
                self.on_saved()
        ttk.Button(dlg, text="Apply", command=go).pack(pady=8)


# ===================================================================== AI tools (Milestone 9): local models, bulk AI extraction, comparison
class _Bg:
    """Background work for the AI windows (the screen stays responsive; Cancel stops at the next document)."""
    def _bg_init(self):
        self.q = queue.Queue(); self.control = None; self.busy = False

    def run_bg(self, label, fn, done=None, cancellable=True):
        if self.busy:
            return
        self.busy = True; self.control = JobControl(); self.msg.set(label + " ...")
        def prog(i, n, name):
            self.q.put(("progress", f"{label}: {i} of {n}  {name}"))
        def work():
            try:
                self.q.put(("done", fn(self.control, prog), done))
            except Exception as e:
                import logging
                logging.getLogger("docintel").exception("AI window job failed")
                self.q.put(("error", e))
        threading.Thread(target=work, daemon=True).start()

    def cancel(self):
        if self.control:
            self.control.cancel()

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "progress":
                    self.msg.set(m[1]); continue
                self.busy = False; self.msg.set("")
                if m[0] == "done":
                    if m[2]:
                        m[2](m[1])
                else:
                    from .llm.provider import ProviderError
                    messagebox.showerror("AI", str(m[1]) if isinstance(m[1], (ProviderError, ValueError)) else friendly.explain(m[1], "AI")[1], parent=self)
        except queue.Empty:
            pass
        try:
            self.after(150, self._poll)
        except tk.TclError:
            pass


class ModelDialog(tk.Toplevel):
    def __init__(self, owner, model, on_save):
        super().__init__(owner)
        from .llm.provider import SERVER_TYPES
        self.owner, self.on_save, self.types = owner, on_save, SERVER_TYPES
        self.title("AI model connection"); self.geometry("720x470")
        m = dict(model or {}); f = ttk.Frame(self, padding=12); f.pack(fill="both", expand=True)
        self.v = {k: tk.StringVar(value=str(m.get(k, d))) for k, d in (("name", ""), ("base_url", ""), ("model", ""), ("embed_model", ""), ("context_chars", "12000"), ("timeout", "180"))}
        self.type = tk.StringVar(value=SERVER_TYPES.get(m.get("type", "ollama"), SERVER_TYPES["ollama"])["label"])
        rows = [("Name", "name", "A name you choose, for example: Qwen small, Llama big."), ("Model name", "model", "The model as your server calls it. Click 'Find models' to list them."),
                ("Embedding model (optional)", "embed_model", "Only for meaning-based search. Leave empty if you have none."), ("Memory per request (characters)", "context_chars", "How much document text is sent to the model at once. Smaller = faster, for small models."),
                ("Time limit (seconds)", "timeout", "Slow computers may need more.")]
        ttk.Label(f, text="Server type").grid(row=0, column=0, sticky="w")
        cb = ttk.Combobox(f, textvariable=self.type, values=[t["label"] for t in SERVER_TYPES.values()], state="readonly", width=40); cb.grid(row=0, column=1, sticky="w")
        ttk.Label(f, text="Server address").grid(row=1, column=0, sticky="w", pady=(8, 0)); ttk.Entry(f, textvariable=self.v["base_url"], width=60).grid(row=1, column=1, sticky="we", pady=(8, 0))
        ttk.Label(f, text="Normally on this computer (localhost). Filled in for you.", foreground="#555").grid(row=2, column=1, sticky="w")
        for i, (lab, key, hint) in enumerate(rows):
            ttk.Label(f, text=lab).grid(row=3 + 2 * i, column=0, sticky="w", pady=(8, 0))
            if key == "model":
                self.model_cb = ttk.Combobox(f, textvariable=self.v[key], values=[], width=58); self.model_cb.grid(row=3 + 2 * i, column=1, sticky="we", pady=(8, 0))
            else:
                ttk.Entry(f, textvariable=self.v[key], width=60).grid(row=3 + 2 * i, column=1, sticky="we", pady=(8, 0))
            ttk.Label(f, text=hint, foreground="#555").grid(row=4 + 2 * i, column=1, sticky="w")
        f.columnconfigure(1, weight=1)
        self.msg = tk.StringVar(); ttk.Label(self, textvariable=self.msg, padding=(12, 0), wraplength=680).pack(anchor="w")
        bar = ttk.Frame(self, padding=12); bar.pack(fill="x")
        ttk.Button(bar, text="Find models", command=self.find).pack(side="left"); ttk.Button(bar, text="Test connection", command=self.test).pack(side="left", padx=6)
        ttk.Button(bar, text="Save", command=self.save).pack(side="right"); ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right", padx=6)
        self.type.trace_add("write", lambda *a: self._fill_url()) if hasattr(self.type, "trace_add") else None
        if not self.v["base_url"].get():
            self._fill_url()

    def _key(self):
        return next((k for k, t in self.types.items() if t["label"] == self.type.get()), "other")

    def _fill_url(self):
        cur = self.v["base_url"].get()
        if not cur or cur in [t["base_url"] for t in self.types.values()]:
            self.v["base_url"].set(self.types[self._key()]["base_url"])

    def _prov(self):
        from .llm.provider import provider_from_model
        return provider_from_model({**{k: x.get().strip() for k, x in self.v.items()}, "type": self._key()})

    def _in_thread(self, fn, done):
        def work():
            try:
                r = fn()
            except Exception as e:
                r = e
            try:
                self.after(0, lambda: done(r))
            except tk.TclError:
                pass
        threading.Thread(target=work, daemon=True).start()

    def find(self):
        self.msg.set("Asking the server which models it has ...")
        def done(r):
            if isinstance(r, Exception):
                self.msg.set(str(r)); return
            self.model_cb.configure(values=r)
            self.msg.set(f"{len(r)} model(s) found: " + ", ".join(r[:8]) + (" ..." if len(r) > 8 else "") + "  Choose one in the 'Model name' box.")
        self._in_thread(lambda: self._prov().list_models(), done)

    def test(self):
        self.msg.set("Testing: asking the model a tiny question ...")
        def done(r):
            self.msg.set(str(r) if isinstance(r, Exception) else (("OK - " if r[0] else "Problem - ") + r[1] + (f"  ({r[2]:.1f} s)" if r[0] else "")))
        self._in_thread(lambda: self._prov().test(), done)

    def save(self):
        try:
            m = {k: x.get().strip() for k, x in self.v.items()}; m["type"] = self._key()
            for k in ("context_chars", "timeout"):
                m[k] = int(m[k] or 0) or (12000 if k == "context_chars" else 180)
            self.owner.reg.save(m)
        except Exception as e:
            messagebox.showerror("AI model", str(e), parent=self); return
        self.on_save(); self.destroy()


class AIModelsWindow(tk.Toplevel):
    """Connect, test and switch local AI models. Several can be saved; one is active."""
    def __init__(self, app, home=None):
        super().__init__(app)
        self.app = app; self.reg = app.lib.ai_models()
        self.title("AI models"); self.geometry("980x520")
        ttk.Label(self, padding=10, wraplength=940, justify="left", text=
                  "Run an open model on this computer with a model server such as Ollama, LM Studio or llama.cpp (see the user guide, section 13). Then add it here. "
                  "Everything stays on this computer. You can save several models and switch between them to find the one that works best for your documents.").pack(anchor="w")
        cols = ("Active", "Name", "Server", "Model", "Embedding model")
        self.tv = ttk.Treeview(self, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (60, 200, 300, 220, 160)):
            self.tv.heading(c, text=c); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=10)
        bar = ttk.Frame(self, padding=10); bar.pack(fill="x")
        for t, c in (("Add model...", self.add), ("Edit...", self.edit), ("Make active", self.activate), ("Test selected", self.test), ("Delete", self.delete)):
            ttk.Button(bar, text=t, command=c).pack(side="left", padx=(0, 6))
        self.msg = tk.StringVar(); ttk.Label(self, textvariable=self.msg, padding=(10, 0, 10, 10), wraplength=940).pack(anchor="w")
        self.models = []; self.reload()

    def reload(self):
        self.models = self.reg.list()
        for i in self.tv.get_children():
            self.tv.delete(i)
        for m in self.models:
            self.tv.insert("", "end", values=("*" if m["name"] == self.reg.active_name() else "", m["name"], m["base_url"], m["model"], m.get("embed_model", "")))

    def _picked(self):
        s = self.tv.selection()
        if not s:
            messagebox.showinfo("AI models", "Choose a model in the list first.", parent=self); return None
        try:
            idx = int(self.tv.index(s[0]))
        except (TypeError, ValueError):
            idx = 0
        return self.models[idx] if 0 <= idx < len(self.models) else None

    def add(self):
        ModelDialog(self, None, self.reload)

    def edit(self):
        m = self._picked()
        if m:
            ModelDialog(self, m, self.reload)

    def activate(self):
        m = self._picked()
        if m:
            self.reg.activate(m["name"]); self.reload(); self.msg.set(f"'{m['name']}' is now the active model.")

    def delete(self):
        m = self._picked()
        if m and messagebox.askyesno("Delete", f"Remove the connection '{m['name']}'? (The model itself is not touched.)", parent=self):
            self.reg.delete(m["name"]); self.reload()

    def test(self):
        m = self._picked()
        if not m:
            return
        self.msg.set("Testing ...")
        prov = self.reg.provider(m["name"])
        def work():
            r = prov.test()
            try:
                self.after(0, lambda: self.msg.set(("OK - " if r[0] else "Problem - ") + r[1] + (f"  ({r[2]:.1f} s)" if r[0] else "")))
            except tk.TclError:
                pass
        threading.Thread(target=work, daemon=True).start()


class AIExtractWindow(tk.Toplevel, _Bg):
    """AI-assisted extraction in bulk: name the fields (or the columns of a table) and the model reads every selected document."""
    def __init__(self, app, home=None):
        super().__init__(app)
        self._bg_init(); self.app = app; self.job = None
        self.title("Extract with AI (bulk)"); self.geometry("1000x720")
        top = ttk.Frame(self, padding=10); top.pack(fill="x")
        ttk.Label(top, text="1. Which folders?").grid(row=0, column=0, sticky="w")
        self.roots = app.lib.roots()
        self.lb = tk.Listbox(top, selectmode="extended", exportselection=False, height=5); self.lb.grid(row=1, column=0, columnspan=3, sticky="we")
        for r in self.roots:
            self.lb.insert("end", f"{r['name']}   ({r['path']})")
        self.lb.select_set(0, "end")
        ttk.Label(top, text="2. What do you want? (comma separated names)").grid(row=2, column=0, sticky="w", pady=(8, 0))
        self.fields = tk.StringVar(); ttk.Entry(top, textvariable=self.fields, width=80).grid(row=3, column=0, columnspan=3, sticky="we")
        ttk.Label(top, text="Example: Invoice number, Date, Total amount   -   or the columns of a table: Item, Quantity, Price", foreground="#555").grid(row=4, column=0, columnspan=3, sticky="w")
        self.mode = tk.StringVar(value="One record per document (the fields)")
        ttk.Combobox(top, textvariable=self.mode, values=["One record per document (the fields)", "Many rows per document (the columns of a table)"], state="readonly", width=48).grid(row=5, column=0, sticky="w", pady=6)
        ttk.Label(top, text="Extra instructions (optional)").grid(row=6, column=0, sticky="w")
        self.instr = tk.StringVar(); ttk.Entry(top, textvariable=self.instr, width=80).grid(row=7, column=0, columnspan=3, sticky="we")
        top.columnconfigure(0, weight=1)
        bar = ttk.Frame(self, padding=(10, 4)); bar.pack(fill="x")
        ttk.Button(bar, text="3. Start", command=self.start).pack(side="left"); ttk.Button(bar, text="Cancel", command=self.cancel).pack(side="left", padx=6)
        ttk.Button(bar, text="Export to Excel", command=self.export).pack(side="right")
        ttk.Button(bar, text="Retry failed", command=self.retry).pack(side="right", padx=6)
        self.msg = tk.StringVar(); ttk.Label(self, textvariable=self.msg, padding=(10, 0)).pack(anchor="w")
        self.tv = ttk.Treeview(self, columns=("doc", "res", "det"), show="headings", height=14)
        for c, w, t in (("doc", 260, "Document"), ("res", 220, "Result"), ("det", 480, "Details")):
            self.tv.heading(c, text=t); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=10, pady=6)
        ttk.Label(self, padding=(10, 0, 10, 10), wraplength=960, foreground="#444", text=
                  "Every value the model returns is checked against the text of the document. A value that is not in the document is still shown but marked for review - "
                  "models can invent things, so look at those cells before you rely on them.").pack(anchor="w")
        self.after(150, self._poll)

    def _cols(self):
        cols = [c.strip() for c in self.fields.get().replace("\n", ",").split(",") if c.strip()]
        if not cols:
            raise ValueError("Type at least one field name (for example: Invoice number, Total).")
        return cols

    def start(self):
        from .llm.extract import AIExtractor
        try:
            cols = self._cols(); ex = AIExtractor(self.app.lib)
            if not ex.provider.available():
                raise ValueError("No AI model is connected yet. Use AI tools > Connect or switch AI model first.")
        except ValueError as e:
            messagebox.showinfo("Extract with AI", str(e), parent=self); return
        ids = [self.roots[i]["id"] for i in self.lb.curselection()]
        if not ids:
            messagebox.showinfo("Extract with AI", "Choose at least one folder.", parent=self); return
        mode = "fields" if self.mode.get().startswith("One") else "rows"
        self.ex = ex
        self.run_bg("Reading documents", lambda ctl, pg: ex.run(cols, self.instr.get().strip(), mode, root_ids=ids, control=ctl, progress=pg), self._done)

    def _done(self, jid):
        self.job = jid; self._show()
        messagebox.showinfo("Finished", self.ex.br.summary_text(jid), parent=self)

    def _show(self):
        from .batch import STATUS_TEXT
        for i in self.tv.get_children():
            self.tv.delete(i)
        for it in self.ex.br.items(self.job):
            self.tv.insert("", "end", values=(it["name"], STATUS_TEXT.get(it["status"], it["status"]), it["message"] or ""))

    def retry(self):
        if self.job is None:
            return
        self.run_bg("Retrying", lambda ctl, pg: self.ex.retry(self.job, ctl, pg), lambda s: (self._show(), messagebox.showinfo("Finished", self.ex.br.summary_text(self.job), parent=self)))

    def export(self):
        if self.job is None:
            messagebox.showinfo("Export", "Run the extraction first.", parent=self); return
        path = filedialog.asksaveasfilename(title="Save the Excel file", defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")], initialfile=f"DocIntel AI {time.strftime('%Y-%m-%d_%H%M')}.xlsx", parent=self)
        if not path:
            return
        try:
            files = self.ex.br.export_job(self.job, path)
        except PermissionError:
            messagebox.showerror("Export", "The file could not be written. If it is open in Excel, close it and try again.", parent=self); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Export"), parent=self); return
        if messagebox.askyesno("Export finished", "Done. Cells the model gave that were NOT found in the document are marked for review.\n\nOpen the folder?", parent=self):
            _open(os.path.dirname(files[0]))


class AICompareWindow(tk.Toplevel, _Bg):
    def __init__(self, app, home=None):
        super().__init__(app)
        self._bg_init(); self.app = app; self.reg = app.lib.ai_models()
        self.title("Compare AI models on my documents"); self.geometry("900x700")
        f = ttk.Frame(self, padding=10); f.pack(fill="x")
        ttk.Label(f, text="Models to compare (choose two or more)").pack(anchor="w")
        self.names = [m["name"] for m in self.reg.list()]
        self.lb = tk.Listbox(f, selectmode="extended", exportselection=False, height=5); self.lb.pack(fill="x")
        for n in self.names:
            self.lb.insert("end", n)
        ttk.Label(f, text="Fields to extract (comma separated)").pack(anchor="w", pady=(8, 0))
        self.fields = tk.StringVar(); ttk.Entry(f, textvariable=self.fields, width=80).pack(fill="x")
        r = ttk.Frame(f); r.pack(fill="x", pady=6)
        ttk.Label(r, text="Use the first").pack(side="left"); self.n = tk.IntVar(value=5); ttk.Spinbox(r, from_=1, to=50, width=4, textvariable=self.n).pack(side="left", padx=4)
        ttk.Label(r, text="documents of the library as the sample").pack(side="left")
        ttk.Button(f, text="Compare", command=self.go).pack(anchor="w")
        self.msg = tk.StringVar(); ttk.Label(self, textvariable=self.msg, padding=(10, 0)).pack(anchor="w")
        self.out = tk.Text(self, wrap="word"); self.out.pack(fill="both", expand=True, padx=10, pady=8)
        self.after(150, self._poll)

    def go(self):
        sel = [self.names[i] for i in self.lb.curselection()]
        cols = [c.strip() for c in self.fields.get().split(",") if c.strip()]
        if len(sel) < 2 or not cols:
            messagebox.showinfo("Compare models", "Choose at least two models and type the field names.", parent=self); return
        ids = [r["id"] for r in self.app.lib.db.q("SELECT id FROM files WHERE missing_since IS NULL AND status='indexed' ORDER BY id LIMIT ?", (int(self.n.get()),))]
        if not ids:
            messagebox.showinfo("Compare models", "Add documents first.", parent=self); return
        from .llm.compare import compare_models, format_report
        self.run_bg("Comparing", lambda ctl, pg: format_report(compare_models(self.app.lib, sel, ids, cols, progress=lambda i, n, t: pg(i + 1, n, t))),
                    lambda text: (self.out.delete("1.0", "end"), self.out.insert("end", text)))


class AIHubWindow(tk.Toplevel, _Bg):
    """One place for everything that uses an AI model. Nothing here is needed for the rest of DocIntel."""
    def __init__(self, app, home=None):
        super().__init__(app)
        self._bg_init(); self.app = app; self.title("AI tools"); self.geometry("820x560")
        self.status = tk.StringVar(); ttk.Label(self, textvariable=self.status, padding=12, wraplength=780, font=("Segoe UI", 11)).pack(anchor="w")
        self.msg = tk.StringVar(); ttk.Label(self, textvariable=self.msg, padding=(12, 0), wraplength=780).pack(anchor="w")
        f = ttk.Frame(self, padding=12); f.pack(fill="both", expand=True)
        self.btns = {}
        for key, text, cmd, need in (("models", "Connect or switch AI model...", self.models, False), ("ask", "Ask Documents (talk to your documents)...", self.ask, True),
                                      ("extract", "Extract with AI (bulk) - fields or tables from many documents...", self.extract, True),
                                      ("index", "Build / update meaning-based search (needs an embedding model)", self.build_index, True),
                                      ("compare", "Compare models on my documents...", self.compare, False)):
            b = ttk.Button(f, text=text, command=cmd); b.pack(fill="x", pady=5, ipady=6); self.btns[key] = (b, need)
        ttk.Label(self, padding=12, wraplength=780, foreground="#444", text=
                  "How it works: DocIntel finds the relevant records and pages itself, then asks your local model to answer or extract using only that text. "
                  "Everything runs on this computer (offline). Answers show their sources; extracted values are checked against the document text.").pack(anchor="w")
        self.refresh(); self.after(150, self._poll)

    def refresh(self):
        reg = self.app.lib.ai_models(); name = reg.active_name(); m = reg.get(name) if name else None
        if m:
            prov = reg.provider(); where = "on this computer (nothing leaves it)" if prov.kind == "local" else "OUTSIDE this computer (offline mode must be off and every send needs your confirmation)"
            self.status.set(f"Active model: {name}  ({m['model']})  -  runs {where}.")
        else:
            self.status.set("No AI model is connected yet. Click 'Connect or switch AI model' to add one. DocIntel works fully without it.")
        for key, (b, need) in self.btns.items():
            b.config(state="normal" if (m or not need) else "disabled")

    def models(self):
        w = AIModelsWindow(self.app, self); w.bind("<Destroy>", lambda e: self.refresh()) if hasattr(w, "bind") else None

    def ask(self):
        AskWindow(self.app, self)

    def extract(self):
        AIExtractWindow(self.app, self)

    def compare(self):
        AICompareWindow(self.app, self)

    def build_index(self):
        from .llm.semantic import SemanticIndex
        from .llm.provider import ProviderError
        prov = self.app.lib.ai_models().provider()
        if not prov.can_embed:
            messagebox.showinfo("Meaning-based search", "The active model has no embedding model. Add an embedding model name in 'Connect or switch AI model' (for example an embedding model from Ollama or LM Studio).", parent=self); return
        ix = SemanticIndex(self.app.lib, prov)
        self.run_bg("Building the search index", lambda ctl, pg: ix.build(ctl, pg), lambda n: messagebox.showinfo("Meaning-based search", f"{n} new item(s) added. {ix.stats()['vectors']} item(s) can now be found by meaning.", parent=self))


# ===================================================================== Ask Documents (Milestone 7; hidden until an AI assistant is connected)
class AskWindow(tk.Toplevel):
    """Question -> records found in the library (shown) -> [confirm if the AI is outside this computer] -> answer with source references."""
    def __init__(self, app, home=None):
        super().__init__(app)
        self.app = app
        self.asst = app.lib.assistant()
        self.pack_, self.prev = None, None
        self.title("Ask Documents"); self.geometry("1000x720")
        top = ttk.Frame(self, padding=10); top.pack(fill="x")
        ttk.Label(top, text="Your question (the answer uses only records extracted from your documents):").pack(anchor="w")
        self.q = tk.StringVar(); ttk.Entry(top, textvariable=self.q, width=110).pack(fill="x", pady=4)
        ttk.Button(top, text="1. Find the records", command=self.find).pack(side="left")
        self.go = ttk.Button(top, text="2. Ask", command=self.ask, state="disabled"); self.go.pack(side="left", padx=8)
        self.info = tk.StringVar(); ttk.Label(self, textvariable=self.info, padding=(10, 0)).pack(anchor="w")
        self.confirm = tk.BooleanVar(value=False)
        self.chk = ttk.Checkbutton(self, text="I confirm that these records may be sent to the external AI service shown above", variable=self.confirm)
        self.tv = ttk.Treeview(self, columns=("id", "src", "text"), show="headings", height=14)
        for c, w in (("id", 50), ("src", 330), ("text", 560)):
            self.tv.heading(c, text={"id": "No.", "src": "Source", "text": "Record"}[c]); self.tv.column(c, width=w)
        self.tv.pack(fill="both", expand=True, padx=10, pady=6)
        self.out = tk.Text(self, height=9, wrap="word"); self.out.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Button(self, text="Open source of selected record", command=self.open_src).pack(anchor="w", padx=10, pady=(0, 10))

    def find(self):
        try:
            self.pack_, self.prev = self.asst.prepare(self.q.get().strip())
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Find records"), parent=self); return
        for i in self.tv.get_children():
            self.tv.delete(i)
        for it in self.pack_.items:
            self.tv.insert("", "end", values=(it.id, it.record.cite_text(), it.text[:200]))
        p = self.prev
        self.info.set(f"{p['records']} record(s) from {len(p['files'])} document(s) would be used. " +
                      ("These records would LEAVE this computer (" + p["provider"] + ")." if p["leaves_computer"] else "Everything stays on this computer."))
        if p["leaves_computer"]:
            self.chk.pack(anchor="w", padx=10)
        self.go.config(state="normal" if p["records"] else "disabled")

    def ask(self):
        from .llm.assistant import ConsentRequired
        try:
            ans = self.asst.ask(self.q.get().strip(), self.pack_, self.prev, consent=self.prev["token"] if self.confirm.get() else None)
        except ConsentRequired:
            messagebox.showinfo("Confirmation needed", "Tick the confirmation box to allow sending these records.", parent=self); return
        except Exception as e:
            messagebox.showerror(*friendly.explain(e, "Ask Documents"), parent=self); return
        self.out.delete("1.0", "end")
        self.out.insert("end", ans.text + "\n")
        for w in ans.warnings:
            self.out.insert("end", "\n! " + w)
        if ans.cited:
            self.out.insert("end", "\n\nSources: " + "; ".join(f"[{e.id}] {e.record.cite_text()}" for e in ans.cited))

    def open_src(self):
        sel = self.tv.selection()
        if not sel or self.pack_ is None:
            return
        try:
            idx = int(self.tv.index(sel[0]))
        except (TypeError, ValueError):
            idx = 0
        if 0 <= idx < len(self.pack_.items):
            _open(self.pack_.items[idx].record.path)


# ===================================================================== installation into the main window
def install_home(app):
    """Add the Home tab first and keep the classic tabs available under 'advanced tools'. Called once from App.__init__."""
    nb = app.nb
    home = HomeFrame(nb, app)
    nb.insert(0, home, text="Home")
    app.tabs["Home"] = home
    app.home = home
    classic = [t for t in nb.tabs() if str(t) != str(home)]
    app._advanced_on = False
    orig_select = nb.select

    def select(tab=None):                      # old buttons call nb.select(<hidden tab>): show it first
        if tab is not None and str(tab) in [str(x) for x in app._hidden]:
            nb.add(tab); app._hidden = [x for x in app._hidden if str(x) != str(tab)]
        return orig_select(tab) if tab is not None else orig_select()

    app._hidden = []
    nb.select = select

    def toggle():
        app._advanced_on = not app._advanced_on
        if app._advanced_on:
            for t in list(app._hidden):
                nb.add(t)
            app._hidden = []
        else:
            for t in classic:
                try:
                    nb.hide(t); app._hidden.append(t)
                except tk.TclError:
                    pass
            orig_select(home)
        return app._advanced_on

    app.toggle_advanced = toggle

    def show_tab(name):
        nb.select(app.tabs[name])
    app.show_tab = show_tab
    app._advanced_on = True
    toggle()                                   # start with the classic tabs hidden
    orig_select(home)
    home.refresh()
    return home
