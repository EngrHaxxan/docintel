@echo off
REM Source-mode launcher (after: pip install -r requirements.txt)
cd /d "%~dp0"
python -m docintel gui
