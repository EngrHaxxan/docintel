"""Saved AI models (several can be saved; one is active; switching is one click). Stored in the library database; no key is stored."""
from __future__ import annotations
import json, time
from .provider import provider_from_model, provider_from_config, NoProvider, SERVER_TYPES


class ModelRegistry:
    def __init__(self, db, cfg):
        self.db, self.cfg = db, cfg

    def list(self):
        return [json.loads(r["json"]) for r in self.db.q("SELECT json FROM ai_models ORDER BY created")]

    def get(self, name):
        r = self.db.one("SELECT json FROM ai_models WHERE name=?", (name,))
        return json.loads(r["json"]) if r else None

    def save(self, m):
        name = (m.get("name") or "").strip()
        if not name:
            raise ValueError("Please give the model connection a name.")
        if not (m.get("model") or "").strip():
            raise ValueError("Please enter the model name (use 'Find models' to list what your server offers).")
        m = dict(m); m["name"] = name
        m.setdefault("type", "ollama")
        m["base_url"] = (m.get("base_url") or SERVER_TYPES.get(m["type"], SERVER_TYPES["other"])["base_url"]).strip()
        old = self.db.one("SELECT created FROM ai_models WHERE name=?", (name,))
        self.db.x("INSERT OR REPLACE INTO ai_models(name,json,created) VALUES(?,?,?)", (name, json.dumps(m, ensure_ascii=False), old["created"] if old else time.time()))
        if not self.cfg.get("ai_active_model"):
            self.activate(name)
        return m

    def delete(self, name):
        self.db.x("DELETE FROM ai_models WHERE name=?", (name,))
        if self.cfg.get("ai_active_model") == name:
            self.cfg.set("ai_active_model", "")

    def activate(self, name):
        if name and self.get(name) is None:
            raise ValueError("That model connection does not exist.")
        self.cfg.set("ai_active_model", name or "")

    def active_name(self):
        return self.cfg.get("ai_active_model") or ""

    def provider(self, name=None):
        name = name or self.active_name()
        m = self.get(name) if name else None
        return provider_from_model(m) if m else provider_from_config(self.cfg)
