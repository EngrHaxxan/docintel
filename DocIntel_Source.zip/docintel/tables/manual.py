"""Manual table selection (Milestone 8): the user draws a rectangle on a page and (optionally) the column lines; the table is read from
the words inside it. Works on text PDFs and, with OCR, on scanned pages. A selection can be saved as a template and applied to other
documents of the same layout (relative position on the page, never page-number tricks: the template names its page and is always checked)."""
from __future__ import annotations
import difflib, re
from .office import table_from_rows
from .model import Table

MANUAL_METHOD = "manual"


def _words_in(path, page_no, bbox, ocr=None):
    """Words (x0, top, x1, bottom, text) inside bbox (PDF points) + the page size + whether OCR was used."""
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        pg = pdf.pages[page_no - 1]
        W, H = float(pg.width), float(pg.height)
        native = len(pg.chars) >= 20
        ws = [(w["x0"], w["top"], w["x1"], w["bottom"], w["text"]) for w in pg.extract_words(keep_blank_chars=False)] if native else []
    used_ocr = False
    if not native and ocr is not None:
        from .ocrpage import ocr_pagedata
        pd, why = ocr_pagedata(path, page_no, W, H, ocr(), dpi=300)
        if pd is not None:
            ws = [(w["x0"], w["top"], w["x1"], w["bottom"], w["text"]) for w in pd.words]; used_ocr = True
    x0, t0, x1, b0 = bbox
    return [w for w in ws if x0 <= (w[0] + w[2]) / 2 <= x1 and t0 <= (w[1] + w[3]) / 2 <= b0], W, H, used_ocr


def _lines(words):
    """Group words into text lines (same baseline band)."""
    if not words:
        return []
    hts = sorted(w[3] - w[1] for w in words)
    tol = max(1.5, 0.55 * hts[len(hts) // 2])
    lines = []
    for w in sorted(words, key=lambda w: ((w[1] + w[3]) / 2, w[0])):
        cy = (w[1] + w[3]) / 2
        if lines and abs(cy - lines[-1]["cy"]) <= tol:
            lines[-1]["w"].append(w); lines[-1]["cy"] = (lines[-1]["cy"] * (len(lines[-1]["w"]) - 1) + cy) / len(lines[-1]["w"])
        else:
            lines.append({"cy": cy, "w": [w]})
    return lines


def auto_columns(words, bbox, min_gap=6.0):
    """Column separators from empty vertical strips that (almost) every text line respects."""
    lines = _lines(words)
    if len(lines) < 2:
        return []
    x0, _, x1, _ = bbox
    step = 1.0
    n = int(x1 - x0) + 1
    occ = [0] * n
    for ln in lines:
        seen = set()
        for w in ln["w"]:
            for x in range(max(0, int(w[0] - x0)), min(n, int(w[2] - x0) + 1)):
                seen.add(x)
        for x in seen:
            occ[x] += 1
    thr = max(1, int(0.06 * len(lines)))
    seps, run = [], None
    for x in range(n):
        if occ[x] <= thr:
            run = x if run is None else run
        else:
            if run is not None and x - run >= min_gap and run > 0:
                seps.append(x0 + (run + x) / 2.0)
            run = None
    return seps


def _col_of(x, seps):
    return sum(1 for s in seps if x > s)


def manual_extract(path, page, bbox, col_edges=None, header_rows=1, ocr=None, title=""):
    """bbox = (x0, top, x1, bottom) in PDF points; col_edges = x positions of the column lines inside it (None = find them automatically)."""
    words, W, H, used_ocr = _words_in(path, page, bbox, ocr)
    if not words:
        raise ValueError("No text was found inside the selected area. Select the table area again (include all of its text).")
    seps = sorted(col_edges) if col_edges else auto_columns(words, bbox)
    ncol = len(seps) + 1
    lines = _lines(words)
    grid = []
    for ln in lines:
        cells = [[] for _ in range(ncol)]
        for w in sorted(ln["w"], key=lambda w: w[0]):
            cells[_col_of((w[0] + w[2]) / 2, seps)].append(w[4])
        grid.append([" ".join(c) for c in cells])
    # rows: a line without text in the first column continues the previous row when most lines do have one (numbered / coded rows)
    body = grid[header_rows:]
    first_filled = sum(1 for r in body if r[0].strip()) / max(1, len(body))
    rows = grid[:header_rows]
    head = [" ".join(x for x in col if x).strip() for col in zip(*rows)] if header_rows else []
    out = []
    for r in body:
        if out and first_filled >= 0.4 and not r[0].strip():
            out[-1] = [(a + " " + b).strip() for a, b in zip(out[-1], r)]
        else:
            out.append(list(r))
    all_rows = ([head] if header_rows else []) + out
    t = table_from_rows(all_rows, title=title or "Table selected by hand", section="", page=page, method=MANUAL_METHOD + ("-ocr" if used_ocr else ""),
                        source=path, header=bool(header_rows), notes=["table selected by hand: columns " + ("given by you" if col_edges else "found automatically") +
                                                                       (", text read with OCR: please verify" if used_ocr else "")])
    if t is None:
        raise ValueError("Fewer than two rows or two columns were found in the selected area. Adjust the area or the column lines.")
    t.quality = 0.7 if used_ocr else 0.85
    t.col_edges = [bbox[0]] + list(seps) + [bbox[2]]
    t.page_bboxes = {page: tuple(bbox)}
    t.engine_version = MANUAL_METHOD
    t.stats = {"page_size": [W, H], "header_rows": header_rows, "template": make_template(page, bbox, seps, W, H, header_rows, [h.name for h in t.headers])}
    return t


def make_template(page, bbox, seps, W, H, header_rows, headers):
    x0, t0, x1, b0 = bbox
    return {"page": page, "bbox_rel": [x0 / W, t0 / H, x1 / W, b0 / H], "cols_rel": [s / W for s in seps], "header_rows": header_rows, "headers": headers}


def apply_template(path, template, page=None, ocr=None):
    """Read the same kind of table from another document: same relative area, same column lines. Returns (Table, warnings)."""
    import pdfplumber
    page = page or template["page"]
    with pdfplumber.open(path) as pdf:
        if page > len(pdf.pages):
            raise ValueError(f"The document has only {len(pdf.pages)} page(s); the saved selection is on page {page}.")
        W, H = float(pdf.pages[page - 1].width), float(pdf.pages[page - 1].height)
    r = template["bbox_rel"]
    bbox = (r[0] * W, r[1] * H, r[2] * W, r[3] * H)
    t = manual_extract(path, page, bbox, [c * W for c in template["cols_rel"]] or None, template["header_rows"], ocr)
    warn = ["Read with a saved table selection: please check the result."]
    old = [h.lower() for h in template.get("headers", [])]
    new = [h.name.lower() for h in t.headers]
    if old and (len(old) != len(new) or sum(difflib.SequenceMatcher(None, a, b).ratio() >= 0.6 for a, b in zip(old, new)) < 0.6 * len(old)):
        warn.append("The column titles differ from the original selection - this may be a different layout.")
    return t, warn


def save_manual_table(db, file_id, table, sha256=None):
    """Store the table with the other tables of the file (they are kept when the file is extracted again)."""
    from .store import save_analysis
    from .engine import Analysis
    return save_analysis(db, file_id, Analysis(table.source, 1, [], [table], [], [], 0.0), sha256=sha256, replace=False)[0]


def save_template(db, name, template):
    import json, time
    db.x("INSERT OR REPLACE INTO manual_templates(name,json,created) VALUES(?,?,?)", (name.strip(), json.dumps(template), time.time()))


def list_templates(db):
    import json
    return {r["name"]: json.loads(r["json"]) for r in db.q("SELECT name, json FROM manual_templates ORDER BY created DESC")}
