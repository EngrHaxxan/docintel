"""Entry point for the frozen Windows executable (double-click = GUI; arguments = CLI)."""
import multiprocessing, os, sys
multiprocessing.freeze_support()
for _n in ("stdout", "stderr"):                    # windowed (no-console) builds have no stdout/stderr: make printing harmless
    if getattr(sys, _n) is None:
        setattr(sys, _n, open(os.devnull, "w", encoding="utf-8"))
    else:
        try: getattr(sys, _n).reconfigure(encoding="utf-8", errors="replace")      # Arabic file names/text never crash the CLI
        except Exception: pass
if __name__ == "__main__":
    from docintel.cli import main
    sys.exit(main(sys.argv[1:] or ["gui"]))
