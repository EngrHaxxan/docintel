"""End-to-end smoke test of a PACKAGED DocIntel (portable folder or installed folder). No Python on the target is needed
to run the app itself; this script (run by CI) only drives it from outside.

    python tools/smoke_packaged.py <app_folder> [--data-dir DIR] [--expect-portable] [--report out.json]

Scenarios: A launch + self-check, B multi-folder index/search/persistence, C extract + Excel (new + template, formulas kept),
F interrupted batch resumed / unreachable drive, GUI start.  Exit code 0 only if every step passed."""
import argparse, json, os, shutil, signal, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
sys.path.insert(0, os.path.join(HERE, ".."))
RESULTS = []


def step(name, ok, detail=""):
    RESULTS.append({"step": name, "ok": bool(ok), "detail": str(detail)[:500]})
    print(("PASS " if ok else "FAIL ") + name + (f" - {detail}" if (detail and not ok) else ""), flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("app"); ap.add_argument("--data-dir"); ap.add_argument("--expect-portable", action="store_true")
    ap.add_argument("--report", default="smoke_report.json"); ap.add_argument("--no-gui", action="store_true"); ap.add_argument("--default-data-dir", action="store_true", help="installed layout: data must land in the user profile"); a = ap.parse_args()
    exe_ext = ".exe" if os.name == "nt" else ""
    cli = os.path.join(a.app, "docintel-cli" + exe_ext); gui = os.path.join(a.app, "DocIntel" + exe_ext)
    step("application files present", os.path.exists(cli) and os.path.exists(gui), f"{cli} / {gui}")
    if os.name == "nt":
        step("bundled Tesseract present", os.path.exists(os.path.join(a.app, "tesseract", "tesseract.exe")) and os.path.exists(os.path.join(a.app, "tesseract", "tessdata", "ara.traineddata")) and os.path.exists(os.path.join(a.app, "tesseract", "tessdata", "eng.traineddata")))
    work = tempfile.mkdtemp(prefix="di smoke ")                     # note the space: paths with spaces must work
    data = a.data_dir or os.path.join(work, "data")
    env = {**os.environ}; env.pop("DOCINTEL_HOME", None)
    if not a.expect_portable and not a.default_data_dir: env["DOCINTEL_HOME"] = data
    def run(*args, timeout=600, **kw):
        return subprocess.run([cli, *args], capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=timeout, **kw)
    import make_corpus
    corpus = os.path.join(work, "Docs Corpus"); make_corpus.build(corpus)

    # A: self-check
    r = run("doctor"); step("A self-check passes (OCR eng+ara, DB, modules)", r.returncode == 0, r.stdout[-600:] + r.stderr[-300:])

    # B: multi-folder
    for d in ("driveA", "driveB", "driveC"):
        run("add-root", os.path.join(corpus, d))
    r = run("update"); step("B recursive index of 3 folders", r.returncode == 0 and "'errors': 0" in r.stdout or "indexed" in r.stdout, r.stdout[-300:] + r.stderr[-300:])
    r = run("search", "INV-00777"); hit = "INV-00777" in r.stdout
    step("B OCR'd identifier found with source path", hit and ("driveB" in r.stdout), r.stdout[:300])
    r = run("search", "منى"); step("B Arabic text search", "منى" in r.stdout, r.stdout[:200])
    if a.expect_portable:
        step("portable: data kept next to the app", os.path.isdir(os.path.join(a.app, "DocIntel_Data")) and os.path.exists(os.path.join(a.app, "DocIntel_Data", "index.db")))
    r = run("search", "INV-00777"); step("B index persists across restart", "INV-00777" in r.stdout)

    # C: extraction + Excel
    run("profile-save", os.path.join(HERE, "..", "samples", "profiles", "daily_report.json"))
    r = run("extract", "Daily report"); step("C extraction run", r.returncode == 0 and "2 records" in r.stdout, r.stdout)
    out_new = os.path.join(work, "out new.xlsx"); out_tpl = os.path.join(work, "out template.xlsx")
    r = run("export", "1", "--out", out_new); step("C export to new workbook", os.path.exists(out_new), r.stdout[-300:] + r.stderr[-300:])
    r = run("export", "1", "--out", out_tpl, "--template", os.path.join(corpus, "template.xlsx")); ok = os.path.exists(out_tpl)
    step("C export into template", ok, r.stdout[-300:] + r.stderr[-300:])
    if ok:
        import openpyxl
        ws = openpyxl.load_workbook(out_tpl).active
        step("C template formulas + formatting + provenance kept", ws["D2"].value == "=C2*2" and ws["D3"].value == "=C3*2" and ws["A1"].font.bold and ws["C3"].value == 120, [c.value for c in ws[3]])
        wb2 = openpyxl.load_workbook(out_new); step("C new workbook has Provenance sheet", "Provenance" in wb2.sheetnames and wb2["Provenance"].max_row > 1)

    # F: unreachable drive does not delete data; interrupted batch resumes
    os.rename(os.path.join(corpus, "driveB"), os.path.join(corpus, "driveB_unplugged"))
    r = run("scan"); step("F unplugged drive flagged, not treated as deleted", '"unavailable": true' in r.stdout, r.stdout[-300:])
    r = run("search", "INV-00777"); step("F data of unplugged drive still searchable", "INV-00777" in r.stdout)
    os.rename(os.path.join(corpus, "driveB_unplugged"), os.path.join(corpus, "driveB"))
    big = os.path.join(corpus, "driveA", "bulk"); os.makedirs(big, exist_ok=True)
    for i in range(1500): open(os.path.join(big, f"n{i}.txt"), "w").write(f"bulk file {i} token-{i}\n" * 20)
    run("scan")
    p = subprocess.Popen([cli, "index"], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE); time.sleep(2.0)
    p.kill(); p.wait()                                              # hard kill mid-batch
    r = run("index"); r2 = run("search", "token-1499"); step("F killed batch resumes; every file indexed", "token-1499" in r2.stdout, r.stdout[-200:] + r2.stdout[-200:])
    if os.name == "nt":
        lock = os.path.join(corpus, "driveA", "locked dir"); os.makedirs(lock, exist_ok=True); open(os.path.join(lock, "x.txt"), "w").write("x")
        subprocess.run(["icacls", lock, "/deny", f"{os.environ.get('USERNAME', 'Users')}:(OI)(CI)(RX)"], capture_output=True)
        r = run("scan"); step("F inaccessible directory does not stop the batch", r.returncode == 0, r.stderr[-300:])
        subprocess.run(["icacls", lock, "/remove:d", os.environ.get('USERNAME', 'Users')], capture_output=True)

    if a.default_data_dir:
        base = os.environ.get("LOCALAPPDATA") if os.name == "nt" else os.path.expanduser("~")
        dd = os.path.join(base, "DocIntel") if os.name == "nt" else os.path.join(base, ".docintel")
        step("installed: data stored in the user profile, not the program folder", os.path.exists(os.path.join(dd, "index.db")) and not os.path.exists(os.path.join(a.app, "DocIntel_Data")), dd)

    # GUI start
    if not a.no_gui:
        rep = os.path.join(work, "gui.json")
        try:
            r = subprocess.run([gui, "gui", "--smoke-test", rep], env=env, timeout=120, capture_output=True)
            g = json.load(open(rep)); step("GUI opens, 10 tabs, environment check clean", g["tabs"] == 10 and g["doctor_ok"] and not g["problems"], g)
            if a.expect_portable: step("GUI recognises portable mode", g["portable"])
        except Exception as e:
            step("GUI opens", False, e)
    json.dump(RESULTS, open(a.report, "w"), indent=1)
    ok = all(r["ok"] for r in RESULTS); print(f"\n{sum(r['ok'] for r in RESULTS)}/{len(RESULTS)} steps passed"); shutil.rmtree(work, ignore_errors=True)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
