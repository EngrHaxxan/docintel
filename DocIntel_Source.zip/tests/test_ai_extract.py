"""Milestone 9: AI-assisted extraction in bulk with verification (against a fake local model server - NO real language model)."""
import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from openpyxl import load_workbook
from fake_llm_server import Fake
from docintel.library import Library
from docintel.llm.provider import OpenAICompatProvider
from docintel.llm.extract import AIExtractor, parse_json, windows, find_page, norm
from docintel import search as S
from docintel.tables import store


def pdf(path, lines):
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(path); y = 780
    for l in lines:
        c.drawString(72, y, l); y -= 16
    c.save()


class Base(unittest.TestCase):
    def setUp(self):
        self.srv = Fake(); self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "s"); os.makedirs(self.src)
        for i, (no, tot) in enumerate([("INV-00012", "1,250.00"), ("INV-00013", "980.50"), ("INV-00014", "20.00")]):
            pdf(os.path.join(self.src, f"inv_{i}.pdf"), ["ACME Trading - Tax invoice", f"Invoice No: {no}", "Date: 2026-03-04", f"Total: {tot}", "Thank you for your business."])
        pdf(os.path.join(self.src, "plain.pdf"), ["Meeting notes", "Nothing about money here, just a long paragraph of text for the test."])
        pdf(os.path.join(self.src, "rows.pdf"), ["Delivery note", "Item | Qty | Price", "Cable | 10 | 15.50", "Clamp | 4 | 2.25", "Total lines: 2"])
        self.lib = Library(os.path.join(self.tmp, "h")); self.lib.cfg.set("workers", 1); self.lib.add_root(self.src); self.lib.scan(); self.lib.index()
        self.prov = OpenAICompatProvider(self.srv.url, "fake-chat", name="fake")
        self.ids = lambda *names: [self.lib.db.one("SELECT id FROM files WHERE name=?", (n,))["id"] for n in names]

    def tearDown(self):
        self.srv.stop(); shutil.rmtree(self.tmp, ignore_errors=True)


class Helpers(unittest.TestCase):
    def test_parse_json_tolerates_chatter(self):
        self.assertEqual(parse_json('Sure! ```json\n{"a": {"value": "x", "page": 1}}\n``` done'), {"a": {"value": "x", "page": 1}})
        with self.assertRaises(Exception):
            parse_json("I could not find anything.")

    def test_find_page_and_windows(self):
        texts = {1: "Invoice No:  INV-00012\nTotal 1 250.00", 2: "other page 65% done"}
        self.assertEqual(find_page("inv-00012", texts), 1); self.assertEqual(find_page("65%", texts), 2); self.assertEqual(find_page("1250.00", texts), 1)   # spaces from OCR ignored
        self.assertIsNone(find_page("9999", texts)); self.assertEqual(find_page("", texts), None)
        self.assertEqual([[n for n, _ in w] for w in windows([(1, "a" * 60), (2, "b" * 60), (3, "c" * 60)], 100)], [[1], [2], [3]])


class Fields(Base):
    def test_bulk_fields_verified_saved_exported(self):
        ex = AIExtractor(self.lib, self.prov)
        jid = ex.run(["Invoice No", "Date", "Total"], file_ids=self.ids("inv_0.pdf", "inv_1.pdf", "inv_2.pdf", "plain.pdf"))
        s = ex.br.summary(jid)
        self.assertEqual((s["processed"], s["records"]), (3, 3)); self.assertEqual(s["partial"] + s["failed"], 0)
        self.assertEqual(s["section_not_found"] + s["no_tables"], 1)                      # plain.pdf: the model found nothing: reported, not invented
        en = ex.entries(jid)
        self.assertEqual(sorted(e.table.rows[0].orig[0] for e in en), ["INV-00012", "INV-00013", "INV-00014"])
        r = next(e for e in en if e.label == "inv_1.pdf").table
        self.assertEqual([h.name for h in r.headers], ["Invoice No", "Date", "Total", "Source page"]); self.assertEqual(r.rows[0].orig, ["INV-00013", "2026-03-04", "980.50", "1"])
        self.assertTrue(r.method == "ai-fields" and r.quality > 0.85 and not r.rows[0].cell_flags)
        x = os.path.join(self.tmp, "o.xlsx"); ex.br.export_job(jid, x)                       # same export / job report as any batch job
        wb = load_workbook(x); self.assertIn("Job report", wb.sheetnames)
        data = [sh for sh in wb.sheetnames if sh not in ("Summary", "Job report")][0]
        self.assertEqual(len(list(wb[data].iter_rows(values_only=True))) - 1, 3)
        hits = [h for h in S.search(self.lib.db, "INV-00013", "text", limit=20) if h.kind == "table"]
        self.assertTrue(hits)                                                                # AI results are searchable like any table
        self.lib.extract_tables(force=True)
        self.assertTrue(any(str(t["method"]).startswith("ai-") for t in store.list_tables(self.lib.db, self.ids("inv_0.pdf")[0])))   # kept when tables are extracted again

    def test_invented_value_is_flagged(self):
        self.srv.mode = "hallucinate"
        ex = AIExtractor(self.lib, self.prov); jid = ex.run(["Invoice No", "Total"], file_ids=self.ids("inv_0.pdf"))
        s = ex.br.summary(jid); self.assertEqual(s["partial"], 1); self.assertEqual(s["review_rows"], 1)
        it = ex.br.items(jid)[0]; self.assertIn("not found in the document text", it["message"])
        t = ex.entries(jid)[0].table
        self.assertEqual(t.rows[0].orig[0], "INV-999999"); self.assertTrue(t.rows[0].cell_flags[0][0].startswith("review"))   # shown, but marked
        self.assertLess(t.quality, 0.8)

    def test_rows_mode_and_flag(self):
        ex = AIExtractor(self.lib, self.prov); jid = ex.run(["Item", "Qty", "Price"], mode="rows", file_ids=self.ids("rows.pdf"))
        t = ex.entries(jid)[0].table
        self.assertEqual([r.orig[:3] for r in t.rows], [["Cable", "10", "15.50"], ["Clamp", "4", "2.25"]]); self.assertEqual(t.method, "ai-rows")
        self.srv.mode = "hallucinate"
        jid2 = ex.run(["Item", "Qty", "Price"], mode="rows", file_ids=self.ids("rows.pdf")); t2 = ex.entries(jid2)[0].table
        self.assertTrue(t2.rows[0].cell_flags and "9999.99" == t2.rows[0].orig[2])

    def test_server_trouble_never_stops_the_batch_and_retry_works(self):
        self.srv.mode = "down500"
        ex = AIExtractor(self.lib, self.prov); jid = ex.run(["Invoice No"], file_ids=self.ids("inv_0.pdf", "inv_1.pdf"))
        s = ex.br.summary(jid); self.assertEqual(s["failed"], 2)
        self.assertIn("500", ex.br.items(jid)[0]["message"])
        self.srv.mode = "good"; s = ex.retry(jid); self.assertEqual((s["failed"], s["processed"]), (0, 2))

    def test_add_new_documents_only(self):
        ex = AIExtractor(self.lib, self.prov); jid = ex.run(["Invoice No"], root_ids=[self.lib.roots()[0]["id"]])
        n_before = len([b for b in self.srv.log if b[0].endswith("/chat/completions")])
        pdf(os.path.join(self.src, "inv_9.pdf"), ["Invoice No: INV-00099", "Total: 5.00"]); self.lib.scan(); self.lib.index()
        s = ex.add_new_documents(jid); self.assertEqual(s["new_documents"], 1)
        self.assertEqual(len([b for b in self.srv.log if b[0].endswith("/chat/completions")]) - n_before, 1)       # only the new file went to the model


if __name__ == "__main__":
    unittest.main()


class Compare(Base):
    def test_compare_two_models_good_vs_inventing(self):
        from docintel.llm.compare import compare_models, format_report
        bad = Fake("hallucinate")
        try:
            reg = self.lib.ai_models()
            reg.save({"name": "Good", "type": "other", "base_url": self.srv.url, "model": "fake-chat"})
            reg.save({"name": "Sloppy", "type": "other", "base_url": bad.url, "model": "fake-chat"})
            res = compare_models(self.lib, ["Good", "Sloppy"], self.ids("inv_0.pdf", "inv_1.pdf"), ["Invoice No", "Total"])
            g, s = res
            self.assertEqual(g["verified_pct"], 100.0); self.assertLess(s["verified_pct"], 100.0)
            self.assertLess(g["agree"]["Sloppy"], 100.0)                                       # they disagree on the invented value
            self.assertIn("confirmed in the document text", format_report(res))
            self.assertEqual(self.lib.db.one("SELECT COUNT(*) n FROM doc_tables WHERE method LIKE 'ai-%'")["n"], 0)   # nothing saved
        finally:
            bad.stop()
