"""Download the pinned OCR language files and verify their SHA-256. Used by the release build (needs internet once).
    python tools/download_models.py <target_dir>"""
import hashlib, json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()


def fetch(target):
    spec = json.load(open(os.path.join(HERE, "..", "resources", "models.json")))
    os.makedirs(target, exist_ok=True)
    for name, d in spec["files"].items():
        p = os.path.join(target, name)
        if not (os.path.exists(p) and sha(p) == d["sha256"]):
            for attempt in range(3):
                try:
                    urllib.request.urlretrieve(d["url"], p); break
                except Exception as e:
                    if attempt == 2: raise
        if sha(p) != d["sha256"]:
            raise SystemExit(f"CHECKSUM MISMATCH for {name}: refusing to continue")
        print("ok", name)
    return target


if __name__ == "__main__":
    fetch(sys.argv[1])
