# AI-ready, but AI-free (v1.7.0-m7)
DocIntel works completely without any AI. This release only prepares the clean interfaces a future assistant (local or online) would use.

**Structured records with sources** (`docintel/retrieval.py`, also `docintel-cli records`): every extracted table row can be found by words, by column filters (`Urgency=High`, `Qty>10`, `Status~open`) and by scope (document type, section, folder). Each record carries its source: file, page, table/section, row.
Example: `docintel-cli records --filter "Urgency=High" --section "Issues" --ext pdf --json`

**Evidence packs**: only the selected records (never whole documents), numbered E1, E2, ...; a list of exactly what would be sent is shown before anything is sent.

**Providers** (`docintel/llm/`): by default NONE is connected, nothing is sent anywhere and the "Ask Documents" button does not appear. A provider can be a local model (stays on this computer) or any online service that speaks the common chat protocol; the API key is read from an environment variable you name and is never stored by DocIntel.
**Safety gate**: an online provider is blocked while offline mode is on (default). Even when allowed, every send needs your confirmation of THIS exact set of records; every send is logged (what, how many, when - not the content).
**Answers** must cite the records [E#]; an answer without sources, or one that cites records that were not provided, is flagged as unverified.

Not done yet: a screen to connect a provider (settings keys exist: llm_provider, llm_base_url, llm_model, llm_key_env), semantic (meaning-based) search, any real model test.
