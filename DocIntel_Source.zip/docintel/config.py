import json, os


from . import paths


def app_dir():
    return paths.data_dir()


DEFAULTS = {
    "offline_mode": True,
    "workers": 2,
    "max_file_mb": 400,
    "max_pdf_pages": 2000,
    "max_ocr_pixels": 60_000_000,
    "ocr_langs": "eng+ara",
    "ocr_dpi": 250,
    "min_free_disk_mb": 500,
    "default_excludes": ["~$*", "*.tmp", "Thumbs.db", ".DS_Store", "$RECYCLE.BIN",
                         "System Volume Information", ".git", "node_modules"],
    "day_first": True,
    "review_confidence_threshold": 0.75,
    "tesseract_cmd": "",
    "tessdata_dir": "",
    "first_run_done": False,
}


class Config:
    def __init__(self, home=None):
        self.home = home or app_dir()
        os.makedirs(self.home, exist_ok=True)
        self.path = os.path.join(self.home, "config.json")
        self.data = dict(DEFAULTS)
        if os.path.exists(self.path):
            try:
                self.data.update(json.load(open(self.path, encoding="utf-8")))
            except Exception:
                pass

    def __getitem__(self, k):
        return self.data[k]

    def get(self, k, d=None):
        return self.data.get(k, d)

    def set(self, k, v):
        self.data[k] = v
        self.save()

    def save(self):
        tmp = self.path + ".tmp"
        json.dump(self.data, open(tmp, "w", encoding="utf-8"), indent=2)
        os.replace(tmp, self.path)

    @property
    def db_path(self):
        return os.path.join(self.home, "index.db")

    @property
    def log_path(self):
        return os.path.join(self.home, "docintel.log")
