"""Source-region previews: render the page/image region a value came from, with the value highlighted."""
import json, os


def render_preview(path, loc, bbox=None, page_w=0, page_h=0, out_path=None, margin=60, dpi=150):
    from PIL import Image, ImageDraw, ImageOps
    ext = os.path.splitext(path)[1].lower()
    img = None
    if ext == ".pdf":
        import pypdfium2 as pdfium
        pno = int(loc.lstrip("p")) - 1 if loc.startswith("p") and loc[1:].isdigit() else 0
        doc = pdfium.PdfDocument(path)
        try:
            img = doc[pno].render(scale=dpi / 72.0).to_pil().convert("RGB")
        finally:
            doc.close()
    elif ext in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp"):
        im = Image.open(path)
        if loc.startswith("frame") and loc[5:].isdigit():
            im.seek(int(loc[5:]) - 1)
        img = ImageOps.exif_transpose(im).convert("RGB")
    else:
        return None      # office/text/dxf: no region preview (the located text is shown in the UI instead)
    if bbox and page_w:
        f = img.width / page_w
        x0, y0, x1, y1 = [v * f for v in bbox]
        d = ImageDraw.Draw(img, "RGBA")
        d.rectangle([x0 - 3, y0 - 3, x1 + 3, y1 + 3], outline=(255, 0, 0, 255), width=3, fill=(255, 255, 0, 70))
        img = img.crop((max(0, x0 - margin * 3), max(0, y0 - margin), min(img.width, x1 + margin * 3), min(img.height, y1 + margin)))
    if out_path:
        img.save(out_path)
    return img
