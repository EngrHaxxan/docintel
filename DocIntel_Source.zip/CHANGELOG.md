# Changelog

## 1.0.0 (Windows release candidate) - changes since the first delivery
**Windows readiness**
- NEW `paths.py`: installed vs portable data folders, resource folders, safe long-path handling. Portable marker file `portable.txt`.
- FIXED scanner would have stored `\\?\`-prefixed paths and failed relative-path calculations on Windows long paths.
- FIXED Tesseract language path now passed via `TESSDATA_PREFIX` (quoted CLI option broke on spaces/backslashes); bundled Tesseract chosen per OS.
- NEW case-insensitive duplicate-root detection on Windows; no console windows for helper processes; DPI awareness; windowed-build stdout handling; UTF-8 CLI output.
- FIXED build spec (`docintel.spec`) had a comment swallowing the closing parenthesis - the earlier delivery's build script could not have worked.
- NEW app icon, GUI+CLI executables, Inno Setup installer (Start Menu, optional desktop icon, uninstall with optional data removal), portable zip.
- NEW GitHub Actions Windows pipeline (tests, build, portable/offline/installer checks, release), pinned Tesseract + language files by SHA-256, `constraints.txt`.
- NEW `tools/smoke_packaged.py` end-to-end test of packaged builds; `DocIntel.exe gui --smoke-test`.

**For non-technical users**
- NEW "Start here" page, first-run welcome and environment check, Help menu, plain-English error messages with next steps (`friendly.py`),
  drag-and-drop folders, "Describe fields I want" helper, indexing-complete prompt, 11-page User Guide PDF, click-by-click build guide.

**OCR**
- CORRECTED earlier finding: Arabic OCR was *not* poor; the earlier test image was generated incorrectly. With correctly shaped text, English+Arabic read at ~100 % on clean, skewed, low-resolution, blurred, JPEG-damaged and speckled images.
- NEW small-angle deskew (Pillow only), automatic denoise retry for low-confidence pages, removal of invisible bidi marks from OCR output.

**Excel**
- NEW templates containing charts, pictures/shapes, pivot tables, slicers or form controls are blocked from being rewritten unless the user chooses a safer results-only workbook or explicitly accepts losing those items (original is never changed).
- FIXED update-by-key matching when the key column holds real dates/numbers.

**Tests**: 43 automated tests (was 34) + 4 platform-specific skips.
