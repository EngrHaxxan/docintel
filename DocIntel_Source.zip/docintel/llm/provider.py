"""Providers: the only place that could talk to a language model. Default = NoProvider (nothing connected, nothing sent)."""
from __future__ import annotations
import json, os, urllib.request


class ProviderError(Exception):
    pass


class ProviderUnavailable(ProviderError):
    pass


class Provider:
    name = "none"
    kind = "none"                  # "local" (stays on this computer) | "remote" (leaves the computer) | "none"

    def available(self):
        return False

    def complete(self, system, user, max_tokens=800):
        raise ProviderUnavailable("No AI assistant is connected. Search, extraction and Excel export work without it.")


class NoProvider(Provider):
    pass


class CallableProvider(Provider):
    """Wraps a Python function (local model, or a test double). kind='local' means nothing leaves the computer."""
    def __init__(self, fn, name="callable", kind="local"):
        self.fn, self.name, self.kind = fn, name, kind

    def available(self):
        return True

    def complete(self, system, user, max_tokens=800):
        return self.fn(system, user)


class OpenAICompatProvider(Provider):
    """Any server that speaks the common /v1/chat/completions protocol: a local one (localhost) or a remote one. The API key is read
    from an environment variable the user names; it is never stored by DocIntel and never written to the index."""
    def __init__(self, base_url, model, key_env="", timeout=60):
        self.base_url, self.model, self.key_env, self.timeout = base_url.rstrip("/"), model, key_env, timeout
        host = self.base_url.split("//", 1)[-1].split("/", 1)[0].split(":")[0]
        self.kind = "local" if host in ("localhost", "127.0.0.1", "::1") else "remote"
        self.name = f"{self.kind}:{host}/{model}"

    def available(self):
        return bool(self.base_url and self.model)

    def complete(self, system, user, max_tokens=800):
        body = json.dumps({"model": self.model, "max_tokens": max_tokens, "temperature": 0,
                           "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/chat/completions", data=body, headers={"Content-Type": "application/json"})
        key = os.environ.get(self.key_env, "") if self.key_env else ""
        if key:
            req.add_header("Authorization", "Bearer " + key)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))["choices"][0]["message"]["content"]
        except Exception as e:
            raise ProviderError(f"The AI service could not be reached or answered with an error ({type(e).__name__}).") from e


def provider_from_config(cfg):
    """llm_provider in the settings: 'none' (default) or 'openai-compatible' with llm_base_url / llm_model / llm_key_env."""
    if (cfg.get("llm_provider") or "none") == "openai-compatible" and cfg.get("llm_base_url") and cfg.get("llm_model"):
        return OpenAICompatProvider(cfg["llm_base_url"], cfg["llm_model"], cfg.get("llm_key_env", ""))
    return NoProvider()
