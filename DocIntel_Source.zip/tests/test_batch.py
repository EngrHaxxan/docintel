"""Milestone 4: profiles + batch jobs. Run: python -m unittest tests.test_batch"""
import json, os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from openpyxl import load_workbook
from docintel.library import Library, JobControl
from docintel.wizard import Session
from docintel import batch
from docintel.batch import BatchRunner, new_profile

HERE = os.path.dirname(os.path.abspath(__file__))
DAILY = os.path.join(HERE, "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")


def heading_pdf(path, heading, rows):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from tests.make_table_pdfs import ST
    from reportlab.lib.styles import ParagraphStyle
    h = ParagraphStyle("H", parent=ST["Heading1"], fontSize=18)
    data = [["S.No", "Activity", "Status"]] + rows
    t = Table(data); t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.7, colors.black), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]))
    SimpleDocTemplate(path, pagesize=A4).build([Paragraph(heading, h), Spacer(1, 12), t])


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.a, self.b = os.path.join(self.tmp, "a"), os.path.join(self.tmp, "b")
        os.makedirs(self.a); os.makedirs(self.b)
        shutil.copy(DAILY, os.path.join(self.a, "daily_01.pdf")); shutil.copy(DAILY, os.path.join(self.a, "daily_02.pdf"))
        heading_pdf(os.path.join(self.b, "similar.pdf"), "Construction Progress", [["1", "Piling", "Done"], ["2", "Backfill", "Open"]])
        heading_pdf(os.path.join(self.b, "unrelated.pdf"), "Safety Statistics", [["1", "Toolbox talk", "Done"]])
        with open(os.path.join(self.b, "broken.pdf"), "wb") as f: f.write(b"%PDF-1.4 this is not really a pdf")
        with open(os.path.join(self.b, "notes.txt"), "w") as f: f.write("just text")
        self.lib = Library(os.path.join(self.tmp, "home"))
        self.lib.add_root(self.a); self.lib.add_root(self.b); self.lib.scan()
        self.run_ = BatchRunner(self.lib)
        self.prof = new_profile("Construction", section={"heading": "Construction Activities", "aliases": []})

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _job(self):
        return self.run_.run(self.prof, root_ids=[r["id"] for r in self.lib.roots()])

    def test_profile_roundtrip_and_starters(self):
        batch.save_profile(self.lib.db, self.prof)
        p = batch.load_profile(self.lib.db, "Construction")
        self.assertEqual(p["section"]["heading"], "Construction Activities")
        self.assertNotIn("page", json.dumps(p).lower().replace("page_", ""))            # nothing page dependent
        names = [x["name"] for x in batch.list_profiles(self.lib.db)]
        self.assertIn("Construction", names); self.assertTrue(any("SCAL" in n for n in names))
        batch.delete_profile(self.lib.db, "Construction")
        self.assertIsNone(batch.load_profile(self.lib.db, "Construction"))

    def test_batch_continues_after_failures_and_reports_every_file(self):
        jid = self._job()
        s = self.run_.summary(jid)
        self.assertEqual(s["total"], 6)
        self.assertEqual(s["processed"], 2)                      # two real daily reports
        self.assertEqual(s["records"], 8)                         # 4 construction rows each
        self.assertEqual(s["failed"], 1)                          # broken.pdf did not stop the batch
        self.assertEqual(s["unsupported"], 1)                     # notes.txt is reported, not skipped silently
        st = {i["name"]: i["status"] for i in self.run_.items(jid)}
        self.assertEqual(st["unrelated.pdf"], "section_not_found")
        self.assertEqual(st["similar.pdf"], "needs_confirmation")  # similar heading is shown, never assumed
        self.assertEqual(self.run_.job_profile(jid)["section"]["aliases"], [])
        self.assertEqual(self.lib.db.one("SELECT status FROM extraction_jobs WHERE id=?", (jid,))["status"], "done")

    def test_confirm_alias_then_export_with_report(self):
        jid = self._job()
        cand = json.loads(next(i for i in self.run_.items(jid) if i["name"] == "similar.pdf")["candidates_json"])
        self.assertEqual(cand[0]["heading"], "Construction Progress")
        s = self.run_.confirm_section(jid, cand[0]["heading"], save_to_profile=False)
        self.assertEqual(s["needs_confirmation"], 0)
        self.assertEqual(s["records"], 10)
        out = os.path.join(self.tmp, "out.xlsx")
        self.run_.export_job(jid, out, arrangement="per_table")
        wb = load_workbook(out)
        self.assertIn("Job report", wb.sheetnames)
        rep = list(wb["Job report"].iter_rows(values_only=True))
        self.assertEqual(len(rep), 7)                             # header + 6 documents
        self.assertTrue(any(r[2] == "Failed" for r in rep[1:]) and any(r[2] == "Section not found" for r in rep[1:]))

    def test_stacked_export_one_sheet_with_source_columns(self):
        jid = self._job()
        out = os.path.join(self.tmp, "stack.xlsx")
        self.run_.export_job(jid, out)
        wb = load_workbook(out)
        sheets = [n for n in wb.sheetnames if n not in ("Summary", "Job report")]
        self.assertEqual(len(sheets), 1)
        rows = list(wb[sheets[0]].iter_rows(values_only=True))
        self.assertEqual(len(rows) - 1, 8)
        self.assertIn("Source file", [str(c) for c in rows[0]])

    def test_retry_fixed_document_and_add_new_documents_only(self):
        jid = self._job()
        shutil.copy(DAILY, os.path.join(self.b, "broken.pdf"))            # the user repairs the file
        self.lib.scan()
        before = {i["name"]: i["updated"] for i in self.run_.items(jid)}
        s = self.run_.retry(jid)
        self.assertEqual(s["failed"], 0); self.assertEqual(s["processed"], 3)
        shutil.copy(DAILY, os.path.join(self.a, "daily_03.pdf")); self.lib.scan()
        s = self.run_.add_new_documents(jid)
        self.assertEqual(s["new_documents"], 1); self.assertEqual(s["processed"], 4); self.assertEqual(s["records"], 16)
        after = {i["name"]: i["updated"] for i in self.run_.items(jid)}
        self.assertEqual(before["daily_01.pdf"], after["daily_01.pdf"])    # unchanged documents were not processed again

    def test_cancel_and_resume(self):
        ctl = JobControl(); n = []
        def prog(i, t, name):
            n.append(i)
            if i == 2:
                ctl.cancel()
        jid = self.run_.run(self.prof, root_ids=[r["id"] for r in self.lib.roots()], control=ctl, progress=prog)
        self.assertEqual(self.lib.db.one("SELECT status FROM extraction_jobs WHERE id=?", (jid,))["status"], "cancelled")
        self.assertGreater(self.run_.summary(jid)["pending"], 0)
        s = self.run_.resume(jid)
        self.assertEqual(s["pending"], 0); self.assertEqual(s["total"], 6)

    def test_fields_filter_and_header_signature(self):
        p = new_profile("Issues", section={"heading": "Issues & Concerns", "aliases": []}, fields=["Issue Type", "Urgency", "Owner", "Nonexistent Thing"])
        jid = self.run_.run(p, file_ids=[f["id"] for f in self.lib.db.q("SELECT id FROM files WHERE name='daily_01.pdf'")])
        ents = self.run_.entries(jid)
        self.assertEqual(len(ents), 1); self.assertEqual(len(ents[0].table.rows), 3)
        self.assertEqual(self.run_.summary(jid)["partial"], 1)             # missing requested field is reported, not invented
        self.assertIn("Nonexistent Thing", [h.name for h in ents[0].table.headers])
        sig = new_profile("Bysig", table={"headers": ["S.No", "Issue Type", "Urgency", "Impact"], "min_match": 0.75})
        jid = self.run_.run(sig, file_ids=[f["id"] for f in self.lib.db.q("SELECT id FROM files WHERE name='daily_02.pdf'")])
        ents = self.run_.entries(jid)
        self.assertEqual([len(e.table.rows) for e in ents], [3])           # found by header words, no section name needed

    def test_profile_from_session_has_no_page_numbers(self):
        s = Session(self.lib); s.select_files([f["id"] for f in self.lib.db.q("SELECT id FROM files WHERE name='daily_01.pdf'")]); s.prepare()
        s.build("section", headings=["Construction Activities"], fields=["Location", "Work status"])
        p = batch.profile_from_session(s, "From wizard")
        self.assertEqual(p["section"]["heading"], "Construction Activities"); self.assertEqual(p["fields"], ["Location", "Work status"])
        jid = self.run_.run(p, root_ids=[r["id"] for r in self.lib.roots()][:1])
        self.assertEqual(self.run_.summary(jid)["records"], 8)

    def test_request_only_profile(self):
        p = new_profile("Req", request="Extract every issue from the Issues & Concerns section, including Issue Type, Urgency and Owner")
        jid = self.run_.run(p, root_ids=[self.lib.roots()[0]["id"]])
        self.assertEqual(self.run_.summary(jid)["records"], 6)


if __name__ == "__main__":
    unittest.main()


class RealPdfBatchTests(unittest.TestCase):
    """The user's real PDFs through the batch route, found by column names only (no page numbers, no hard-coded layout)."""
    def test_scal_raci_daily_by_header_names(self):
        import time
        tmp = tempfile.mkdtemp()
        d = os.path.join(tmp, "docs"); os.makedirs(d)
        for n in ("WI-NG-6460-001-001_SCAL_Rev03.pdf", "RACI_Matrix_UGC_Submittals.pdf", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf"):
            shutil.copy(os.path.join(HERE, "real_pdfs", n), d)
        lib = Library(os.path.join(tmp, "home")); lib.add_root(d); lib.scan()
        r = BatchRunner(lib)
        scal = new_profile("scal", table={"headers": ["Sr.", "Main Activity Name", "Main Activity Test Code", "Sub-Activity Name", "Sub-Activity Test Code", "Duration In Hours", "Unit", "Remarks"], "min_match": 0.75})
        jid = r.run(scal, root_ids=[lib.roots()[0]["id"]])
        by = {i["name"]: i for i in r.items(jid)}
        s = by["WI-NG-6460-001-001_SCAL_Rev03.pdf"]
        self.assertEqual(s["status"], "processed"); self.assertEqual(s["records"], 1000)            # whole 41-page table, no row limit
        self.assertEqual(by["RACI_Matrix_UGC_Submittals.pdf"]["status"], "table_not_found")         # other tables are not mixed in
        self.assertEqual(by["MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf"]["status"], "table_not_found")
        raci = new_profile("raci", table={"headers": ["SN", "Submittal Title", "Submittal Type", "Submittal Code"], "min_match": 0.75})
        jid2 = r.run(raci, root_ids=[lib.roots()[0]["id"]])
        by = {i["name"]: i for i in r.items(jid2)}
        self.assertEqual(by["RACI_Matrix_UGC_Submittals.pdf"]["records"], 134)
        out = os.path.join(tmp, "scal.xlsx")
        r.export_job(jid, out)
        wb = load_workbook(out, read_only=True)
        self.assertIn("Job report", wb.sheetnames)
        shutil.rmtree(tmp, ignore_errors=True)
