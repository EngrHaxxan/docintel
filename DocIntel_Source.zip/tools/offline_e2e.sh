#!/bin/sh
# End-to-end workflow run inside an isolated network namespace (no interfaces at all) to prove offline operation.
# Usage: unshare -rn sh tools/offline_e2e.sh <corpus_dir> <home_dir>
set -e
C=$1; H=$2
rm -rf "$H"; export DOCINTEL_HOME="$H"
ip -br addr 2>/dev/null | grep -v '^lo' || echo "network interfaces: loopback only"
python3 -m docintel add-root "$C/driveA" "$C/driveB" "$C/driveC"
python3 -m docintel update | tail -1
python3 -m docintel profile-save samples/profiles/daily_report.json
python3 -m docintel extract "Daily report"
python3 -m docintel export 1 --out "$H/out.xlsx" --template "$C/template.xlsx"| grep -E '"output"|verified'
python3 -m docintel search "INV-00777" | head -2
python3 -m docintel doctor | grep -E '\[!!\]|OK' | head -3
