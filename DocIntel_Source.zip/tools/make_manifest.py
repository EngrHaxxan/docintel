"""Write/verify a SHA-256 manifest for model files:  make_manifest.py <dir> <out.json>   |   make_manifest.py --verify <dir> <manifest.json>"""
import hashlib, json, os, sys

def h(p):
    s = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): s.update(b)
    return s.hexdigest()

if sys.argv[1] == "--verify":
    d, m = sys.argv[2], json.load(open(sys.argv[3])); bad = [k for k, v in m.items() if not os.path.exists(os.path.join(d, k)) or h(os.path.join(d, k)) != v]
    print("OK: all model files match" if not bad else f"MISMATCH: {bad}"); sys.exit(1 if bad else 0)
d, out = sys.argv[1], sys.argv[2]
m = {f: h(os.path.join(d, f)) for f in sorted(os.listdir(d)) if f.endswith(".traineddata")}
json.dump(m, open(out, "w"), indent=2); print(f"{len(m)} files hashed -> {out}")
