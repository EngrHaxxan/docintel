"""Builds docs/DocIntel_User_Guide.pdf (plain-language, for non-technical users). Describes the Home screen with six actions."""
import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=18, textColor=colors.HexColor("#1F4E78"), spaceBefore=8, spaceAfter=8)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=13, textColor=colors.HexColor("#1F4E78"), spaceBefore=10, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=10.5, leading=15)
NOTE = ParagraphStyle("N", parent=B, backColor=colors.HexColor("#EEF3F8"), borderPadding=6, spaceBefore=6, spaceAfter=8)
STEP = ParagraphStyle("S", parent=B, leftIndent=18, bulletIndent=2)
CELL = ParagraphStyle("c", parent=B, fontSize=9.5, leading=12)
HDR = ParagraphStyle("h", parent=CELL, textColor=colors.white, fontName="Helvetica-Bold")


def steps(items):
    return [Paragraph(t, STEP, bulletText=f"{i}.") for i, t in enumerate(items, 1)]


def table(data, widths=(5.6, 11.4)):
    rows = [[Paragraph(c, HDR if i == 0 else CELL) for c in r] for i, r in enumerate(data)]
    t = Table(rows, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E78")), ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    return t


def build(out):
    d = SimpleDocTemplate(out, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm, title="DocIntel User Guide")
    s = [Paragraph("DocIntel", ParagraphStyle("T", parent=H1, fontSize=30)),
         Paragraph("User Guide - from your documents to a clean Excel table", ParagraphStyle("T2", parent=H2, fontSize=14)), Spacer(1, 10),
         Paragraph("DocIntel reads your PDFs (text and scanned), Word, Excel, PowerPoint, HTML and CSV files, finds the tables and sections inside them, and puts the "
                   "information you choose into Excel - for one document or for hundreds. It works entirely on your computer, needs no internet, and never changes your documents.", B),
         Paragraph("Contents", H2),
         Paragraph("1. Install &nbsp; 2. The Home screen &nbsp; 3. Add documents &nbsp; 4. Search &nbsp; 5. Extract to Excel (the 5 steps) &nbsp; 6. Review results &nbsp; 7. Export &nbsp; "
                   "8. Hundreds of reports: saved extractions and batch jobs &nbsp; 9. When the table is not found: select it by hand &nbsp; 10. Scanned documents &nbsp; "
                   "11. History &nbsp; 12. Speed settings &nbsp; 13. AI tools with a model on your own computer (optional) &nbsp; 14. If something goes wrong &nbsp; 15. Honest limits", B), PageBreak()]
    s += [Paragraph("1. Install", H1), Paragraph("Use whichever file you received:", B), Paragraph("<b>DocIntel_Setup.exe</b> (installer)", H2)] + steps([
        "Double-click <b>DocIntel_Setup.exe</b>. If Windows says <b>Windows protected your PC</b>, click <b>More info</b>, then <b>Run anyway</b> (a new program from a small publisher).",
        "Click <b>Next</b> through the screens, then <b>Install</b> and <b>Finish</b>. Start DocIntel from the desktop icon or Start menu."]) + [
        Paragraph("<b>DocIntel_Portable_Windows_x64.zip</b> (no installation)", H2)] + steps([
        "Right-click the zip, choose <b>Extract All...</b>, pick any folder, open the new <b>DocIntel</b> folder and double-click <b>DocIntel.exe</b>.",
        "Your settings and index are kept inside that folder, so you can move the whole folder to another computer."]) + [
        Paragraph("You do not need to install Python, Tesseract or anything else. Administrator rights are not required.", NOTE)]
    s += [Paragraph("2. The Home screen", H1), Paragraph("DocIntel opens on a page with six large buttons. This is all most people ever need:", B),
          table([["Button", "What it does"],
                 ["1. Add Documents", "Add folders (all subfolders are included) or single files. DocIntel reads them in the background and remembers them."],
                 ["2. Search Documents", "Find words, codes, numbers or values across everything you added; open the source page."],
                 ["3. Extract to Excel", "The guided wizard: choose documents, say what you want, check the preview, export."],
                 ["4. Review Results", "See values DocIntel was unsure about and fix them; your correction is kept and the original is never lost."],
                 ["5. Export to Excel", "Save the result as a clean workbook (one sheet, or one per table, document or file)."],
                 ["6. Extraction History", "See earlier exports and batch jobs."]]),
          Paragraph("At the bottom: <b>Saved extractions &amp; batch jobs</b> (section 8) and <b>Show advanced tools</b> (the classic tabs: sources, settings, compare, diagnostics).", NOTE), PageBreak()]
    s += [Paragraph("3. Add documents", H1)] + steps([
        "Click <b>Add Documents</b> and choose a folder. Repeat for every folder or drive you need. You can also drag folders into the window.",
        "DocIntel reads the files in the background; you can keep working. The first time takes longest. After that only new or changed files are read again.",
        "A file that cannot be read (password, damaged) is listed with the reason - nothing is skipped silently."])
    s += [Paragraph("4. Search", H1), Paragraph("Type what you look for. You can search file names, text, table cells, section headings and codes; exact words, parts of words, phrases, several words, "
                                                "and special characters (65%, DTS-022, 110/13.8 kV, Tan &#8706;). Pick a result to see the page; double-click to open the file. "
                                                "Cells of tables you have already extracted are searched too.", B)]
    s += [Paragraph("5. Extract to Excel (the 5 steps)", H1)] + steps([
        "<b>Choose documents</b>: a folder, several folders, single files, or everything you added. Untick documents you do not want.",
        "<b>What do you want?</b> All tables, one table, one section (for example <i>Construction Activities</i>), rows containing a word, certain columns, all text - or "
        "<b>describe it in your own words</b> (for example: <i>every issue with urgency, owner and status</i>).",
        "<b>Pick the target</b>: DocIntel shows the headings and tables it found. If you are not sure which table you need, type what you need under "
        "<b>Not sure which? Describe what you need</b> and click <b>Suggest tables</b>: it ranks the tables and tells you how many documents have the same layout. "
        "A heading that is only <i>similar</i> to the one you asked for is always shown to you first - DocIntel never assumes.",
        "<b>Preview</b>: a spreadsheet-like view. Rename or hide columns, correct a value, mark a value as uncertain. Original column titles are kept in the record.",
        "<b>Export</b>: choose the layout and click <b>Export to Excel</b> (section 7). You can also click <b>Save these choices as a reusable extraction</b> (section 8)."])
    s += [Paragraph("Merged cells", H2), Paragraph("Many tables show a value once for a group of rows. <b>Original layout</b> keeps the blanks as in the document; <b>Normalized</b> repeats the value on every row, "
                                                    "which is better for filtering and sorting. A repeated value is never invented: it is marked in the record.", B), PageBreak()]
    s += [Paragraph("6. Review results", H1), Paragraph("DocIntel does not present doubtful results as certain. Values from scanned pages, values read from a table that continues over a page break, and values "
                                                         "you marked are listed in <b>Review Results</b>. Click one to see the source page with the value boxed. Correct it, or confirm it. Your correction is stored "
                                                         "separately - the original text stays - and the corrected value goes into the export.", B)]
    s += [Paragraph("7. Export", H1), table([["Choice", "Result"], ["One workbook, tables stacked", "All tables with the same columns in one worksheet (dates in column titles are ignored, so 30 daily reports become one list)."],
                                              ["Everything in one worksheet", "Every table below the other in a single sheet - easy to filter."],
                                              ["One worksheet per table / document", "Separate sheets."], ["One Excel file per document", "A folder of workbooks."],
                                              ["CSV", "Plain text files for other programs."]]),
          Spacer(1, 6), Paragraph("Every workbook has source columns (document, page, table, row), an extraction date and a <b>Summary</b> sheet. Values are exported exactly as written (65% stays 65%, "
                                  "001 stays 001); you can choose to convert clear numbers and dates instead. Headers, filters, frozen header row and column widths are set for you. "
                                  "A sheet that would exceed Excel's row limit is continued on another sheet and you are told.", B), PageBreak()]
    s += [Paragraph("8. Hundreds of reports: saved extractions and batch jobs", H1), Paragraph("Example: you have 500 daily reports and want <i>Construction Activities</i> from all of them in one list.", B)] + steps([
        "In the wizard (step 5) click <b>Save these choices as a reusable extraction</b> and give it a name. Or open <b>Saved extractions &amp; batch jobs</b> and click <b>New...</b> "
        "(DocIntel also offers examples such as <i>Daily report - Issues &amp; Concerns</i>). A saved extraction remembers the <b>section name or the column titles</b>, never page numbers.",
        "Select it, click <b>Run on documents...</b>, choose the folders, <b>Start</b>. You can cancel at any time and continue later.",
        "Every document gets a result: <b>Done</b>, <b>Section not found</b>, <b>Similar heading found - please confirm</b>, <b>Failed</b>, <b>File type not supported</b>. One bad file never stops the others.",
        "Click <b>Show documents</b> to read the list. For a similar heading, select the document and click <b>This heading is the same section...</b>; it is remembered.",
        "Click <b>Export to Excel</b>: the workbook has all records, and a <b>Job report</b> sheet that lists every document, including the ones that failed.",
        "Next week: click <b>Add new documents</b> - only new or changed files are processed. <b>Retry failed</b> tries the failed ones again."])
    s += [Paragraph("9. When the table is not found: select it by hand", H1), Paragraph("If DocIntel cannot find your table, or finds the wrong one: in step 3 of the wizard click "
                                                                                          "<b>My table is not in the list - select it by hand...</b>", B)] + steps([
        "Choose the document. The page is shown. <b>Drag a rectangle</b> around the table.",
        "Click <b>Preview</b>. Columns are found automatically; if they are wrong, switch to <b>Click the column lines</b> and click where each column starts (right-click removes a line). "
        "Set the number of <b>header rows</b> (0 if the table has none).",
        "When the rows look right, click <b>Save table</b>. It is stored with the document and used by Export.",
        "Many documents with the same layout? Click <b>Save selection and apply to other documents...</b>, choose them, and check the results (DocIntel warns when the column titles differ)."])
    s += [Paragraph("10. Scanned documents", H1), Paragraph("Pages without selectable text are read with OCR. Tables in scans are rebuilt from the position of the words and the table lines. "
                                                            "Results from scans are always marked <b>read with OCR - please verify</b> and never shown as fully certain; check numbers and codes against the page. "
                                                            "Quality depends on the scan: clear, straight, 200-300 dpi scans work best. Arabic is supported, but scanned Arabic tables are less reliable "
                                                            "than English (see section 15). Choose the OCR languages in <b>Settings</b>.", B), PageBreak()]
    s += [Paragraph("11. History", H1), Paragraph("<b>Extraction History</b> lists your earlier exports (when, what, where saved); <b>Batch jobs</b> lists saved jobs with their summary "
                                                   "(documents, done, failed, section not found, records, rows needing review). Open a job to continue it, retry it or export it again.", B),
          Paragraph("12. Speed settings", H1), Paragraph("<b>Settings &gt; Processing speed</b>: <i>Balanced</i> uses half of your processor cores, <i>Faster</i> uses all but one, "
                                                         "<i>Low resource usage</i> uses one. DocIntel stays responsive while it works and you can pause or cancel.", B),
          Paragraph("13. AI tools with a model on your own computer", H1),
          Paragraph("DocIntel works completely without AI. If you want to talk to your documents, extract fields or tables with AI, or search by meaning, you can connect an "
                    "<b>open model that runs on your own computer</b> - no company, no internet, nothing leaves the machine. Open <b>AI tools</b> on the Home screen.", B),
          Paragraph("Step 1 - get a model server and a model", H2)] + steps([
        "Install one model server: <b>Ollama</b>, <b>LM Studio</b> or the <b>llama.cpp server</b> (free; see their own websites for installation and for the list of downloadable models).",
        "Download an open model with that tool. Start small (a few billion parameters) to test speed; try a bigger one for better accuracy if your computer can run it. "
        "Common open families include Qwen, Llama, Mistral and Gemma - for Arabic documents choose one that is described as multilingual. For meaning-based search also download an <i>embedding</i> model.",
        "Make sure the server is running (Ollama and LM Studio show a small icon or a 'start server' button)."]) + [
          Paragraph("Step 2 - connect it", H2)] + steps([
        "<b>AI tools &gt; Connect or switch AI model &gt; Add model...</b> Choose the server type (the address is filled in), click <b>Find models</b>, pick the model, click <b>Test connection</b>, then <b>Save</b>.",
        "You can save several models (for example a fast one and an accurate one). <b>Make active</b> switches between them in one click."]) + [
          Paragraph("What you can do", H2),
          table([["Tool", "What it does"],
                 ["Ask Documents", "Type a question. DocIntel first finds the relevant table rows and page text itself, shows you which records will be used, then your model answers using only those and names the sources [E1], [E2]... An answer without sources is marked as unverified."],
                 ["Extract with AI (bulk)", "Name the fields you want (for example Invoice number, Date, Total) or the columns of a table. The model reads every selected document. <b>Every value is checked against the document text</b>: values not found there are still shown but marked for review. Results are normal tables: search, review, export to Excel, job report, retry, add new documents."],
                 ["Meaning-based search", "Build the search index once (new documents are added later automatically on the next build); then questions find rows and pages by meaning, also across Arabic and English if your embedding model is multilingual."],
                 ["Compare models", "Runs the same extraction on a sample of your documents with several saved models and reports how many values were confirmed in the text, the time, and where the models disagree. Use it to choose the best model for YOUR documents."]]),
          Paragraph("Privacy: connections to a model on this computer work in offline mode. A model on another computer or an online service is blocked unless you turn off offline mode and confirm exactly what is sent each time; every send is logged.", NOTE),
          Paragraph("Models make mistakes. DocIntel reduces the risk (it only gives the model the relevant text and checks extracted values against it) but cannot remove it: always look at a sample of the results.", NOTE)]
    s += [Paragraph("14. If something goes wrong", H1), table([["What you see", "What to do"],
          ["Windows protected your PC", "Click More info, then Run anyway."],
          ["Section not found", "The heading may be written differently. Open the document list of the job: DocIntel shows similar headings for you to confirm. Or select the table by hand."],
          ["Could not identify a reliable table on page N", "Select the table by hand (section 9)."],
          ["This document contains scanned pages", "OCR is used automatically; results are marked to verify."],
          ["Some rows require review", "Open Review Results before exporting."],
          ["The Excel file cannot be written", "It is open in Excel. Close it and export again."],
          ["A folder shows UNAVAILABLE", "The drive is not connected. Reconnect it and update."],
          ["Anything else", "Advanced tools &gt; Settings &amp; Diagnostics &gt; Run self-check, or Export diagnostic report to send to support."]]), PageBreak()]
    s += [Paragraph("15. Honest limits", H1)] + [Paragraph("&bull; " + t, B) for t in [
        "Extraction is very reliable for text PDFs with clear tables (tested on the 41-page SCAL list: 1,000 of 1,000 rows, and on daily reports). It is never perfect: always look at the preview.",
        "Scanned tables work best for English, ruled or aligned tables. Digits can be misread (for example 11 read as li). Scanned Arabic tables and tables made only of dotted lines are NOT reliable yet.",
        "Section headings are not detected automatically on scanned pages; choose such tables by their column titles or select them by hand.",
        "Old Word/Excel formats (.doc, .xls) and handwriting are not read as tables. DWG drawings are not supported.",
        "AI tools need a model server you install yourself (Ollama, LM Studio, llama.cpp). DocIntel was tested with a stand-in model, not with real models: accuracy and speed depend on the model and your computer - use Compare models.",
        "Speed depends on your computer; the numbers in the test report were measured on a small test machine, not on a large library."]]
    d.build(s)


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "docs", "DocIntel_User_Guide.pdf"))
