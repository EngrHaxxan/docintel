"""Excel export of extracted tables (Milestone 2).
Layouts: original (blank where the PDF merges cells) / normalized (merged values repeated).
Values: 'raw' = exact source text for every cell (default); 'typed' = numbers/percentages/dates converted only when unambiguous
(the raw text is then also written to a companion sheet). Corrections made by the user are already part of the table rows."""
from __future__ import annotations
import datetime, os, re, warnings
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.filters import AutoFilter
from openpyxl.worksheet.table import Table as XlTable, TableStyleInfo
from .values import suggest

_NUMLIKE = re.compile(r"^[\d.,%+\-/ ]+$")
_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
MAX_ROWS = 1_048_576
_HDR_FONT, _HDR_FILL = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="1F4E78")
_WRAP = Alignment(wrap_text=True, vertical="top")
_TYPED_FMT = {"percentage": "0.##%", "date": "yyyy-mm-dd", "datetime": "yyyy-mm-dd hh:mm", "decimal": "General", "integer": "General", "currency": "#,##0.00"}


def _safe_sheet(name, used):
    base = re.sub(r"[\[\]\*\?/\\:]", "_", name).strip()[:27] or "Table"
    n, i = base, 1
    while n.lower() in used:
        i += 1; n = f"{base[:24]} ({i})"
    used.add(n.lower())
    return n


def _clean(v):
    return _BAD.sub("", v) if isinstance(v, str) else v


def column_names(table, header_style="joined"):
    """Visible column names (hidden columns removed). 'leaf' uses only the lowest header level when that stays unique."""
    hidden = set(getattr(table, "hidden_cols", []) or [])
    idx = [i for i in range(len(table.headers)) if i not in hidden]
    names = [table.headers[i].name for i in idx]
    if header_style == "leaf":
        leaves = [table.headers[i].leaf or table.headers[i].name for i in idx]
        if len(set(leaves)) == len(leaves):
            names = leaves
    return idx, names


def _unique(names):
    out, seen = [], {}
    for n in names:
        n = (n or "Column").replace("\n", " ")[:250]
        if n.lower() in seen:
            seen[n.lower()] += 1; n = f"{n} ({seen[n.lower()]})"
        else:
            seen[n.lower()] = 1
        out.append(n)
    return out


def _rows_for(table, mode, idx, names, include_source, stamp):
    extra = ["Group"] if table.has_groups else []
    meta = ["Source file", "Page", "Section / table", "Extraction method", "Needs review", "Review notes", "Corrected cells", "Extracted on"] if include_source else []
    sect = table.section or table.title
    rows = []
    for r in table.rows:
        vals = r.orig if mode == "orig" else r.norm
        row = [_clean(vals[i]) for i in idx]
        if table.has_groups:
            row.append(_clean(r.group))
        if include_source:
            pages = f"{r.pages[0]}-{r.pages[-1]}" if len(r.pages) > 1 else str(r.page)
            notes = "; ".join(sorted({f"{table.headers[c].name}: {f.split(': ', 1)[-1]}" for c, fl in r.cell_flags.items() for f in fl if f.startswith("review")}))
            nfix = sum(1 for fl in r.cell_flags.values() if any("corrected by user" in f for f in fl))
            review = "Yes" if (notes or any(f.startswith("review") for f in r.flags)) else ""
            row += [os.path.basename(table.source), pages, sect, table.method, review, notes, nfix or "", stamp]
        rows.append(row)
    return rows, extra + meta


def _write_sheet(wb, title, header, rows, typed, tcounter, max_rows):
    """Write rows to one or more sheets (rolls over at Excel's row limit). write_only keeps memory/time low."""
    header = _unique(header)
    per = max(1, max_rows - 1)
    chunks = [rows[i:i + per] for i in range(0, len(rows), per)] or [[]]
    names = []
    for ci, chunk in enumerate(chunks):
        ws = wb.create_sheet(title if ci == 0 else f"{title[:24]} ({ci + 1})")
        names.append(ws.title)
        long_cols = set()
        for j in range(len(header)):
            mx = max((len(str(r[j])) for r in chunk[:300] if j < len(r) and r[j] is not None), default=len(header[j]))
            mx = max(mx, len(header[j]))
            ws.column_dimensions[get_column_letter(j + 1)].width = max(8, min(50, mx + 2))
            if mx > 40:
                long_cols.add(j)
        ws.freeze_panes = "A2"
        hdr = []
        for h in header:
            c = WriteOnlyCell(ws, value=h); c.font = _HDR_FONT; c.fill = _HDR_FILL; c.alignment = _WRAP
            hdr.append(c)
        ws.append(hdr)
        for r in chunk:
            out = []
            for j, v in enumerate(r):
                if typed and isinstance(v, str) and v:
                    kind, parsed, _ = suggest(v)
                    if parsed is not None and kind in _TYPED_FMT and not isinstance(parsed, bool):
                        c = WriteOnlyCell(ws, value=parsed); c.number_format = _TYPED_FMT[kind]; out.append(c); continue
                if isinstance(v, str) and v and _NUMLIKE.match(v):
                    c = WriteOnlyCell(ws, value=v); c.number_format = "@"; out.append(c)     # 001, 65%, 01.02 stay exact text
                elif j in long_cols and isinstance(v, str):
                    c = WriteOnlyCell(ws, value=v); c.alignment = _WRAP; out.append(c)
                else:
                    out.append(v)
            ws.append(out)
        if chunk:
            tcounter[0] += 1
            try:
                xt = XlTable(displayName=f"T{tcounter[0]}_{re.sub(r'[^A-Za-z0-9]', '', title)[:12]}", ref=f"A1:{get_column_letter(len(header))}{len(chunk) + 1}")
                xt.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
                xt._initialise_columns()                       # write-only sheets need the table columns declared by hand
                xt.autoFilter = AutoFilter(ref=xt.ref)
                for tc_, name_ in zip(xt.tableColumns, header):
                    tc_.name = name_
                with warnings.catch_warnings():               # openpyxl always warns here; columns are declared above
                    warnings.simplefilter("ignore")
                    ws.add_table(xt)
            except Exception:
                pass
    return names


def export_tables_xlsx(tables, path, modes=("orig", "norm"), include_source=True, value_mode="raw", combine="per_table",
                       header_style="joined", max_rows=MAX_ROWS):
    """tables: list[Table] (fresh from the engine or loaded from the database).
    combine: 'per_table' (default) or 'combined' (tables with identical columns are stacked in one sheet, source columns tell them apart)."""
    typed = value_mode == "typed"
    wb = Workbook(write_only=True)
    summ = wb.create_sheet("Summary")
    used, stamp, tc = {"summary"}, datetime.date.today().isoformat(), [0]
    srows = []
    groups = []
    if combine == "combined":
        by = {}
        for t in tables:
            idx, names = column_names(t, header_style)
            key = (tuple(n.lower() for n in names), t.has_groups)
            by.setdefault(key, []).append(t)
        groups = list(by.values())
    else:
        groups = [[t] for t in tables]
    for gi, grp in enumerate(groups, 1):
        t0 = grp[0]
        idx, names = column_names(t0, header_style)
        base = t0.title or t0.section or f"Table p{t0.page_from}-{t0.page_to}"
        if len(grp) > 1:
            base = f"Combined - {base}"
        for mode in modes:
            label = "Original" if mode == "orig" else "Normalized"
            allrows, meta = [], []
            for t in grp:
                ti, tn = column_names(t, header_style)
                rr, meta = _rows_for(t, mode, ti, tn, include_source, stamp)
                allrows.extend(rr)
            sheets = _write_sheet(wb, _safe_sheet(f"{base} - {label}", used), names + meta, allrows, typed, tc, max_rows)
            if typed:       # keep the exact source text too
                _write_sheet(wb, _safe_sheet(f"{base} - {label} raw", used), names + meta, allrows, False, tc, max_rows)
            srows.append((base, label, sheets))
        for t in grp:
            rev = sum(1 for r in t.rows if any(f.startswith("review") for fl in r.cell_flags.values() for f in fl) or any(f.startswith("review") for f in r.flags))
            srows.append(("__t", t, rev))
    hdr = ["Table", "Section", "Source file", "Pages", "Columns", "Rows", "Rows needing review", "Quality", "Method", "Notes"]
    out = [[ _hdrcell(summ, h) for h in hdr]]
    for s in srows:
        if s[0] == "__t":
            t, rev = s[1], s[2]
            out.append([t.title or t.section or "", t.section, os.path.basename(t.source), f"{t.page_from}-{t.page_to}", len(t.headers), len(t.rows), rev,
                        round(t.quality, 2), t.method, "; ".join(t.quality_notes)])
    for i, w in enumerate([34, 30, 36, 8, 8, 8, 12, 8, 14, 60], 1):
        summ.column_dimensions[get_column_letter(i)].width = w
    for r in out:
        summ.append(r)
    wb.save(path)
    return path


def _hdrcell(ws, v):
    c = WriteOnlyCell(ws, value=v); c.font = Font(bold=True); return c
