"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.3.1-m3"
