"""Milestone 6: tables in scanned (image-only) PDFs, read with OCR. Arabic needs the 'ara' OCR language (bundled in the Windows build)."""
import os, shutil, subprocess, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw
import make_corpus
from docintel.library import Library
from docintel.tables import store

HAVE_TESS = shutil.which("tesseract") is not None


def langs():
    try:
        return subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return ""


ROWS = [["S.No", "Activity", "Status", "Progress"], ["1", "Backfilling", "Completed", "100%"], ["2", "Compaction", "In Progress", "45%"],
        ["3", "Fencing", "To be Started", "0%"], ["4", "Signboard", "Completed", "90%"], ["5", "Piling", "In Progress", "30%"]]


def scan_pdf(path, rows, xs=(150, 330, 760, 1160), fsize=36, title="Site Progress Summary", dpi=200):
    im = Image.new("RGB", (1654, 2339), "white"); d = ImageDraw.Draw(im)
    d.text((150, 200), title, fill="black", font=make_corpus.font(60))
    y = 400
    for r in rows:
        for x, c in zip(xs, r):
            d.text((x, y), c, fill="black", font=make_corpus.font(fsize))
        y += fsize + 34
    im.save(path, "PDF", resolution=dpi)


@unittest.skipUnless(HAVE_TESS, "tesseract not installed")
class Scanned(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.src = os.path.join(self.tmp, "s"); os.makedirs(self.src)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _tables(self, name):
        lib = Library(os.path.join(self.tmp, "h")); lib.add_root(self.src); lib.scan(); lib.index()
        res = lib.extract_tables()
        fid = lib.db.one("SELECT id FROM files WHERE name=?", (name,))["id"]
        return [store.load_table(lib.db, t["id"]) for t in store.list_tables(lib.db, fid)], res[fid]

    def test_english_scanned_table(self):
        scan_pdf(os.path.join(self.src, "scan.pdf"), ROWS)
        tabs, r = self._tables("scan.pdf")
        self.assertEqual(r["status"], "extracted", r)
        t = tabs[0]
        self.assertTrue(t.method.startswith("ocr-")); self.assertLessEqual(t.quality, 0.7)
        self.assertTrue(any("OCR" in n for n in t.quality_notes))                       # never presented as fully certain
        self.assertEqual([h.name for h in t.headers], ROWS[0])
        got = [r.orig for r in t.rows]
        ok = sum(1 for a, b in zip(got, ROWS[1:]) for x, y in zip(a, b) if x == y)
        self.assertEqual(len(got), 5)
        self.assertGreaterEqual(ok, 18, got)                                            # at least 18 of 20 cells exact (measured accuracy, see report)

    @unittest.skipUnless("ara" in langs(), "Arabic OCR data (ara) not installed here")
    def test_arabic_scanned_table_synthetic(self):
        # SYNTHETIC test only: correctly shaped Arabic drawn by this test, not a real scan
        try:
            import arabic_reshaper
            from bidi.algorithm import get_display
        except ImportError:
            self.skipTest("arabic_reshaper / python-bidi not installed")
        sh = lambda s: get_display(arabic_reshaper.reshape(s))
        rows = [["S.No", "Activity", "Status"], ["1", sh("الحفر"), "Completed"], ["2", sh("الردم"), "In Progress"], ["3", sh("التسوية"), "Completed"]]
        scan_pdf(os.path.join(self.src, "ar.pdf"), rows, xs=(150, 330, 900))
        tabs, r = self._tables("ar.pdf")
        self.assertTrue(tabs and len(tabs[0].rows) >= 3)


if __name__ == "__main__":
    unittest.main()
