"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.9.0-m9"
