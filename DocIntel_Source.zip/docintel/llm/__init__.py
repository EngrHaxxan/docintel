"""Optional AI assistant layer (Milestone 7). Nothing here is used unless the user connects a provider; the application is complete without it."""
