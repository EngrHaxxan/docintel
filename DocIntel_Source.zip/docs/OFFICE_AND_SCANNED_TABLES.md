# Tables from Word, Excel, PowerPoint, HTML, CSV and scanned PDFs (v1.6.0-m6)
These now work in "Extract to Excel" and in saved extractions / batch jobs, exactly like PDF tables (sections, headers, merged cells, review, Excel export, search).
- **Word (.docx):** each table is found under the nearest Heading. Vertically merged cells: blank in "Original layout", repeated in "Normalized".
- **Excel (.xlsx/.xlsm):** each block of rows separated by an empty row is a table; a single-cell row above it is its title; the sheet name is kept. Merged cells like Word. Percent cells keep the displayed form (65%), codes keep leading zeros. Formulas show the value Excel last saved. Hidden sheets are skipped.
- **PowerPoint, HTML, CSV:** each table is read as one table (slide number kept for PowerPoint).
- **Scanned PDFs:** pages without a text layer are read with OCR (300 dpi) and the table is rebuilt from the position of the words. These tables are always marked "scanned page read with OCR - please verify" and never exceed quality 0.70. Tables drawn with ruling lines on scans are read by word alignment only.
- Limits: not tested on real scans or real Arabic scans (only synthetic images); old Word/Excel formats (.doc/.xls) are not read as tables yet; one table that continues over several Word pages is not stitched.
