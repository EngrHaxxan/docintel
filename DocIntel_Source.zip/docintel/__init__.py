"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.2.0-m2"
