"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.4.1-m4"
