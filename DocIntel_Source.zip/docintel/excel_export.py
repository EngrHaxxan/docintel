"""Safe Excel export. Never overwrites existing data silently; backs up / writes a new file by default;
re-opens the result to verify; keeps an audit trail.

Template mode uses openpyxl. openpyxl preserves cell values, formulas, styles, number formats, merged cells,
validation and conditional formatting, but DROPS charts, images, pivot tables, slicers, form controls and
external-link caches. preview() reports those (`risks`) so the user can choose a new output file.
"""
import csv, json, os, re, shutil, time, zipfile
from copy import copy

import openpyxl
from openpyxl.utils import get_column_letter

from .db import jdump
from . import extraction

LOSSY = {"charts", "drawings", "media", "pivotTables", "slicers", "ctrlProps"}      # items the Excel writer cannot keep
FRIENDLY = {"charts": "charts", "drawings": "shapes / text boxes", "media": "pictures", "pivotTables": "pivot tables",
            "slicers": "slicers", "ctrlProps": "form buttons/controls", "externalLinks": "links to other workbooks (kept, but not refreshed)"}


class RiskyTemplate(Exception):
    """The template holds items that cannot be preserved when the workbook is rewritten."""
    def __init__(self, items):
        self.items = items
        super().__init__("This workbook contains " + ", ".join(FRIENDLY.get(i, i) for i in items) +
                         " that DocIntel cannot keep when it saves a copy.")


RISKY_PARTS = ("xl/charts/", "xl/drawings/", "xl/pivotTables/", "xl/slicers/", "xl/externalLinks/", "xl/ctrlProps/", "xl/media/")


def workbook_risks(path):
    risks = []
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
        for part in RISKY_PARTS:
            if any(n.startswith(part) for n in names):
                risks.append(part.split("/")[1])
        if any(n.endswith("vbaProject.bin") for n in names):
            risks.append("macros (kept only if saved as .xlsm; never executed)")
    except zipfile.BadZipFile:
        risks.append("not a valid workbook")
    return risks


def read_headers(path, sheet=None, header_row=None):
    wb = openpyxl.load_workbook(path, read_only=False, keep_vba=path.lower().endswith(".xlsm"))
    ws = wb[sheet] if sheet else wb.active
    if header_row is None:
        header_row = _guess_header_row(ws)
    heads = {}
    for c in ws[header_row]:
        if c.value not in (None, ""):
            heads[str(c.value).strip()] = c.column
    return {"sheets": wb.sheetnames, "sheet": ws.title, "header_row": header_row, "headers": heads}


def _guess_header_row(ws):
    best, best_n = 1, 0
    for r in range(1, min(ws.max_row, 30) + 1):
        n = sum(1 for c in ws[r] if isinstance(c.value, str) and c.value.strip())
        if n > best_n:
            best, best_n = r, n
    return best


def auto_mapping(fields, headers):
    norm = lambda s: re.sub(r"[^\w]+", " ", s.lower()).strip()
    hmap = {norm(h): h for h in headers}
    return {f: hmap[norm(f)] for f in fields if norm(f) in hmap}


def _keyval(v):
    """Canonical text for comparing a worksheet cell with an extracted value (dates, ints/floats, whitespace)."""
    import datetime as _dt
    if v is None:
        return ""
    if isinstance(v, _dt.datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.isoformat(sep=" ")
    if isinstance(v, _dt.date):
        return v.isoformat()
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    s = str(v).strip()
    if re.fullmatch(r"-?\d+\.0+", s):
        s = s.split(".")[0]
    return s


def _last_data_row(ws, header_row, cols):
    last = header_row
    for r in range(header_row + 1, ws.max_row + 1):
        if any(ws.cell(r, c).value not in (None, "") for c in cols):
            last = r
    return last


def preview(path, records, mapping, sheet=None, header_row=None, mode="append", key_columns=None, date_format="yyyy-mm-dd"):
    """Dry run: returns planned operations and conflicts. Nothing is written."""
    info = read_headers(path, sheet, header_row)
    heads = info["headers"]
    bad = [h for h in mapping.values() if h not in heads]
    if bad:
        raise ValueError(f"mapped columns not found in sheet '{info['sheet']}': {bad}")
    wb = openpyxl.load_workbook(path, keep_vba=path.lower().endswith(".xlsm"))
    ws = wb[info["sheet"]]
    hr = info["header_row"]
    cols = [heads[h] for h in mapping.values()]
    plan = {"target": path, "sheet": ws.title, "header_row": hr, "mode": mode, "ops": [], "conflicts": [],
            "risks": workbook_risks(path), "mapping": mapping}
    last = _last_data_row(ws, hr, cols)
    if mode == "append":
        r = last + 1
        for rec in records:
            plan["ops"].append({"op": "insert", "row": r, "key": rec["key"],
                                "cells": {mapping[f]: rec["values"].get(f) for f in mapping}})
            r += 1
        # destination row must not hold unmapped content that would be hidden/overwritten
        for op in plan["ops"]:
            for c in range(1, ws.max_column + 1):
                v = ws.cell(op["row"], c)
                if v.value not in (None, "") and c in cols:
                    plan["conflicts"].append({"row": op["row"], "column": get_column_letter(c), "existing": v.value, "why": "target cell not empty"})
    elif mode == "update":
        kc = [mapping[k] for k in (key_columns or [])]
        if not kc:
            raise ValueError("update mode needs key_columns")
        index = {}
        for r in range(hr + 1, ws.max_row + 1):
            k = tuple(_keyval(ws.cell(r, heads[h]).value) for h in kc)
            index.setdefault(k, []).append(r)
        fieldof = {v: k for k, v in mapping.items()}
        for rec in records:
            k = tuple(_keyval(rec["values"].get(key)) for key in key_columns)
            rows = index.get(k, [])
            if len(rows) == 1:
                r = rows[0]; changes = {}
                for h, f in fieldof.items():
                    new = rec["values"].get(f); old = ws.cell(r, heads[h]).value
                    if new not in (None, "") and _keyval(old) != _keyval(new):
                        changes[h] = {"old": old, "new": new}
                        if old not in (None, ""):
                            plan["conflicts"].append({"row": r, "column": get_column_letter(heads[h]), "existing": old, "incoming": new,
                                                      "why": "existing value differs (will be overwritten only if overwrite=True)"})
                plan["ops"].append({"op": "update", "row": r, "key": rec["key"], "changes": changes})
            elif not rows:
                plan["ops"].append({"op": "skip", "key": rec["key"], "why": "no matching row for key " + str(k)})
            else:
                plan["ops"].append({"op": "skip", "key": rec["key"], "why": f"key {k} matches {len(rows)} rows (ambiguous)"})
    else:
        raise ValueError("mode must be append or update")
    return plan


def apply(db, run_id, path, records, mapping, sheet=None, header_row=None, mode="append", key_columns=None,
          out_path=None, in_place=False, overwrite=False, date_format="yyyy-mm-dd", allow_lossy=False):
    """Writes the export. By default writes to a NEW file next to the template (`<name>_export_<ts>.xlsx`).
    in_place=True first copies the original to a timestamped backup."""
    plan = preview(path, records, mapping, sheet, header_row, mode, key_columns)
    lossy = [r for r in plan["risks"] if r in LOSSY]
    if lossy and not allow_lossy:
        raise RiskyTemplate(lossy)      # nothing has been written; the caller must offer the safe alternative
    ext = os.path.splitext(path)[1]
    ts = time.strftime("%Y%m%d_%H%M%S")
    backup = None
    if in_place:
        backup = f"{os.path.splitext(path)[0]}.backup_{ts}{ext}"
        shutil.copy2(path, backup)
        dest = path
    else:
        dest = out_path or f"{os.path.splitext(path)[0]}_export_{ts}{ext}"
        if os.path.exists(dest):
            raise FileExistsError(dest)
    wb = openpyxl.load_workbook(path, keep_vba=ext.lower() == ".xlsm")
    ws = wb[plan["sheet"]]
    heads = read_headers(path, plan["sheet"], plan["header_row"])["headers"]
    audit = {"inserted": [], "updated": [], "skipped": [], "rejected_conflicts": []}
    bykey = {r["key"]: r for r in records}
    idf = lambda key, h: bykey[key].get("types", {}).get(next((f for f, c in mapping.items() if c == h), None)) == "id"
    blocked = {(c["row"], c["column"]) for c in plan["conflicts"] if c["why"].startswith("target cell not empty")}
    for op in plan["ops"]:
        if op["op"] == "insert":
            if any((op["row"], get_column_letter(heads[h])) in blocked for h in op["cells"]):
                audit["skipped"].append({"key": op["key"], "why": f"row {op['row']} not empty"}); continue
            _copy_row_style(ws, op["row"] - 1, op["row"], plan["header_row"])
            for h, v in op["cells"].items():
                _write(ws.cell(op["row"], heads[h]), v, date_format, idf(op["key"], h))
            filled = _extend_formulas(ws, op["row"], plan["header_row"], {heads[h] for h in op["cells"]})
            audit["inserted"].append({"key": op["key"], "row": op["row"], "cells": op["cells"], "formulas_extended": filled})
        elif op["op"] == "update":
            applied = {}
            for h, ch in op["changes"].items():
                if ch["old"] not in (None, "") and not overwrite:
                    audit["rejected_conflicts"].append({"key": op["key"], "row": op["row"], "column": h, **ch}); continue
                _write(ws.cell(op["row"], heads[h]), ch["new"], date_format, idf(op["key"], h)); applied[h] = ch
            if applied: audit["updated"].append({"key": op["key"], "row": op["row"], "changes": applied})
        else:
            audit["skipped"].append({"key": op["key"], "why": op["why"]})
    tmp = dest + ".tmp" + ext
    wb.save(tmp)
    os.replace(tmp, dest)
    ok, msg = verify(dest, plan, audit)
    audit["verified"] = ok; audit["verify_message"] = msg; audit["risks"] = plan["risks"]
    db.x("INSERT INTO exports(ts,run_id,target,sheet,backup,audit_json) VALUES(?,?,?,?,?,?)",
         (time.time(), run_id, dest, plan["sheet"], backup, jdump(audit)))
    return {"output": dest, "backup": backup, "audit": audit}


def _write(cell, v, date_format, text=False):
    if v is None or v == "":
        return
    if text:
        cell.value = str(v); cell.number_format = "@"; return   # identifiers stay text
    if isinstance(v, str):
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
            from datetime import date
            y, m, d = map(int, v.split("-"))
            cell.value = date(y, m, d); cell.number_format = date_format; return
        if re.fullmatch(r"-?\d+(\.\d+)?", v) and not (len(v) > 1 and v.startswith("0") and "." not in v):
            cell.value = float(v) if "." in v else int(v); return   # leading zeros (identifiers) stay text
        if v.startswith(("=", "+", "-", "@")):
            cell.value = v; cell.data_type = "s"; cell.quotePrefix = True; return   # never create live formulas from extracted text
    cell.value = v


def _extend_formulas(ws, row, header_row, mapped_cols):
    """Unmapped columns that hold a formula in the row above get the same formula (row references shifted)."""
    from openpyxl.formula.translate import Translator
    done = []
    src = row - 1
    if src <= header_row:
        return done
    for c in range(1, ws.max_column + 1):
        if c in mapped_cols: continue
        v = ws.cell(src, c).value
        if isinstance(v, str) and v.startswith("=") and ws.cell(row, c).value in (None, ""):
            ws.cell(row, c).value = Translator(v, origin=ws.cell(src, c).coordinate).translate_formula(ws.cell(row, c).coordinate)
            done.append(get_column_letter(c))
    return done


def _copy_row_style(ws, src, dst, header_row):
    if src <= header_row or src == dst:
        return
    for c in range(1, ws.max_column + 1):
        s, d = ws.cell(src, c), ws.cell(dst, c)
        if s.has_style:
            d._style = copy(s._style)


def verify(dest, plan, audit):
    try:
        wb = openpyxl.load_workbook(dest, keep_vba=dest.lower().endswith(".xlsm"))
        ws = wb[plan["sheet"]]
        heads = read_headers(dest, plan["sheet"], plan["header_row"])["headers"]
        for ins in audit["inserted"]:
            for h, v in ins["cells"].items():
                if v in (None, ""): continue
                got = ws.cell(ins["row"], heads[h]).value
                if str(got).split(" ")[0] != str(v).split(" ")[0] and str(got) != str(v) and not _num_eq(got, v):
                    return False, f"row {ins['row']} column {h}: wrote {v!r}, read back {got!r}"
        return True, "re-opened and all written cells match"
    except Exception as e:
        return False, f"could not re-open output: {e}"


def _num_eq(a, b):
    try: return float(a) == float(b)
    except (TypeError, ValueError): return False


# ---------------------------------------------------------------- new workbooks / CSV
def export_new(db, run_id, records, fields, out_path, sheet="Extracted", include_provenance=True, date_format="yyyy-mm-dd",
               extra_tables=None):
    """Fresh workbook: data sheet (+ Provenance sheet + optional table sheets). Atomic write, then re-opened to verify."""
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = sheet
    ws.append(fields + (["Source file", "Location"] if include_provenance else []))
    for c in ws[1]:
        c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F4E78")
    for rec in records:
        src = next(iter(rec["src"].values()), {}) if rec["src"] else {}
        ws.append([None] * len(fields) + ([src.get("path"), src.get("loc")] if include_provenance else []))
        r = ws.max_row
        for i, f in enumerate(fields):
            _write(ws.cell(r, i + 1), rec["values"].get(f), date_format, text=rec.get("types", {}).get(f) == "id")
    for i in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(i)].width = min(60, max(12, max(len(str(c.value or "")) for c in ws[get_column_letter(i)]) + 2))
    ws.freeze_panes = "A2"
    if include_provenance:
        pv = wb.create_sheet("Provenance")
        pv.append(["Record", "Field", "Value", "Raw text", "Method", "Confidence (heuristic)", "Source file", "Location"])
        for rec in records:
            for f in fields:
                s = rec["src"].get(f)
                if s:
                    pv.append([rec["key"], f, rec["values"].get(f), s["raw"], s["method"], s["confidence"], s["path"], s["loc"]])
        for c in pv[1]:
            c.font = Font(bold=True)
    for name, rows in (extra_tables or {}).items():
        t = wb.create_sheet(re.sub(r"[\[\]:*?/\\]", "_", name)[:31])
        for r in rows: t.append([None if c == "" else c for c in r])
    tmp = out_path + ".tmp.xlsx"
    wb.save(tmp); os.replace(tmp, out_path)
    chk = openpyxl.load_workbook(out_path)
    ok = chk[sheet].max_row == len(records) + 1
    db.x("INSERT INTO exports(ts,run_id,target,sheet,audit_json) VALUES(?,?,?,?,?)",
         (time.time(), run_id, out_path, sheet, jdump({"inserted": len(records), "verified": ok})))
    return {"output": out_path, "rows": len(records), "verified": ok}


def export_csv(records, fields, out_path, delimiter=","):
    with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=delimiter)
        w.writerow(fields)
        for r in records:
            w.writerow(["" if r["values"].get(k) is None else r["values"].get(k) for k in fields])
    return out_path


def export_table(db, table_id, out_path):
    """Export one stored table (corrected version if present) to its own workbook."""
    t = db.one("SELECT * FROM tables_ WHERE id=?", (table_id,))
    rows = json.loads(t["corrected_json"] or t["rows_json"])
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Table"
    for r in rows: ws.append([None if c == "" else c for c in r])
    wb.save(out_path)
    return out_path
