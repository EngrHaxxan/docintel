# Saved extractions and batch jobs (v1.4.0-m4)

**Home screen > "Saved extractions & batch jobs"** (button at the bottom right).

## Save an extraction
- In the wizard, at step 5 click **Save these choices as a reusable extraction...**, or in the batch window click **New...** / **Edit...**.
- A saved extraction stores: the section heading (and other headings you confirmed as the same), optional column names of the table, optional list of columns, optional row filter, and Excel options. It never stores page numbers, so it finds the section or table again in every document.
- Starter examples are listed (Daily report - Construction Activities, Issues & Concerns, ...). Edit one to save your own copy.

## Run it on many documents
1. Select the saved extraction, click **Run on documents...**, pick the folders, **Start**. You can cancel at any time.
2. Every document gets a result: Done / Done - some parts need attention / Failed / Section not found / Table not found / Similar heading found - please confirm / No table / File type not supported yet. One bad file never stops the others.
3. **Show documents** lists each document with its result. For "Similar heading found" select the document and click **This heading is the same section...** to confirm it (remembered for the job and for the saved extraction). Similar headings are never used without your confirmation.
4. **Export to Excel** writes the records of all successful documents, with source columns and a **Job report** sheet that lists every document including the failed ones.
5. **Retry failed** processes the failed/partial documents again. **Add new documents** scans the folders again and processes only new or changed files. **Continue** finishes a job that was stopped.

Command line (same engine): `docintel-cli saved-extractions`, `batch "<name>" --out result.xlsx`, `batch-jobs`, `batch-retry <job>`, `batch-new <job>`.
