"""Table engine tests: real PDFs (mandatory) + synthetic layouts. Run: python -m unittest tests.test_tables_engine -v"""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from docintel.tables import analyze_pdf, match_sections, heading_similarity
from docintel.tables.export import export_tables_xlsx

HERE = os.path.dirname(os.path.abspath(__file__))
REAL = os.path.join(HERE, "real_pdfs")
DAILY = os.path.join(REAL, "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf")
SCAL = os.path.join(REAL, "WI-NG-6460-001-001_SCAL_Rev03.pdf")
_cache = {}


def get(path):
    if path not in _cache:
        _cache[path] = analyze_pdf(path)
    return _cache[path]


def table(a, section):
    return next(t for t in a.tables if t.section.upper().startswith(section))


@unittest.skipUnless(os.path.exists(DAILY), "real daily report missing")
class DailyReport(unittest.TestCase):
    def test_construction_exact(self):
        t = table(get(DAILY), "CONSTRUCTION")
        self.assertEqual(t.column_names, ["S.No", "Location", "Area", "Discipline", "Activity Type", "Activity Description",
                                          "Progress % / 07-Oct-2026", "Progress % / 08-Oct-2026", "Work status", "Remarks"])
        self.assertEqual(len(t.rows), 4)
        exp = [["1", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Backfilling", "Backfilling of the 5th layer for the Substation Building and Power Transformer Foundation.", "70%", "100%", "Completed", ""],
               ["2", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Compaction", "Compaction of the 5th layer for the Substation Building and Power Transformer Foundation.", "0%", "0%", "To be Started", ""],
               ["3", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Temporary Fencing", "Installation of plywood panels", "70%", "90%", "In-Progress", ""],
               ["4", "MUNA-1 Substation Site", "Substation Area", "CIVIL", "Temporary Project Signboard", "Supply and installation", "0%", "0%", "To be Started", ""]]
        self.assertEqual([r.orig for r in t.rows], exp)
        self.assertTrue(all(r.group == "SUBSTATION" and r.page == 2 for r in t.rows))

    def test_issues_exact(self):
        t = table(get(DAILY), "ISSUES")
        self.assertEqual(t.column_names[:4], ["S.No", "Issue Type", "Description", "Urgency"])
        self.assertEqual(len(t.rows), 3)
        r = t.rows[1].orig
        self.assertEqual(r[1:], ["UGC - Mashaer / MUNA-1 Circuits", "Existing UGC works by other contractor remain on hold, impacting design and execution.",
                                 "High", "Time Delay", "02-Aug-26", "67", "SE", "Open", ""])
        self.assertEqual([x.orig[6] for x in t.rows], ["156", "67", "67"])

    def test_sections_not_mixed(self):
        a = get(DAILY)
        c, i = table(a, "CONSTRUCTION"), table(a, "ISSUES")
        self.assertNotIn("UGC", " ".join(" ".join(r.orig) for r in c.rows))
        self.assertNotIn("Backfilling", " ".join(" ".join(r.orig) for r in i.rows))

    def test_other_sections_found(self):
        a = get(DAILY)
        self.assertEqual(len(table(a, "ENGINEERING").rows), 7)
        names = [t.section for t in a.tables]
        self.assertTrue(any(n.startswith("PROCUREMENT") for n in names))

    def test_section_fuzzy_match_needs_confirmation(self):
        a = get(DAILY)
        m = match_sections("Construction Activity", a.tables)
        self.assertTrue(m and m[0]["heading"].upper().startswith("CONSTRUCTION"))
        self.assertGreater(heading_similarity("Construction Activity", "Construction Activities"), 85)
        self.assertLess(heading_similarity("Construction Progress", "Issues & Concerns"), 50)


@unittest.skipUnless(os.path.exists(SCAL), "real SCAL pdf missing")
class ScalReport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a = get(SCAL)
        cls.t = max(cls.a.tables, key=lambda t: len(t.rows))
        cls.by = {int(r.anchor): r for r in cls.t.rows}

    def test_complete_table(self):
        self.assertEqual([int(r.anchor) for r in self.t.rows], list(range(1, 1001)))
        self.assertEqual((self.t.page_from, self.t.page_to), (5, 40))
        self.assertEqual(len(self.t.headers), 13)

    def test_headers(self):
        n = self.t.column_names
        self.assertEqual(n[:3], ["Sr.", "Main Activity Name", "Main Activity Test Code"])
        for want in ("Sub-Activity Name", "Sub-Activity Test Code", "Duration In Hours", "Unit", "Remarks"):
            self.assertIn(want, n)
        self.assertTrue(n[-1].endswith("Activity Group") and n[-3].startswith("Scheduling Rules"))
        self.assertTrue(any("Commissioning Stage" in x for x in n))

    def test_reference_rows(self):
        b = self.by
        self.assertEqual(b[1].norm[1:3] + b[1].norm[5:], ["Substation Battery Bank", "SBB", "Substation Battery Bank", "SBBXX.TEST", "12.00", "Battery", "125 V", "0%", "100%", "Testing - Batteries&Chargers"])
        self.assertEqual(b[1].orig[3:5], ["X", "X"])
        self.assertEqual(b[15].orig[5:11], ["Scheme Check", "ACDBXX.SCH", "16", "Panel", "To be witnessed during pre-check", "100%"])
        self.assertEqual(b[202].norm[5:9] + b[202].norm[9:], ["LCC Scheme Check", "EHV.SWGXX.LCC.SCH", "24.00", "CB", "", "100%", "20% Including All Typicals", b[202].norm[-1]])
        self.assertEqual(b[999].orig[5], "On Load Test For Phase Synchronizing Device")
        self.assertEqual(b[999].orig[6], "OLTXX.PSD")

    def test_page_split_rows(self):
        r = self.by[11]
        self.assertEqual(r.pages, [5, 6]); self.assertTrue(r.orig[9].endswith("meters, secondary injection, MCB & MCCB") or "secondary injection" in " ".join(r.orig))
        self.assertEqual(self.by[179].pages[-1], 11)

    def test_merged_cell_modes(self):
        # original layout keeps blanks where the PDF merges; normalized repeats the main activity
        grp = [r for r in self.t.rows if r.anchor in ("1", "2", "3")]
        self.assertEqual(grp[0].orig[1], "Substation Battery Bank")
        self.assertTrue(all(r.norm[1] == "Substation Battery Bank" for r in grp[:1]))
        blanks_orig = sum(1 for r in self.t.rows if not r.orig[1])
        self.assertGreater(blanks_orig, 100)
        self.assertEqual(sum(1 for r in self.t.rows if not r.norm[1]), 0)
        self.assertEqual(sum(1 for r in self.t.rows if not r.norm[2]), 0)

    def test_horizontal_merge_row_1000(self):
        r = self.by[1000]
        self.assertTrue(r.orig[9].startswith("Punch List (PL) Clearance Activity Duration is not identifiable"))
        self.assertEqual(r.orig[10:], ["", "", ""])

    def test_source_quirks_preserved(self):
        txt = {k: " ".join(r.orig) for k, r in self.by.items()}
        self.assertIn("OLISXX.HV", txt[994])
        self.assertIn("SASXX.FUN.OLTA\u0650\u0650.MV", txt[912])
        self.assertIn("TATCOM.COOL.TEST", txt[752])
        self.assertTrue(any("Tan \u2202" in v for v in txt.values()))
        self.assertTrue(any("Transfor mer" in v for v in txt.values()))

    def test_running_header_not_in_data(self):
        self.assertFalse(any("NATIONAL GRID" in " ".join(r.orig) for r in self.t.rows))


class Synthetic(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from tests.make_table_pdfs import all_synthetic
        cls.d = tempfile.mkdtemp()
        cls.p = all_synthetic(cls.d)

    def test_special_values_preserved(self):
        t = analyze_pdf(self.p["lined_special"]).tables[0]
        self.assertEqual(t.column_names[0], "Item No.")
        self.assertEqual(t.column_names[2], "Description of the work item")
        rows = [r.orig for r in t.rows]
        self.assertEqual(rows[0][:2], ["001", "EHV.SWGXX.SF6.TEST"]); self.assertEqual(rows[0][3:], ["65%", "110/13.8 kV", ""])
        self.assertTrue(rows[0][2].endswith("repeated for every bay"))
        from tests.make_table_pdfs import UNICODE_FONT
        if UNICODE_FONT:                       # needs a TrueType font on the test machine (DejaVu on Linux, Arial on Windows)
            self.assertEqual(rows[1], ["002", "DTS-022", "Tan \u2202 test & insulation", "0.25", "-12.5", "N/A"])
            self.assertEqual(rows[2], ["01.02", "#A-1", "24 hours soak", "100%", "48 V", "ملاحظة 24"])
        else:
            self.assertEqual(rows[1][:2] + rows[1][3:], ["002", "DTS-022", "0.25", "-12.5", "N/A"])
            self.assertEqual(rows[2][:2] + rows[2][3:5], ["01.02", "#A-1", "100%", "48 V"])

    def test_multipage_repeated_header(self):
        t = analyze_pdf(self.p["lined_multipage"]).tables[0]
        self.assertEqual(len(t.rows), 90)
        self.assertEqual([r.anchor for r in t.rows], [str(i) for i in range(1, 91)])
        self.assertFalse(any(r.orig[1] == "Name" for r in t.rows))
        self.assertGreater(t.page_to, t.page_from)

    def test_merged_cells_two_modes(self):
        t = analyze_pdf(self.p["merged_cells"]).tables[0]
        self.assertEqual([r.orig[1] for r in t.rows], ["Battery Bank", "", "", "Panel", ""])
        self.assertEqual([r.norm[1] for r in t.rows], ["Battery Bank"] * 3 + ["Panel"] * 2)
        self.assertEqual([r.norm[2] for r in t.rows], ["SBB"] * 3 + ["ACDB"] * 2)

    def test_two_tables_one_page(self):
        a = analyze_pdf(self.p["two_tables"])
        self.assertEqual([(t.section, len(t.rows), len(t.headers)) for t in a.tables], [("Issues", 2, 3), ("Equipment", 2, 5)])

    def test_borderless(self):
        t = analyze_pdf(self.p["borderless"]).tables[0]
        self.assertEqual(t.method, "borderless-alignment")
        self.assertEqual(t.column_names, ["No", "Material", "Qty", "Unit", "Delivered %"])
        self.assertEqual([r.orig for r in t.rows][3], ["4", "Lug 185 mm2", "300", "pcs", "12.5%"])

    def test_excel_export_text_exact(self):
        from openpyxl import load_workbook
        a = analyze_pdf(self.p["lined_special"])
        out = os.path.join(self.d, "o.xlsx")
        export_tables_xlsx(a.tables, out)
        wb = load_workbook(out)
        self.assertEqual(wb.sheetnames[0], "Summary"); self.assertEqual(len(wb.sheetnames), 3)
        ws = wb[wb.sheetnames[2]]
        self.assertEqual(ws["A2"].value, "001"); self.assertEqual(ws["D2"].value, "65%"); self.assertEqual(ws["A4"].value, "01.02")
        self.assertEqual(ws["A2"].number_format, "@")
        hdr = [c.value for c in ws[1]]
        self.assertIn("Page", hdr); self.assertIn("Source file", hdr)


if __name__ == "__main__":
    unittest.main()
