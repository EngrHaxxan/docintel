"""Builds docs/DocIntel_User_Guide.pdf (plain-language, for non-technical users)."""
import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle, KeepTogether

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SH = os.path.join(ROOT, "docs", "screenshots")
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=18, textColor=colors.HexColor("#1F4E78"), spaceBefore=8, spaceAfter=8)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=13, textColor=colors.HexColor("#1F4E78"), spaceBefore=10, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=10.5, leading=15)
NOTE = ParagraphStyle("N", parent=B, backColor=colors.HexColor("#EEF3F8"), borderPadding=6, spaceBefore=6, spaceAfter=8)
STEP = ParagraphStyle("S", parent=B, leftIndent=18, bulletIndent=2)


def img(name, w=15.5):
    p = os.path.join(SH, name)
    if not os.path.exists(p): return Spacer(1, 1)
    from PIL import Image as PI
    iw, ih = PI.open(p).size
    return Image(p, width=w * cm, height=w * cm * ih / iw)


def steps(items): return [Paragraph(t, STEP, bulletText=f"{i}.") for i, t in enumerate(items, 1)]


def build(out):
    d = SimpleDocTemplate(out, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm, title="DocIntel User Guide")
    s = [Paragraph("DocIntel", ParagraphStyle("T", parent=H1, fontSize=30)), Paragraph("User Guide - find information in your documents and send it to Excel", H2),
         Paragraph("DocIntel reads your PDFs, scanned pages, photos, Word, PowerPoint and Excel files, lets you search all of them at once, and copies the "
                   "information you choose into Excel. It works entirely on your computer and does <b>not</b> need the internet. It never changes or deletes your documents.", B), Spacer(1, 8)]
    s += [Paragraph("Contents", H2), Paragraph("1. Install &nbsp;&nbsp; 2. First start &nbsp;&nbsp; 3. Add your folders &nbsp;&nbsp; 4. Read your documents &nbsp;&nbsp; 5. Search &nbsp;&nbsp; "
                                              "6. Pull data into Excel &nbsp;&nbsp; 7. Check uncertain values &nbsp;&nbsp; 8. Save to Excel &nbsp;&nbsp; 9. Share with someone else &nbsp;&nbsp; "
                                              "10. Working without internet &nbsp;&nbsp; 11. If something goes wrong &nbsp;&nbsp; 12. Good to know", B), PageBreak()]
    s += [Paragraph("1. Install", H1), Paragraph("You received one of two files. Use whichever you have:", B),
          Paragraph("<b>DocIntel_Setup.exe</b> (installer)", H2)] + steps([
        "Double-click <b>DocIntel_Setup.exe</b>.", "If Windows says <b>\"Windows protected your PC\"</b>, click <b>More info</b>, then <b>Run anyway</b>. (This message appears for any new program from a small publisher. DocIntel does not use the internet.)",
        "Click <b>Next</b> through the screens. Tick <b>Create a desktop shortcut</b> if you want one. Click <b>Install</b>, then <b>Finish</b>.",
        "Start DocIntel from the desktop icon or Start menu > DocIntel."]) + [
          Paragraph("<b>DocIntel_Portable_Windows_x64.zip</b> (no installation; also good for a USB stick)", H2)] + steps([
        "Right-click the zip file and choose <b>Extract All...</b>, then pick any folder (for example Documents).", "Open the new <b>DocIntel</b> folder and double-click <b>DocIntel.exe</b>.",
        "Your settings and search index are saved inside that folder (in <i>DocIntel_Data</i>), so you can move the whole folder to another computer."]) + [
          Paragraph("You do not need to install Python, Tesseract, or anything else. Administrator rights are not required.", NOTE), PageBreak()]
    s += [Paragraph("2. First start", H1), Paragraph("The first time DocIntel opens, it checks your computer and shows a short welcome. A green message means everything is ready.", B), img("welcome.png", 11), PageBreak()]
    s += [Paragraph("3. Add your folders", H1), img("start.png", 15)] + steps([
        "Click <b>1. Add your folders</b> and choose a folder with documents. Subfolders are included automatically.",
        "Repeat for every folder or drive you want (for example reports on D:, drawings on E:, a network folder). You can also drag folders from Windows Explorer into the window.",
        "To remove a folder later: open the <b>Sources</b> tab, select it, click <b>Remove from index</b>. This never deletes your files."]) + [PageBreak()]
    s += [Paragraph("4. Read your documents", H1), Paragraph("Click <b>2. Read my documents</b> (or answer Yes when asked). DocIntel reads each file once. The bar at the bottom shows progress. "
                                                           "You can start searching while it is still working, and you can <b>Pause</b> or <b>Cancel</b> at any time; it continues where it stopped next time.", B),
          Paragraph("Scanned pages and photos are read with OCR (text recognition), which is slower. A large collection can take hours the first time; later updates only look at new or changed files. "
                    "Click <b>Update all</b> on the <b>Sources</b> tab whenever you add documents.", NOTE), Paragraph("Files that cannot be read (password-protected, damaged, unsupported) are listed on the Dashboard with the reason.", B), PageBreak()]
    s += [Paragraph("5. Search", H1), img("search.png", 15.5)] + steps([
        "Open the <b>Search</b> tab, type what you are looking for, press Enter.", "Pick the mode: <b>text</b> (exact words or numbers - use this for invoice and drawing numbers), <b>word</b> (whole word), <b>all</b> (every word must appear), <b>regex</b> (patterns - advanced), <b>fuzzy</b> (tolerates scanning mistakes but is approximate).",
        "Click a result: the matching text is highlighted and, for PDFs and images, the page is shown with a red box. Double-click to open the file; <b>Open folder</b> shows where it is stored.",
        "To search only some folders, select them in the list on the left."]) + [PageBreak()]
    s += [Paragraph("6. Pull data into Excel", H1), img("extract.png", 15.5), Paragraph("Open the <b>Extract</b> tab. You tell DocIntel what to look for; this is called a <i>profile</i>, and you can save and reuse it.", B)] + steps([
        "Click <b>Describe fields I want...</b> and type the items separated by commas, for example <i>Date, Project, Manpower, Invoice number, Total amount</i>. DocIntel looks for these words followed by a colon in your documents and guesses the type (date, number, text).",
        "Or click <b>Import JSON...</b> and choose a ready-made profile from the <i>samples\\profiles</i> folder (daily reports, invoice lines, drawing title blocks).",
        "To read a <b>table</b>, set <b>Mode</b> to <i>table</i>: every row becomes one record, and the column headings are matched to your field names.",
        "Give the profile a name, click <b>Save</b>, then <b>RUN EXTRACTION</b>. Use <b>Export JSON...</b> to keep a copy or share it."]) + [
          Paragraph("Use <b>File name pattern</b> (for example <i>daily_report*</i>) to limit the extraction to certain files.", NOTE), PageBreak()]
    s += [Paragraph("7. Check uncertain values", H1), img("review.png", 15.5), Paragraph("DocIntel never presents a doubtful value as certain. Values it is unsure about go to the <b>Review</b> tab: unclear scans, dates like 05/04/2026 that could be day/month or month/day, missing required items, two different values in the same document, duplicates, and all revision numbers, tags and dimensions on drawings.", B)] + steps([
        "Choose the run and click <b>Load review queue</b>.", "Click a row to see the original page with the value boxed in red.", "Choose <b>Approve as is</b>, <b>Correct...</b> (type the right value), <b>Reject record</b>, or <b>Mark unresolved</b>.",
        "Records with unresolved values are held back from the export, so nothing doubtful reaches Excel by accident."]) + [Paragraph("The \"quality indicator\" is a guide based on how the text was read - it is not a guarantee. Always look at the boxed source for important numbers.", NOTE), PageBreak()]
    s += [Paragraph("8. Save to Excel", H1), img("export.png", 15.5)] + steps([
        "Open the <b>Export</b> tab and choose the run.", "For a <b>new workbook</b>, leave the template box empty. For an <b>existing Excel file</b>, click <b>Browse...</b> and choose it; DocIntel matches your fields to its column headings (use <b>Change mapping...</b> to adjust).",
        "Click <b>PREVIEW changes</b>. Read what will be written and any warnings. Nothing has been written yet.", "Click <b>EXPORT</b>. By default DocIntel saves a <b>new file</b> next to your Excel file and leaves yours untouched. Formulas and formatting are kept, and formulas are copied down to the new rows.",
        "DocIntel re-opens the result to check it. A second sheet called <b>Provenance</b> lists, for every value, the file and page it came from."]) + [
          Paragraph("If your Excel file contains charts, pictures, pivot tables or slicers, DocIntel warns you because it cannot keep those when it saves. Your original is never changed; choose the offered <b>new separate workbook</b> instead.", NOTE),
          Paragraph("Tick <b>Write into the template itself</b> only if you want your file changed; a backup copy with the date in its name is made first.", B), PageBreak()]
    s += [Paragraph("9. Share with someone else", H1)] + steps([
        "Send them <b>DocIntel_Setup.exe</b> or the <b>DocIntel_Portable_Windows_x64.zip</b> (by email, cloud drive or USB stick).", "They follow Section 1. They do not need your documents or your index.",
        "To share your saved extraction settings, use <b>Export JSON...</b> on the Extract tab and send the .json file; they use <b>Import JSON...</b>.",
        "To give them your index too (so they need not re-read everything), use <b>Settings & Diagnostics > Backup index + settings</b> and send the zip; the document folders must have the same paths on their computer."]) + [Spacer(1, 12),
          Paragraph("10. Working without internet", H1), Paragraph("Everything above works with no internet connection, including reading scans in English and Arabic. DocIntel has an \"Offline mode\" (on by default) that makes the program refuse any network connection. Nothing is uploaded, and nothing is downloaded after installation.", B), PageBreak()]
    data = [["What you see", "What to do"],
            ["\"Windows protected your PC\"", "Click More info, then Run anyway (new program from a small publisher)."],
            ["Red message on the Start page about OCR", "Scanned pages can't be read. Reinstall DocIntel, or run Help > Run self-check and send the result to your support person."],
            ["A folder shows UNAVAILABLE", "The drive or network folder is not connected. Reconnect it and click Update all. Its documents stay searchable meanwhile."],
            ["\"Windows would not allow access\"", "The file is open in Excel or another program, or you lack permission. Close the file or choose another folder."],
            ["Files listed as 'could not be read'", "Password-protected or damaged files can't be read. Remove the password and click Retry failed on the Sources tab."],
            ["Search finds nothing for a scanned page", "Try the <i>fuzzy</i> mode, or check the Dashboard to see whether that file was read."],
            ["Windows asks for administrator rights", "It should not. Use the portable zip, or reinstall for the current user only."],
            ["The index seems damaged", "Settings & Diagnostics > Rebuild search index. Your documents are not affected."]]
    cell = ParagraphStyle("c", parent=B, fontSize=9.5, leading=12)
    hdr = ParagraphStyle("h", parent=cell, textColor=colors.white, fontName="Helvetica-Bold")
    rows = [[Paragraph(c, hdr if i == 0 else cell) for c in r] for i, r in enumerate(data)]
    t = Table(rows, colWidths=[5.6 * cm, 11.4 * cm], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E78")), ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    s += [Paragraph("11. If something goes wrong", H1), t, Spacer(1, 10),
          Paragraph("Help > Run self-check shows what DocIntel found on your computer. <b>Settings & Diagnostics > Show log</b> shows recent events (file names and errors, never the text of your documents).", B),
          Paragraph("12. Good to know", H1), Paragraph("&bull; Accuracy depends on the quality of the documents. Clean scans are read very well; poor photos, stamps and handwriting are not. Always review important numbers.<br/>"
                                                       "&bull; Reading Arabic and English scans is supported; handwriting is not.<br/>&bull; AutoCAD <b>.dwg</b> files are not read directly: in AutoCAD choose Save As > DXF, or print to PDF. DXF and PDF drawings are supported.<br/>"
                                                       "&bull; Old .doc/.ppt/.xls files are read only if LibreOffice is installed; saving them as .docx/.pptx/.xlsx always works.<br/>&bull; DocIntel does not guess meanings: it finds the words you name. Describe fields the way they are written in your documents.", B)]
    d.build(s)


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "docs", "DocIntel_User_Guide.pdf"))
