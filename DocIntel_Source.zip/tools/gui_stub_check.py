"""Drives the guided screens against a tiny stand-in for Tkinter, so Python-level mistakes (typos, wrong names, wrong calls)
are caught even where no display is available. It does NOT prove the layout looks right - that needs a real Windows run.
Usage: python tools/gui_stub_check.py   (exit code 0 = passed)"""
import os, shutil, sys, tempfile, threading, time, types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


class W:
    def __init__(self, *a, **k):
        self.master = a[0] if a and isinstance(a[0], W) else None
        self._d, self._sel, self._items, self._text, self.kw = {}, (), [], "", k
        self._ch = []
        if self.master is not None:
            self.master._ch.append(self)

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        return lambda *a, **k: W()

    def __setitem__(self, k, v): self._d[k] = v
    def __getitem__(self, k): return self._d.get(k, ())
    def winfo_children(self): return list(self._ch)
    def destroy(self):
        if self.master is not None and self in self.master._ch:
            self.master._ch.remove(self)
    def curselection(self): return tuple(self._sel)
    def insert(self, *a, **k):
        if a and a[0] == "1.0":
            self._text = a[1]
        else:
            self._items.append(a[-1] if a else "")
        return str(len(self._items) - 1)
    def delete(self, *a, **k): self._items = []; return None
    def get(self, *a, **k): return self._text if a else ""
    def get_children(self, *a): return list(range(len(self._items)))
    def current(self, i=None):
        if i is not None: self._d["_cur"] = i
        return self._d.get("_cur", 0)
    def identify_row(self, y): return "0"
    def identify_column(self, x): return "#6"
    def tk_popup(self, *a): pass
    def pack(self, *a, **k): return None
    def grid(self, *a, **k): return None
    def after(self, *a, **k): return "id"
    def config(self, *a, **k): return None
    configure = config


class Var:
    def __init__(self, *a, value=None, **k): self.v = value
    def get(self): return self.v
    def set(self, v): self.v = v


tk = types.ModuleType("tkinter"); ttk = types.ModuleType("tkinter.ttk"); fd = types.ModuleType("tkinter.filedialog")
mb = types.ModuleType("tkinter.messagebox"); sd = types.ModuleType("tkinter.simpledialog"); sc = types.ModuleType("tkinter.scrolledtext")
for n in ("Frame", "Label", "Button", "Radiobutton", "Checkbutton", "Entry", "Combobox", "Treeview", "Scrollbar", "LabelFrame", "Notebook", "Progressbar", "Spinbox", "Panedwindow"):
    setattr(ttk, n, type(n, (W,), {}))
for n in ("Tk", "Toplevel", "Frame", "Label", "Listbox", "Text", "Menu", "Canvas", "PhotoImage"):
    setattr(tk, n, type(n, (W,), {}))
tk.StringVar = tk.BooleanVar = tk.IntVar = Var
tk.TclError = type("TclError", (Exception,), {})
tk.ttk, tk.filedialog, tk.messagebox, tk.simpledialog = ttk, fd, mb, sd
MSGS = []
mb.showinfo = lambda *a, **k: MSGS.append(("info", a[1] if len(a) > 1 else ""))
mb.showerror = lambda *a, **k: MSGS.append(("error", a[1] if len(a) > 1 else ""))
mb.askyesno = lambda *a, **k: True
sd.askstring = lambda *a, **k: "NEW"
fd.askdirectory = lambda *a, **k: ""; fd.askopenfilenames = lambda *a, **k: (); fd.asksaveasfilename = lambda *a, **k: ""
for name, mod in (("tkinter", tk), ("tkinter.ttk", ttk), ("tkinter.filedialog", fd), ("tkinter.messagebox", mb), ("tkinter.simpledialog", sd), ("tkinter.scrolledtext", sc)):
    sys.modules[name] = mod

from docintel.library import Library                       # noqa: E402
from docintel import gui_guided as G                       # noqa: E402
G._open = lambda p: None


class Nb(W):
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self._tabs = []; self.sel = None
    def insert(self, pos, child, **k): self._tabs.insert(pos, child)
    def add(self, child, **k):
        if child not in self._tabs: self._tabs.append(child)
    def tabs(self): return list(self._tabs)
    def hide(self, t): pass
    def select(self, t=None):
        if t is not None: self.sel = t
        return self.sel


def wait(win):
    t0 = time.time()
    while win.busy and time.time() - t0 < 120:
        win._poll(); time.sleep(0.05)
    win._poll()


def main():
    tmp = tempfile.mkdtemp(); d = os.path.join(tmp, "docs"); os.makedirs(d)
    shutil.copy(os.path.join(ROOT, "tests", "real_pdfs", "MUNA-1_Daily_Activities_Report-8-Oct-2026.pdf"), os.path.join(d, "daily.pdf"))
    lib = Library(os.path.join(tmp, "home")); lib.add_root(d); lib.scan()
    app = W(); app.lib = lib; app.nb = Nb(); app.tabs = {"Search": W(), "Review": W()}; app.add_folder = lambda: None; app.add_many = lambda: None
    home = G.install_home(app)
    for fn in (home.add_documents, home.search, home.review, home.export, home.history, home.toggle_advanced, home.toggle_advanced):
        home._safe(fn)()
    # ---- wizard: section mode
    win = G.WizardWindow(app, home)
    win.src.set("all"); win._src_changed(); assert win.s.selected_count() == 1
    win.next(); win.mode.set("section"); win.next(); wait(win)
    assert win.step == 2 and len(win.s.catalog) == 7, (win.step, len(win.s.catalog), MSGS[-3:])
    names = [h["heading"] for h in win._hs]
    win.hlist._sel = (names.index("CONSTRUCTION ACTIVITIES"),)
    win.next(); assert win.step == 3 and win.s.preview and len(win.s.preview[0].table.rows) == 4
    p = win.panel
    ev = types.SimpleNamespace(x=5, y=5)
    p.on_click(ev); p.on_edit(ev); p.on_mark(); p.on_rename(); p.on_hide(); p.on_hide(); p.layout.set("orig"); p.redraw()
    assert win.s.preview[0].table.rows[0].norm[5] == "NEW" or win.s.preview[0].table.rows[0].orig[5] == "NEW"
    win.next()                                          # leave4 -> step 5
    assert win.step == 4
    out = os.path.join(tmp, "out.xlsx")
    fd.asksaveasfilename = lambda *a, **k: out
    panel = [c for c in win.body.winfo_children() if isinstance(c, G.ExportPanel)][0]
    panel.val.set("typed"); panel.lay_orig.set(True); panel.go()
    assert os.path.exists(out), "export file missing"
    assert home.last_session is win.s
    G.HistoryWindow(app, home)
    G.ExportDialog(home, win.s)
    G.ReviewWindow(app, home).open()
    # ---- Milestone 4: save the wizard choices as a profile, run it as a batch job, view/confirm/export
    win.save_profile()
    from docintel import batch as B
    assert B.load_profile(lib.db, "NEW")["section"]["heading"] == "CONSTRUCTION ACTIVITIES"
    bw = G.BatchWindow(app, home); home.batch()
    bw.lb._sel = (0,); bw.edit_profile(); bw.new_profile(); bw.lb._sel = (0,)
    prof = B.load_profile(lib.db, "NEW")
    bw.run_bg("Extracting", lambda ctl, pg: bw.runner.run(prof, root_ids=[r["id"] for r in lib.roots()], control=ctl, progress=pg), bw._after_run)
    wait(bw)
    jid = bw.jobs[0]["id"]; assert bw.runner.summary(jid)["records"] == 4, bw.runner.summary(jid)
    out2 = os.path.join(tmp, "batch.xlsx"); fd.asksaveasfilename = lambda *a, **k: out2
    bw.tv.selection = lambda: ("0",); bw.tv.item = lambda i: {"values": (jid,)}
    bw.export_job(); assert os.path.exists(out2), "batch export missing"
    bw.retry(); wait(bw); bw.add_new(); wait(bw); bw.resume(); wait(bw)
    G.JobDocsWindow(bw, jid).open()
    # ---- Milestone 8: manual selection window + discovery in the wizard
    row0 = lib.db.one("SELECT id, abspath FROM files WHERE lower(ltrim(ext,'.'))='pdf' LIMIT 1")
    mw = G.ManualTableWindow(app, row0["abspath"], row0["id"])
    mw.box = (40.0, 60.0, 500.0, 300.0); mw.scale = 1.0; mw.cols = [200.0]; mw._press = None
    mw.preview(); time.sleep(1.5); mw._poll(); mw.save(); mw.apply_others() if False else None
    win.sq = G.tk.StringVar(value="progress"); win.tbl_list = G.tk.Listbox(win); win.sug = G.tk.StringVar(); win._suggest()
    # ---- Milestone 9: AI tools against a fake LOCAL model server (not a real model)
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tests"))
    from fake_llm_server import Fake
    srv = Fake()
    hub = G.AIHubWindow(app, home); assert not lib.ai_available()
    mw2 = G.AIModelsWindow(app, home)
    dlg = G.ModelDialog(mw2, None, mw2.reload)
    for k, v in (("name", "Fake"), ("base_url", srv.url), ("model", "fake-chat"), ("embed_model", "fake-embed")):
        dlg.v[k].set(v)
    dlg.find(); dlg.test(); time.sleep(1.0); dlg.save(); mw2.reload(); mw2.tv.selection = lambda: ("0",); mw2.activate(); mw2.test(); time.sleep(0.6)
    hub.refresh(); assert lib.ai_available(), "model should be active"
    ew = G.AIExtractWindow(app, home); ew.fields.set("Location, Work status"); ew.start(); wait(ew); ew.retry(); wait(ew)
    out3 = os.path.join(tmp, "ai.xlsx"); fd.asksaveasfilename = lambda *a, **k: out3
    cw = G.AICompareWindow(app, home); cw.lb.curselection = lambda: (0, 0); cw.fields.set("Location"); cw.go()
    hub.build_index(); wait(hub); hub.ask(); hub.extract(); hub.compare(); home.ai_tools()
    srv.stop(); lib.ai_models().delete("Fake")
    # ---- Milestone 7: the Ask button is hidden without an AI; the Ask window works with a local test provider
    assert not lib.ai_available()
    from docintel.llm.provider import CallableProvider
    lib.assistant = lambda provider=None: __import__("docintel.llm.assistant", fromlist=["Assistant"]).Assistant(lib, CallableProvider(lambda s, u: "Seen [E1].", "t", "local"))
    aw = G.AskWindow(app, home); aw.q.set("construction"); aw.find(); aw.ask(); aw.open_src()
    home._update_ask()
    # ---- other modes through the same screens
    for mode, setup in (("all_tables", None), ("table", lambda w: setattr(w.tbl_list, "_sel", (0, 1))),
                        ("records", lambda w: w.p["text"].set("UGC")), ("fields", lambda w: (setattr(w.flist, "_sel", (0,)), w.p["extra"].set("Cost"))),
                        ("text", None), ("custom", lambda w: setattr(w.req, "_text", "Extract the issues from the Issues & Concerns section including urgency and owner"))):
        w = G.WizardWindow(app, home); w.src.set("all"); w._src_changed(); w.next(); w.mode.set(mode)
        if mode == "text":
            lib.index()
        w.next(); wait(w)
        assert w.step == 2, mode
        if setup: setup(w)
        if mode in ("section", "records", "fields", "custom") and hasattr(w, "hlist") and mode != "custom":
            pass
        if mode == "custom":
            w._parse_req(); w.hlist._sel = ()
        w.next()
        assert w.step == 3, (mode, MSGS[-3:])
        assert w.s.preview or mode == "records", mode
    # ---- empty selection self-test and tab restore
    w = G.WizardWindow(app, home); assert w.selftest()
    errors = [m for m in MSGS if m[0] == "error"]
    assert not errors, errors
    print("gui stub check OK")


if __name__ == "__main__":
    main()
