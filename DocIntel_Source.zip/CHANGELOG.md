# Changelog

## 1.3.1-m3 (feedback from build 9: single worksheet + colour-cell tables)
- NEW export arrangement **"Everything in ONE worksheet"** (columns merged by name, blanks where a table lacks a column, "Section / table" and source columns on every row) - for filtering across all tables of a document.
- IMPROVED stacking: dates written inside column names ("Progress % / 07-Oct-2026") no longer stop daily reports of different days from stacking; they become "Progress % / (date 1)", "(date 2)" plus real-date columns ("... - date"). The wizard now suggests stacking for such reports.
- NEW option: Original layout can show the PDF's merged heading bands (e.g. "CATEGORY - 2 ...") as their own rows; normalized layout keeps them in the Group column.
- Engine, tables drawn with coloured cells instead of lines (real RACI PDF): fall-back "fill-edge grid" used when the line-based pass explains little of the page; heading bands inside a table no longer cut it into pieces (group labels instead); repeated page-header/footer boxes and their border lines are ignored; numbered table rows are no longer mistaken for headings; unbordered columns (REMARKS) keep their text; header block detection skips titles/logos above the header; tables continuing across pages under a heading band stay one table; rows whose vertical borders are missing are split into cells; adaptive word spacing for small print (missing space characters).
- Real RACI PDF: 134/134 rows in order over pages 2-6, 10 columns, 7 group headings, remarks kept. SCAL (1000/1000) and daily-report results unchanged.
- Tests: +6 (`SingleWorksheet`, `RaciStyleTable`); real PDF added to `tests/real_pdfs/`.

## 1.3.0-m3 (Milestone 3: guided interface)
- NEW Home tab (first): six large actions - Add Documents, Search Documents, Extract to Excel, Review Results, Export to Excel, Extraction History. The ten classic tabs are kept; they are hidden behind "Show advanced tools" (any old button that jumps to a classic tab reveals it automatically). If the new screens cannot be built, the classic tabs simply stay visible.
- NEW 5-step "Extract to Excel" wizard (`docintel/gui_guided.py`, logic in `docintel/wizard.py`): select documents (all / folders / individual PDFs / exclude), choose what to extract (all tables, specific table, specific section, matching records, selected fields, all readable text, free-text request), identify the target (headings found, similar-heading search that must be confirmed, fields not found are left blank and flagged, never substituted), spreadsheet-like preview with correction / mark uncertain / rename / hide / open source, export (xlsx stacked / per table / one file per document, CSV, raw or typed values, layouts, source columns). Background reading with cancel.
- NEW `tests/test_wizard.py` (15), `tools/gui_stub_check.py` + `tests/test_gui_stub.py` (drives every screen against a Tkinter stand-in), `export_tables_csv`.
- Test expectations updated: classic tabs 10 -> 11 (Home added); the Windows smoke test now also reports `home_ok` and `wizard_ok`.

## 1.2.0-m2 (Milestone 2: stored tables, value model, Excel options)
- Database schema v2 (additive, old libraries upgrade automatically): `doc_sections`, `doc_tables`, `table_rows`, `table_cells` (raw original-layout and normalized text, suggested kind, flags, user correction stored apart, reviewed mark). Tables are cached per file content + engine version; unchanged files are reused.
- NEW `docintel/tables/store.py` (save/load/list, `set_correction` / `clear_correction` / `mark_reviewed`, `rename_header` keeps the PDF wording, hide columns) and `service.py`; NEW `Library.extract_tables(file_ids, force, control, progress)`. Friendly messages for unsupported / missing / unreadable files (technical detail only in the log).
- NEW `docintel/tables/values.py`: suggests a kind (text, integer, decimal, percentage, date, datetime, currency, duration, boolean, identifier, unit_value, special, empty); never rejects or changes the raw text; ambiguous dates are not converted.
- Old field extraction: new types `percentage` ("65%" -> 0.65, original kept) and `auto` (never rejects).
- Excel export v2: raw-text (default) or typed values (typed adds a raw-text companion sheet), original/normalized layouts, per-table or combined sheets (tables with identical columns stacked, source columns identify them), leaf or joined header names, hidden columns, user corrections included with a "Corrected cells" column, rollover to extra sheets at the Excel row limit, fast write-only writer, valid Excel tables.
- Tests: `tests/test_tables_store.py` (17).

## 1.1.0-m1 (Milestone 1: new table & section engine)
- NEW package `docintel/tables/`: general stroke-grid table reader (row bands from horizontal strokes, columns from vertical strokes, merged cells = missing separator strokes), header detection (bold/fill/row-number evidence, multi-level headers, rotated header text), cross-page stitching with repeated-header removal, rows split by page breaks, horizontal merges, running page-header boxes ignored, borderless tables by text alignment, heading/section detection with side-by-side headings, fuzzy section matching (always shown for confirmation).
- NEW Excel export (`docintel/tables/export.py`): per table an "Original layout" sheet (blanks where the PDF merges cells) and a "Normalized" sheet (merged values repeated), raw text preserved (cells formatted as text), source/page/section/method/review columns, Summary sheet.
- NEW CLI: `python -m docintel tables FILE.pdf [--section "Construction Activities"] [--pages 5-41] [--out result.xlsx]`.
- NEW tests `tests/test_tables_engine.py` (19) and `tools/table_accuracy.py`; real PDFs under `tests/real_pdfs/`.
- Not yet wired into the GUI/library/database (Milestones 2-4). Scanned-page table reconstruction (OCR geometry) is not part of Milestone 1.

## 1.0.1 (fixes after the first real Windows build)
- FIXED self-check reported failure when optional LibreOffice is absent (broke GUI smoke test and "doctor" on Windows).
- FIXED export row order depended on file scan order (records now ordered by source path, then position).
- FIXED packaged app could not read DXF: numpy was excluded from the build but ezdxf requires it (numpy now bundled and pinned).
- ADDED `prototypes/scal_spike2.py`: proof of method for complete extraction of the 41-page SCAL table (1,000/1,000 rows) - not yet part of the app.

## 1.0.0 (Windows release candidate) - changes since the first delivery
**Windows readiness**
- NEW `paths.py`: installed vs portable data folders, resource folders, safe long-path handling. Portable marker file `portable.txt`.
- FIXED scanner would have stored `\\?\`-prefixed paths and failed relative-path calculations on Windows long paths.
- FIXED Tesseract language path now passed via `TESSDATA_PREFIX` (quoted CLI option broke on spaces/backslashes); bundled Tesseract chosen per OS.
- NEW case-insensitive duplicate-root detection on Windows; no console windows for helper processes; DPI awareness; windowed-build stdout handling; UTF-8 CLI output.
- FIXED build spec (`docintel.spec`) had a comment swallowing the closing parenthesis - the earlier delivery's build script could not have worked.
- NEW app icon, GUI+CLI executables, Inno Setup installer (Start Menu, optional desktop icon, uninstall with optional data removal), portable zip.
- NEW GitHub Actions Windows pipeline (tests, build, portable/offline/installer checks, release), pinned Tesseract + language files by SHA-256, `constraints.txt`.
- NEW `tools/smoke_packaged.py` end-to-end test of packaged builds; `DocIntel.exe gui --smoke-test`.

**For non-technical users**
- NEW "Start here" page, first-run welcome and environment check, Help menu, plain-English error messages with next steps (`friendly.py`),
  drag-and-drop folders, "Describe fields I want" helper, indexing-complete prompt, 11-page User Guide PDF, click-by-click build guide.

**OCR**
- CORRECTED earlier finding: Arabic OCR was *not* poor; the earlier test image was generated incorrectly. With correctly shaped text, English+Arabic read at ~100 % on clean, skewed, low-resolution, blurred, JPEG-damaged and speckled images.
- NEW small-angle deskew (Pillow only), automatic denoise retry for low-confidence pages, removal of invisible bidi marks from OCR output.

**Excel**
- NEW templates containing charts, pictures/shapes, pivot tables, slicers or form controls are blocked from being rewritten unless the user chooses a safer results-only workbook or explicitly accepts losing those items (original is never changed).
- FIXED update-by-key matching when the key column holds real dates/numbers.

**Tests**: 43 automated tests (was 34) + 4 platform-specific skips.
