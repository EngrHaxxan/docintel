"""DocIntel - offline document indexing, search, extraction and Excel export."""
__version__ = "1.1.0-m1"
