"""Rule-based structured extraction driven by reusable profiles, with full provenance and a review queue.

Deterministic by design: no AI model is required. Every value keeps raw text, normalised value, location,
method, a heuristic confidence indicator (NOT a probability of correctness), issues and review status.
"""
import fnmatch, json, re, time

from . import cleaning
from .db import jdump

PROFILE_DEFAULT = {
    "name": "", "description": "", "mode": "document",       # document | table
    "root_ids": [], "path_prefix": "", "exts": [], "name_glob": "",
    "fields": [], "table_rules": {"min_header_matches": 2},
    "key_fields": [], "duplicate_policy": "flag", "min_fields_matched": 1,             # flag | skip
    "excel": {"mapping": {}},
}
FIELD_DEFAULT = {"name": "", "type": "text", "labels": [], "regex": None, "required": False,
                 "min": None, "max": None, "pattern": None, "choices": None, "multi": False,
                 "always_review": False}


def save_profile(db, profile):
    p = {**PROFILE_DEFAULT, **profile}
    if not p["name"]:
        raise ValueError("profile needs a name")
    p["fields"] = [{**FIELD_DEFAULT, **f} for f in p["fields"]]
    for f in p["fields"]:
        if f["regex"]:
            re.compile(f["regex"])
    db.x("INSERT INTO profiles(name,json,updated) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET json=excluded.json, updated=excluded.updated",
         (p["name"], jdump(p), time.time()))
    return p


def load_profile(db, name):
    r = db.one("SELECT json FROM profiles WHERE name=?", (name,))
    if not r:
        raise KeyError(f"no such profile: {name}")
    return json.loads(r[0])


def list_profiles(db):
    return [r["name"] for r in db.q("SELECT name FROM profiles ORDER BY name")]


def _norm_label(s):
    return re.sub(r"[^\w]+", " ", (s or "").lower()).strip()


# ---------------------------------------------------------------- candidate finders
def _label_candidates(text, labels):
    out = []
    for lab in labels:
        l = re.escape(lab).replace(r"\ ", r"\s+")
        # "Label: value" on one line (value ends at end of line, a pipe, or a 3+ space gap)
        for m in re.finditer(rf"(?im)(?:^|[\s|]){l}\s*[:：=\-–]\s*(.+?)\s*(?=$|\||\s{{3,}})", text):
            v = m.group(1).strip()
            if v: out.append((v, m.start(1), m.end(1)))
        # "Label | value" (table-like text)
        for m in re.finditer(rf"(?im)^\s*{l}\s*\|\s*([^|\n]+)", text):
            v = m.group(1).strip()
            if v: out.append((v, m.start(1), m.end(1)))
        # label alone on a line, value on the next line
        for m in re.finditer(rf"(?im)^\s*{l}\s*[:：]?\s*\n\s*(.+?)\s*$", text):
            v = m.group(1).strip()
            if v: out.append((v, m.start(1), m.end(1)))
    return out


def _regex_candidates(text, rx):
    out = []
    for m in re.finditer(rx, text, re.I | re.M):
        g = m.group(1) if m.groups() else m.group(0)
        s = m.start(1) if m.groups() else m.start(0)
        out.append((g.strip(), s, s + len(g)))
    return out


def locate_bbox(words, value):
    """Find the word sequence matching `value` in OCR/PDF word boxes; returns [x0,y0,x1,y1] or None."""
    if not words or not value:
        return None
    toks = value.split()
    if not toks:
        return None
    n = len(toks)
    for i in range(len(words) - n + 1):
        if all(words[i + j][0] == toks[j] for j in range(n)):
            seq = words[i:i + n]
            return [min(w[1] for w in seq), min(w[2] for w in seq), max(w[3] for w in seq), max(w[4] for w in seq)]
    return None


# ---------------------------------------------------------------- running
def _file_selected(f, p):
    if p["name_glob"] and not fnmatch.fnmatch(f["name"].lower(), p["name_glob"].lower()):
        return False
    return True


def run_profile(lib, profile, file_ids=None, progress=None):
    """Runs the profile on indexed files. Returns run_id. Results are persisted in `vals` for review/export."""
    db, cfg = lib.db, lib.cfg
    p = {**PROFILE_DEFAULT, **profile}
    fields = [{**FIELD_DEFAULT, **f} for f in p["fields"]]
    if not fields:
        raise ValueError("profile has no fields")
    run_id = db.x("INSERT INTO runs(profile,started,params) VALUES(?,?,?)", (p["name"], time.time(), jdump(p))).lastrowid

    q = ("SELECT f.* FROM files f JOIN roots r ON r.id=f.root_id WHERE f.status='indexed' AND r.enabled=1")
    args = []
    if p["root_ids"]:
        q += f" AND f.root_id IN ({','.join('?' * len(p['root_ids']))})"; args += p["root_ids"]
    if p["exts"]:
        q += f" AND f.ext IN ({','.join('?' * len(p['exts']))})"; args += [e.lower().lstrip('.') for e in p["exts"]]
    if p["path_prefix"]:
        q += " AND f.abspath LIKE ?"; args.append(p["path_prefix"] + "%")
    if file_ids:
        q += f" AND f.id IN ({','.join('?' * len(file_ids))})"; args += list(file_ids)
    files = [f for f in db.q(q + " ORDER BY f.abspath", args) if _file_selected(f, p)]
    thr = cfg["review_confidence_threshold"]
    nrec = 0
    for i, f in enumerate(files):
        recs = (_extract_tables(db, f, fields, p, cfg) if p["mode"] == "table" else _extract_document(db, f, fields, cfg, p["min_fields_matched"]))
        for ri, rec in enumerate(recs):
            key = f"{f['id']}:{ri}"
            for fld in fields:
                v = rec.get(fld["name"]) or {"raw": None, "norm": None, "loc": None, "bbox": None, "method": None, "conf": 0.0, "issues": []}
                issues = list(v["issues"]) + cleaning.validate(fld, v["norm"], v["raw"])
                missing = v["norm"] in (None, "")
                status = "ok"
                if fld["always_review"] and not missing:
                    issues.append("critical value (dimension/identifier): verify against the source region")
                if issues or (v["conf"] < thr and not missing) or (missing and fld["required"]):
                    status = "review"
                db.conn.execute(
                    "INSERT INTO vals(run_id,record_key,file_id,abspath,sha256,field,raw,normalized,loc,bbox,method,confidence,issues,status) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (run_id, key, f["id"], f["abspath"], f["sha256"], fld["name"], v["raw"],
                     None if v["norm"] is None else str(v["norm"]), v["loc"], jdump(v["bbox"]) if v["bbox"] else None,
                     v["method"], round(v["conf"], 3), jdump(issues) if issues else None, status))
            nrec += 1
        db.conn.commit()
        if progress: progress(i + 1, len(files))
    _flag_duplicates(db, run_id, p)
    return run_id


def _mk_value(raw, fld, loc, method, base_conf, seg_conf, bbox, cfg, extra_issues=()):
    norm, iss = cleaning.normalise(raw, fld["type"], cfg["day_first"], ocr_fix=(method == "ocr" and fld["type"] in ("number", "integer", "currency")))
    conf = base_conf * (seg_conf if seg_conf is not None else 1.0)
    iss = list(iss) + list(extra_issues)
    if iss:
        conf *= 0.8
    return {"raw": raw, "norm": norm, "loc": loc, "bbox": bbox, "method": method, "conf": conf, "issues": iss}


def _extract_document(db, f, fields, cfg, min_match=1):
    segs = db.q("SELECT * FROM segments WHERE file_id=? ORDER BY id", (f["id"],))
    rec = {}
    for fld in fields:
        cands = []
        for s in segs:
            texts = []
            if fld["labels"]:
                texts += [(v, a, b, 0.92) for v, a, b in _label_candidates(s["text"], fld["labels"])]
            if fld["regex"]:
                texts += [(v, a, b, 0.88) for v, a, b in _regex_candidates(s["text"], fld["regex"])]
            for v, a, b, base in texts:
                words = json.loads(s["words_json"]) if s["words_json"] else None
                bbox = locate_bbox(words, v)
                cands.append(_mk_value(v, fld, s["loc"], s["method"], base, s["confidence"], bbox, cfg) | {"page_w": s["page_w"], "page_h": s["page_h"]})
        if not cands:
            continue
        distinct = []
        for c in cands:
            if str(c["norm"]) not in [str(d["norm"]) for d in distinct]:
                distinct.append(c)
        best = distinct[0]
        if fld["multi"]:
            best = dict(best); best["raw"] = "; ".join(d["raw"] for d in distinct)
            best["norm"] = "; ".join(str(d["norm"]) for d in distinct if d["norm"] is not None)
        elif len(distinct) > 1:
            best["issues"] = best["issues"] + [f"conflict: {len(distinct)} different values found: " +
                                                " | ".join(f"{d['raw']} ({d['loc']})" for d in distinct[:5])]
            best["conf"] *= 0.7
        rec[fld["name"]] = best
    return [rec] if len(rec) >= max(1, min_match) else []


def _extract_tables(db, f, fields, p, cfg):
    """One record per table row. Handles repeated headers and tables continuing on following pages."""
    out = []
    minmatch = p["table_rules"].get("min_header_matches", 2)
    label_map = {fld["name"]: {_norm_label(l) for l in ([fld["name"]] + fld["labels"])} for fld in fields}
    last_cols = None
    tables = db.q("SELECT * FROM tables_ WHERE file_id=? ORDER BY id", (f["id"],))
    for t in tables:
        rows = json.loads(t["corrected_json"] or t["rows_json"])
        if not rows:
            continue
        hdr_i, colmap = None, {}
        for i, r in enumerate(rows[:4]):
            cm = {}
            for ci, cell in enumerate(r):
                for name, labs in label_map.items():
                    if _norm_label(cell) in labs and name not in cm.values():
                        cm[ci] = name
            if len(cm) >= min(minmatch, len(fields)):
                hdr_i, colmap = i, cm; break
        if hdr_i is None:
            if last_cols and rows and max(len(r) for r in rows) == last_cols[0]:
                colmap, hdr_i = last_cols[1], -1          # continuation of previous table (same column count)
            else:
                continue
        else:
            last_cols = (max(len(r) for r in rows), colmap)
        hdr_cells = [_norm_label(c) for c in rows[hdr_i]] if hdr_i >= 0 else None
        for ri in range(hdr_i + 1, len(rows)):
            r = rows[ri]
            if not any((c or "").strip() for c in r):
                continue
            if hdr_cells and [_norm_label(c) for c in r] == hdr_cells:
                continue                                    # repeated header row
            rec = {}
            for ci, name in colmap.items():
                if ci < len(r):
                    fld = next(x for x in fields if x["name"] == name)
                    raw = (r[ci] or "").strip()
                    if raw:
                        v = _mk_value(raw, fld, f"{t['loc']} row {ri + 1}", t["method"], 0.95, t["confidence"], None, cfg)
                        rec[name] = v
            if rec:
                out.append(rec)
    return out


def _flag_duplicates(db, run_id, p):
    keys = p.get("key_fields") or []
    if not keys:
        return
    rows = db.q("SELECT record_key, field, COALESCE(NULLIF(correction,''),normalized) v FROM vals WHERE run_id=? AND field IN (%s)" %
                ",".join("?" * len(keys)), [run_id] + keys)
    recs = {}
    for r in rows:
        recs.setdefault(r["record_key"], {})[r["field"]] = r["v"]
    seen = {}
    for rk, d in recs.items():
        k = tuple(d.get(x) for x in keys)
        if all(v in (None, "") for v in k):
            continue
        seen.setdefault(k, []).append(rk)
    for k, rks in seen.items():
        if len(rks) > 1:
            for rk in rks:
                db.conn.execute("UPDATE vals SET status=CASE WHEN status='ok' THEN 'review' ELSE status END, "
                                "issues=json_insert(COALESCE(issues,'[]'),'$[#]',?) WHERE run_id=? AND record_key=?",
                                (f"duplicate key {k} appears in {len(rks)} records", run_id, rk))
    db.conn.commit()


# ---------------------------------------------------------------- review workflow
def review_queue(db, run_id, statuses=("review", "unresolved")):
    return db.q(f"SELECT * FROM vals WHERE run_id=? AND status IN ({','.join('?' * len(statuses))}) ORDER BY record_key, id",
                [run_id] + list(statuses))


def set_value(db, val_id, correction=None, status=None, note=None):
    """User actions: correct (-> approved), approve as-is, reject, mark unresolved. Original raw value is never overwritten."""
    if correction is not None:
        db.x("UPDATE vals SET correction=?, status='approved' WHERE id=?", (correction, val_id))
    if status:
        if status not in ("ok", "review", "approved", "rejected", "unresolved"):
            raise ValueError("bad status")
        db.x("UPDATE vals SET status=? WHERE id=?", (status, val_id))
    if note is not None:
        db.x("UPDATE vals SET note=? WHERE id=?", (note, val_id))


def approve_all_ok(db, run_id):
    return db.x("UPDATE vals SET status='approved' WHERE run_id=? AND status='ok'", (run_id,)).rowcount


def records_for_export(db, run_id, allow_unreviewed=False):
    """-> (records[], held_back[]). A record with any value still 'review'/'unresolved' is held back unless allowed."""
    # Preserve extraction/insertion order. Sorting by record_key can reorder
    # records alphabetically and make template exports disagree with profile order.
    rows = db.q("SELECT * FROM vals WHERE run_id=? ORDER BY id", (run_id,))
    params = json.loads(db.one("SELECT params FROM runs WHERE id=?", (run_id,))[0] or "{}")
    types = {f["name"]: f.get("type", "text") for f in params.get("fields", [])}
    recs, order = {}, []
    for r in rows:
        if r["record_key"] not in recs:
            recs[r["record_key"]] = {"key": r["record_key"], "values": {}, "src": {}, "status": set(), "ids": [], "types": types}
            order.append(r["record_key"])
        d = recs[r["record_key"]]
        final = r["correction"] if r["correction"] not in (None, "") else r["normalized"]
        d["values"][r["field"]] = final
        d["src"][r["field"]] = {"path": r["abspath"], "loc": r["loc"], "method": r["method"], "raw": r["raw"], "val_id": r["id"],
                                "confidence": r["confidence"]}
        d["status"].add(r["status"]); d["ids"].append(r["id"])
    ok, held = [], []
    for k in order:
        d = recs[k]
        if "rejected" in d["status"]:
            continue
        if d["status"] & {"review", "unresolved"} and not allow_unreviewed:
            held.append(d)
        else:
            ok.append(d)
    return ok, held
