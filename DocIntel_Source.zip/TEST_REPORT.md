# Test report - DocIntel 1.0.0 (Windows release candidate)

**Read this first: nothing in this report was run on Windows.** The Windows installer and portable package do not exist yet. Everything below ran on a Linux sandbox
(Python 3.12, 1 CPU, 4 GB RAM). Linux results show the *program logic and packaging approach* work; they do **not** prove Windows compatibility. The Windows pipeline
(`WINDOWS_BUILD_GUIDE.md`) is written to produce that proof automatically; its verdict will appear in `BUILD_RESULT.txt`.

## 1. Required scenarios (A-F): status
| Scenario | Windows status | Linux evidence this round |
|---|---|---|
| A Fresh install, no Python needed, OCR found, launch | **PENDING (CI step "Install / run / uninstall check")** | frozen app (PyInstaller, no Python on PATH needed) ran self-check and GUI start: 16/16 |
| B Multi-folder index, search identifier, restart persistence | PENDING (CI smoke) | 3 roots, nested folders, OCR identifier found with path, Arabic search, index persisted: pass |
| C Extract, review, export new + template, formulas/formatting/provenance | PENDING (CI smoke) | pass (formulas kept and extended, formats kept, Provenance sheet) |
| D Offline | PENDING (CI step with Windows Firewall rules) | whole smoke run inside an empty network namespace: 17/17 |
| E Portable in another folder, data stays beside app | PENDING (CI portable step) | unzipped into `/tmp/Portable Test Dir/DocIntel` (spaces): 17/17, data in `DocIntel_Data` |
| F Interrupt/resume, inaccessible dir, disconnected drive | PENDING (CI; ACL test is Windows-only) | killed mid-batch then resumed (1,500 files all indexed); unplugged-drive: flagged, data stays searchable |

## 2. What was actually run (Linux)
* **Automated suite: 43 passed, 4 skipped, 0 failed** (`pytest tests`). Skipped: unreadable-directory test (needs non-root) and 3 Windows-only tests
  (long paths, case-insensitive roots, locked files) - these run on the Windows build server. New this round: spaces/Unicode in folder, file, data and OCR-data paths;
  portable data-folder rules; Excel template safety (charts block the write, original untouched); plain-English errors; field-name helper; GUI first-run/smoke.
* **Packaged-app smoke harness** (`tools/smoke_packaged.py`) against the PyInstaller build: installed-style 16/16, portable 17/17, portable + no network 17/17.
* **Release script** (`tools/make_release.py`) executed on Linux with the real Windows Tesseract layout (unpacked from the pinned official installer): app, portable zip,
  offline-resources zip and checksums produced; the Windows-only steps (running `tesseract.exe`, Inno Setup) were skipped.
* GUI driven headlessly (Xvfb): start page, first-run welcome, drag-and-drop library loads (an actual drop was not exercised).

## 3. Arabic / English OCR (corrected result)
My first report said Arabic OCR was poor. That was caused by a wrongly generated test image. Re-tested with correctly shaped Arabic + English text through the application's own OCR
pipeline (5 lines, mean similarity to the known text):
| Condition | clean | 3-degree skew | 0.4x resolution | blur | heavy speckle noise | JPEG quality 18 | combined (skew+downscale+blur+JPEG) |
|---|---|---|---|---|---|---|---|
| Score | 1.00 | 1.00 | 1.00 | 1.00 | 0.29 -> **0.9+ after the new denoise retry** (one word wrong) | 1.00 | 1.00 |
Caveats: synthetic text in one font; real scans, stamps, handwriting and other Arabic fonts are untested. Numbers inside Arabic lines can come out in reversed digit-group order (e.g. 2026-03-14 read as 14-03-2026); the review queue flags ambiguous dates.
`tessdata_best` was no better than `tessdata_fast` on this test, so the smaller fast files are shipped.

## 4. Other measurements carried forward (Linux, earlier build; not repeated on Windows)
40-row page-spanning invoice table 200/200 cells exact; OCR identifier 4/4; 5,540 files indexed in 31 s on 1 CPU, peak 338 MB; exact search 17 ms.

## 5. Status of the limitations you listed
| Item | Status |
|---|---|
| Windows exe/installer built and verified | **Not yet.** Pipeline ready; awaits the first Windows run. |
| Arabic OCR weak | Corrected (see 3); real-world scans still untested. Denoise retry + deskew added. |
| Semantic search | **Not implemented** (needs an embedding model; would add ~100 MB+ and risk; left out rather than faked). |
| Natural-language extraction | **Not implemented.** A deterministic helper turns typed field names into fields ("Describe fields I want"); it does not understand sentences. |
| Native DWG | **Not implemented** (proprietary format; export to DXF/PDF). DXF and PDF drawings work. |
| Drag-and-drop folders | Implemented (tkinterdnd2); loads under test; a real drop is untested; falls back to the Add button. |
| Real engineering drawings | **Not tested** (only synthetic DXF/PDF title blocks). |
| Scale beyond 5,540 files | **Not tested.** |
| Filesystem monitoring | Implemented, **still no automated test**. |
| Legacy/OpenDocument formats | ODT/ODS checked by hand once (worked; ODS adds one empty column); ODP, RTF, legacy DOC/PPT/XLS untested. |
| Excel writer loses charts/images/pivots | **Mitigated**: such templates are now refused unless the user picks a results-only workbook or explicitly accepts the loss; original is never changed. Macros (.xlsm) are kept but never executed; not tested with real macro workbooks. |

## 6. Remaining verification steps (cannot be done by me)
1. Run the Windows build (click steps in the guide) and read `BUILD_RESULT.txt`.
2. On a *different, clean* Windows 11 PC (not the build server): install, run the guide's first-run steps, and try a few of your real documents (especially Arabic scans and your Excel templates).
3. Report anything odd with a screenshot; the log is at Settings & Diagnostics > Show log.


---
# Milestone 1 addendum - table & section engine (v1.1.0-m1)
**Run on Linux only (Python 3.12/3.x, 1 CPU). Not run on Windows yet - pending GitHub Actions.**
- `python -m unittest tests.test_tables_engine`: 19 tests, all pass (real daily report: Construction 4 rows / Issues 3 rows exact; real SCAL: 1,000/1,000 sequential rows over pages 5-40, headers, reference rows 1/15/202/999, rows split by page breaks (11, 179), merged-cell original vs normalized, row 1000 horizontal merge, source quirks incl. invisible Arabic mark, running header excluded; synthetic: special values/percent/codes/Unicode+Arabic text, multi-page repeated header, merged cells, two tables on a page, borderless; Excel export text-exact).
- `python tools/table_accuracy.py`: 102 hand-verified cells correct, 0 wrong, 0 missing, 0 extra rows.
- Existing suite (`tests/test_docintel.py`, `tests/test_release_readiness.py`) was NOT run in this sandbox (pytest could not be installed offline). The old modules were not modified except `cli.py` (new `tables` command) and `__init__.py` (version), so CI must confirm.
- Measured time (Linux, 1 CPU): SCAL 41 pages = ~16 s total analysis (all tables); daily report 2 pages = 0.3 s.


---
# Milestone 2 addendum - stored tables, value model, Excel options (v1.2.0-m2)
**Run on Linux only; Windows pending.**
- `python -m unittest tests.test_tables_store` = 17 tests pass (values, database round-trip equals engine output, reuse of unchanged files / forced re-extraction, unsupported + missing file messages, corrections keep the original, header rename + hidden columns, cascade delete, schema upgrade v1->v2, typed/raw Excel, combined sheets, row-limit rollover, leaf headers, old normaliser `percentage`/`auto`).
- `tests.test_tables_engine` (Milestone 1) still 19/19 pass.
- Measured (SCAL table 1,000 rows x 13 cols, Linux 1 CPU): save to database 0.10 s, load 0.06 s, Excel export (Original+Normalized sheets) 0.39 s raw / 0.96 s typed, peak process memory ~102 MB. Output opens in LibreOffice (Excel itself not available here).
- Smoke test: scan + index + `extract_tables` on a library folder works with the old indexing code.
